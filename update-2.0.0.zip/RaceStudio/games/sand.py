"""Sand Fill: every racer pours coloured sand from a moving spout into the same jar.
When the jar is full, whoever has the most sand inside wins. Pixel-sand physics."""
import math
import random

import numpy as np

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner

THEMES = {
    "desert": {"bg1": "#0d0804", "bg2": "#33210c", "wall": "#f2e4c4", "jar": "#1a120a"},
    "night": {"bg1": "#03040a", "bg2": "#141a33", "wall": "#cfd8ff", "jar": "#0a0d1a"},
    "mint": {"bg1": "#020c0a", "bg2": "#0b2e26", "wall": "#cffff0", "jar": "#06140f"},
    "rose": {"bg1": "#0e0408", "bg2": "#381022", "wall": "#ffd6e6", "jar": "#1a0810"},
}
RANDOM_THEMES = list(THEMES)
GW, GH, CELL = 180, 250, 5
X0, Y0 = (W - GW * CELL) // 2, 360
WALL = -1


def build_jar(seed):
    rng = random.Random(seed * 3 + 1)
    g = np.zeros((GW, GH), np.int16)
    # outer walls (x 0..2, GW-3.., bottom), rounded bottom corners
    g[:3, 30:] = WALL
    g[GW - 3:, 30:] = WALL
    g[:, GH - 3:] = WALL
    for k in range(18):
        r = 18 - k
        g[3:3 + r, GH - 3 - k - 1] = WALL if k < 18 else 0
        g[GW - 3 - r:GW - 3, GH - 3 - k - 1] = WALL
    # obstacles: ledges and round bumps
    for _ in range(rng.randint(3, 5)):
        kind = rng.choice(["ledge", "bump"])
        cx, cy = rng.randint(30, GW - 30), rng.randint(80, GH - 70)
        if kind == "ledge":
            L = rng.randint(14, 30)
            s = rng.choice([-1, 1])
            for i in range(L):
                x, y = cx + i - L // 2, cy + s * (i // 3)
                g[x:x + 1, y:y + 2] = WALL
        else:
            r = rng.randint(4, 8)
            for x in range(cx - r, cx + r + 1):
                for y in range(cy - r, cy + r + 1):
                    if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                        g[x, y] = WALL
    return g


class Sim:
    def __init__(self, n, seed, rate, sound=None, looks=None):
        self.rng = random.Random(seed)
        self.nrng = np.random.default_rng(seed)
        self.n, self.rate, self.sound = n, rate, sound
        self.g = build_jar(seed)
        self.shade = np.zeros((GW, GH), np.uint8)
        self.capacity = int((self.g[3:GW - 3, 30:GH - 3] == 0).sum())
        self.fill_line = 34
        self.spouts = [{"x": (i + 0.5) / n * GW, "ph": self.rng.uniform(0, 6.28), "amp": self.rng.uniform(14, 34),
                        "spd": self.rng.uniform(0.4, 0.9), "r": 1.0} for i in range(n)]
        self.clock = 0.0
        self.done = False
        self.it = 0
        self.counts = [0] * n

    def _cells(self):
        return self.g

    def pour(self, dt):
        for i, s in enumerate(self.spouts):
            s["r"] = max(0.2, min(2.3, s["r"] + self.rng.uniform(-1, 1) * dt * 2.6))
            x = s["x"] + math.sin(self.clock * s["spd"] + s["ph"]) * s["amp"]
            x = max(6, min(GW - 7, x))
            s["cx"] = x
            k = self.rate * s["r"] * dt
            cnt = int(k) + (1 if self.rng.random() < k - int(k) else 0)
            for _ in range(cnt):
                xx = int(x + self.rng.uniform(-1.6, 1.6))
                yy = self.rng.randint(1, 4)
                if self.g[xx, yy] == 0:
                    self.g[xx, yy] = i + 1
                    self.shade[xx, yy] = self.rng.randint(0, 3)

    def physics(self):
        g, sh = self.g, self.shade
        # 1) straight down
        a, b = g[:, :-1], g[:, 1:]
        m = (a > 0) & (b == 0)
        b[m] = a[m]
        a[m] = 0
        sa, sb = sh[:, :-1], sh[:, 1:]
        sb[m] = sa[m]
        # 2) diagonal: alternate direction each iteration so piles stay symmetric
        self.it += 1
        if self.it % 2:
            src, side, dst = g[1:, :-1], g[:-1, :-1], g[:-1, 1:]
            ssrc, sdst = sh[1:, :-1], sh[:-1, 1:]
            below = g[1:, 1:]
        else:
            src, side, dst = g[:-1, :-1], g[1:, :-1], g[1:, 1:]
            ssrc, sdst = sh[:-1, :-1], sh[1:, 1:]
            below = g[:-1, 1:]
        m = (src > 0) & (below != 0) & (dst == 0) & (side == 0)
        m &= self.nrng.random(m.shape) < 0.8
        dst[m] = src[m]
        src[m] = 0
        sdst[m] = ssrc[m]

    def step(self, dt, iters=3):
        self.clock += dt
        if not self.done:
            self.pour(dt)
        for _ in range(iters):
            self.physics()
        # full when sand reaches the fill line
        if not self.done and (self.g[3:GW - 3, self.fill_line] > 0).mean() > 0.5:
            self.done = True
        if int(self.clock * 10) != int((self.clock - dt) * 10):
            for i in range(self.n):
                self.counts[i] = int((self.g == i + 1).sum())


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    S0 = Sim(n, cfg["seed"], 1)
    target = (t_min + t_max) / 2
    rate = S0.capacity * 0.66 / (n * target)
    print(f"  capacity {S0.capacity}, rate {rate:.0f} grains/s per spout, ~{target:.0f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["desert"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, target + 6, th)
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    S = Sim(n, cfg["seed"], rate, sound=sound, looks=looks)
    title = _wrap(cfg.get("title") or "WHO FILLS THE JAR MOST?", 22)
    handle = cfg.get("handle", "")
    # colour table: index 0 empty, 1.. teams (4 shades each), wall
    pal = np.zeros((n + 1, 4, 3), np.uint8)
    for i, lk in enumerate(looks):
        c = np.array(lk.color, float)
        for s in range(4):
            pal[i + 1, s] = np.clip(c * (0.82 + 0.08 * s), 0, 255)
    jar = np.array(T["jar"], np.uint8)
    wall = np.array(T["wall"], np.uint8)
    surf = pygame.Surface((GW, GH))
    big = pygame.Surface((GW * CELL, GH * CELL))
    sound.add(0.0, "go")
    win_time = None
    winner = None
    settle = None
    tick_acc = 0.0
    disp = [0.0] * n
    while True:
        t = run.t
        S.step(run.dt)
        if win_time is None:
            lead = max(range(n), key=lambda i: S.counts[i])
            if S.counts[lead] > 0:
                run.comm.lead(t, looks[lead].name, hold=1.0)
            tick_acc += run.dt
            if not S.done and tick_acc > 0.11:
                tick_acc = 0.0
                i = int(t * 9) % n
                sound.add(t, "bounce", who=i, pan=0.15 + 0.7 * S.spouts[i].get("cx", GW / 2) / GW, gain=0.35)
            if S.done and settle is None:
                settle = t
                sound.add(t, "whoosh")
                run.comm.say(t, "final", force=True)
            if settle is not None and t - settle > 1.3:
                for i in range(n):
                    S.counts[i] = int((S.g == i + 1).sum())
                winner = max(range(n), key=lambda i: (S.counts[i], -i))
                win_time = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        g = S.g
        img = np.empty((GW, GH, 3), np.uint8)
        img[:] = jar
        team = np.clip(g, 0, None)
        sandm = team > 0
        img[sandm] = pal[team[sandm], S.shade[sandm]]
        img[g == WALL] = wall
        pygame.surfarray.blit_array(surf, img)
        pygame.transform.scale(surf, (GW * CELL, GH * CELL), big)
        big.set_colorkey(None)
        cv.blit(big, (X0, Y0))
        # spouts
        for i, s in enumerate(S.spouts):
            x = X0 + s.get("cx", s["x"]) * CELL
            V.blit_center(cv, looks[i].badge(54), x, Y0 - 38)
            if not S.done:
                pygame.draw.line(cv, looks[i].color, (x, Y0 - 10), (x, Y0 + 8), 6)
        fy = Y0 + S.fill_line * CELL
        for xx in range(X0 + 15, X0 + GW * CELL - 15, 28):
            pygame.draw.line(cv, (255, 255, 255), (xx, fy), (xx + 14, fy), 3)
        fx.draw(cv)
        _draw_title(cv, title, t)
        tot = max(1, sum(S.counts))
        bx, bw = 90, 900
        acc = bx
        for i in range(n):
            disp[i] += (S.counts[i] / tot - disp[i]) * min(1, run.dt * 6)
            w = bw * disp[i]
            if w > 1:
                pygame.draw.rect(cv, looks[i].color, pygame.Rect(acc, 1650, w + 1, 34))
            acc += w
        pygame.draw.rect(cv, (255, 255, 255), pygame.Rect(bx - 3, 1647, bw + 6, 40), 3, border_radius=6)
        slot = min(150, 1000 // n)
        x0 = W / 2 - slot * (n - 1) / 2
        for pos, i in enumerate(sorted(range(n), key=lambda i: -S.counts[i])):
            V.blit_center(cv, looks[i].badge(int(slot * 0.42)), x0 + pos * slot, 1745)
            V.blit_center(cv, V.text(f"{100 * S.counts[i] / tot:.0f}%", 28, (255, 255, 255), (0, 0, 0)), x0 + pos * slot, 1800)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1880)
        if win_time is not None:
            class _W:
                look = looks[winner]
            _draw_winner(cv, _W, t - win_time + 0.8, T, line3=f"{100 * S.counts[winner] / tot:.0f}% of the jar")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > max(t_max * 3, 120):
            raise RuntimeError("Sand ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": looks[winner].name, "level": cfg["seed"]}
