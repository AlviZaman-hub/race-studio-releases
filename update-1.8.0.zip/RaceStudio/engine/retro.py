"""Retro screen modes: every finished frame is shrunk to a low resolution, snapped to a
limited palette (with ordered dithering on the handheld mode) and blown back up with
hard pixel edges. Works for every game because it runs on the final frame."""
import numpy as np

from .video import pygame

W, H = 1080, 1920
# 4 x 4 Bayer matrix, values -0.5 .. 0.5
BAYER = (np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16.0) - 0.47

# NES-style palette subset (original selection of the classic hardware's colour set look)
NESLIKE = [
    (0, 0, 0), (124, 124, 124), (188, 188, 188), (248, 248, 248), (252, 252, 252),
    (0, 0, 252), (0, 88, 248), (60, 188, 252), (164, 228, 252),
    (104, 68, 252), (152, 120, 248), (216, 0, 204), (248, 120, 248),
    (168, 0, 32), (228, 0, 88), (248, 56, 0), (248, 88, 152), (248, 120, 88), (252, 160, 68),
    (136, 20, 0), (172, 124, 0), (248, 184, 0), (248, 216, 120),
    (0, 120, 0), (0, 168, 0), (88, 216, 84), (184, 248, 24), (0, 168, 68), (0, 136, 136), (0, 232, 216),
    (80, 48, 0), (120, 120, 0),
]

MODES = {
    "gameboy": {"w": 180, "h": 320, "scale": 6, "name": "Game Boy",
                "pal": [(15, 56, 15), (48, 98, 48), (139, 172, 15), (155, 188, 15)], "dither": 0.6, "grid": True},
    "8bit": {"w": 216, "h": 384, "scale": 5, "name": "8-bit", "pal": NESLIKE, "dither": 0.35, "grid": False},
    "16bit": {"w": 270, "h": 480, "scale": 4, "name": "16-bit", "pal": None, "levels": 12, "dither": 0.25, "grid": False},
}


class Retro:
    def __init__(self, mode):
        self.m = MODES[mode]
        w, h = self.m["w"], self.m["h"]
        self.small = pygame.Surface((w, h))
        self.big = pygame.Surface((W, H))
        self.dith = np.tile(BAYER, (w // 4 + 1, h // 4 + 1))[:w, :h][..., None] * self.m["dither"]
        if self.m["pal"] is not None:
            self.pal = np.array(self.m["pal"], np.float32)
        self.grid = None
        if self.m.get("grid"):
            s = self.m["scale"]
            g = pygame.Surface((W, H), pygame.SRCALPHA)
            for x in range(0, W, s):
                pygame.draw.line(g, (0, 0, 0, 34), (x, 0), (x, H))
            for y in range(0, H, s):
                pygame.draw.line(g, (0, 0, 0, 34), (0, y), (W, y))
            self.grid = g

    def apply(self, frame):
        m = self.m
        pygame.transform.smoothscale(frame, (m["w"], m["h"]), self.small)
        a = pygame.surfarray.array3d(self.small).astype(np.float32)
        if m["pal"] is None:  # 16-bit: posterize each channel
            lv = m["levels"]
            q = np.clip(np.round(a / 255 * (lv - 1) + self.dith), 0, lv - 1) * (255 / (lv - 1))
            out = q
        elif len(m["pal"]) <= 4:  # handheld: luminance -> 4 shades with dithering
            lum = (0.3 * a[..., 0] + 0.59 * a[..., 1] + 0.11 * a[..., 2]) / 255
            lum = np.clip(lum * 1.15 + 0.04, 0, 1)  # lift shadows a little so dark games stay visible
            k = np.clip(np.round(lum[..., None] * 3 + self.dith), 0, 3).astype(int)[..., 0]
            out = self.pal[k]
        else:
            b = a + self.dith * 48
            d = ((b[..., None, :] - self.pal[None, None, :, :]) ** 2).sum(-1)
            out = self.pal[d.argmin(-1)]
        pygame.surfarray.blit_array(self.small, out.astype(np.uint8))
        pygame.transform.scale(self.small, (W, H), self.big)
        if self.grid is not None:
            self.big.blit(self.grid, (0, 0))
        return self.big


class RetroWriter:
    """Wraps a VideoWriter / PreviewSink and filters each frame."""
    def __init__(self, inner, mode):
        self.inner = inner
        self.r = Retro(mode)

    def write(self, surface):
        self.inner.write(self.r.apply(surface))

    def close(self, wav_path=None):
        return self.inner.close(wav_path)

    def __getattr__(self, k):
        return getattr(self.inner, k)
