"""Frame output: pygame surfaces -> ffmpeg -> MP4, then audio muxed in."""
import os
import subprocess
import shutil

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
import pygame  # noqa: E402

# Font objects become invalid after pygame.quit(); anything caching them registers a hook here.
QUIT_HOOKS = []
_real_quit = pygame.quit


def _quit():
    for h in QUIT_HOOKS:
        h()
    _real_quit()


pygame.quit = _quit


def ffmpeg_bin():
    exe = shutil.which("ffmpeg")
    if not exe:
        try:
            import imageio_ffmpeg
            exe = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            exe = None
    if not exe:
        raise SystemExit("ffmpeg not found. Install it and make sure it's on PATH.")
    return exe


class VideoWriter:
    def __init__(self, path, w, h, fps, quality="good"):
        self.path = path
        self.tmp = path + ".noaudio.mp4"
        preset = {"fast": "ultrafast", "good": "veryfast", "best": "slow", "preview": "ultrafast"}[quality]
        crf = {"fast": "23", "good": "18", "best": "16", "preview": "28"}[quality]
        scale = ["-vf", "scale=540:960"] if quality == "preview" else []
        self.proc = subprocess.Popen(
            [ffmpeg_bin(), "-y", "-loglevel", "error",
             "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(fps),
             "-i", "-",
             *scale, "-c:v", "libx264", "-preset", preset, "-crf", crf,
             "-pix_fmt", "yuv420p", "-r", str(fps), self.tmp],
            stdin=subprocess.PIPE)

    def write(self, surface):
        self.proc.stdin.write(pygame.image.tobytes(surface, "RGB"))

    def close(self, wav_path=None):
        self.proc.stdin.close()
        self.proc.wait()
        if wav_path:
            subprocess.run(
                [ffmpeg_bin(), "-y", "-loglevel", "error", "-i", self.tmp, "-i", wav_path,
                 "-c:v", "copy", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000",
                 "-c:a", "aac", "-b:a", "256k",
                 "-shortest", "-movflags", "+faststart", self.path], check=True)
            os.remove(self.tmp)
        else:
            os.replace(self.tmp, self.path)
        return self.path


class PreviewDone(Exception):
    """Raised from a preview sink once it has what it needs. `frame` = still image, `finish()` closes a clip."""
    def __init__(self, frame=None, finish=None):
        super().__init__("preview done")
        self.frame = frame
        self.finish = finish or (lambda: None)


class PreviewSink:
    """Drop-in for VideoWriter in preview mode: {"still": t} grabs one frame, {"clip": t} writes a short clip."""
    def __init__(self, cfg, path, w, h, fps, sound):
        self.p, self.fps, self.sound, self.path = cfg["_preview"], fps, sound, path
        self.n = 0
        self.real = VideoWriter(path, w, h, fps, "preview") if "clip" in self.p else None

    def write(self, surface):
        t = self.n / self.fps
        if self.real is None:
            if t >= self.p["still"]:
                raise PreviewDone(frame=surface.copy())
        else:
            self.real.write(surface)
            if t >= self.p["clip"]:
                raise PreviewDone(finish=self._finish)
        self.n += 1

    def _finish(self):
        wav = self.path + ".wav"
        self.sound.render(self.n / self.fps, wav)
        self.real.close(wav)
        os.remove(wav)

    def close(self, wav_path=None):
        if self.real is not None:
            self.real.close(wav_path)


def make_writer(cfg, path, w, h, fps, sound=None):
    if cfg.get("_preview"):
        wr = PreviewSink(cfg, path, w, h, fps, sound)
    else:
        wr = VideoWriter(path, w, h, fps, cfg.get("quality", "good"))
    if cfg.get("retro"):
        from .retro import RetroWriter, MODES
        if cfg["retro"] in MODES:
            wr = RetroWriter(wr, cfg["retro"])
    return wr
