"""Game 2: Ring Escape.

Balls fall inside a stack of spinning rings. Each ring has one gap; when a
ball slips through, the ring shatters, that ball scores a point and the
camera zooms out to the next ring. Whoever breaks the most rings wins.
With one racer it becomes "Can it escape N rings?".

Rings grow geometrically and everything (ball size, gravity, speed) scales
with them, so the zoom looks seamless and endless.
"""
import colorsys
import math
import random

from engine.video import pygame
from engine import visual as V
from games.maze import W, H, _wrap, _draw_winner, _draw_title
import pygame.gfxdraw as gfx

THEMES = {
    "neon": {"bg1": "#05050c", "bg2": "#1a1240", "sat": 0.75, "val": 1.0},
    "sunset": {"bg1": "#1a0612", "bg2": "#5a1838", "sat": 0.65, "val": 1.0},
    "ocean": {"bg1": "#03101f", "bg2": "#0d3a63", "sat": 0.6, "val": 1.0},
    "mono": {"bg1": "#0a0a0a", "bg2": "#2a2a2a", "sat": 0.0, "val": 0.95},
    "candy": {"bg1": "#2a0a2e", "bg2": "#7a2a6e", "sat": 0.45, "val": 1.0},
    "forest": {"bg1": "#04140a", "bg2": "#14402a", "sat": 0.55, "val": 0.95},
    "gold": {"bg1": "#140c02", "bg2": "#3d2a08", "sat": 0.85, "val": 1.0},
}
RANDOM_THEMES = ["neon", "ocean", "mono", "gold", "forest"]

CX, CY = W / 2, 1010
VIEW_R = 370          # on-screen radius of the ring being attacked
R0 = 180.0            # world radius of ring 0
Q = 1.26              # each ring is 26% bigger
BALL_R0 = 16.5
G0 = 830.0


class Ring:
    def __init__(self, k, rng, gap_scale):
        self.k = k
        self.R = R0 * Q ** k
        self.rot = rng.uniform(0, 2 * math.pi)
        sign = 1 if k % 2 == 0 else -1
        self.w = sign * rng.uniform(0.9, 1.7) * (1 + min(k, 40) * 0.01)
        early = 1 + 0.6 * max(0, 4 - k) / 4  # first rings break fast, then it gets harder
        self.gap = min(1.6, max(0.4, rng.uniform(0.5, 0.68) * gap_scale * early - min(k, 30) * 0.004))
        h = (k * 0.071 + rng.uniform(-0.01, 0.01)) % 1.0
        self.hue = h
        self.alive = True


class Ball:
    def __init__(self, i, look, x, y, vx, vy):
        self.i = i
        self.look = look
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.squash = 0.0
        self.score = 0
        self.last_score = -1.0
        self.trail = []


def _ang_diff(a, b):
    return (a - b + math.pi) % (2 * math.pi) - math.pi


class Sim:
    def __init__(self, n_rings, looks, seed, gap_scale=1.0, sound=None, fx=None, ring_color=None):
        self.rng = random.Random(seed * 31 + 7)
        rr = random.Random(seed * 17 + 3)
        self.rings = [Ring(k, rr, gap_scale) for k in range(n_rings)]
        self.cur = 0
        self.scale = 1.0           # world multiplier of current ring (Q**cur)
        self.sound = sound
        self.fx = fx
        self.ring_color = ring_color
        self.done = False
        self.break_times = []
        self.balls = []
        n = len(looks)
        r = BALL_R0
        for i, lk in enumerate(looks):
            x = (i - (n - 1) / 2) * r * 2.6
            y = -R0 * 0.25 + self.rng.uniform(-10, 10)
            self.balls.append(Ball(i, lk, x, y, self.rng.uniform(-120, 120), self.rng.uniform(-60, 0)))

    @property
    def r(self):
        return BALL_R0 * self.scale

    @property
    def g(self):
        return G0 * self.scale

    def _event(self, now, kind, b=None, x=0.0, **kw):
        if self.sound is not None:
            pan = 0.5 + max(-0.35, min(0.35, x / (self.rings[min(self.cur, len(self.rings) - 1)].R * 2.5)))
            self.sound.add(now, kind, who=b.i if b else None, pan=pan, **kw)

    def step(self, dt, now):
        for ring in self.rings[self.cur:self.cur + 8]:
            ring.rot += ring.w * dt
        r = self.r
        g = self.g
        for b in self.balls:
            b.squash *= math.exp(-dt / 0.06)
            b.vy += g * dt
            b.x += b.vx * dt
            b.y += b.vy * dt
            if self.done:
                continue
            ring = self.rings[self.cur]
            d = math.hypot(b.x, b.y)
            if d >= ring.R:
                self._break(b, now)
                if self.done:
                    continue
                ring = self.rings[self.cur]
                r = self.r
                g = self.g
                d = math.hypot(b.x, b.y)
            if d + r > ring.R:
                a = math.atan2(b.y, b.x)
                in_gap = abs(_ang_diff(a, ring.rot)) < ring.gap / 2 - (r / ring.R) * 0.9
                if in_gap:
                    continue
                nx, ny = b.x / d, b.y / d
                b.x, b.y = nx * (ring.R - r), ny * (ring.R - r)
                vn = b.vx * nx + b.vy * ny
                if vn > 0:
                    b.vx -= 2 * vn * nx
                    b.vy -= 2 * vn * ny
                    # small random spin so it never repeats a path
                    ang = math.radians(self.rng.uniform(-4, 4))
                    c, s = math.cos(ang), math.sin(ang)
                    b.vx, b.vy = b.vx * c - b.vy * s, b.vx * s + b.vy * c
                    # keep it lively: always enough energy to reach the top
                    sp = math.hypot(b.vx, b.vy)
                    vmin = math.sqrt(2 * g * ring.R) * 0.95
                    vmax = math.sqrt(2 * g * ring.R) * 1.45
                    k = min(max(sp * 1.01, vmin), vmax) / (sp or 1)
                    b.vx *= k
                    b.vy *= k
                    b.squash = 1.0
                    self._event(now, "bounce", b, b.x, min_gap=0.05)
        self._ball_collisions(now)

    def _break(self, b, now):
        ring = self.rings[self.cur]
        ring.alive = False
        b.score += 1
        b.last_score = now
        self.break_times.append(now)
        self._event(now, "escape", b, b.x)
        if self.fx is not None:
            self.fx_ring = (ring, now)
        self.cur += 1
        if self.cur >= len(self.rings):
            self.done = True
            return
        # everything grows with the next ring so the zoom feels seamless
        for o in self.balls:
            o.vx *= Q
            o.vy *= Q
        self.scale *= Q

    def _ball_collisions(self, now):
        r = self.r
        bs = self.balls
        for i in range(len(bs)):
            for j in range(i + 1, len(bs)):
                a, c = bs[i], bs[j]
                dx, dy = c.x - a.x, c.y - a.y
                d = math.hypot(dx, dy)
                if 0 < d < 2 * r:
                    nx, ny = dx / d, dy / d
                    push = (2 * r - d) / 2
                    a.x -= nx * push
                    a.y -= ny * push
                    c.x += nx * push
                    c.y += ny * push
                    va = a.vx * nx + a.vy * ny
                    vc = c.vx * nx + c.vy * ny
                    if va - vc > 0:
                        a.vx += (vc - va) * nx
                        a.vy += (vc - va) * ny
                        c.vx += (va - vc) * nx
                        c.vy += (va - vc) * ny
                        self._event(now, "racer", a, (a.x + c.x) / 2, min_gap=0.1)

    def ranking(self):
        return sorted(self.balls, key=lambda b: (-b.score, -b.last_score))


# ---------------------------------------------------------------- tuning

def tune(seed, n, t_min, t_max, sub_dt=1 / 240):
    """Choose how many rings so the last one breaks inside [t_min, t_max]."""
    best = None
    for attempt in range(12):
        base = 1.75 if n == 1 else 1.3 if n <= 3 else 1.0
        gap_scale = base * [1.0, 0.85, 1.15, 0.75, 1.3, 0.9, 1.05, 0.8, 1.2, 0.95, 1.1, 0.7][attempt]
        s = seed * 100 + attempt
        S = Sim(400, [None] * n, s, gap_scale)
        t = 0.0
        while t < t_max + 0.5 and not S.done:
            S.step(sub_dt, t)
            t += sub_dt
        bt = S.break_times
        inside = [i for i, x in enumerate(bt) if t_min <= x <= t_max and i >= 4]
        if inside:
            k = inside[-1]
            return s, gap_scale, k + 1, bt[k]
        if bt:
            near = min(range(len(bt)), key=lambda i: abs(bt[i] - (t_min + t_max) / 2))
            miss = abs(bt[near] - (t_min + t_max) / 2)
            if best is None or miss < best[0]:
                best = (miss, s, gap_scale, near + 1, bt[near])
    if best:
        return best[1:]
    raise RuntimeError("Could not build a ring level, try another seed")


# ---------------------------------------------------------------- render

def render(cfg, out_path, sound):
    import os
    from engine.video import VideoWriter
    theme_name = cfg.get("theme", "neon")
    T = THEMES.get(theme_name, THEMES["neon"])
    Tc = {"bg1": V.hexc(T["bg1"]), "bg2": V.hexc(T["bg2"])}
    fps = cfg.get("fps", 60)
    racers_spec = cfg["racers"]
    n = len(racers_spec)
    solo = n == 1
    V.STYLE["mode"] = cfg.get("style", "sleek")
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    lseed, gap_scale, n_rings, est = tune(cfg["seed"], n, t_min, t_max)
    print(f"  {n_rings} rings, race ~{est:.1f}s")

    pygame.display.init()
    pygame.font.init()
    pygame.display.set_mode((1, 1))
    canvas = pygame.Surface((W, H))
    looks = [V.Look(s, 48) for s in racers_spec]
    fx = V.Particles(random.Random(cfg["seed"]))
    S = Sim(n_rings, looks, lseed, gap_scale, sound=sound, fx=fx)
    from engine import backgrounds
    bg, _ = backgrounds.make(W, H, Tc["bg1"], Tc["bg2"], cfg.get("background"), cfg["seed"])
    default_title = f"CAN IT ESCAPE {n_rings} RINGS?" if solo else "WHO BREAKS THE MOST RINGS?"
    title_lines = _wrap(cfg.get("title") or default_title, 22)
    handle = cfg.get("handle", "")
    writer = VideoWriter(out_path, W, H, fps, cfg.get("quality", "good"))
    dt = 1 / fps
    sub = max(1, round(240 / fps))
    count_in = 0.0 if V.sleek() else 1.5
    end_len = 4.2
    if count_in > 0:
        for m in (0.0, 0.5, 1.0):
            sound.add(m, "count")
    sound.add(count_in, "go")
    cam = VIEW_R / R0  # pixels per world unit
    frame = 0
    win_time = None
    seen_break = 0
    rank_x = {}
    glow = pygame.Surface((W, H), pygame.SRCALPHA)
    while True:
        t = frame * dt
        racing = t >= count_in
        if racing and win_time is None:
            for i in range(sub):
                S.step(dt / sub, t + i * dt / sub)
            if S.done:
                win_time = t
                sound.climax(t)
                fx.confetti(W)
        elif win_time is not None and t - win_time < 0.8:
            for i in range(sub):
                S.step(dt / sub * 0.3, t + i * dt / sub)
        # ring break effects
        while seen_break < len(S.break_times):
            ring = S.rings[seen_break]
            col = _ring_col(ring, T)
            pr = ring.R * cam
            for k in range(70):
                a = ring.rot + ring.gap / 2 + (2 * math.pi - ring.gap) * k / 70
                x, y = CX + math.cos(a) * pr, CY + math.sin(a) * pr
                fx.p.append([x, y, math.cos(a) * fx.rng.uniform(150, 650), math.sin(a) * fx.rng.uniform(150, 650),
                             fx.rng.uniform(0.5, 1.1), 0.0, col, fx.rng.uniform(6, 13), 600, fx.rng.uniform(0, 6)])
            seen_break += 1
        fx.update(dt)
        # camera follows the current ring (smooth zoom)
        target = VIEW_R / S.rings[min(S.cur, n_rings - 1)].R
        cam *= (target / cam) ** min(1, dt / 0.22)
        for b in S.balls:
            b.trail.append((b.x, b.y))
            if len(b.trail) > 10:
                b.trail.pop(0)
        # ------------------------------------------------ draw
        canvas.blit(bg, (0, 0))
        left = n_rings - S.cur
        if win_time is None:
            num = V.text(str(left), 300, (255, 255, 255), None)
            num.set_alpha(28)
            V.blit_center(canvas, num, CX, CY)
        glow.fill((0, 0, 0, 0))
        for ring in reversed(S.rings[S.cur:S.cur + 7]):
            pr = ring.R * cam
            if pr > 1500:
                continue
            col = _ring_col(ring, T)
            is_cur = ring.k == S.cur
            th = 14 if is_cur else 9
            if not is_cur:
                col = V.mix(col, Tc["bg1"], min(0.75, 0.28 * (ring.k - S.cur)))
            else:
                _arc(glow, CX, CY, pr, 30, ring.rot, ring.gap, (*col, 55))
            _arc(canvas, CX, CY, pr, th, ring.rot, ring.gap, col)
        canvas.blit(glow, (0, 0))
        r_px = BALL_R0 * S.scale * cam
        for b in S.balls:
            pts = [(CX + x * cam, CY + y * cam) for x, y in b.trail]
            for i in range(1, len(pts)):
                k = i / len(pts)
                pygame.draw.line(canvas, V.mix(Tc["bg1"], b.look.color, 0.2 + 0.6 * k), pts[i - 1], pts[i], max(2, int(r_px * (0.8 if V.sleek() else 1.2) * k)))
        for b in S.balls:
            b.look.draw_ball(canvas, CX + b.x * cam, CY + b.y * cam, r_px, b.vx, b.vy)
        fx.draw(canvas)
        y = _draw_title(canvas, title_lines, t)
        if win_time is None:
            V.blit_center(canvas, V.text(f"RINGS LEFT: {left}", 44, (255, 230, 60), (15, 15, 25), 5), W / 2, y + 10)
        _leader(canvas, S, rank_x, dt, solo)
        if handle:
            V.blit_center(canvas, V.text(handle, 30, (255, 255, 255), (0, 0, 0), 3, "Medium"), W / 2, 1720)
        if t < count_in:
            k = min(2, int(t / 0.5))
            sc = 1.6 - 0.6 * min(1, (t % 0.5) / 0.5 * 3)
            V.blit_center(canvas, V.text(str(3 - k), int(240 * sc), (255, 255, 255), (15, 15, 25), 14), CX, CY)
        elif count_in > 0 and t - count_in < 0.45 and win_time is None:
            a = (t - count_in) / 0.45
            V.blit_center(canvas, V.text("GO!", int(220 * (1 + a * 0.3)), (255, 230, 60), (15, 15, 25), 14), CX, CY)
        if win_time is not None:
            if solo:
                _draw_winner(canvas, S.balls[0], t - win_time, Tc, line1="", line2="ESCAPED!",
                             line3=f"{n_rings} rings in {win_time - count_in:.1f}s")
            else:
                w = S.ranking()[0]
                _draw_winner(canvas, w, t - win_time, Tc, line3=f"{w.score} rings broken")
        writer.write(canvas)
        frame += 1
        if frame % 30 == 0:
            print(f"PROGRESS {frame} {int((est + count_in + end_len) * fps)}", flush=True)
        if win_time is not None and t - win_time >= end_len:
            break
        if t > t_max * 3:
            raise RuntimeError("Race ran too long")
    duration = frame * dt
    wav = out_path + ".wav"
    sound.render(duration, wav)
    writer.close(wav)
    os.remove(wav)
    pygame.quit()
    win = S.balls[0] if solo else S.ranking()[0]
    return {"duration": duration, "winner": win.look.name, "level": lseed}


def _ring_col(ring, T):
    r, g, b = colorsys.hsv_to_rgb(ring.hue, T["sat"], T["val"])
    return (int(r * 255), int(g * 255), int(b * 255))


def _arc(dst, cx, cy, r, th, rot, gap, col):
    """Thick anti-aliased ring with a gap centred on angle `rot`."""
    a0 = rot + gap / 2
    span = 2 * math.pi - gap
    n = max(24, int(span * r / 6))
    ro, ri = r + th / 2, r - th / 2
    outer = [(cx + math.cos(a0 + span * i / n) * ro, cy + math.sin(a0 + span * i / n) * ro) for i in range(n + 1)]
    inner = [(cx + math.cos(a0 + span * i / n) * ri, cy + math.sin(a0 + span * i / n) * ri) for i in range(n, -1, -1)]
    poly = outer + inner
    # split into chunks: gfx polygons dislike very long concave shapes
    step = 40
    for s in range(0, n, step):
        e = min(n, s + step)
        o = outer[s:e + 1]
        i_ = [(cx + math.cos(a0 + span * k / n) * ri, cy + math.sin(a0 + span * k / n) * ri) for k in range(e, s - 1, -1)]
        p = o + i_
        if len(col) == 4:
            pygame.draw.polygon(dst, col, p)
        else:
            gfx.filled_polygon(dst, p, col)
            gfx.aapolygon(dst, p, col)
    # rounded caps at the gap edges
    for a in (a0, a0 + span):
        pygame.draw.circle(dst, col, (round(cx + math.cos(a) * r), round(cy + math.sin(a) * r)), max(1, round(th / 2)))
    return poly


def _leader(dst, S, rank_x, dt, solo):
    order = S.ranking()
    n = len(order)
    if solo:
        return
    slot = min(130, 940 // n)
    y = 1600
    x0 = W / 2 - slot * (n - 1) / 2
    for pos, b in enumerate(order):
        target = x0 + pos * slot
        cur = rank_x.get(b.i, target)
        cur += (target - cur) * min(1, dt * 14)
        rank_x[b.i] = cur
        V.blit_center(dst, b.look.badge(int(slot * 0.55)), cur, y)
        V.blit_center(dst, V.text(str(b.score), 40, (255, 255, 255), (0, 0, 0), 4), cur, y + slot * 0.55)
