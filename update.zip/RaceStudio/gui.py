"""Race Studio: a simple window for making race videos."""
import json
import os
import queue
import re
import subprocess
import sys
import threading
import tkinter as tk
import unicodedata
from tkinter import colorchooser, filedialog, messagebox, ttk

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from make import PRESETS, GAMES  # noqa: E402
import updater  # noqa: E402
MAC = sys.platform == "darwin"
BTN_FG = "#111111" if MAC else "#e9ecf5"  # macOS ignores button colours

EMOJI_DIR = os.path.join(HERE, "assets", "emoji")
SETTINGS = os.path.join(HERE, "config", "_last_settings.json")
from games import maze as _m, rings as _r, marbles as _mb, territory as _t  # noqa: E402
from engine.backgrounds import STYLES  # noqa: E402
GAME_THEMES = {"maze": ["random"] + list(_m.THEMES), "rings": ["random"] + list(_r.THEMES),
               "marbles": ["random"] + list(_mb.THEMES), "territory": ["random"] + list(_t.THEMES)}
GAME_NAMES = {"Maze Race": "maze", "Ring Escape": "rings", "Marble Elimination": "marbles",
              "Territory War": "territory"}
MIN_RACERS = {"maze": 2, "rings": 1, "marbles": 2, "territory": 2}
DEFAULT_TITLES = {"WHO REACHES THE FLAG FIRST?", "WHO BREAKS THE MOST RINGS?", "LAST ONE DOWN IS OUT!",
                  "WHICH COLOUR TAKES OVER?", ""}
GAME_HELP = {
    "maze": "Racers bounce through a maze, smash numbered blocks, dodge spikes. First to the flag wins.",
    "rings": "Balls escape spinning rings; most rings broken wins. 1 racer = solo 'Can it escape?' mode.",
    "marbles": "Marbles drop through a new peg board each round; last one down is OUT. Length = number of racers.",
    "territory": "Each colour's ball flips enemy tiles. Biggest territory when the timer ends wins.",
}
BACKGROUNDS = ["random"] + STYLES
COMING = []

BG = "#14161f"
PANEL = "#1d2030"
FG = "#e9ecf5"
MUTED = "#9aa1b8"
ACCENT = "#ffb020"


# ====================================================================== emoji picker

class EmojiPicker(tk.Toplevel):
    def __init__(self, master, on_pick):
        super().__init__(master)
        self.title("Pick an emoji")
        self.configure(bg=BG)
        self.geometry("560x520")
        self.on_pick = on_pick
        self.imgs = []
        self.index = []
        for f in os.listdir(EMOJI_DIR):
            code = f[:-4]
            parts = code.split("-")
            try:
                ch = "".join(chr(int(p, 16)) for p in parts)
            except ValueError:
                continue
            names = []
            for c in ch:
                try:
                    names.append(unicodedata.name(c))
                except ValueError:
                    pass
            self.index.append((" ".join(names).lower(), ch, os.path.join(EMOJI_DIR, f)))
        self.index.sort()
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Search:", bg=BG, fg=FG).pack(side="left")
        self.q = tk.StringVar()
        e = tk.Entry(top, textvariable=self.q, bg=PANEL, fg=FG, insertbackground=FG, relief="flat")
        e.pack(side="left", fill="x", expand=True, padx=6)
        e.focus_set()
        self.q.trace_add("write", lambda *_: self.refresh())
        self.grid_frame = tk.Frame(self, bg=BG)
        self.grid_frame.pack(fill="both", expand=True, padx=10)
        tk.Label(self, text="Try: pizza, cat, car, heart, fire, ball", bg=BG, fg=MUTED).pack(pady=4)
        self.q.set("face")

    def refresh(self):
        for w in self.grid_frame.winfo_children():
            w.destroy()
        self.imgs.clear()
        words = self.q.get().lower().split()
        hits = [x for x in self.index if all(w in x[0] for w in words)][:48]
        for i, (name, ch, path) in enumerate(hits):
            try:
                img = tk.PhotoImage(file=path).subsample(4)
            except tk.TclError:
                continue
            self.imgs.append(img)
            b = tk.Button(self.grid_frame, image=img, bg=PANEL, activebackground=ACCENT, relief="flat", highlightbackground=PANEL,
                          command=lambda c=ch, n=name: self.pick(c, n))
            b.grid(row=i // 8, column=i % 8, padx=3, pady=3)

    def pick(self, ch, name):
        self.on_pick(ch, name.split()[-1].title() if name else "Racer")
        self.destroy()


# ====================================================================== racer row

class RacerRow(tk.Frame):
    TYPES = ["Square", "Emoji", "Image"]

    def __init__(self, master, app, spec):
        super().__init__(master, bg=PANEL)
        self.app = app
        self.name = tk.StringVar(value=spec.get("name", "Racer"))
        self.kind = tk.StringVar(value="Emoji" if spec.get("emoji") else "Image" if spec.get("image") else "Square")
        self.emoji = spec.get("emoji", "")
        self.image = spec.get("image", "")
        self.color = spec.get("color", "#ef3b3b")
        self.shape = tk.StringVar(value=spec.get("shape", "fit"))
        self.preview_img = None

        tk.Entry(self, textvariable=self.name, width=12, bg=BG, fg=FG, insertbackground=FG, relief="flat").pack(side="left", padx=4, pady=4)
        ttk.Combobox(self, textvariable=self.kind, values=self.TYPES, width=7, state="readonly").pack(side="left", padx=4)
        self.kind.trace_add("write", lambda *_: self.update_view())
        self.color_btn = tk.Label(self, text="", width=4, bg=self.color, cursor="hand2", relief="ridge", bd=2)
        self.color_btn.pack(side="left", padx=4, ipady=4)
        self.color_btn.bind("<Button-1>", lambda e: self.pick_color())
        self.pick_btn = tk.Button(self, text="Choose…", relief="flat", bg=BG, fg=BTN_FG, command=self.choose)
        self.pick_btn.pack(side="left", padx=4)
        self.shape_box = ttk.Combobox(self, textvariable=self.shape, values=["fit", "circle"], width=6, state="readonly")
        self.shape_box.pack(side="left", padx=4)
        self.preview = tk.Label(self, bg=PANEL, fg=MUTED, width=6)
        self.preview.pack(side="left", padx=4)
        tk.Button(self, text="Remove", relief="flat", bg=PANEL, fg="#ff6b6b", command=self.remove).pack(side="right", padx=6)
        self.update_view()

    def update_view(self):
        k = self.kind.get()
        self.pick_btn.configure(state="normal" if k != "Square" else "disabled")
        self.shape_box.configure(state="readonly" if k == "Image" else "disabled")
        self.preview_img = None
        txt = ""
        try:
            if k == "Emoji" and self.emoji:
                code = "-".join(f"{ord(c):x}" for c in self.emoji)
                p = os.path.join(EMOJI_DIR, code + ".png")
                if not os.path.exists(p):
                    p = os.path.join(EMOJI_DIR, "-".join(f"{ord(c):x}" for c in self.emoji if ord(c) != 0xFE0F) + ".png")
                self.preview_img = tk.PhotoImage(file=p).subsample(6)
            elif k == "Image" and self.image:
                txt = os.path.basename(self.image)[:10]
                if self.image.lower().endswith((".png", ".gif")):
                    img = tk.PhotoImage(file=self.image)
                    f = max(1, max(img.width(), img.height()) // 32)
                    self.preview_img = img.subsample(f)
            elif k == "Square":
                txt = "■"
        except Exception:
            txt = "?"
        self.preview.configure(image=self.preview_img or "", text="" if self.preview_img else ("" if k == "Square" else txt),
                               bg=self.color if k == "Square" and not self.preview_img else PANEL, fg=MUTED,
                               width=0 if self.preview_img else 6)

    def pick_color(self):
        c = colorchooser.askcolor(self.color, parent=self)[1]
        if c:
            self.color = c
            self.color_btn.configure(bg=c)
            self.update_view()

    def choose(self):
        if self.kind.get() == "Emoji":
            EmojiPicker(self.app.root, self.set_emoji)
        else:
            p = filedialog.askopenfilename(parent=self, title="Racer image",
                                           filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.gif"), ("All", "*.*")])
            if p:
                self.image = p
                if self.name.get() in ("", "Racer"):
                    self.name.set(os.path.splitext(os.path.basename(p))[0].title())
                self.update_view()

    def set_emoji(self, ch, name):
        self.emoji = ch
        if self.name.get() in ("", "Racer") or self.name.get().startswith("Racer"):
            self.name.set(name)
        self.update_view()

    def remove(self):
        self.app.rows.remove(self)
        self.destroy()

    def spec(self):
        s = {"name": self.name.get().strip() or "Racer", "color": self.color}
        k = self.kind.get()
        if k == "Emoji":
            if not self.emoji:
                raise ValueError(f"Pick an emoji for {s['name']}")
            s["emoji"] = self.emoji
        elif k == "Image":
            if not self.image or not os.path.exists(self.image):
                raise ValueError(f"Pick an image for {s['name']}")
            s["image"] = self.image
            s["shape"] = self.shape.get()
        return s


# ====================================================================== main window

class App:
    def __init__(self, root):
        self.root = root
        root.title("Race Studio")
        root.configure(bg=BG)
        root.geometry("920x900")
        root.minsize(820, 760)
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure("TCombobox", fieldbackground=BG, background=PANEL, foreground=FG, arrowcolor=FG)
        st.map("TCombobox", fieldbackground=[("readonly", BG)], foreground=[("readonly", FG)])
        st.configure("Horizontal.TProgressbar", troughcolor=PANEL, background=ACCENT)
        self.proc = None
        self.q = queue.Queue()
        self.rows = []
        self.last_video = None
        s = self._load()

        self._pending_game_refresh = True
        tk.Label(root, text="RACE STUDIO", bg=BG, fg=ACCENT, font=("Segoe UI", 20, "bold")).pack(pady=(12, 0))
        tk.Label(root, text="Satisfying race videos for Shorts, TikTok and Reels", bg=BG, fg=MUTED).pack()
        upd = tk.Frame(root, bg=BG)
        upd.pack()
        self.ver_label = tk.StringVar(value=f"Version {updater.current_version()}")
        tk.Label(upd, textvariable=self.ver_label, bg=BG, fg=MUTED).pack(side="left", padx=6)
        self.upd_btn = self._btn(upd, "Check for updates", lambda: self.check_updates(manual=True))
        self.upd_btn.pack(side="left")

        body = tk.Frame(root, bg=BG)
        body.pack(fill="both", expand=True, padx=14, pady=8)

        # ------------------------------------------------ game + look
        g = self._section(body, "1  Game & look")
        self.game = tk.StringVar(value=s.get("game", "Maze Race"))
        gcb = self._combo(g, "Game", self.game, list(GAME_NAMES) + COMING, 0, 0)
        gcb.bind("<<ComboboxSelected>>", lambda e: self._game_changed())
        self.theme = tk.StringVar(value=s.get("theme", "random"))
        self.theme_cb = self._combo(g, "Theme", self.theme, GAME_THEMES["maze"], 0, 2)
        self.title_v = tk.StringVar(value=s.get("title", ""))
        self._entry(g, "Title text", self.title_v, 1, 0, 40, span=3)
        tk.Label(g, text="Leave the title empty to use the game's default title.", bg=PANEL, fg=MUTED).grid(row=3, column=0, columnspan=4, sticky="w")
        self.handle = tk.StringVar(value=s.get("handle", ""))
        self._entry(g, "Your @handle", self.handle, 2, 0, 20)
        self.bg_style = tk.StringVar(value=s.get("background", "random"))
        self._combo(g, "Background", self.bg_style, BACKGROUNDS, 2, 2)
        self.extra = tk.Frame(g, bg=PANEL)
        self.extra.grid(row=4, column=0, columnspan=4, sticky="w", pady=(4, 0))
        self.layout = tk.StringVar(value=s.get("layout", "random"))
        self.shape = tk.StringVar(value=s.get("shape", "random"))
        self.help = tk.StringVar()
        tk.Label(g, textvariable=self.help, bg=PANEL, fg=ACCENT, wraplength=800, justify="left").grid(row=5, column=0, columnspan=4, sticky="w", pady=(4, 0))

        # ------------------------------------------------ racers
        r = self._section(body, "2  Racers (2–8; Ring Escape also allows 1 for solo mode)")
        bar = tk.Frame(r, bg=PANEL)
        bar.pack(fill="x")
        tk.Label(bar, text="Load preset:", bg=PANEL, fg=MUTED).pack(side="left", padx=4)
        self.preset = tk.StringVar(value="")
        cb = ttk.Combobox(bar, textvariable=self.preset, values=list(PRESETS), width=12, state="readonly")
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self.load_racers(PRESETS[self.preset.get()]))
        self._btn(bar, "+ Add racer", self.add_racer).pack(side="right", padx=4)
        hdr = tk.Frame(r, bg=PANEL)
        hdr.pack(fill="x")
        for txt, w in (("Name", 13), ("Type", 10), ("Colour", 7), ("Pick", 10), ("Shape", 8), ("Preview", 8)):
            tk.Label(hdr, text=txt, bg=PANEL, fg=MUTED, width=w, anchor="w").pack(side="left")
        self.rows_frame = tk.Frame(r, bg=PANEL)
        self.rows_frame.pack(fill="x")
        self.load_racers(s.get("racers") or PRESETS["colors4"])

        # ------------------------------------------------ sound + timing
        a = self._section(body, "3  Sound & timing")
        self.vibe = tk.StringVar(value=s.get("vibe", "random"))
        self._combo(a, "Music vibe", self.vibe, ["random", "chill", "hype"], 0, 0)
        self.music = tk.StringVar(value=s.get("music", "Built-in music"))
        mb = self._combo(a, "Music", self.music, ["Built-in music", "No music", "My own WAV…"], 0, 2)
        mb.bind("<<ComboboxSelected>>", self._music_pick)
        self.music_file = s.get("music_file", "")
        self.tmin = tk.IntVar(value=s.get("tmin", 30))
        self.tmax = tk.IntVar(value=s.get("tmax", 50))
        self._spin(a, "Race length from (s)", self.tmin, 15, 300, 1, 0)
        self._spin(a, "to (s)", self.tmax, 20, 600, 1, 2)

        # ------------------------------------------------ output
        o = self._section(body, "4  Output")
        self.count = tk.IntVar(value=s.get("count", 1))
        self._spin(o, "How many videos", self.count, 1, 100, 0, 0)
        self.quality = tk.StringVar(value=s.get("quality", "good"))
        self._combo(o, "Quality", self.quality, ["fast", "good", "best"], 0, 2)
        self.out = tk.StringVar(value=s.get("out", os.path.join(HERE, "output")))
        self._entry(o, "Save to", self.out, 1, 0, 40, span=2)
        self._btn(o, "Browse…", lambda: self.out.set(filedialog.askdirectory() or self.out.get())).grid(row=1, column=3, sticky="w")

        # ------------------------------------------------ actions
        act = tk.Frame(body, bg=BG)
        act.pack(fill="x", pady=(8, 4))
        self.go = tk.Button(act, text="▶  MAKE VIDEOS", bg=ACCENT, fg="#1a1300", activebackground="#ffc95a", highlightbackground=BG,
                            font=("Segoe UI", 13, "bold"), relief="flat", padx=18, pady=6, command=self.start)
        self.go.pack(side="left")
        self.stop_btn = self._btn(act, "Stop", self.stop)
        self.stop_btn.pack(side="left", padx=8)
        self.stop_btn.configure(state="disabled")
        self._btn(act, "Open output folder", self.open_out).pack(side="right")
        self.play_btn = self._btn(act, "Play last video", self.play_last)
        self.play_btn.pack(side="right", padx=8)
        self.play_btn.configure(state="disabled")

        self.prog = ttk.Progressbar(body, mode="determinate", maximum=100)
        self.prog.pack(fill="x", pady=4)
        self.status = tk.StringVar(value="Ready.")
        tk.Label(body, textvariable=self.status, bg=BG, fg=FG, anchor="w").pack(fill="x")
        self.log = tk.Text(body, height=7, bg=PANEL, fg=MUTED, relief="flat", font=("Consolas", 9))
        self.log.pack(fill="both", expand=True, pady=(4, 0))
        root.protocol("WM_DELETE_WINDOW", self.close)
        self._game_changed(keep_theme=True)
        root.after(100, self.poll)
        root.after(800, lambda: self.check_updates(manual=False))

    # ------------------------------------------------ widgets
    def _section(self, parent, title):
        f = tk.Frame(parent, bg=PANEL, padx=10, pady=8)
        f.pack(fill="x", pady=5)
        tk.Label(f, text=title, bg=PANEL, fg=ACCENT, font=("Segoe UI", 11, "bold")).pack(anchor="w")
        inner = tk.Frame(f, bg=PANEL)
        inner.pack(fill="x", pady=(4, 0))
        return inner

    def _combo(self, p, label, var, values, row, col):
        tk.Label(p, text=label, bg=PANEL, fg=FG).grid(row=row, column=col, sticky="w", padx=(0, 6), pady=3)
        cb = ttk.Combobox(p, textvariable=var, values=values, width=30 if col == 0 else 16, state="readonly")
        cb.grid(row=row, column=col + 1, sticky="w", padx=(0, 20))
        return cb

    def _entry(self, p, label, var, row, col, width, span=1):
        tk.Label(p, text=label, bg=PANEL, fg=FG).grid(row=row, column=col, sticky="w", padx=(0, 6), pady=3)
        e = tk.Entry(p, textvariable=var, width=width, bg=BG, fg=FG, insertbackground=FG, relief="flat")
        e.grid(row=row, column=col + 1, columnspan=span, sticky="we", padx=(0, 20))
        return e

    def _spin(self, p, label, var, lo, hi, row, col):
        tk.Label(p, text=label, bg=PANEL, fg=FG).grid(row=row, column=col, sticky="w", padx=(0, 6), pady=3)
        tk.Spinbox(p, from_=lo, to=hi, textvariable=var, width=6, bg=BG, fg=FG, buttonbackground=PANEL,
                   insertbackground=FG, relief="flat").grid(row=row, column=col + 1, sticky="w", padx=(0, 20))

    def _btn(self, p, text, cmd):
        return tk.Button(p, text=text, command=cmd, bg=PANEL, fg=BTN_FG, activebackground="#2a2e44",
                         activeforeground=BTN_FG, relief="flat", padx=10, pady=3, highlightbackground=PANEL)

    # ------------------------------------------------ racers
    def load_racers(self, specs):
        for row in list(self.rows):
            row.destroy()
        self.rows = []
        for sp in specs:
            self._add_row(sp)

    def _add_row(self, spec):
        row = RacerRow(self.rows_frame, self, spec)
        row.pack(fill="x", pady=1)
        self.rows.append(row)

    def add_racer(self):
        if len(self.rows) >= 8:
            messagebox.showinfo("Race Studio", "Max 8 racers.")
            return
        palette = ["#ef3b3b", "#2f6bff", "#1fbf4f", "#ffd21f", "#9b4dff", "#ff8a1f", "#19c3c3", "#ff5fb0"]
        self._add_row({"name": f"Racer {len(self.rows) + 1}", "color": palette[len(self.rows) % 8]})

    def _game_changed(self, keep_theme=False):
        code = GAME_NAMES.get(self.game.get())
        if not code:
            return
        themes = GAME_THEMES[code]
        self.theme_cb.configure(values=themes)
        if not keep_theme or self.theme.get() not in themes:
            self.theme.set("random")
        if self.title_v.get().strip().upper() in DEFAULT_TITLES:
            self.title_v.set("")
        self.help.set(GAME_HELP[code])
        for w in self.extra.winfo_children():
            w.destroy()
        if code == "territory":
            self._combo(self.extra, "Starting layout", self.layout, ["random", "voronoi", "blocks", "bands"], 0, 0)
            self._combo(self.extra, "Arena shape", self.shape, ["random", "square", "circle", "diamond", "plus"], 0, 2)

    def _music_pick(self, _e=None):
        if self.music.get() == "My own WAV…":
            p = filedialog.askopenfilename(title="Music (WAV, copyright-free)", filetypes=[("WAV audio", "*.wav")])
            if p:
                self.music_file = p
                self.music.set("My own WAV…")
            else:
                self.music.set("Built-in music")

    # ------------------------------------------------ settings
    def _settings(self):
        return {"game": self.game.get(), "theme": self.theme.get(), "title": self.title_v.get(),
                "handle": self.handle.get(), "vibe": self.vibe.get(), "music": self.music.get(),
                "music_file": self.music_file, "tmin": self.tmin.get(), "tmax": self.tmax.get(),
                "count": self.count.get(), "quality": self.quality.get(), "out": self.out.get(),
                "background": self.bg_style.get(), "layout": self.layout.get(), "shape": self.shape.get(),
                "racers": [r.spec() for r in self.rows]}

    def _load(self):
        try:
            with open(SETTINGS, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    # ------------------------------------------------ run
    def start(self):
        if self.game.get() not in GAME_NAMES:
            messagebox.showinfo("Race Studio", "That game isn't built yet. Pick Maze Race for now.")
            return
        try:
            s = self._settings()
        except ValueError as e:
            messagebox.showwarning("Race Studio", str(e))
            return
        lo = MIN_RACERS[GAME_NAMES[s["game"]]]
        if not lo <= len(s["racers"]) <= 8:
            messagebox.showwarning("Race Studio", f"Use {lo} to 8 racers for this game.")
            return
        if s["tmax"] <= s["tmin"] + 5:
            messagebox.showwarning("Race Studio", "Make the 'to' time at least 6 seconds more than 'from'.")
            return
        os.makedirs(os.path.dirname(SETTINGS), exist_ok=True)
        with open(SETTINGS, "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=1)
        cfg = {"title": s["title"].strip().upper(), "handle": s["handle"], "racers": s["racers"],
               "race_seconds": [s["tmin"], s["tmax"]]}
        if s["theme"] != "random":
            cfg["theme"] = s["theme"]
        if s["background"] != "random":
            cfg["background"] = s["background"]
        if GAME_NAMES[s["game"]] == "territory":
            if s["layout"] != "random":
                cfg["layout"] = s["layout"]
            if s["shape"] != "random":
                cfg["shape"] = s["shape"]
        if s["vibe"] != "random":
            cfg["vibe"] = s["vibe"]
        run_cfg = os.path.join(HERE, "config", "_gui_run.json")
        with open(run_cfg, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False)
        cmd = [sys.executable.replace("pythonw", "python"), "-u", os.path.join(HERE, "make.py"),
               GAME_NAMES[s["game"]], "--config", run_cfg, "--count", str(s["count"]),
               "--quality", s["quality"], "--out", s["out"]]
        if s["music"] == "No music":
            cmd += ["--music", "off"]
        elif s["music"] == "My own WAV…" and s["music_file"]:
            cmd += ["--music", s["music_file"]]
        self.total = s["count"]
        self.done = 0
        self.prog["value"] = 0
        self.log.delete("1.0", "end")
        self.status.set("Starting…")
        self.go.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        flags = 0x08000000 if os.name == "nt" else 0  # no console window
        self.proc = subprocess.Popen(cmd, cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     text=True, encoding="utf-8", errors="replace", env=env, creationflags=flags)
        threading.Thread(target=self._reader, args=(self.proc,), daemon=True).start()

    def _reader(self, proc):
        for line in proc.stdout:
            self.q.put(line.rstrip())
        proc.wait()
        self.q.put(("__END__", proc.returncode))

    # ------------------------------------------------ updates
    def check_updates(self, manual=False):
        self.ver_label.set(f"Version {updater.current_version()} · checking…")

        def work():
            try:
                ok, info = updater.check()
                self.q.put(("__UPD__", ok, info, manual, None))
            except Exception as e:  # offline, repo not ready, etc.
                self.q.put(("__UPD__", False, None, manual, str(e)))
        threading.Thread(target=work, daemon=True).start()

    def _update_result(self, ok, info, manual, err):
        cur = updater.current_version()
        if err:
            self.ver_label.set(f"Version {cur}")
            if manual:
                messagebox.showwarning("Race Studio", "Couldn't check for updates right now.\nCheck your internet and try again.")
            return
        if not ok:
            self.ver_label.set(f"Version {cur} · up to date")
            if manual:
                messagebox.showinfo("Race Studio", f"You're on the latest version ({cur}).")
            return
        self.ver_label.set(f"Version {cur} · update {info['version']} available")
        notes = info.get("notes", "")
        if messagebox.askyesno("Update available", f"Race Studio {info['version']} is ready.\n\n{notes}\n\nUpdate now? (takes a few seconds)"):
            if self.proc:
                messagebox.showinfo("Race Studio", "Wait until the current videos finish, then try again.")
                return
            try:
                updater.apply(info)
            except Exception as e:
                messagebox.showerror("Race Studio", f"Update failed: {e}\nYou can download it again from:\n{updater.DOWNLOAD_PAGE}")
                return
            messagebox.showinfo("Race Studio", "Updated! Race Studio will close now.\nOpen it again to use the new version.")
            self.close()

    def poll(self):
        try:
            while True:
                item = self.q.get_nowait()
                if isinstance(item, tuple) and item[0] == "__UPD__":
                    self._update_result(*item[1:])
                    continue
                if isinstance(item, tuple):
                    self._finished(item[1])
                    continue
                self._handle(item)
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

    def _handle(self, line):
        if "ALSA" in line:
            return
        m = re.match(r"PROGRESS (\d+) (\d+)", line)
        if m:
            cur, tot = int(m.group(1)), max(1, int(m.group(2)))
            frac = min(1, cur / tot)
            self.prog["value"] = (self.done + frac) / self.total * 100
            self.status.set(f"Video {self.done + 1} of {self.total}: rendering {int(frac * 100)}%")
            return
        self.log.insert("end", line + "\n")
        self.log.see("end")
        m = re.search(r"-> (.+?\.mp4)", line)
        if m:
            self.done += 1
            self.last_video = m.group(1).strip()
            if not os.path.isabs(self.last_video):
                self.last_video = os.path.join(HERE, self.last_video)
            self.play_btn.configure(state="normal")
            self.prog["value"] = self.done / self.total * 100
        elif line.startswith("["):
            self.status.set(f"Video {self.done + 1} of {self.total}: designing the level…")

    def _finished(self, code):
        self.go.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        if code == 0:
            self.status.set(f"Done! {self.done} video(s) saved.")
            self.prog["value"] = 100
        elif self.proc is None:
            self.status.set("Stopped.")
        else:
            self.status.set("Something went wrong. See the log below.")
        self.proc = None

    def stop(self):
        if self.proc:
            p, self.proc = self.proc, None
            p.kill()

    def open_out(self):
        os.makedirs(self.out.get(), exist_ok=True)
        _open(self.out.get())

    def play_last(self):
        if self.last_video and os.path.exists(self.last_video):
            _open(self.last_video)

    def close(self):
        self.stop()
        self.root.destroy()


def _open(path):
    if os.name == "nt":
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
