"""Game 4: Color Territory War.

The board is split between the racers. Each racer's ball can only fly
through its own colour; when it hits another colour, that tile flips to its
colour and the ball bounces. Power-ups spawn extra balls or speed boosts.
When the timer runs out, the biggest territory wins.
"""
import math
import random

from engine.video import pygame
from engine import visual as V
from games.maze import W, H, _wrap, _draw_winner

THEMES = {
    "clean": {"bg1": "#101321", "bg2": "#2a3150", "frame": "#f4f6fb", "shade": 0.9},
    "dark": {"bg1": "#050507", "bg2": "#1c1c24", "frame": "#3a3a48", "shade": 0.85},
    "pastel": {"bg1": "#2b2140", "bg2": "#6b4f8a", "frame": "#fff7fb", "shade": 0.93},
    "neon": {"bg1": "#03030a", "bg2": "#170f3a", "frame": "#00e5ff", "shade": 0.8},
}

CELL = 30
COLS, ROWS = 32, 40
BX, BY = (W - COLS * CELL) // 2, 380
WALL = -1


def make_grid(n, rng, layout, shape):
    g = [[0] * COLS for _ in range(ROWS)]
    if layout == "voronoi":
        pts = [(rng.uniform(4, COLS - 4), rng.uniform(4, ROWS - 4)) for _ in range(n)]
        for r in range(ROWS):
            for c in range(COLS):
                g[r][c] = min(range(n), key=lambda i: (c - pts[i][0]) ** 2 + (r - pts[i][1]) ** 2)
    elif layout == "bands":
        for r in range(ROWS):
            for c in range(COLS):
                g[r][c] = min(n - 1, r * n // ROWS)
    else:  # blocks
        cols = 2 if n <= 4 else 2 if n <= 6 else 2
        rows = math.ceil(n / cols)
        for r in range(ROWS):
            for c in range(COLS):
                i = (r * rows // ROWS) * cols + (c * cols // COLS)
                g[r][c] = min(i, n - 1)
    cx, cy = (COLS - 1) / 2, (ROWS - 1) / 2
    for r in range(ROWS):
        for c in range(COLS):
            dx, dy = (c - cx) / (COLS / 2), (r - cy) / (ROWS / 2)
            if shape == "circle" and dx * dx + dy * dy > 1.0:
                g[r][c] = WALL
            elif shape == "diamond" and abs(dx) + abs(dy) > 1.15:
                g[r][c] = WALL
            elif shape == "plus" and abs(dx) > 0.42 and abs(dy) > 0.42:
                g[r][c] = WALL
    return g


class Ball:
    def __init__(self, owner, x, y, ang, speed):
        self.owner = owner
        self.x, self.y = x, y
        self.vx, self.vy = math.cos(ang) * speed, math.sin(ang) * speed
        self.boost = 0.0
        self.squash = 0.0


class Sim:
    def __init__(self, n, seed, layout, shape, speed=660, r=19, sound=None, fx=None, colors=None):
        self.rng = random.Random(seed * 7 + 1)
        self.n = n
        self.g = make_grid(n, self.rng, layout, shape)
        self.speed = speed
        self.r = r
        self.sound = sound
        self.fx = fx
        self.colors = colors
        self.balls = []
        self.flips = []  # (r, c) changed since last draw
        self.counts = [0] * n
        for row in self.g:
            for v in row:
                if v >= 0:
                    self.counts[v] += 1
        self.total = sum(self.counts)
        per = 2 if n <= 4 else 1
        for i in list(range(n)) * per:
            cells = [(r_, c_) for r_ in range(ROWS) for c_ in range(COLS) if self.g[r_][c_] == i]
            # start near the middle of its territory, away from edges
            cells.sort(key=lambda rc: self._edge_score(rc, i), reverse=True)
            r_, c_ = cells[self.rng.randrange(min(len(cells), 12))] if cells else (ROWS // 2, COLS // 2)
            self.balls.append(Ball(i, BX + (c_ + 0.5) * CELL, BY + (r_ + 0.5) * CELL,
                                   self.rng.uniform(0, 2 * math.pi), speed))
        for b in self.balls:
            self._fix_angle(b)
        self.powerups = []
        self.next_power = 5.0
        self.popups = []

    def _edge_score(self, rc, i):
        r_, c_ = rc
        k = 0
        for d in range(1, 6):
            for dr, dc in ((d, 0), (-d, 0), (0, d), (0, -d)):
                rr, cc = r_ + dr, c_ + dc
                if 0 <= rr < ROWS and 0 <= cc < COLS and self.g[rr][cc] == i:
                    k += 1
        return k + self.rng.random() * 0.1

    def _fix_angle(self, b):
        sp = math.hypot(b.vx, b.vy) or 1
        vx, vy = b.vx / sp, b.vy / sp
        m = 0.3
        if abs(vx) < m:
            vx = math.copysign(m, vx or 1)
        if abs(vy) < m:
            vy = math.copysign(m, vy or 1)
        k = math.hypot(vx, vy)
        s = self.speed * (1.45 if b.boost > 0 else 1.0)
        b.vx, b.vy = vx / k * s, vy / k * s

    def _cells(self, x, y):
        r = self.r - 0.01
        c0, c1 = int((x - r - BX) // CELL), int((x + r - BX) // CELL)
        r0, r1 = int((y - r - BY) // CELL), int((y + r - BY) // CELL)
        for rr in range(r0, r1 + 1):
            for cc in range(c0, c1 + 1):
                yield rr, cc

    def _ev(self, now, kind, b, **kw):
        if self.sound is not None:
            self.sound.add(now, kind, who=b.owner, pan=0.15 + 0.7 * b.x / W, **kw)

    def step(self, dt, now):
        for b in self.balls:
            b.squash *= math.exp(-dt / 0.06)
            if b.boost > 0:
                b.boost -= dt
                if b.boost <= 0:
                    self._fix_angle(b)
            for axis in (0, 1):
                if axis == 0:
                    b.x += b.vx * dt
                else:
                    b.y += b.vy * dt
                hit = False
                flipped = 0
                for rr, cc in self._cells(b.x, b.y):
                    if not (0 <= rr < ROWS and 0 <= cc < COLS) or self.g[rr][cc] == WALL:
                        hit = True
                        continue
                    o = self.g[rr][cc]
                    if o != b.owner:
                        hit = True
                        self.g[rr][cc] = b.owner
                        self.counts[o] -= 1
                        self.counts[b.owner] += 1
                        self.flips.append((rr, cc))
                        flipped += 1
                if hit:
                    if axis == 0:
                        b.x -= b.vx * dt
                        b.vx = -b.vx
                        b.squash = -1
                    else:
                        b.y -= b.vy * dt
                        b.vy = -b.vy
                        b.squash = 1
                    a = math.atan2(b.vy, b.vx) + math.radians(self.rng.uniform(-6, 6))
                    sp = math.hypot(b.vx, b.vy)
                    b.vx, b.vy = math.cos(a) * sp, math.sin(a) * sp
                    self._fix_angle(b)
                    if flipped:
                        self._ev(now, "bounce", b, min_gap=0.055)
        self._powerups(dt, now)

    def _powerups(self, dt, now):
        self.next_power -= dt
        if self.next_power <= 0:
            self.next_power = self.rng.uniform(5, 8)
            for _ in range(30):
                r_, c_ = self.rng.randrange(2, ROWS - 2), self.rng.randrange(2, COLS - 2)
                if self.g[r_][c_] != WALL:
                    kind = self.rng.choice(["split", "split", "speed"])
                    self.powerups.append({"x": BX + (c_ + 0.5) * CELL, "y": BY + (r_ + 0.5) * CELL,
                                          "kind": kind, "age": 0.0})
                    break
        for p in self.powerups:
            p["age"] += dt
        for p in list(self.powerups):
            for b in self.balls:
                if math.hypot(b.x - p["x"], b.y - p["y"]) < self.r + 22:
                    self.powerups.remove(p)
                    self._ev(now, "boost", b)
                    if p["kind"] == "split" and sum(1 for o in self.balls if o.owner == b.owner) < 4:
                        nb = Ball(b.owner, b.x, b.y, self.rng.uniform(0, 2 * math.pi), self.speed)
                        self._fix_angle(nb)
                        self.balls.append(nb)
                        self.popups.append([p["x"], p["y"], "+1 BALL", b.owner, 0.0])
                    else:
                        b.boost = 4.0
                        self._fix_angle(b)
                        self.popups.append([p["x"], p["y"], "SPEED!", b.owner, 0.0])
                    if self.fx is not None and self.colors:
                        self.fx.burst(p["x"], p["y"], self.colors[b.owner], n=22, speed=420)
                    break
        self.powerups = [p for p in self.powerups if p["age"] < 9]

    def leader(self):
        return max(range(self.n), key=lambda i: self.counts[i])


# ---------------------------------------------------------------- render

def render(cfg, out_path, sound):
    import os
    from engine.video import VideoWriter
    from engine import backgrounds
    th = THEMES.get(cfg.get("theme", "clean"), THEMES["clean"])
    T = {"bg1": V.hexc(th["bg1"]), "bg2": V.hexc(th["bg2"]), "frame": V.hexc(th["frame"])}
    fps = cfg.get("fps", 60)
    seed = cfg["seed"]
    rng = random.Random(seed)
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [30, 50])
    race_len = round((t_min + t_max) / 2)
    layout = cfg.get("layout") or rng.choice(["voronoi", "voronoi", "blocks", "bands"])
    shape = cfg.get("shape") or rng.choice(["square", "square", "circle", "diamond", "plus"])
    print(f"  layout {layout}, arena {shape}, {race_len}s battle")
    pygame.display.init()
    pygame.font.init()
    pygame.display.set_mode((1, 1))
    canvas = pygame.Surface((W, H))
    looks = [V.Look(s, 40) for s in cfg["racers"]]
    colors = [lk.color for lk in looks]
    fx = V.Particles(random.Random(seed))
    S = Sim(n, seed, layout, shape, sound=sound, fx=fx, colors=colors)
    bg, _ = backgrounds.make(W, H, T["bg1"], T["bg2"], cfg.get("background"), seed)
    title_lines = _wrap(cfg.get("title") or "WHICH COLOUR TAKES OVER?", 22)
    handle = cfg.get("handle", "")
    board = pygame.Surface((COLS * CELL, ROWS * CELL), pygame.SRCALPHA)
    shade = th["shade"]
    cell_cols = [(c, V.darker(c, shade)) for c in colors]

    def paint(r_, c_):
        o = S.g[r_][c_]
        rect = pygame.Rect(c_ * CELL, r_ * CELL, CELL, CELL)
        if o == WALL:
            board.fill((0, 0, 0, 0), rect)
        else:
            board.fill(cell_cols[o][(r_ + c_) % 2], rect)

    for r_ in range(ROWS):
        for c_ in range(COLS):
            paint(r_, c_)
    writer = VideoWriter(out_path, W, H, fps, cfg.get("quality", "good"))
    dt = 1 / fps
    sub = max(1, round(240 / fps))
    count_in = 1.5
    end_len = 4.2
    for m in (0.0, 0.5, 1.0):
        sound.add(m, "count")
    sound.add(count_in, "go")
    for k in range(5, 0, -1):
        sound.add(count_in + race_len - k, "count")
    frame = 0
    win_time = None
    winner = None
    while True:
        t = frame * dt
        race_t = t - count_in
        if 0 <= race_t < race_len:
            for i in range(sub):
                S.step(dt / sub, t + i * dt / sub)
        elif race_t >= race_len and win_time is None:
            win_time = t
            winner = S.leader()
            sound.add(t, "win")
            fx.confetti(W)
        for rc in S.flips:
            paint(*rc)
            pygame.draw.rect(board, (255, 255, 255, 120), pygame.Rect(rc[1] * CELL, rc[0] * CELL, CELL, CELL))
        flashed = S.flips
        S.flips = []
        fx.update(dt)
        # ------------------------------------------------ draw
        canvas.blit(bg, (0, 0))
        frame_rect = pygame.Rect(BX - 10, BY - 10, COLS * CELL + 20, ROWS * CELL + 20)
        if shape == "square":
            pygame.draw.rect(canvas, (0, 0, 0), frame_rect.move(6, 10), border_radius=14)
            pygame.draw.rect(canvas, T["frame"], frame_rect, border_radius=14)
        canvas.blit(board, (BX, BY))
        for rr, cc in flashed:  # repaint so the white flash lasts one frame
            paint(rr, cc)
        for p in S.powerups:
            pulse = 1 + 0.15 * math.sin(p["age"] * 8)
            col = (255, 230, 60) if p["kind"] == "split" else (80, 230, 255)
            pygame.draw.circle(canvas, (20, 20, 30), (round(p["x"]), round(p["y"])), round(19 * pulse))
            pygame.draw.circle(canvas, col, (round(p["x"]), round(p["y"])), round(16 * pulse))
            V.blit_center(canvas, V.text("+" if p["kind"] == "split" else ">>", 24, (20, 20, 30), None), p["x"], p["y"] - 1)
        for b in S.balls:
            lk = looks[b.owner]
            x, y = b.x, b.y
            if lk.kind == "square":
                pygame.draw.circle(canvas, (255, 255, 255), (round(x), round(y)), S.r + 4)
                lk.draw_ball(canvas, x, y, S.r + 1, b.vx, b.vy)
            else:
                pygame.draw.circle(canvas, (255, 255, 255), (round(x), round(y)), S.r + 6)
                lk.draw_ball(canvas, x, y, S.r + 4)
        fx.draw(canvas)
        for pp in S.popups:
            pp[4] += dt
            a = pp[4]
            if a < 1.0:
                V.blit_center(canvas, V.text(pp[2], 44, colors[pp[3]], (255, 255, 255), 5), pp[0], pp[1] - 40 - a * 60)
        S.popups = [pp for pp in S.popups if pp[4] < 1.0]
        y = 110
        for line in title_lines:
            V.blit_center(canvas, V.text(line, 62, (255, 255, 255), (15, 15, 25), 7), W / 2, y)
            y += 78
        left = max(0.0, race_len - max(0.0, race_t))
        if win_time is None:
            tc = (255, 80, 80) if left <= 5 else (255, 230, 60)
            size = 54 if left > 5 else int(54 + 18 * (1 - (left % 1)))
            V.blit_center(canvas, V.text(f"0:{int(math.ceil(left)):02d}" if left < 60 else f"{int(left // 60)}:{int(left % 60):02d}", size, tc, (15, 15, 25), 5), W / 2, y + 6)
        _bars(canvas, S, looks)
        if handle:
            V.blit_center(canvas, V.text(handle, 30, (255, 255, 255), (0, 0, 0), 3, "Medium"), W / 2, 1840)
        if t < count_in:
            k = min(2, int(t / 0.5))
            sc = 1.6 - 0.6 * min(1, (t % 0.5) / 0.5 * 3)
            V.blit_center(canvas, V.text(str(3 - k), int(240 * sc), (255, 255, 255), (15, 15, 25), 14), W / 2, BY + ROWS * CELL / 2)
        elif 0 <= race_t < 0.45:
            V.blit_center(canvas, V.text("GO!", int(220 * (1 + race_t)), (255, 230, 60), (15, 15, 25), 14), W / 2, BY + ROWS * CELL / 2)
        if win_time is not None:
            pct = 100 * S.counts[winner] / S.total
            _draw_winner(canvas, _Fake(looks[winner]), t - win_time + 0.8, T, line3=f"{pct:.0f}% of the board")
        writer.write(canvas)
        frame += 1
        if frame % 30 == 0:
            print(f"PROGRESS {frame} {int((race_len + count_in + end_len) * fps)}", flush=True)
        if win_time is not None and t - win_time >= end_len:
            break
    duration = frame * dt
    wav = out_path + ".wav"
    sound.render(duration, wav)
    writer.close(wav)
    os.remove(wav)
    pygame.quit()
    return {"duration": duration, "winner": looks[winner].name, "level": seed}


class _Fake:
    def __init__(self, look):
        self.look = look


def _bars(dst, S, looks):
    n = S.n
    x0, w = 70, W - 140
    y = 1640
    h = 34
    order = sorted(range(n), key=lambda i: -S.counts[i])
    x = x0
    pygame.draw.rect(dst, (0, 0, 0), pygame.Rect(x0 - 4, y - 4, w + 8, h + 8), border_radius=12)
    for i in order:
        seg = w * S.counts[i] / S.total
        if seg >= 1:
            pygame.draw.rect(dst, looks[i].color, pygame.Rect(round(x), y, math.ceil(seg), h))
        x += seg
    slot = min(130, (W - 80) // n)
    xs = W / 2 - slot * (n - 1) / 2
    for k, i in enumerate(order):
        cx = xs + k * slot
        V.blit_center(dst, looks[i].badge(int(slot * 0.45)), cx, y + 85)
        V.blit_center(dst, V.text(f"{100 * S.counts[i] / S.total:.0f}%", 32, (255, 255, 255), (0, 0, 0), 3), cx, y + 140)
