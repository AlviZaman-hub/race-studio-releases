"""Game 1: Square Maze Race.

Racers bounce at constant speed through a zig-zag maze. Numbered blocks
seal some of the passages and lose 1 point per hit; spikes send a racer
back to the start of its lane; the first racer to touch the checkered
flag wins.

Every race is generated from a seed and auto-tuned so the race lasts
inside the target time window.
"""
import math
import random
from collections import deque

from engine.video import pygame
from engine import visual as V

EMPTY, WALL, SPIKE, FINISH = 0, 1, 2, 3

THEMES = {
    "ocean": {"bg1": "#0b1a3a", "bg2": "#1b4a8a", "paper": "#eef6ff", "grid": "#d7e6f7",
              "wall": "#2456c8", "wall_hi": "#5d8cf0", "block": "#ffb020", "block_txt": "#3a2200"},
    "jungle": {"bg1": "#0b2a17", "bg2": "#1f6a3a", "paper": "#effbe9", "grid": "#d6efcb",
               "wall": "#1f8a3c", "wall_hi": "#57c46f", "block": "#ff6b5b", "block_txt": "#3a0c06"},
    "candy": {"bg1": "#3a0b33", "bg2": "#8a2b72", "paper": "#fff2fa", "grid": "#f6d7ea",
              "wall": "#d9368b", "wall_hi": "#ff7cbc", "block": "#45c7ff", "block_txt": "#062a3a"},
    "night": {"bg1": "#07070f", "bg2": "#1d1b3a", "paper": "#1c1f33", "grid": "#262a44",
              "wall": "#7b5cff", "wall_hi": "#b29dff", "block": "#22e3a1", "block_txt": "#05301f"},
    "lava": {"bg1": "#1a0500", "bg2": "#5a1a05", "paper": "#fff4ea", "grid": "#f6dcc6",
             "wall": "#e2461b", "wall_hi": "#ff8a4c", "block": "#ffd400", "block_txt": "#3a2a00"},
    "ice": {"bg1": "#06202e", "bg2": "#1a6a8a", "paper": "#f2fbff", "grid": "#d4eef8",
            "wall": "#2aa8d8", "wall_hi": "#8fe0ff", "block": "#ff5c8a", "block_txt": "#3a0614"},
    "retro": {"bg1": "#1b1a2e", "bg2": "#3a2f5b", "paper": "#fdf6e3", "grid": "#efe3c4",
              "wall": "#2b2b2b", "wall_hi": "#5a5a5a", "block": "#ff6f3c", "block_txt": "#2b0d00"},
    "mint": {"bg1": "#062a24", "bg2": "#0f6b5c", "paper": "#f0fffa", "grid": "#cdf2e6",
             "wall": "#13a383", "wall_hi": "#5be0bf", "block": "#7a5cff", "block_txt": "#ffffff"},
}

W, H = 1080, 1920
TILE = 40
COLS, ROWS = 25, 31
BX, BY = 40, 360  # board top-left on screen


# ====================================================================== level

class Level:
    def __init__(self, seed, n_gates=None, lanes=None):
        rng = random.Random(seed)
        self.rng = rng
        g = [[EMPTY] * COLS for _ in range(ROWS)]
        for r in range(ROWS):
            g[r][0] = g[r][COLS - 1] = WALL
        for c in range(COLS):
            g[0][c] = g[ROWS - 1][c] = WALL
        # --- lanes separated by wall rows, openings zig-zag left/right
        k = rng.choice(lanes or [4, 5, 5])
        inner = ROWS - 2 - (k - 1)
        heights = [inner // k] * k
        for i in range(inner - sum(heights)):
            heights[i % k] += 1
        for _ in range(3):  # vary lane heights a little
            a, b = rng.sample(range(k), 2)
            if heights[a] > 4:
                heights[a] -= 1
                heights[b] += 1
        self.lanes = []  # (top_row, bottom_row)
        r = 1
        seps = []
        for i, h in enumerate(heights):
            self.lanes.append((r, r + h - 1))
            r += h
            if i < k - 1:
                seps.append(r)
                for c in range(COLS):
                    g[r][c] = WALL
                r += 1
        self.gaps = []  # (sep_row, c0, c1, side)
        side = "R"
        for sr in seps:
            gw = rng.choice([3, 3, 4])
            c0, c1 = (COLS - 1 - gw, COLS - 2) if side == "R" else (1, gw)
            for c in range(c0, c1 + 1):
                g[sr][c] = EMPTY
            self.gaps.append((sr, c0, c1, side))
            side = "L" if side == "R" else "R"
        self.start_side = "L"
        self.finish_side = side  # far end of last lane
        # --- finish 2x2 at far end of the last lane (vertically centred)
        lt, lb = self.lanes[-1]
        fr = (lt + lb) // 2
        fc = COLS - 3 if self.finish_side == "R" else 1
        self.finish = [(fc, fr), (fc + 1, fr), (fc, fr + 1), (fc + 1, fr + 1)]
        for c, rr in self.finish:
            g[rr][c] = FINISH

        def near_gap(c, lane_i):
            for sr, c0, c1, s in self.gaps:
                if abs(sr - self.lanes[lane_i][0]) <= 1 or abs(sr - self.lanes[lane_i][1]) <= 1:
                    if c0 - 4 <= c <= c1 + 4:
                        return True
            return False

        # --- wall stubs inside lanes for bouncier paths
        for li, (t, b) in enumerate(self.lanes):
            h = b - t + 1
            for _ in range(rng.choice([1, 2, 2, 3])):
                c = rng.randint(5, COLS - 6)
                if near_gap(c, li) or (li == len(self.lanes) - 1 and abs(c - fc) < 5):
                    continue
                ln = rng.randint(1, max(1, h - 3))
                if rng.random() < 0.5:
                    for rr in range(t, t + ln):
                        g[rr][c] = WALL
                else:
                    for rr in range(b - ln + 1, b + 1):
                        g[rr][c] = WALL
        # --- spikes on lane floors / ceilings
        for li, (t, b) in enumerate(self.lanes):
            if li == 0:
                continue
            for _ in range(rng.choice([0, 1, 1, 2])):
                ln = rng.randint(2, 3)
                c = rng.randint(4, COLS - 5 - ln)
                if any(near_gap(cc, li) for cc in range(c, c + ln)):
                    continue
                if li == len(self.lanes) - 1 and abs(c - fc) < 6:
                    continue
                rr = b if rng.random() < 0.6 else t
                if all(g[rr][cc] == EMPTY for cc in range(c, c + ln)):
                    for cc in range(c, c + ln):
                        g[rr][cc] = SPIKE
        self.grid = g
        # --- numbered gate blocks in some openings (gap row + row above)
        n_gates = n_gates if n_gates is not None else rng.choice([1, 2, 2, 3])
        n_gates = min(n_gates, len(self.gaps))
        gated = sorted(rng.sample(range(len(self.gaps)), n_gates))
        self.blocks = []
        for gi in gated:
            sr, c0, c1, s = self.gaps[gi]
            tiles = [(c, rr) for c in range(c0, c1 + 1) for rr in (sr - 1, sr)]
            self.blocks.append({"tiles": tiles, "hp": rng.randint(20, 45), "max": 0,
                                "alive": True, "flash": 0.0, "pulse": 0.0,
                                "rect": pygame.Rect(BX + c0 * TILE, BY + (sr - 1) * TILE,
                                                    (c1 - c0 + 1) * TILE, 2 * TILE)})
        for b in self.blocks:
            b["max"] = b["hp"]
        self._rebuild_blockmap()
        self.dist = self._distance_field()

    def _rebuild_blockmap(self):
        self.blockmap = {}
        for i, b in enumerate(self.blocks):
            if b["alive"]:
                for t in b["tiles"]:
                    self.blockmap[t] = i

    def set_hp(self, values):
        for b, v in zip(self.blocks, values):
            b["hp"] = b["max"] = max(1, int(v))

    def _distance_field(self):
        d = [[10 ** 6] * COLS for _ in range(ROWS)]
        q = deque()
        for c, r in self.finish:
            d[r][c] = 0
            q.append((c, r))
        while q:
            c, r = q.popleft()
            for dc, dr in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nc, nr = c + dc, r + dr
                if 0 <= nc < COLS and 0 <= nr < ROWS and self.grid[nr][nc] != WALL and d[nr][nc] > d[r][c] + 1:
                    d[nr][nc] = d[r][c] + 1
                    q.append((nc, nr))
        return d

    def lane_of(self, row):
        for i, (t, b) in enumerate(self.lanes):
            if t - 1 <= row <= b:
                return i
        return len(self.lanes) - 1

    def checkpoint(self, lane_i):
        """Where a racer respawns: entrance of its lane (screen coords)."""
        t, b = self.lanes[lane_i]
        if lane_i == 0:
            return BX + 3 * TILE, BY + (t + 1.5) * TILE
        sr, c0, c1, s = self.gaps[lane_i - 1]
        return BX + ((c0 + c1 + 1) / 2) * TILE, BY + (t + 1.4) * TILE


# ====================================================================== sim

class Racer:
    def __init__(self, idx, look, x, y, vx, vy):
        self.i = idx
        self.look = look
        self.x, self.y = x, y
        self.vx, self.vy = vx, vy
        self.dead = 0.0  # respawn countdown
        self.squash = 0.0
        self.trail = deque(maxlen=12)
        self.finished = False


class Sim:
    def __init__(self, level, looks, seed, speed=640, size=56, sound=None, fx=None):
        self.L = level
        self.rng = random.Random(seed * 7919 + 13)
        self.speed = speed
        self.half = size / 2
        self.sound = sound
        self.fx = fx  # particles (visual only)
        self.shake = 0.0
        self.winner = None
        self.racers = []
        t, b = level.lanes[0]
        y = BY + (t + (b - t + 1) / 2) * TILE
        for i, lk in enumerate(looks):
            x = BX + TILE * 1.2 + self.half + i * (size + 14)
            a = math.radians(self.rng.uniform(25, 65)) * (1 if i % 2 else -1)
            self.racers.append(Racer(i, lk, x, y, math.cos(a) * speed, math.sin(a) * speed))

    # --------------------------------------------------- collision helpers
    def _tiles_hit(self, x, y):
        h = self.half - 0.01
        c0, c1 = int((x - h - BX) // TILE), int((x + h - BX) // TILE)
        r0, r1 = int((y - h - BY) // TILE), int((y + h - BY) // TILE)
        out = []
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                if not (0 <= c < COLS and 0 <= r < ROWS):
                    out.append(("wall", c, r))
                    continue
                v = self.L.grid[r][c]
                if (c, r) in self.L.blockmap:
                    out.append(("block", c, r))
                elif v == WALL:
                    out.append(("wall", c, r))
                elif v == SPIKE:
                    out.append(("spike", c, r))
                elif v == FINISH:
                    out.append(("finish", c, r))
        return out

    def _nudge(self, R):
        """Small random angle change on bounce so races never loop."""
        a = math.atan2(R.vy, R.vx) + math.radians(self.rng.uniform(-7, 7))
        vx, vy = math.cos(a), math.sin(a)
        m = 0.28
        if abs(vx) < m:
            vx = math.copysign(m, vx or 1)
        if abs(vy) < m:
            vy = math.copysign(m, vy or 1)
        n = math.hypot(vx, vy)
        R.vx, R.vy = vx / n * self.speed, vy / n * self.speed

    def _event(self, now, kind, R=None, x=None, **kw):
        if self.sound is not None:
            px = (x if x is not None else (R.x if R else W / 2)) / W
            self.sound.add(now, kind, who=R.i if R else None, pan=0.15 + 0.7 * px, **kw)

    # --------------------------------------------------- step
    def step(self, dt, now):
        for R in self.racers:
            R.squash *= math.exp(-dt / 0.07)
            if R.dead > 0:
                R.dead -= dt
                if R.dead <= 0:
                    lane = self.L.lane_of(int((R.y - BY) // TILE))
                    R.x, R.y = self.L.checkpoint(lane)
                    a = math.radians(self.rng.uniform(30, 60)) * self.rng.choice([1, -1])
                    R.vx, R.vy = math.cos(a) * self.speed, abs(math.sin(a)) * self.speed
                    self._event(now, "spawn", R)
                continue
            for axis in (0, 1):
                if axis == 0:
                    R.x += R.vx * dt
                else:
                    R.y += R.vy * dt
                hits = self._tiles_hit(R.x, R.y)
                if not hits:
                    continue
                kinds = {h[0] for h in hits}
                if "finish" in kinds and self.winner is None:
                    self.winner = R
                    R.finished = True
                    self._event(now, "win", R)
                    return
                if "spike" in kinds and not kinds & {"wall", "block"}:
                    self._die(R, now)
                    break
                solid = [h for h in hits if h[0] in ("wall", "block")]
                if not solid:
                    if "spike" in kinds:
                        self._die(R, now)
                        break
                    continue
                if axis == 0:
                    if R.vx > 0:
                        edge = min(BX + h[1] * TILE for h in solid)
                        R.x = edge - self.half - 0.01
                    else:
                        edge = max(BX + (h[1] + 1) * TILE for h in solid)
                        R.x = edge + self.half + 0.01
                    R.vx = -R.vx
                    R.squash = -1.0
                else:
                    if R.vy > 0:
                        edge = min(BY + h[2] * TILE for h in solid)
                        R.y = edge - self.half - 0.01
                    else:
                        edge = max(BY + (h[2] + 1) * TILE for h in solid)
                        R.y = edge + self.half + 0.01
                    R.vy = -R.vy
                    R.squash = 1.0
                self._nudge(R)
                blocks = {self.L.blockmap[(h[1], h[2])] for h in solid if h[0] == "block"}
                if blocks:
                    for bi in blocks:
                        self._hit_block(bi, R, now)
                else:
                    self._event(now, "bounce", R, min_gap=0.06)
                if "spike" in kinds:
                    self._die(R, now)
                    break
        self._racer_collisions(now)
        self.shake *= math.exp(-dt / 0.12)

    def _hit_block(self, bi, R, now):
        b = self.L.blocks[bi]
        if not b["alive"]:
            return
        b["hp"] -= 1
        b["flash"] = 1.0
        b["pulse"] = 1.0
        if b["hp"] <= 0:
            b["alive"] = False
            self.L._rebuild_blockmap()
            self.shake = 1.0
            self._event(now, "break", R, x=b["rect"].centerx)
            if self.fx:
                rc = b["rect"]
                for k in range(6):
                    self.fx.burst(rc.x + rc.w * (k + 0.5) / 6, rc.centery, self.block_color, n=10, speed=650, size=(10, 22))
        else:
            self._event(now, "hit", R, x=b["rect"].centerx, min_gap=0.035)

    def _die(self, R, now):
        R.dead = 0.8
        self._event(now, "die", R)
        if self.fx:
            self.fx.burst(R.x, R.y, R.look.color, n=26, speed=600)

    def _racer_collisions(self, now):
        rs = [r for r in self.racers if r.dead <= 0]
        s = self.half * 2
        for i in range(len(rs)):
            for j in range(i + 1, len(rs)):
                a, b = rs[i], rs[j]
                dx, dy = b.x - a.x, b.y - a.y
                ox, oy = s - abs(dx), s - abs(dy)
                if ox > 0 and oy > 0:
                    if ox < oy:
                        push = ox / 2 * (1 if dx > 0 else -1)
                        a.x -= push
                        b.x += push
                        a.vx, b.vx = b.vx, a.vx
                        a.squash = b.squash = -0.7
                    else:
                        push = oy / 2 * (1 if dy > 0 else -1)
                        a.y -= push
                        b.y += push
                        a.vy, b.vy = b.vy, a.vy
                        a.squash = b.squash = 0.7
                    self._event(now, "racer", a, x=(a.x + b.x) / 2, min_gap=0.12)

    def ranking(self):
        def key(R):
            if R.finished:
                return -1
            c, r = int((R.x - BX) // TILE), int((R.y - BY) // TILE)
            c, r = min(max(c, 0), COLS - 1), min(max(r, 0), ROWS - 1)
            return self.L.dist[r][c] + (1000 if R.dead > 0 else 0)
        prev = getattr(self, "_prev_rank", {})
        # only swap places when the gap is real (stops the bar flickering)
        order = sorted(self.racers, key=lambda R: (key(R) // 3, prev.get(R.i, 0)))
        self._prev_rank = {R.i: p for p, R in enumerate(order)}
        return order

    block_color = (255, 176, 32)


# ====================================================================== tuning

def tune(seed, n_racers, t_min, t_max, speed, size, n_gates=None, tries=80):
    """Find a level + block numbers whose race length lands in [t_min, t_max].
    Returns (level_seed, block_hp, race_seconds, lanes)."""
    lanes = [3, 3, 4] if t_max <= 30 else [3, 4] if t_max <= 40 else [4, 5, 5] if t_max <= 75 else [5, 6]
    dummy_looks = [None] * n_racers
    best = None
    for attempt in range(tries):
        lseed = seed * 1000 + attempt
        L = Level(lseed, n_gates, lanes)
        hp = [b["hp"] for b in L.blocks]
        for _ in range(8):
            L = Level(lseed, n_gates, lanes)
            L.set_hp(hp)
            S = Sim(L, dummy_looks, lseed, speed, size)
            t, dt = 0.0, 1 / 240
            while S.winner is None and t < t_max * 1.6:
                S.step(dt, t)
                t += dt
            if S.winner is not None:
                miss = max(0, t_min - t, t - t_max)
                if best is None or miss < best[0]:
                    best = (miss, lseed, list(hp), t)
            if S.winner is None or t > t_max:
                if not hp or min(hp) * 0.7 < 12:
                    break  # numbers would get too small -> try a new layout
                hp = [max(1, int(h * 0.7)) for h in hp]
                continue
            if t < t_min:
                if not hp:
                    break
                hp = [int(h * (t_min / t) * 1.25) + 2 for h in hp]
                continue
            return lseed, hp, t, lanes
    if best:
        return best[1], best[2], best[3], lanes
    raise RuntimeError("Could not make a level for that race length, try a longer range")


# ====================================================================== render

def render(cfg, out_path, sound):
    from engine.video import VideoWriter
    theme = THEMES.get(cfg.get("theme", "ocean"), THEMES["ocean"])
    T = {k: V.hexc(v) for k, v in theme.items()}
    fps = cfg.get("fps", 60)
    seed = cfg["seed"]
    racers_spec = cfg["racers"]
    n = len(racers_spec)
    size = cfg.get("racer_size", 60 if n <= 6 else 50)
    t_min, t_max = cfg.get("race_seconds", [30, 50])
    speed = cfg.get("speed", 760 if t_max > 40 else 920)

    lseed, hp, est, lanes = tune(seed, n, t_min, t_max, speed, size, cfg.get("gates"))
    print(f"  level {lseed}: blocks {hp}, race ~{est:.1f}s")

    pygame.display.init()
    pygame.font.init()
    pygame.display.set_mode((1, 1))
    canvas = pygame.Surface((W, H))
    looks = [V.Look(s, size) for s in racers_spec]
    L = Level(lseed, cfg.get("gates"), lanes)
    L.set_hp(hp)
    fx = V.Particles(random.Random(seed))
    S = Sim(L, looks, lseed, speed, size, sound=sound, fx=fx)
    S.block_color = T["block"]

    from engine import backgrounds
    bg, _ = backgrounds.make(W, H, T["bg1"], T["bg2"], cfg.get("background"), seed)
    board = _board_layer(L, T)
    title = cfg.get("title") or "WHO REACHES THE FLAG FIRST?"
    title_lines = _wrap(title, 22)
    handle = cfg.get("handle", "")

    writer = VideoWriter(out_path, W, H, fps, cfg.get("quality", "good"))
    dt = 1 / fps
    sub = max(1, round(240 / fps))
    count_in = 1.5
    frame = 0
    t = 0.0
    phase = "count"
    win_time = None
    rank_x = {R.i: 0.0 for R in S.racers}
    count_marks = [0.0, 0.5, 1.0]
    for k, m in enumerate(count_marks):
        sound.add(m, "count")
    sound.add(count_in, "go")

    end_len = 4.0
    while True:
        t = frame * dt
        # ------------------------------------------------ simulate
        if phase == "count" and t >= count_in:
            phase = "race"
        if phase == "race":
            for i in range(sub):
                S.step(dt / sub, t + i * dt / sub)
                if S.winner:
                    phase = "slowmo"
                    win_time = t
                    fx.confetti(W)
                    break
        elif phase == "slowmo":
            if t - win_time < 0.8:
                for i in range(sub):
                    S.step(dt / sub * 0.25, t + i * dt / sub)
        fx.update(dt)
        for b in L.blocks:
            b["flash"] = max(0, b["flash"] - dt * 6)
            b["pulse"] = max(0, b["pulse"] - dt * 8)
        for R in S.racers:
            if R.dead <= 0 and phase in ("race", "slowmo"):
                R.trail.append((R.x, R.y))
        # ------------------------------------------------ draw
        canvas.blit(bg, (0, 0))
        sx = sy = 0
        if S.shake > 0.02:
            sx = random.Random(frame).uniform(-1, 1) * 14 * S.shake
            sy = random.Random(frame + 1).uniform(-1, 1) * 14 * S.shake
        canvas.blit(board, (BX - 20 + sx, BY - 20 + sy))
        _draw_blocks(canvas, L, T, sx, sy)
        for R in S.racers:
            _draw_trail(canvas, R, T, sx, sy)
        for R in sorted(S.racers, key=lambda r: r is S.winner):
            if R.dead > 0:
                continue
            bob = math.sin(t * 6 + R.i) * 4 if phase == "count" else 0
            R.look.draw(canvas, R.x + sx, R.y + sy + bob, R.vx, R.vy, 1.0, R.squash)
        fx.draw(canvas)
        # title
        y = 120
        for line in title_lines:
            surf = V.text(line, 66, (255, 255, 255), (15, 15, 25), 7)
            V.blit_center(canvas, surf, W / 2, y)
            y += 84
        # leaderboard
        order = S.ranking()
        _draw_leader(canvas, order, rank_x, dt)
        if handle:
            V.blit_center(canvas, V.text(handle, 30, (255, 255, 255), (0, 0, 0), 3, "Medium"), W / 2, BY + ROWS * TILE + 150)
        # countdown
        if phase == "count":
            k = min(2, int(t / 0.5))
            local = (t % 0.5) / 0.5
            sc = 1.6 - 0.6 * min(1, local * 3)
            surf = V.text(str(3 - k), int(260 * sc), (255, 255, 255), (15, 15, 25), 14)
            V.blit_center(canvas, surf, W / 2, BY + ROWS * TILE / 2)
        elif phase == "race" and t - count_in < 0.45:
            a = (t - count_in) / 0.45
            surf = V.text("GO!", int(240 * (1 + a * 0.3)), (255, 230, 60), (15, 15, 25), 14)
            V.blit_center(canvas, surf, W / 2, BY + ROWS * TILE / 2)
        if win_time is not None:
            _draw_winner(canvas, S.winner, t - win_time, T)
        writer.write(canvas)
        frame += 1
        if frame % 30 == 0:
            print(f"PROGRESS {frame} {int((est + count_in + end_len) * fps)}", flush=True)
        if win_time is not None and t - win_time >= end_len:
            break
        if t > t_max * 2.5:
            raise RuntimeError("Race ran too long")
    duration = frame * dt
    wav = out_path + ".wav"
    sound.render(duration, wav)
    writer.close(wav)
    import os
    os.remove(wav)
    pygame.quit()
    return {"duration": duration, "winner": S.winner.look.name, "level": lseed}


# ---------------------------------------------------------------- drawing

def _wrap(s, width):
    words, lines, cur = s.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width and cur:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return lines[:3]


def _background(T):
    s = pygame.Surface((W, H))
    for y in range(H):
        pygame.draw.line(s, V.mix(T["bg1"], T["bg2"], y / H), (0, y), (W, y))
    # soft diagonal stripes
    over = pygame.Surface((W, H), pygame.SRCALPHA)
    for k in range(-H, W + H, 120):
        pygame.draw.polygon(over, (255, 255, 255, 10), [(k, 0), (k + 60, 0), (k + 60 - H, H), (k - H, H)])
    s.blit(over, (0, 0))
    return s


def _board_layer(L, T):
    pad = 20
    s = pygame.Surface((COLS * TILE + pad * 2, ROWS * TILE + pad * 2), pygame.SRCALPHA)
    # shadow + frame
    pygame.draw.rect(s, (0, 0, 0, 90), pygame.Rect(pad + 6, pad + 12, COLS * TILE, ROWS * TILE), border_radius=18)
    paper = pygame.Rect(pad, pad, COLS * TILE, ROWS * TILE)
    pygame.draw.rect(s, T["paper"], paper, border_radius=14)
    for c in range(COLS + 1):
        pygame.draw.line(s, T["grid"], (pad + c * TILE, pad), (pad + c * TILE, pad + ROWS * TILE), 2)
    for r in range(ROWS + 1):
        pygame.draw.line(s, T["grid"], (pad, pad + r * TILE), (pad + COLS * TILE, pad + r * TILE), 2)
    g = L.grid
    for r in range(ROWS):
        for c in range(COLS):
            x, y = pad + c * TILE, pad + r * TILE
            v = g[r][c]
            if v == WALL:
                rc = pygame.Rect(x, y, TILE, TILE)
                pygame.draw.rect(s, T["wall"], rc)
                if r == 0 or g[r - 1][c] != WALL:
                    pygame.draw.rect(s, T["wall_hi"], pygame.Rect(x, y, TILE, 8))
            elif v == SPIKE:
                up = r + 1 < ROWS and g[r + 1][c] == WALL
                base_y, tip_y = (y + TILE, y + 6) if up else (y, y + TILE - 6)
                for k in range(2):
                    x0 = x + k * TILE / 2
                    pts = [(x0 + 1, base_y), (x0 + TILE / 2 - 1, base_y), (x0 + TILE / 4, tip_y)]
                    pygame.draw.polygon(s, (60, 64, 80) if sum(T["paper"]) > 380 else (190, 196, 215), pts)
                    tip = [(x0 + TILE / 4 - 5, tip_y + (10 if up else -10)), (x0 + TILE / 4 + 5, tip_y + (10 if up else -10)), (x0 + TILE / 4, tip_y)]
                    pygame.draw.polygon(s, (235, 60, 70), tip)
            elif v == FINISH:
                fc, fr = L.finish[0]
                cell = TILE // 2
                for i in range(2):
                    for j in range(2):
                        col = (25, 25, 30) if (c * 2 + i + r * 2 + j) % 2 else (250, 250, 250)
                        pygame.draw.rect(s, col, pygame.Rect(x + i * cell, y + j * cell, cell, cell))
    # wall outlines for a crisp cartoon look
    edge = V.darker(T["wall"], 0.45)
    for r in range(ROWS):
        for c in range(COLS):
            if g[r][c] != WALL:
                continue
            x, y = pad + c * TILE, pad + r * TILE
            for dc, dr, a, b in ((0, -1, (x, y), (x + TILE, y)), (0, 1, (x, y + TILE), (x + TILE, y + TILE)),
                                 (-1, 0, (x, y), (x, y + TILE)), (1, 0, (x + TILE, y), (x + TILE, y + TILE))):
                nc, nr = c + dc, r + dr
                if 0 <= nc < COLS and 0 <= nr < ROWS and g[nr][nc] != WALL:
                    pygame.draw.line(s, edge, a, b, 4)
    # finish outline
    fx0, fy0 = L.finish[0]
    pygame.draw.rect(s, (20, 20, 25), pygame.Rect(pad + fx0 * TILE, pad + fy0 * TILE, TILE * 2, TILE * 2), 4)
    pygame.draw.rect(s, (40, 44, 60), paper, 6, border_radius=14)
    return s


def _draw_blocks(dst, L, T, sx, sy):
    for b in L.blocks:
        if not b["alive"]:
            continue
        rc = b["rect"].move(sx, sy)
        k = 1 + 0.06 * b["pulse"]
        rc = rc.inflate(rc.w * (k - 1), rc.h * (k - 1))
        col = V.mix(T["block"], (255, 255, 255), b["flash"] * 0.7)
        pygame.draw.rect(dst, V.darker(T["block"], 0.5), rc.move(0, 6), border_radius=12)
        pygame.draw.rect(dst, col, rc, border_radius=12)
        pygame.draw.rect(dst, V.lighter(col, 0.35), pygame.Rect(rc.x + 8, rc.y + 6, rc.w - 16, 10), border_radius=5)
        # crack lines as HP drops
        dmg = 1 - b["hp"] / b["max"]
        rr = random.Random(id(b) % 997)
        for i in range(int(dmg * 6)):
            x0 = rc.x + rr.uniform(0.1, 0.9) * rc.w
            y0 = rc.y + rr.uniform(0.1, 0.9) * rc.h
            pygame.draw.line(dst, V.darker(col, 0.6), (x0, y0), (x0 + rr.uniform(-25, 25), y0 + rr.uniform(-18, 18)), 3)
        pygame.draw.rect(dst, V.darker(T["block"], 0.4), rc, 4, border_radius=12)
        surf = V.text(str(b["hp"]), int(min(rc.h * 0.75, 64)), T["block_txt"], None)
        V.blit_center(dst, surf, rc.centerx, rc.centery + 2)


def _draw_trail(dst, R, T, sx, sy):
    pts = list(R.trail)
    n = len(pts)
    if n < 2:
        return
    base = T["paper"]
    for i in range(1, n):
        k = i / n
        col = V.mix(base, R.look.color, 0.25 + 0.55 * k)
        w = max(2, int(R.look.size * 0.55 * k))
        (x0, y0), (x1, y1) = pts[i - 1], pts[i]
        pygame.draw.line(dst, col, (x0 + sx, y0 + sy), (x1 + sx, y1 + sy), w)


def _draw_leader(dst, order, rank_x, dt):
    n = len(order)
    slot = min(120, 900 // n)
    y = BY + ROWS * TILE + 70
    x0 = W / 2 - slot * (n - 1) / 2
    for pos, R in enumerate(order):
        target = x0 + pos * slot
        cur = rank_x.get(R.i) or target
        cur += (target - cur) * min(1, dt * 10)
        rank_x[R.i] = cur
        badge = R.look.badge(int(slot * 0.62))
        V.blit_center(dst, badge, cur, y)
        V.blit_center(dst, V.text(str(pos + 1), 30, (255, 255, 255), (0, 0, 0), 3), cur + slot * 0.32, y - slot * 0.3)


def _draw_winner(dst, R, t, T, line1=None, line2="WINS!", line3="Did you guess right?"):
    if t < 0.8:
        return
    a = min(1, (t - 0.8) / 0.3)
    dim = pygame.Surface((W, H), pygame.SRCALPHA)
    dim.fill((0, 0, 0, int(170 * a)))
    dst.blit(dim, (0, 0))
    # pop-in with overshoot
    u = min(1, (t - 0.8) / 0.45)
    sc = 1 + 0.25 * math.sin(u * math.pi) if u < 1 else 1 + 0.03 * math.sin((t - 1.25) * 5)
    hero = R.look.hero(sc * 1.4)
    # rays
    rays = pygame.Surface((W, H), pygame.SRCALPHA)
    cx, cy = W / 2, H * 0.43
    for k in range(12):
        ang = t * 0.6 + k * math.pi / 6
        p = [(cx, cy), (cx + math.cos(ang - 0.12) * 1400, cy + math.sin(ang - 0.12) * 1400),
             (cx + math.cos(ang + 0.12) * 1400, cy + math.sin(ang + 0.12) * 1400)]
        pygame.draw.polygon(rays, (*R.look.color, int(45 * a)), p)
    dst.blit(rays, (0, 0))
    V.blit_center(dst, hero, cx, cy)
    name = (line1 if line1 is not None else R.look.name).upper()
    if name:
        V.blit_center(dst, V.text(name, 120 if len(name) < 9 else 90, R.look.color, (255, 255, 255), 10), W / 2, H * 0.62)
    V.blit_center(dst, V.text(line2, 150 if len(line2) < 8 else 110, (255, 255, 255), (15, 15, 25), 12), W / 2, H * 0.71)
    if t > 2.4 and line3:
        b = min(1, (t - 2.4) / 0.3)
        V.blit_center(dst, V.text(line3, int(64 * b) or 1, (255, 230, 60), (15, 15, 25), 6), W / 2, H * 0.8)
