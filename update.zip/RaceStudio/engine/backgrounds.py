"""Background styles shared by every game. Picked per video for variety."""
import math
import random

import numpy as np

from .video import pygame

STYLES = ["wavy_checker", "stripes", "dots", "grid", "radial", "bokeh", "zigzag"]


def make(w, h, c1, c2, style="random", seed=0):
    rng = random.Random(seed)
    if style in (None, "random") or style not in STYLES:
        style = rng.choice(STYLES)
    fn = globals()["_" + style]
    s = fn(w, h, np.array(c1, float), np.array(c2, float), rng)
    return s, style


def _grad(w, h, c1, c2):
    t = np.linspace(0, 1, h)[None, :, None]
    return np.broadcast_to(c1 + (c2 - c1) * t, (w, h, 3)).copy()


def _to_surf(arr):
    return pygame.surfarray.make_surface(np.clip(arr, 0, 255).astype(np.uint8))


def _wavy_checker(w, h, c1, c2, rng):
    x = np.arange(w)[:, None]
    y = np.arange(h)[None, :]
    cell = rng.choice([110, 130, 150])
    amp = rng.uniform(18, 34)
    ph = rng.uniform(0, 6)
    xx = x + amp * np.sin(y / 140 + ph)
    yy = y + amp * np.sin(x / 160 + ph * 1.3)
    chk = ((xx // cell + yy // cell) % 2).astype(float)[:, :, None]
    base = _grad(w, h, c1, c2)
    alt = base * 0.72 + np.array([8, 8, 14])
    return _to_surf(base * (1 - chk) + alt * chk)


def _stripes(w, h, c1, c2, rng):
    x = np.arange(w)[:, None]
    y = np.arange(h)[None, :]
    period = rng.choice([90, 120, 160])
    band = (((x + y * rng.choice([1, -1])) // (period // 2)) % 2).astype(float)[:, :, None]
    base = _grad(w, h, c1, c2)
    return _to_surf(base * (1 + 0.06 * band))


def _dots(w, h, c1, c2, rng):
    base = _grad(w, h, c1, c2)
    s = _to_surf(base)
    gap = rng.choice([54, 70, 86])
    col = tuple(int(v) for v in (c1 + c2) / 2 * 1.35 + 10)
    col = tuple(min(255, c) for c in col)
    for j, y in enumerate(range(0, h + gap, gap)):
        off = gap // 2 if j % 2 else 0
        for x in range(-gap, w + gap, gap):
            pygame.draw.circle(s, col, (x + off, y), gap // 9)
    return s


def _grid(w, h, c1, c2, rng):
    base = _grad(w, h, c1, c2)
    s = _to_surf(base)
    gap = rng.choice([48, 60, 72])
    col = tuple(min(255, int(v * 1.3 + 12)) for v in (c1 + c2) / 2)
    for x in range(0, w, gap):
        pygame.draw.line(s, col, (x, 0), (x, h), 2)
    for y in range(0, h, gap):
        pygame.draw.line(s, col, (0, y), (w, y), 2)
    return s


def _radial(w, h, c1, c2, rng):
    x = np.arange(w)[:, None] - w / 2
    y = np.arange(h)[None, :] - h * rng.uniform(0.4, 0.55)
    d = np.sqrt(x * x + y * y) / (h * 0.75)
    d = np.clip(d, 0, 1)[:, :, None]
    ang = np.arctan2(y, x)
    rays = (0.5 + 0.5 * np.sin(ang * rng.choice([12, 16, 20])))[:, :, None]
    arr = c2 * (1 - d) + c1 * d
    arr = arr * (1 + 0.07 * rays * (1 - d))
    return _to_surf(arr)


def _bokeh(w, h, c1, c2, rng):
    s = _to_surf(_grad(w, h, c1, c2))
    over = pygame.Surface((w, h), pygame.SRCALPHA)
    for _ in range(38):
        r = rng.randint(30, 140)
        col = tuple(min(255, int(v * 1.6 + 30)) for v in (c2 if rng.random() < 0.6 else c1))
        pygame.draw.circle(over, (*col, rng.randint(14, 34)), (rng.randint(0, w), rng.randint(0, h)), r)
    s.blit(over, (0, 0))
    return s


def _zigzag(w, h, c1, c2, rng):
    base = _grad(w, h, c1, c2)
    s = _to_surf(base)
    over = pygame.Surface((w, h), pygame.SRCALPHA)
    gap = rng.choice([80, 100, 120])
    amp = gap // 3
    for y in range(-gap, h + gap, gap):
        pts = [(x, y + (amp if (x // gap) % 2 else 0)) for x in range(0, w + gap, gap)]
        pygame.draw.lines(over, (255, 255, 255, 16), False, pts, 14)
    s.blit(over, (0, 0))
    return s
