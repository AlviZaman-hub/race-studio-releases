"""Render satisfying race videos.

Examples
  python make.py maze                        # 1 video, 4 colour squares
  python make.py maze --count 10             # 10 different races
  python make.py maze --racers drinks        # emoji preset
  python make.py maze --config config/my_race.json
  python make.py maze --seed 42 --theme ember --vibe phonk
  python make.py maze --style cartoon          # the original cartoon look + sounds
  python make.py rings --racers colors6       # Ring Escape
  python make.py marbles --racers colors6     # Marble Elimination
  python make.py territory --racers animals   # Territory War
"""
import argparse
import json
import os
import random
import sys
import time

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine.audio import SoundTrack  # noqa: E402

PRESETS = {
    "colors4": [{"name": "Red", "color": "#ef3b3b"}, {"name": "Blue", "color": "#2f6bff"},
                {"name": "Green", "color": "#1fbf4f"}, {"name": "Yellow", "color": "#ffd21f"}],
    "colors6": [{"name": "Red", "color": "#ef3b3b"}, {"name": "Blue", "color": "#2f6bff"},
                {"name": "Green", "color": "#1fbf4f"}, {"name": "Yellow", "color": "#ffd21f"},
                {"name": "Purple", "color": "#9b4dff"}, {"name": "Orange", "color": "#ff8a1f"}],
    "drinks": [{"name": "Cola", "emoji": "🥤", "color": "#e8433b"}, {"name": "Coffee", "emoji": "☕", "color": "#8a5a3a"},
               {"name": "Bubble Tea", "emoji": "🧋", "color": "#d8a26a"}, {"name": "Juice", "emoji": "🧃", "color": "#ffb21f"}],
    "food": [{"name": "Burger", "emoji": "🍔", "color": "#e8a33b"}, {"name": "Pizza", "emoji": "🍕", "color": "#ef5b3b"},
             {"name": "Taco", "emoji": "🌮", "color": "#f2c94c"}, {"name": "Sushi", "emoji": "🍣", "color": "#ff7a7a"}],
    "animals": [{"name": "Cat", "emoji": "🐱", "color": "#ffb347"}, {"name": "Dog", "emoji": "🐶", "color": "#c98b5a"},
                {"name": "Frog", "emoji": "🐸", "color": "#4cd964"}, {"name": "Panda", "emoji": "🐼", "color": "#555555"}],
}

GAMES = {"maze": "games.maze", "rings": "games.rings", "marbles": "games.marbles", "territory": "games.territory"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("game", choices=GAMES)
    ap.add_argument("--count", type=int, default=1)
    ap.add_argument("--config")
    ap.add_argument("--racers", default=None, help="preset name: " + ", ".join(PRESETS))
    ap.add_argument("--seed", type=int)
    ap.add_argument("--theme")
    ap.add_argument("--background", help="wavy_checker, stripes, dots, grid, radial, bokeh, zigzag")
    ap.add_argument("--vibe", choices=["dark", "phonk", "lofi", "hype", "playful"])
    ap.add_argument("--style", choices=["sleek", "cartoon"], help="sleek (default) or the original cartoon look")
    ap.add_argument("--music", default=None, help="'off' or path to your own WAV")
    ap.add_argument("--fps", type=int)
    ap.add_argument("--quality", choices=["fast", "good", "best"])
    ap.add_argument("--out", default="output")
    a = ap.parse_args()

    cfg = {}
    if a.config:
        with open(a.config, encoding="utf-8") as f:
            cfg = json.load(f)
    if a.racers:
        cfg["racers"] = PRESETS[a.racers]
    cfg.setdefault("racers", PRESETS["colors4"])
    for k in ("theme", "background", "vibe", "style", "fps", "quality"):
        if getattr(a, k):
            cfg[k] = getattr(a, k)
    os.makedirs(a.out, exist_ok=True)
    module = __import__(GAMES[a.game], fromlist=["render"])
    cartoon = cfg.get("style") == "cartoon"
    themes = list(getattr(module, "THEMES", {"ocean": 0})) if cartoon else \
        list(getattr(module, "RANDOM_THEMES", getattr(module, "THEMES", {"ocean": 0})))

    base = a.seed if a.seed is not None else random.randrange(1, 10 ** 6)
    for i in range(a.count):
        c = dict(cfg)
        c["seed"] = base + i
        rng = random.Random(c["seed"])
        c.setdefault("theme", rng.choice(themes))
        vibe = c.get("vibe") or ("playful" if cartoon else rng.choice(["dark", "phonk", "lofi", "hype"]))
        key = rng.choice([57, 60, 62, 64, 65, 67]) if vibe == "playful" else rng.choice([52, 53, 55, 57, 58])
        music = a.music or c.get("music", "on")
        snd = SoundTrack(key_midi=key, vibe=vibe, bpm=96,
                         music=(music != "off"), seed=c["seed"],
                         music_file=music if music not in ("on", "off") else None)
        out = os.path.join(a.out, f"{a.game}_{c['seed']}.mp4")
        t0 = time.time()
        print(f"[{i + 1}/{a.count}] seed {c['seed']} theme {c['theme']} vibe {vibe}")
        info = module.render(c, out, snd)
        print(f"  -> {out}  ({info['duration']:.1f}s video, winner {info['winner']}, took {time.time() - t0:.0f}s)")


if __name__ == "__main__":
    main()
