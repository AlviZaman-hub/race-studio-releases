"""Race Studio: a simple window for making race videos."""
import json
import os
import queue
import re
import subprocess
import sys
import threading
import tkinter as tk
import unicodedata
from tkinter import colorchooser, filedialog, messagebox, ttk

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from make import PRESETS, GAMES  # noqa: E402
import updater  # noqa: E402
MAC = sys.platform == "darwin"
BTN_FG = "#111111" if MAC else "#e9ecf5"  # macOS ignores button colours

EMOJI_DIR = os.path.join(HERE, "assets", "emoji")
SETTINGS = os.path.join(HERE, "config", "_last_settings.json")
from engine.backgrounds import STYLES  # noqa: E402
from engine import ai  # noqa: E402
import importlib  # noqa: E402

# name shown in the app -> (code, min racers, default title, help text)
GAME_LIST = [
    ("Maze Race", "maze", 2, "WHO REACHES THE FLAG FIRST?",
     "Racers hop through a maze, smash numbered blocks, dodge spikes. First to the flag wins."),
    ("Ring Escape", "rings", 1, "WHO BREAKS THE MOST RINGS?",
     "Balls escape spinning rings; most rings broken wins. 1 racer = solo 'Can it escape?' mode."),
    ("Marble Elimination", "marbles", 2, "LAST ONE DOWN IS OUT!",
     "Marbles drop through a new peg board each round; last one down is OUT. Length = number of racers."),
    ("Territory War", "territory", 2, "WHICH COLOUR TAKES OVER?",
     "Each colour's ball flips enemy tiles. Biggest territory when the timer ends wins."),
    ("Ball Battle Royale", "battle", 2, "LAST BALL STANDING WINS",
     "Balls fight with spinning swords, daggers and spiked shells. Last one alive wins."),
    ("Emoji Quiz", "quiz", 0, "",
     "Emoji clues drop in, a timer ticks, the answer is revealed. Racers aren't used: set the topic or questions below."),
    ("Music Bounce", "music", 1, "",
     "Every bounce plays the next note of a classical melody (public domain). The ball grows until it fills the circle."),
    ("Shrinking Arena", "shrink", 2, "LAST ONE INSIDE WINS",
     "Balls bounce in a shrinking, spinning arena. Fall out through the gap and you're eliminated."),
    ("Chain Reaction", "chain", 1, "WHO BREAKS THE MOST BLOCKS?",
     "Balls smash a wall of bricks. Most bricks broken wins."),
    ("Marble Track", "track", 2, "WHO WINS THE MARBLE RACE?",
     "Marbles race down a long winding track with spinners and bumpers. Camera follows the leader."),
    ("Bar Chart Race", "barrace", 0, "",
     "Animated ranking over time from real data (World Bank or your own CSV). Racers aren't used."),
    ("What If…?", "whatif", 0, "",
     "Side-by-side physics: normal world vs a changed rule (gravity, bounciness, wind…). Racers aren't used."),
]
GAME_NAMES, MIN_RACERS, GAME_HELP, GAME_THEMES, GAME_TITLES = {}, {}, {}, {}, {}
for _name, _code, _min, _title, _help in GAME_LIST:
    try:
        _mod = importlib.import_module(f"games.{_code}")
    except ImportError:
        continue  # not installed yet in this version
    GAME_NAMES[_name] = _code
    MIN_RACERS[_code] = _min
    GAME_HELP[_code] = _help
    GAME_TITLES[_code] = _title
    GAME_THEMES[_code] = ["random"] + list(getattr(_mod, "THEMES", {}))
DEFAULT_TITLES = {t for t in GAME_TITLES.values()} | {"WHO BREAKS THE MOST RINGS?", "LAST ONE DOWN IS OUT!", ""}
NO_RACERS = {"quiz", "barrace", "whatif"}
BACKGROUNDS = ["random"] + STYLES
COMING = []
AI_KEY_URL = "https://aistudio.google.com/apikey"

BG = "#14161f"
PANEL = "#1d2030"
FG = "#e9ecf5"
MUTED = "#9aa1b8"
ACCENT = "#ffb020"


# ====================================================================== emoji picker

class EmojiPicker(tk.Toplevel):
    def __init__(self, master, on_pick):
        super().__init__(master)
        self.title("Pick an emoji")
        self.configure(bg=BG)
        self.geometry("560x520")
        self.on_pick = on_pick
        self.imgs = []
        self.index = []
        for f in os.listdir(EMOJI_DIR):
            code = f[:-4]
            parts = code.split("-")
            try:
                ch = "".join(chr(int(p, 16)) for p in parts)
            except ValueError:
                continue
            names = []
            for c in ch:
                try:
                    names.append(unicodedata.name(c))
                except ValueError:
                    pass
            self.index.append((" ".join(names).lower(), ch, os.path.join(EMOJI_DIR, f)))
        self.index.sort()
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Search:", bg=BG, fg=FG).pack(side="left")
        self.q = tk.StringVar()
        e = tk.Entry(top, textvariable=self.q, bg=PANEL, fg=FG, insertbackground=FG, relief="flat")
        e.pack(side="left", fill="x", expand=True, padx=6)
        e.focus_set()
        self.q.trace_add("write", lambda *_: self.refresh())
        self.grid_frame = tk.Frame(self, bg=BG)
        self.grid_frame.pack(fill="both", expand=True, padx=10)
        tk.Label(self, text="Try: pizza, cat, car, heart, fire, ball", bg=BG, fg=MUTED).pack(pady=4)
        self.q.set("face")

    def refresh(self):
        for w in self.grid_frame.winfo_children():
            w.destroy()
        self.imgs.clear()
        words = self.q.get().lower().split()
        hits = [x for x in self.index if all(w in x[0] for w in words)][:48]
        for i, (name, ch, path) in enumerate(hits):
            try:
                img = tk.PhotoImage(file=path).subsample(4)
            except tk.TclError:
                continue
            self.imgs.append(img)
            b = tk.Button(self.grid_frame, image=img, bg=PANEL, activebackground=ACCENT, relief="flat", highlightbackground=PANEL,
                          command=lambda c=ch, n=name: self.pick(c, n))
            b.grid(row=i // 8, column=i % 8, padx=3, pady=3)

    def pick(self, ch, name):
        self.on_pick(ch, name.split()[-1].title() if name else "Racer")
        self.destroy()


# ====================================================================== racer row

class RacerRow(tk.Frame):
    TYPES = ["Square", "Emoji", "Image"]

    def __init__(self, master, app, spec):
        super().__init__(master, bg=PANEL)
        self.app = app
        self.name = tk.StringVar(value=spec.get("name", "Racer"))
        self.kind = tk.StringVar(value="Emoji" if spec.get("emoji") else "Image" if spec.get("image") else "Square")
        self.emoji = spec.get("emoji", "")
        self.image = spec.get("image", "")
        self.color = spec.get("color", "#ef3b3b")
        self.shape = tk.StringVar(value=spec.get("shape", "fit"))
        self.preview_img = None

        tk.Entry(self, textvariable=self.name, width=12, bg=BG, fg=FG, insertbackground=FG, relief="flat").pack(side="left", padx=4, pady=4)
        ttk.Combobox(self, textvariable=self.kind, values=self.TYPES, width=7, state="readonly").pack(side="left", padx=4)
        self.kind.trace_add("write", lambda *_: self.update_view())
        self.color_btn = tk.Label(self, text="", width=4, bg=self.color, cursor="hand2", relief="ridge", bd=2)
        self.color_btn.pack(side="left", padx=4, ipady=4)
        self.color_btn.bind("<Button-1>", lambda e: self.pick_color())
        self.pick_btn = tk.Button(self, text="Choose…", relief="flat", bg=BG, fg=BTN_FG, command=self.choose)
        self.pick_btn.pack(side="left", padx=4)
        self.shape_box = ttk.Combobox(self, textvariable=self.shape, values=["fit", "circle"], width=6, state="readonly")
        self.shape_box.pack(side="left", padx=4)
        self.preview = tk.Label(self, bg=PANEL, fg=MUTED, width=6)
        self.preview.pack(side="left", padx=4)
        tk.Button(self, text="Remove", relief="flat", bg=PANEL, fg="#ff6b6b", command=self.remove).pack(side="right", padx=6)
        self.update_view()

    def update_view(self):
        k = self.kind.get()
        self.pick_btn.configure(state="normal" if k != "Square" else "disabled")
        self.shape_box.configure(state="readonly" if k == "Image" else "disabled")
        self.preview_img = None
        txt = ""
        try:
            if k == "Emoji" and self.emoji:
                code = "-".join(f"{ord(c):x}" for c in self.emoji)
                p = os.path.join(EMOJI_DIR, code + ".png")
                if not os.path.exists(p):
                    p = os.path.join(EMOJI_DIR, "-".join(f"{ord(c):x}" for c in self.emoji if ord(c) != 0xFE0F) + ".png")
                self.preview_img = tk.PhotoImage(file=p).subsample(6)
            elif k == "Image" and self.image:
                txt = os.path.basename(self.image)[:10]
                if self.image.lower().endswith((".png", ".gif")):
                    img = tk.PhotoImage(file=self.image)
                    f = max(1, max(img.width(), img.height()) // 32)
                    self.preview_img = img.subsample(f)
            elif k == "Square":
                txt = "■"
        except Exception:
            txt = "?"
        self.preview.configure(image=self.preview_img or "", text="" if self.preview_img else ("" if k == "Square" else txt),
                               bg=self.color if k == "Square" and not self.preview_img else PANEL, fg=MUTED,
                               width=0 if self.preview_img else 6)

    def pick_color(self):
        c = colorchooser.askcolor(self.color, parent=self)[1]
        if c:
            self.color = c
            self.color_btn.configure(bg=c)
            self.update_view()

    def choose(self):
        if self.kind.get() == "Emoji":
            EmojiPicker(self.app.root, self.set_emoji)
        else:
            p = filedialog.askopenfilename(parent=self, title="Racer image",
                                           filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.gif"), ("All", "*.*")])
            if p:
                self.image = p
                if self.name.get() in ("", "Racer"):
                    self.name.set(os.path.splitext(os.path.basename(p))[0].title())
                self.update_view()

    def set_emoji(self, ch, name):
        self.emoji = ch
        if self.name.get() in ("", "Racer") or self.name.get().startswith("Racer"):
            self.name.set(name)
        self.update_view()

    def remove(self):
        self.app.rows.remove(self)
        self.destroy()

    def spec(self):
        s = {"name": self.name.get().strip() or "Racer", "color": self.color}
        k = self.kind.get()
        if k == "Emoji":
            if not self.emoji:
                raise ValueError(f"Pick an emoji for {s['name']}")
            s["emoji"] = self.emoji
        elif k == "Image":
            if not self.image or not os.path.exists(self.image):
                raise ValueError(f"Pick an image for {s['name']}")
            s["image"] = self.image
            s["shape"] = self.shape.get()
        return s


# ====================================================================== main window

class App:
    def __init__(self, root):
        self.root = root
        root.title("Race Studio")
        root.configure(bg=BG)
        sh = root.winfo_screenheight()
        root.geometry(f"940x{min(940, max(600, sh - 90))}")
        root.minsize(820, 560)
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure("TCombobox", fieldbackground=BG, background=PANEL, foreground=FG, arrowcolor=FG)
        st.map("TCombobox", fieldbackground=[("readonly", BG)], foreground=[("readonly", FG)])
        st.configure("Horizontal.TProgressbar", troughcolor=PANEL, background=ACCENT)
        self.proc = None
        self.q = queue.Queue()
        self.rows = []
        self.last_video = None
        s = self._load()
        self._saved = s

        self._pending_game_refresh = True
        tk.Label(root, text="RACE STUDIO", bg=BG, fg=ACCENT, font=("Segoe UI", 20, "bold")).pack(pady=(12, 0))
        tk.Label(root, text="Satisfying race videos for Shorts, TikTok and Reels", bg=BG, fg=MUTED).pack()
        upd = tk.Frame(root, bg=BG)
        upd.pack()
        self.ver_label = tk.StringVar(value=f"Version {updater.current_version()}")
        tk.Label(upd, textvariable=self.ver_label, bg=BG, fg=MUTED).pack(side="left", padx=6)
        self.upd_btn = self._btn(upd, "Check for updates", lambda: self.check_updates(manual=True))
        self.upd_btn.pack(side="left")
        airow = tk.Frame(root, bg=BG)
        airow.pack(pady=(4, 0))
        self.ai_status = tk.StringVar()
        tk.Label(airow, textvariable=self.ai_status, bg=BG, fg=ACCENT).pack(side="left", padx=4)
        self._btn(airow, "AI key…", self.ai_key_dialog).pack(side="left", padx=2)
        tk.Label(airow, text="Theme:", bg=BG, fg=MUTED).pack(side="left", padx=(8, 2))
        self.idea_theme = tk.StringVar(value=s.get("idea_theme", ""))
        tk.Entry(airow, textvariable=self.idea_theme, width=14, bg=PANEL, fg=FG, insertbackground=FG, relief="flat").pack(side="left")
        self._btn(airow, "✨ Idea", self.ai_idea).pack(side="left", padx=2)
        self._btn(airow, "Plan my week", self.plan_dialog).pack(side="left", padx=2)
        self._btn(airow, "Racers from comments", self.comments_dialog).pack(side="left", padx=2)
        self._refresh_ai_status()

        # scrollable body so it fits small laptop screens
        outer = tk.Frame(root, bg=BG)
        outer.pack(fill="both", expand=True)
        cnv = tk.Canvas(outer, bg=BG, highlightthickness=0)
        sb = tk.Scrollbar(outer, orient="vertical", command=cnv.yview)
        cnv.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        cnv.pack(side="left", fill="both", expand=True)
        body = tk.Frame(cnv, bg=BG, padx=14, pady=8)
        win = cnv.create_window((0, 0), window=body, anchor="nw")
        body.bind("<Configure>", lambda e: cnv.configure(scrollregion=cnv.bbox("all")))
        cnv.bind("<Configure>", lambda e: cnv.itemconfigure(win, width=e.width))

        def _wheel(e):
            d = e.delta if e.delta else (120 if getattr(e, "num", 0) == 4 else -120)
            cnv.yview_scroll(int(-d / (120 if abs(d) >= 120 else 1)), "units")
        root.bind_all("<MouseWheel>", _wheel)
        root.bind_all("<Button-4>", _wheel)
        root.bind_all("<Button-5>", _wheel)

        # ------------------------------------------------ game + look
        g = self._section(body, "1  Game & look")
        self.game = tk.StringVar(value=s.get("game", "Maze Race"))
        gcb = self._combo(g, "Game", self.game, list(GAME_NAMES) + COMING, 0, 0)
        gcb.bind("<<ComboboxSelected>>", lambda e: self._game_changed())
        self.theme = tk.StringVar(value=s.get("theme", "random"))
        self.theme_cb = self._combo(g, "Theme", self.theme, GAME_THEMES["maze"], 0, 2)
        self.title_v = tk.StringVar(value=s.get("title", ""))
        self._entry(g, "Title text", self.title_v, 1, 0, 40, span=3)
        tk.Label(g, text="Leave the title empty to use the game's default title.", bg=PANEL, fg=MUTED).grid(row=3, column=0, columnspan=4, sticky="w")
        self.handle = tk.StringVar(value=s.get("handle", ""))
        self._entry(g, "Your @handle", self.handle, 2, 0, 20)
        self.bg_style = tk.StringVar(value=s.get("background", "random"))
        self._combo(g, "Background", self.bg_style, BACKGROUNDS, 2, 2)
        self.look = tk.StringVar(value=s.get("look", "Sleek"))
        self._combo(g, "Look", self.look, ["Sleek", "Cartoon"], 6, 0)
        self.extra = tk.Frame(g, bg=PANEL)
        self.extra.grid(row=4, column=0, columnspan=4, sticky="w", pady=(4, 0))
        self.quiz_topic = tk.StringVar(value=s.get("quiz_topic", "mixed"))
        self.quiz_count = tk.IntVar(value=s.get("quiz_count", 6))
        self.quiz_questions = s.get("quiz_questions", [])
        self.weapons = tk.StringVar(value=s.get("weapons", "mixed"))
        self.layout = tk.StringVar(value=s.get("layout", "random"))
        self.shape = tk.StringVar(value=s.get("shape", "random"))
        self.help = tk.StringVar()
        tk.Label(g, textvariable=self.help, bg=PANEL, fg=ACCENT, wraplength=800, justify="left").grid(row=5, column=0, columnspan=4, sticky="w", pady=(4, 0))

        # ------------------------------------------------ racers
        r = self._section(body, "2  Racers (2–8; Ring Escape also allows 1 for solo mode)")
        bar = tk.Frame(r, bg=PANEL)
        bar.pack(fill="x")
        tk.Label(bar, text="Load preset:", bg=PANEL, fg=MUTED).pack(side="left", padx=4)
        self.preset = tk.StringVar(value="")
        cb = ttk.Combobox(bar, textvariable=self.preset, values=list(PRESETS), width=12, state="readonly")
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self.load_racers(PRESETS[self.preset.get()]))
        self._btn(bar, "+ Add racer", self.add_racer).pack(side="right", padx=4)
        hdr = tk.Frame(r, bg=PANEL)
        hdr.pack(fill="x")
        for txt, w in (("Name", 13), ("Type", 10), ("Colour", 7), ("Pick", 10), ("Shape", 8), ("Preview", 8)):
            tk.Label(hdr, text=txt, bg=PANEL, fg=MUTED, width=w, anchor="w").pack(side="left")
        self.rows_frame = tk.Frame(r, bg=PANEL)
        self.rows_frame.pack(fill="x")
        self.load_racers(s.get("racers") or PRESETS["colors4"])

        # ------------------------------------------------ sound + timing
        a = self._section(body, "3  Sound & timing")
        self.vibe = tk.StringVar(value=s.get("vibe", "random"))
        self._combo(a, "Music style", self.vibe, ["random", "dark", "phonk", "lofi", "hype", "playful"], 0, 0)
        self.music = tk.StringVar(value=s.get("music", "Built-in music"))
        mb = self._combo(a, "Music", self.music, ["Built-in music", "No music", "My own WAV…"], 0, 2)
        mb.bind("<<ComboboxSelected>>", self._music_pick)
        self.music_file = s.get("music_file", "")
        self.tmin = tk.IntVar(value=s.get("tmin", 20))
        self.tmax = tk.IntVar(value=s.get("tmax", 35))
        self._spin(a, "Race length from (s)", self.tmin, 15, 300, 1, 0)
        self._spin(a, "to (s)", self.tmax, 20, 600, 1, 2)

        # ------------------------------------------------ output
        o = self._section(body, "4  Output")
        self.count = tk.IntVar(value=s.get("count", 1))
        self._spin(o, "How many videos", self.count, 1, 100, 0, 0)
        self.quality = tk.StringVar(value=s.get("quality", "good"))
        self._combo(o, "Quality", self.quality, ["fast", "good", "best"], 0, 2)
        self.out = tk.StringVar(value=s.get("out", os.path.join(HERE, "output")))
        self._entry(o, "Save to", self.out, 1, 0, 40, span=2)
        self._btn(o, "Browse…", lambda: self.out.set(filedialog.askdirectory() or self.out.get())).grid(row=1, column=3, sticky="w")
        self.ai_caps = tk.BooleanVar(value=s.get("ai_caps", True))
        tk.Checkbutton(o, text="Write captions with AI (a .txt file is saved next to every video either way)",
                       variable=self.ai_caps, bg=PANEL, fg=FG, selectcolor=BG, activebackground=PANEL,
                       activeforeground=FG).grid(row=2, column=0, columnspan=4, sticky="w")

        # ------------------------------------------------ actions
        act = tk.Frame(body, bg=BG)
        act.pack(fill="x", pady=(8, 4))
        self.go = tk.Button(act, text="▶  MAKE VIDEOS", bg=ACCENT, fg="#1a1300", activebackground="#ffc95a", highlightbackground=BG,
                            font=("Segoe UI", 13, "bold"), relief="flat", padx=18, pady=6, command=self.start)
        self.go.pack(side="left")
        self.stop_btn = self._btn(act, "Stop", self.stop)
        self.stop_btn.pack(side="left", padx=8)
        self.stop_btn.configure(state="disabled")
        self._btn(act, "Open output folder", self.open_out).pack(side="right")
        self.play_btn = self._btn(act, "Play last video", self.play_last)
        self.play_btn.pack(side="right", padx=8)
        self.play_btn.configure(state="disabled")

        self.prog = ttk.Progressbar(body, mode="determinate", maximum=100)
        self.prog.pack(fill="x", pady=4)
        self.status = tk.StringVar(value="Ready.")
        tk.Label(body, textvariable=self.status, bg=BG, fg=FG, anchor="w").pack(fill="x")
        self.log = tk.Text(body, height=7, bg=PANEL, fg=MUTED, relief="flat", font=("Consolas", 9))
        self.log.pack(fill="both", expand=True, pady=(4, 0))
        root.protocol("WM_DELETE_WINDOW", self.close)
        self._game_changed(keep_theme=True)
        root.after(100, self.poll)
        root.after(800, lambda: self.check_updates(manual=False))

    # ------------------------------------------------ widgets
    def _section(self, parent, title):
        f = tk.Frame(parent, bg=PANEL, padx=10, pady=8)
        f.pack(fill="x", pady=5)
        tk.Label(f, text=title, bg=PANEL, fg=ACCENT, font=("Segoe UI", 11, "bold")).pack(anchor="w")
        inner = tk.Frame(f, bg=PANEL)
        inner.pack(fill="x", pady=(4, 0))
        return inner

    def _combo(self, p, label, var, values, row, col):
        tk.Label(p, text=label, bg=PANEL, fg=FG).grid(row=row, column=col, sticky="w", padx=(0, 6), pady=3)
        cb = ttk.Combobox(p, textvariable=var, values=values, width=30 if col == 0 else 16, state="readonly")
        cb.grid(row=row, column=col + 1, sticky="w", padx=(0, 20))
        return cb

    def _entry(self, p, label, var, row, col, width, span=1):
        tk.Label(p, text=label, bg=PANEL, fg=FG).grid(row=row, column=col, sticky="w", padx=(0, 6), pady=3)
        e = tk.Entry(p, textvariable=var, width=width, bg=BG, fg=FG, insertbackground=FG, relief="flat")
        e.grid(row=row, column=col + 1, columnspan=span, sticky="we", padx=(0, 20))
        return e

    def _spin(self, p, label, var, lo, hi, row, col):
        tk.Label(p, text=label, bg=PANEL, fg=FG).grid(row=row, column=col, sticky="w", padx=(0, 6), pady=3)
        tk.Spinbox(p, from_=lo, to=hi, textvariable=var, width=6, bg=BG, fg=FG, buttonbackground=PANEL,
                   insertbackground=FG, relief="flat").grid(row=row, column=col + 1, sticky="w", padx=(0, 20))

    def _btn(self, p, text, cmd):
        return tk.Button(p, text=text, command=cmd, bg=PANEL, fg=BTN_FG, activebackground="#2a2e44",
                         activeforeground=BTN_FG, relief="flat", padx=10, pady=3, highlightbackground=PANEL)

    # ------------------------------------------------ racers
    def load_racers(self, specs):
        for row in list(self.rows):
            row.destroy()
        self.rows = []
        for sp in specs:
            self._add_row(sp)

    def _add_row(self, spec):
        row = RacerRow(self.rows_frame, self, spec)
        row.pack(fill="x", pady=1)
        self.rows.append(row)

    def add_racer(self):
        if len(self.rows) >= 8:
            messagebox.showinfo("Race Studio", "Max 8 racers.")
            return
        palette = ["#ef3b3b", "#2f6bff", "#1fbf4f", "#ffd21f", "#9b4dff", "#ff8a1f", "#19c3c3", "#ff5fb0"]
        self._add_row({"name": f"Racer {len(self.rows) + 1}", "color": palette[len(self.rows) % 8]})

    def _game_changed(self, keep_theme=False):
        code = GAME_NAMES.get(self.game.get())
        if not code:
            return
        themes = GAME_THEMES[code]
        self.theme_cb.configure(values=themes)
        if not keep_theme or self.theme.get() not in themes:
            self.theme.set("random")
        cur = self.title_v.get().strip().upper()
        if cur in DEFAULT_TITLES or (code != "quiz" and cur.startswith("GUESS THE")):
            self.title_v.set("")
        self.help.set(GAME_HELP[code])
        for w in self.extra.winfo_children():
            w.destroy()
        if code == "territory":
            self._combo(self.extra, "Starting layout", self.layout, ["random", "voronoi", "blocks", "bands"], 0, 0)
            self._combo(self.extra, "Arena shape", self.shape, ["random", "square", "circle", "diamond", "plus"], 0, 2)
        elif code == "battle":
            self._combo(self.extra, "Weapons", self.weapons, ["mixed", "swords", "daggers", "spikes"], 0, 0)
        elif code == "quiz":
            self._combo(self.extra, "Topic", self.quiz_topic, ["mixed", "movies", "countries", "foods", "phrases", "my questions"], 0, 0)
            self._spin(self.extra, "Questions", self.quiz_count, 3, 10, 0, 2)
            self._btn(self.extra, "Edit questions…", self.quiz_dialog).grid(row=1, column=0, columnspan=2, sticky="w", pady=4)
        extra_hook = getattr(self, "_extra_" + code, None)
        if extra_hook:
            extra_hook()

    # ---- per-game option panels (looked up by name in _game_changed / start)
    def _extra_music(self):
        from engine.melodies import MELODIES
        if not hasattr(self, "song"):
            self.song = tk.StringVar(value=self._saved.get("song", "random"))
        self._combo(self.extra, "Song", self.song, ["random"] + list(MELODIES), 0, 0)

    def _cfg_music(self, cfg):
        if getattr(self, "song", None) and self.song.get() != "random":
            cfg["song"] = self.song.get()

    def _music_pick(self, _e=None):
        if self.music.get() == "My own WAV…":
            p = filedialog.askopenfilename(title="Music (WAV, copyright-free)", filetypes=[("WAV audio", "*.wav")])
            if p:
                self.music_file = p
                self.music.set("My own WAV…")
            else:
                self.music.set("Built-in music")

    # ------------------------------------------------ settings
    def _settings(self):
        return {"game": self.game.get(), "theme": self.theme.get(), "title": self.title_v.get(),
                "handle": self.handle.get(), "vibe": self.vibe.get(), "music": self.music.get(),
                "music_file": self.music_file, "tmin": self.tmin.get(), "tmax": self.tmax.get(),
                "count": self.count.get(), "quality": self.quality.get(), "out": self.out.get(),
                "background": self.bg_style.get(), "look": self.look.get(),
                "quiz_topic": self.quiz_topic.get(), "quiz_count": self.quiz_count.get(),
                "quiz_questions": self.quiz_questions, "weapons": self.weapons.get(),
                "idea_theme": self.idea_theme.get(), "ai_caps": self.ai_caps.get(),
                "song": self.song.get() if hasattr(self, "song") else "random", "layout": self.layout.get(), "shape": self.shape.get(),
                "racers": [r.spec() for r in self.rows]}

    def _load(self):
        try:
            with open(SETTINGS, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    # ------------------------------------------------ run
    def start(self):
        if self.game.get() not in GAME_NAMES:
            messagebox.showinfo("Race Studio", "That game isn't built yet. Pick Maze Race for now.")
            return
        try:
            s = self._settings()
        except ValueError as e:
            messagebox.showwarning("Race Studio", str(e))
            return
        code = GAME_NAMES[s["game"]]
        lo = MIN_RACERS[code]
        if code not in NO_RACERS and not lo <= len(s["racers"]) <= 8:
            messagebox.showwarning("Race Studio", f"Use {lo} to 8 racers for this game.")
            return
        if s["tmax"] <= s["tmin"] + 5:
            messagebox.showwarning("Race Studio", "Make the 'to' time at least 6 seconds more than 'from'.")
            return
        os.makedirs(os.path.dirname(SETTINGS), exist_ok=True)
        with open(SETTINGS, "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False, indent=1)
        cfg = {"title": s["title"].strip().upper(), "handle": s["handle"], "racers": s["racers"],
               "race_seconds": [s["tmin"], s["tmax"]]}
        if s["theme"] != "random":
            cfg["theme"] = s["theme"]
        if s["background"] != "random":
            cfg["background"] = s["background"]
        if GAME_NAMES[s["game"]] == "territory":
            if s["layout"] != "random":
                cfg["layout"] = s["layout"]
            if s["shape"] != "random":
                cfg["shape"] = s["shape"]
        if s["vibe"] != "random":
            cfg["vibe"] = s["vibe"]
        if s["look"] == "Cartoon":
            cfg["style"] = "cartoon"
        if code == "battle" and s["weapons"] != "mixed":
            cfg["weapons"] = [{"swords": "sword", "daggers": "dagger", "spikes": "spikes"}[s["weapons"]]] * 8
        if code == "quiz":
            cfg["quiz_count"] = s["quiz_count"]
            if s["quiz_topic"] == "my questions":
                if not self.quiz_questions:
                    messagebox.showwarning("Race Studio", "Add some questions first (Edit questions…).")
                    return
                cfg["questions"] = self.quiz_questions[: s["quiz_count"]]
            else:
                cfg["quiz_topic"] = s["quiz_topic"]
        hook = getattr(self, "_cfg_" + code, None)
        if hook and hook(cfg) is False:
            return
        run_cfg = os.path.join(HERE, "config", "_gui_run.json")
        with open(run_cfg, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False)
        cmd = [sys.executable.replace("pythonw", "python"), "-u", os.path.join(HERE, "make.py"),
               GAME_NAMES[s["game"]], "--config", run_cfg, "--count", str(s["count"]),
               "--quality", s["quality"], "--out", s["out"]]
        if s["music"] == "No music":
            cmd += ["--music", "off"]
        elif s["music"] == "My own WAV…" and s["music_file"]:
            cmd += ["--music", s["music_file"]]
        if s["ai_caps"] and ai.has_key():
            cmd += ["--ai-captions"]
        self._launch(cmd, s["count"])

    def _launch(self, cmd, total):
        self.total = total
        self.done = 0
        self.prog["value"] = 0
        self.log.delete("1.0", "end")
        self.status.set("Starting…")
        self.go.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        flags = 0x08000000 if os.name == "nt" else 0  # no console window
        self.proc = subprocess.Popen(cmd, cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     text=True, encoding="utf-8", errors="replace", env=env, creationflags=flags)
        threading.Thread(target=self._reader, args=(self.proc,), daemon=True).start()

    def _reader(self, proc):
        for line in proc.stdout:
            self.q.put(line.rstrip())
        proc.wait()
        self.q.put(("__END__", proc.returncode))

    # ------------------------------------------------ AI
    def _refresh_ai_status(self):
        self.ai_status.set("AI: ready ✓" if ai.has_key() else "AI: add a free key →")

    def _ai_thread(self, fn, done, busy="Asking Gemini…"):
        self.status.set(busy)

        def work():
            try:
                self.q.put(("__AI__", done, fn(), None))
            except Exception as e:
                self.q.put(("__AI__", done, None, str(e)))
        threading.Thread(target=work, daemon=True).start()

    def _ai_result(self, done, res, err):
        if err:
            self.status.set("AI: " + err)
            messagebox.showwarning("Race Studio AI", err)
            return
        self.status.set("Ready.")
        done(res)

    def _need_key(self):
        if ai.has_key():
            return True
        self.ai_key_dialog()
        return ai.has_key()

    def ai_key_dialog(self):
        d = tk.Toplevel(self.root)
        d.title("Gemini API key")
        d.configure(bg=BG, padx=16, pady=14)
        tk.Label(d, text="1. Click 'Get a free key' and sign in with Google\n2. Click 'Create API key', copy it\n3. Paste it below and Save",
                 bg=BG, fg=FG, justify="left").pack(anchor="w")
        self._btn(d, "Get a free key (opens browser)", lambda: _open_url(AI_KEY_URL)).pack(anchor="w", pady=6)
        kv = tk.StringVar(value=ai.load().get("key", ""))
        tk.Entry(d, textvariable=kv, width=52, show="•", bg=PANEL, fg=FG, insertbackground=FG, relief="flat").pack(pady=4)
        tk.Label(d, text="Saved only on this computer. Free tier: prompts may be used by Google to improve its products.",
                 bg=BG, fg=MUTED, wraplength=420, justify="left").pack(anchor="w")

        def save():
            ai.save(kv.get())
            self._refresh_ai_status()
            d.destroy()
        self._btn(d, "Save", save).pack(anchor="e", pady=(8, 0))

    def ai_idea(self):
        if not self._need_key():
            return
        code = GAME_NAMES.get(self.game.get())
        theme = self.idea_theme.get().strip()
        if code == "quiz":
            topic = theme or (self.quiz_topic.get() if self.quiz_topic.get() not in ("my questions",) else "mixed")

            def got(qs):
                self.quiz_questions = qs
                self.quiz_topic.set("my questions")
                self.title_v.set(f"GUESS THE {topic.upper()}"[:40] if theme else "")
                messagebox.showinfo("Race Studio AI", f"{len(qs)} questions ready. Check them in 'Edit questions…' before making the video.")
            cnt = self.quiz_count.get()
            self._ai_thread(lambda: ai.quiz(topic, cnt), got)
            return
        if code in NO_RACERS:
            hook = getattr(self, "_idea_" + code, None)
            if hook:
                hook(theme)
            return
        n = max(2 if MIN_RACERS.get(code, 2) >= 2 else 1, len(self.rows) or 4)

        def got(res):
            self.load_racers(res["racers"])
            self.title_v.set(res["title"])
        self._ai_thread(lambda: ai.idea(code, theme, n), got)

    def comments_dialog(self):
        d = tk.Toplevel(self.root)
        d.title("Racers from comments")
        d.configure(bg=BG, padx=14, pady=12)
        tk.Label(d, text="Paste comments from your videos. The commenters become racers (great for 'comment to join the next race').",
                 bg=BG, fg=FG, wraplength=520, justify="left").pack(anchor="w")
        txt = tk.Text(d, width=64, height=14, bg=PANEL, fg=FG, insertbackground=FG, relief="flat")
        txt.pack(pady=6)
        nv = tk.IntVar(value=6)
        row = tk.Frame(d, bg=BG)
        row.pack(fill="x")
        tk.Label(row, text="How many racers", bg=BG, fg=FG).pack(side="left")
        tk.Spinbox(row, from_=2, to=8, textvariable=nv, width=4, bg=PANEL, fg=FG, relief="flat").pack(side="left", padx=6)

        def use(names):
            pal = ai.PALETTE
            self.load_racers([{"name": nm, "color": pal[i % len(pal)]} for i, nm in enumerate(names)])
            d.destroy()

        def go():
            text = txt.get("1.0", "end")
            want = nv.get()
            if ai.has_key():
                self._ai_thread(lambda: ai.names_from_comments(text, want), use)
            else:  # simple fallback: @handles, else first word of each line
                import re as _re
                names = _re.findall(r"@([\w.\-]{2,20})", text) or [ln.split()[0] for ln in text.splitlines() if ln.strip()]
                use(list(dict.fromkeys(n[:14] for n in names))[: nv.get()])
        self._btn(row, "Make racers", go).pack(side="right")

    def quiz_dialog(self):
        d = tk.Toplevel(self.root)
        d.title("Quiz questions")
        d.configure(bg=BG, padx=14, pady=12)
        tk.Label(d, text="One question per line:   emojis = answer      e.g.   🦁👑 = The Lion King",
                 bg=BG, fg=FG).pack(anchor="w")
        txt = tk.Text(d, width=60, height=14, bg=PANEL, fg=FG, insertbackground=FG, relief="flat", font=("Segoe UI Emoji", 12))
        txt.pack(pady=6)
        txt.insert("1.0", "\n".join(f"{q['clue']} = {q['answer']}" for q in self.quiz_questions))
        row = tk.Frame(d, bg=BG)
        row.pack(fill="x")

        def fill_ai():
            if not self._need_key():
                return
            topic = self.idea_theme.get().strip() or (self.quiz_topic.get() if self.quiz_topic.get() != "my questions" else "mixed")

            def got(qs):
                txt.delete("1.0", "end")
                txt.insert("1.0", "\n".join(f"{q['clue']} = {q['answer']}" for q in qs))
            cnt = self.quiz_count.get()
            self._ai_thread(lambda: ai.quiz(topic, cnt), got)

        def save():
            qs, bad = [], 0
            for ln in txt.get("1.0", "end").splitlines():
                if "=" in ln:
                    c, a = ln.split("=", 1)
                    c, a = c.strip(), a.strip()
                    if c and a and ai.emoji_seq_ok(c):
                        qs.append({"clue": c, "answer": a})
                    else:
                        bad += 1
            self.quiz_questions = qs
            self.quiz_topic.set("my questions")
            if bad:
                messagebox.showinfo("Race Studio", f"{bad} line(s) skipped (unknown emoji or missing answer).")
            d.destroy()
        self._btn(row, "Fill with AI (uses Theme box)", fill_ai).pack(side="left")
        self._btn(row, "Save", save).pack(side="right")

    def plan_dialog(self):
        if not self._need_key():
            return
        d = tk.Toplevel(self.root)
        d.title("Plan my week")
        d.configure(bg=BG, padx=14, pady=12)
        tk.Label(d, text="Gemini plans a varied batch; Race Studio renders all of it (with captions).", bg=BG, fg=FG).pack(anchor="w")
        top = tk.Frame(d, bg=BG)
        top.pack(fill="x", pady=6)
        nv = tk.IntVar(value=14)
        tk.Label(top, text="Videos", bg=BG, fg=FG).pack(side="left")
        tk.Spinbox(top, from_=3, to=40, textvariable=nv, width=4, bg=PANEL, fg=FG, relief="flat").pack(side="left", padx=6)
        gvars = {}
        gf = tk.Frame(d, bg=BG)
        gf.pack(fill="x")
        for i, (nm, code) in enumerate(GAME_NAMES.items()):
            v = tk.BooleanVar(value=True)
            gvars[code] = v
            tk.Checkbutton(gf, text=nm, variable=v, bg=BG, fg=FG, selectcolor=PANEL, activebackground=BG,
                           activeforeground=FG).grid(row=i // 3, column=i % 3, sticky="w")
        lb = tk.Listbox(d, width=80, height=14, bg=PANEL, fg=FG, relief="flat")
        lb.pack(pady=6)
        plan = []

        def show(jobs):
            plan.clear()
            plan.extend(jobs)
            lb.delete(0, "end")
            names = {c: n for n, c in GAME_NAMES.items()}
            for j in jobs:
                who = ", ".join(r["name"] for r in j.get("racers", [])[:5])
                extra = j.get("quiz_topic", "") if j["game"] == "quiz" else who
                lb.insert("end", f"{names.get(j['game'], j['game'])}  ·  {j['title']}  ·  {extra}")

        def make_plan():
            games = [c for c, v in gvars.items() if v.get() and c not in ("barrace",)]
            if not games:
                return
            want = nv.get()
            self._ai_thread(lambda: ai.plan_week(want, games), show, "Gemini is planning your week…")

        def render_all():
            if not plan:
                return
            s = self._settings()
            path = os.path.join(HERE, "config", "_plan.json")
            base = {"handle": s["handle"], "race_seconds": [s["tmin"], s["tmax"]]}
            if s["look"] == "Cartoon":
                base["style"] = "cartoon"
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"base": base, "jobs": plan}, f, ensure_ascii=False)
            cmd = [sys.executable.replace("pythonw", "python"), "-u", os.path.join(HERE, "make.py"),
                   "--plan", path, "--quality", s["quality"], "--out", s["out"]]
            if s["ai_caps"] and ai.has_key():
                cmd += ["--ai-captions"]
            d.destroy()
            self._launch(cmd, len(plan))
        row = tk.Frame(d, bg=BG)
        row.pack(fill="x")
        self._btn(row, "1. Make plan", make_plan).pack(side="left")
        self._btn(row, "2. Render all", render_all).pack(side="right")

    # ------------------------------------------------ updates
    def check_updates(self, manual=False):
        self.ver_label.set(f"Version {updater.current_version()} · checking…")

        def work():
            try:
                ok, info = updater.check()
                self.q.put(("__UPD__", ok, info, manual, None))
            except Exception as e:  # offline, repo not ready, etc.
                self.q.put(("__UPD__", False, None, manual, str(e)))
        threading.Thread(target=work, daemon=True).start()

    def _update_result(self, ok, info, manual, err):
        cur = updater.current_version()
        if err:
            self.ver_label.set(f"Version {cur}")
            if manual:
                messagebox.showwarning("Race Studio", "Couldn't check for updates right now.\nCheck your internet and try again.")
            return
        if not ok:
            self.ver_label.set(f"Version {cur} · up to date")
            if manual:
                messagebox.showinfo("Race Studio", f"You're on the latest version ({cur}).")
            return
        self.ver_label.set(f"Version {cur} · update {info['version']} available")
        notes = info.get("notes", "")
        if messagebox.askyesno("Update available", f"Race Studio {info['version']} is ready.\n\n{notes}\n\nUpdate now? (takes a few seconds)"):
            if self.proc:
                messagebox.showinfo("Race Studio", "Wait until the current videos finish, then try again.")
                return
            try:
                updater.apply(info)
            except Exception as e:
                messagebox.showerror("Race Studio", f"Update failed: {e}\nYou can download it again from:\n{updater.DOWNLOAD_PAGE}")
                return
            messagebox.showinfo("Race Studio", "Updated! Race Studio will close now.\nOpen it again to use the new version.")
            self.close()

    def poll(self):
        try:
            while True:
                item = self.q.get_nowait()
                if isinstance(item, tuple) and item[0] == "__UPD__":
                    self._update_result(*item[1:])
                    continue
                if isinstance(item, tuple) and item[0] == "__AI__":
                    self._ai_result(*item[1:])
                    continue
                if isinstance(item, tuple):
                    self._finished(item[1])
                    continue
                self._handle(item)
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

    def _handle(self, line):
        if "ALSA" in line:
            return
        m = re.match(r"PROGRESS (\d+) (\d+)", line)
        if m:
            cur, tot = int(m.group(1)), max(1, int(m.group(2)))
            frac = min(1, cur / tot)
            self.prog["value"] = (self.done + frac) / self.total * 100
            self.status.set(f"Video {self.done + 1} of {self.total}: rendering {int(frac * 100)}%")
            return
        self.log.insert("end", line + "\n")
        self.log.see("end")
        m = re.search(r"-> (.+?\.mp4)", line)
        if m:
            self.done += 1
            self.last_video = m.group(1).strip()
            if not os.path.isabs(self.last_video):
                self.last_video = os.path.join(HERE, self.last_video)
            self.play_btn.configure(state="normal")
            self.prog["value"] = self.done / self.total * 100
        elif line.startswith("["):
            self.status.set(f"Video {self.done + 1} of {self.total}: designing the level…")

    def _finished(self, code):
        self.go.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        if code == 0:
            self.status.set(f"Done! {self.done} video(s) saved.")
            self.prog["value"] = 100
        elif self.proc is None:
            self.status.set("Stopped.")
        else:
            self.status.set("Something went wrong. See the log below.")
        self.proc = None

    def stop(self):
        if self.proc:
            p, self.proc = self.proc, None
            p.kill()

    def open_out(self):
        os.makedirs(self.out.get(), exist_ok=True)
        _open(self.out.get())

    def play_last(self):
        if self.last_video and os.path.exists(self.last_video):
            _open(self.last_video)

    def close(self):
        self.stop()
        self.root.destroy()


def _open_url(url):
    import webbrowser
    webbrowser.open(url)


def _open(path):
    if os.name == "nt":
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
