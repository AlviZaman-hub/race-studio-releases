"""Race Studio web app: a small local server (127.0.0.1 only) + the page in studio/ui.

Everything runs on this computer. The page talks to these JSON endpoints; renders run
make.py in a subprocess exactly like the old window did; previews run in a long-lived
worker process so they come back in about a second.
"""
import hashlib
import importlib
import json
import mimetypes
import os
import queue
import random
import re
import subprocess
import sys
import threading
import time
import traceback
import unicodedata
import urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
UI = os.path.join(HERE, "studio", "ui")
CACHE = os.path.join(HERE, "config", "_cache")
STATE = os.path.join(HERE, "config", "_studio.json")
EMOJI_DIR = os.path.join(HERE, "assets", "emoji")
UPLOADS = {"racer": os.path.join(HERE, "assets", "racers"), "music": os.path.join(HERE, "assets", "sounds"),
           "csv": os.path.join(HERE, "config", "_uploads")}
NOFLAGS = 0x08000000 if os.name == "nt" else 0

from make import PRESETS, GAMES  # noqa: E402
from engine import ai  # noqa: E402
from engine.backgrounds import STYLES  # noqa: E402
import updater  # noqa: E402

PY = sys.executable.replace("pythonw", "python")

# ----------------------------------------------------------------------------- games
GAME_INFO = [
    # code, name, min racers (0 = no racers), default title, blurb
    ("maze", "Maze Race", 2, "WHO REACHES THE FLAG FIRST?", "Racers bounce through a maze and smash numbered blocks. First to the flag wins."),
    ("track", "Marble Track", 2, "WHO WINS THE MARBLE RACE?", "Marbles race down a long track with gates, spinners and bumpers."),
    ("battle", "Ball Battle", 2, "LAST BALL STANDING WINS", "Balls fight with swords, daggers and spikes. Last one alive wins."),
    ("shrink", "Shrinking Arena", 2, "LAST ONE INSIDE WINS", "A spinning arena shrinks. Fall out through the gap and you're out."),
    ("rings", "Ring Escape", 1, "WHO BREAKS THE MOST RINGS?", "Balls break out of spinning rings. 1 racer = 'can it escape?'"),
    ("marbles", "Marble Elimination", 2, "LAST ONE DOWN IS OUT!", "A new peg board every round; last marble down is eliminated."),
    ("territory", "Territory War", 2, "WHICH COLOUR TAKES OVER?", "Balls flip enemy tiles. Biggest territory wins."),
    ("chain", "Chain Reaction", 1, "WHO BREAKS THE MOST BLOCKS?", "Balls smash a wall of bricks. Most bricks broken wins."),
    ("music", "Music Bounce", 1, "", "Every bounce plays the next note of a classical melody."),
    ("quiz", "Emoji Quiz", 0, "", "Emoji clues, a ticking timer, then the answer."),
    ("barrace", "Bar Chart Race", 0, "", "Animated country ranking from real World Bank data or your CSV."),
    ("whatif", "What If…?", 0, "", "Normal world vs a changed rule, side by side."),
]
LOOKS = [("sleek", "Sleek"), ("cartoon", "Cartoon")]
VIBES = ["random", "dark", "phonk", "lofi", "hype", "playful"]


def _game_modules():
    out = {}
    for code, *_ in GAME_INFO:
        try:
            out[code] = importlib.import_module(f"games.{code}")
        except Exception:
            traceback.print_exc()
    return out


MODS = _game_modules()


def version():
    return updater.current_version()


def meta():
    games = []
    for code, name, mn, title, blurb in GAME_INFO:
        if code not in MODS:
            continue
        m = MODS[code]
        extra = {}
        if code == "quiz":
            extra["topics"] = ["mixed", "movies", "countries", "foods", "phrases"]
        if code == "barrace":
            extra["datasets"] = list(m.DATASETS)
        if code == "whatif":
            extra["presets"] = {k: v[1].title() for k, v in m.PRESETS.items()}
        if code == "music":
            from engine.melodies import MELODIES
            extra["songs"] = list(MELODIES)
        games.append({"code": code, "name": name, "min": mn, "title": title, "blurb": blurb,
                      "themes": list(getattr(m, "THEMES", {})), "extra": extra})
    return {"version": version(), "games": games, "backgrounds": STYLES, "looks": LOOKS, "vibes": VIBES,
            "presets": PRESETS, "palette": ai.PALETTE}


# ----------------------------------------------------------------------------- state -> render config
def state_to_cfg(st, for_preview=False):
    """The page's state -> (game, cfg dict, extra make.py args). Raises ValueError with a friendly message."""
    code = st.get("game", "maze")
    info = next((g for g in GAME_INFO if g[0] == code), None)
    if info is None or code not in MODS:
        raise ValueError("Pick a game first.")
    mn = info[2]
    racers = []
    for r in st.get("racers", []):
        s = {"name": (r.get("name") or "Racer").strip()[:24], "color": r.get("color") or "#ef3b3b"}
        if r.get("kind") == "emoji" and r.get("emoji"):
            s["emoji"] = r["emoji"]
        elif r.get("kind") == "image" and r.get("image") and os.path.exists(r["image"]):
            s["image"] = r["image"]
            s["shape"] = r.get("shape", "circle")
        racers.append(s)
    if mn and not for_preview and not (mn <= len(racers) <= 8):
        raise ValueError(f"Use {mn} to 8 racers for this game.")
    if mn and not racers:
        racers = PRESETS["colors4"]
    tmin, tmax = int(st.get("tmin", 20)), int(st.get("tmax", 35))
    if tmax < tmin + 6:
        tmax = tmin + 6
    cfg = {"title": (st.get("title") or "").strip().upper(), "handle": st.get("handle", ""),
           "racers": racers or PRESETS["colors4"], "race_seconds": [tmin, tmax]}
    for k in ("theme", "background", "vibe"):
        if st.get(k) and st[k] != "random":
            cfg[k] = st[k]
    if st.get("look") == "cartoon":
        cfg["style"] = "cartoon"
    com = st.get("commentary", "ai")
    cfg["commentary"] = com != "off"
    cfg["commentary_ai"] = com == "ai"
    if st.get("background", "").startswith("image:") and not os.path.exists(st["background"][6:]):
        cfg.pop("background", None)
    if st.get("seed"):
        cfg["seed"] = int(st["seed"])
    ex = st.get("extra", {})
    if code == "territory":
        for k in ("layout", "shape"):
            if ex.get(k, "random") != "random":
                cfg[k] = ex[k]
    if code == "battle" and ex.get("weapons", "mixed") != "mixed":
        cfg["weapons"] = [ex["weapons"]] * 8
    if code == "music" and ex.get("song", "random") != "random":
        cfg["song"] = ex["song"]
    if code == "quiz":
        cfg["quiz_count"] = int(ex.get("quiz_count", 6))
        qs = [q for q in ex.get("questions", []) if q.get("clue") and q.get("answer")]
        if ex.get("quiz_topic") == "my questions":
            if not qs and not for_preview:
                raise ValueError("Add some questions first (or let AI write them).")
            if qs:
                cfg["questions"] = qs[: cfg["quiz_count"]]
        else:
            cfg["quiz_topic"] = ex.get("quiz_topic", "mixed")
    if code == "barrace":
        if ex.get("dataset") == "csv":
            if not ex.get("csv") or not os.path.exists(ex["csv"]):
                raise ValueError("Upload your CSV first.")
            cfg["csv"] = ex["csv"]
        elif ex.get("dataset", "random") != "random":
            cfg["dataset"] = ex["dataset"]
        a, b = sorted((int(ex.get("from", 1980)), int(ex.get("to", 2023))))
        cfg["years"] = [a, b]
        cfg["top_n"] = int(ex.get("top", 10))
    if code == "whatif":
        if isinstance(ex.get("whatif"), dict):
            cfg["whatif"] = ex["whatif"]
        elif ex.get("preset", "random") not in ("random", "ai"):
            cfg["whatif_preset"] = ex["preset"]
        elif ex.get("preset") == "ai" and (ex.get("idea") or "").strip():
            if for_preview:
                pass
            elif not ai.has_key():
                raise ValueError("Your own what-if idea needs the AI key. Or pick a built-in scenario.")
            else:
                cfg["quiz_topic"] = ex["idea"].strip()
    args = []
    music = st.get("music", "on")
    if music == "off":
        args += ["--music", "off"]
    elif music == "file" and st.get("music_file") and os.path.exists(st["music_file"]):
        args += ["--music", st["music_file"]]
    if st.get("ai_caps") and ai.has_key():
        args += ["--ai-captions"]
    if st.get("budget"):
        args += ["--ai-budget", str(float(st["budget"]))]
    return code, cfg, args


# ----------------------------------------------------------------------------- preview worker
class Worker:
    def __init__(self):
        self.lock = threading.Lock()
        self.proc = None
        self.results = {}
        self.cv = threading.Condition()
        self.n = 0

    def _start(self):
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        self.proc = subprocess.Popen([PY, "-u", "-m", "studio.worker"], cwd=HERE, stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
                                     encoding="utf-8", errors="replace", env=env, creationflags=NOFLAGS)
        threading.Thread(target=self._read, args=(self.proc,), daemon=True).start()

    def _read(self, proc):
        for line in proc.stdout:
            if line.startswith("@@RESULT "):
                r = json.loads(line[9:])
                with self.cv:
                    self.results[r["id"]] = r
                    self.cv.notify_all()
        with self.cv:
            self.cv.notify_all()

    def call(self, job, timeout=120):
        with self.lock:
            if self.proc is None or self.proc.poll() is not None:
                self._start()
            self.n += 1
            job["id"] = self.n
            self.proc.stdin.write(json.dumps(job) + "\n")
            self.proc.stdin.flush()
            t0 = time.time()
            with self.cv:
                while job["id"] not in self.results:
                    if self.proc.poll() is not None or time.time() - t0 > timeout:
                        try:
                            self.proc.kill()
                        except Exception:
                            pass
                        self.proc = None
                        return {"ok": False, "error": "Preview crashed. Try again."}
                    self.cv.wait(0.5)
                return self.results.pop(job["id"])


WORKER = Worker()                       # live preview: never waits behind thumbnails
THUMBS = [Worker(), Worker()]           # thumbnails, two at a time
_th_n = [0]


def thumb_call(job):
    _th_n[0] += 1
    return THUMBS[_th_n[0] % len(THUMBS)].call(job)


_preview_token = {"n": 0}


def _key(*parts):
    return hashlib.sha1(json.dumps(parts, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]


def cached_thumb(kind, job, key_parts):
    os.makedirs(CACHE, exist_ok=True)
    out = os.path.join(CACHE, f"{kind}_{_key(version(), *key_parts)}.png")
    if os.path.exists(out):
        return {"ok": True, "out": out}
    job = dict(job, out=out)
    return thumb_call(job)


# ----------------------------------------------------------------------------- jobs (renders + clips)
class Jobs:
    def __init__(self):
        self.items = []
        self.q = queue.Queue()
        self.lock = threading.Lock()
        self.current = None
        threading.Thread(target=self._loop, daemon=True).start()

    def add(self, kind, cmd, total, label, cfg_path=None):
        j = {"id": len(self.items) + 1, "kind": kind, "label": label, "cmd": cmd, "total": total, "done": 0,
             "frac": 0.0, "status": "queued", "log": [], "outputs": [], "cost": 0.0, "created": time.time()}
        with self.lock:
            self.items.append(j)
        self.q.put(j)
        return j

    def public(self):
        with self.lock:
            return [{k: v for k, v in j.items() if k != "cmd"} | {"log": j["log"][-12:]} for j in self.items[-30:]][::-1]

    def cancel(self, jid):
        for j in self.items:
            if j["id"] == jid:
                if j["status"] == "queued":
                    j["status"] = "cancelled"
                elif j["status"] == "running" and self.current is not None:
                    j["status"] = "cancelled"
                    try:
                        self.current.kill()
                    except Exception:
                        pass

    def busy(self):
        return any(j["status"] in ("queued", "running") for j in self.items)

    def _loop(self):
        while True:
            j = self.q.get()
            if j["status"] == "cancelled":
                continue
            j["status"] = "running"
            env = dict(os.environ, PYTHONIOENCODING="utf-8")
            try:
                p = subprocess.Popen(j["cmd"], cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                     encoding="utf-8", errors="replace", env=env, creationflags=NOFLAGS)
            except Exception as e:
                j["status"], j["error"] = "failed", str(e)
                continue
            self.current = p
            for line in p.stdout:
                line = line.rstrip()
                m = re.match(r"PROGRESS (\d+) (\d+)", line)
                if m:
                    j["frac"] = min(1.0, int(m.group(1)) / max(1, int(m.group(2))))
                    continue
                m = re.match(r"DRAMA ([\d.]+)", line)
                if m:
                    j.setdefault("drama", []).append(float(m.group(1)))
                    continue
                m = re.match(r"AICOST ([\d.]+)", line)
                if m:
                    j["cost"] += float(m.group(1))
                    continue
                m = re.search(r"-> (.+\.mp4)", line)
                if m:
                    path = m.group(1).split("  (")[0].strip()
                    j["outputs"].append(os.path.abspath(os.path.join(HERE, path)))
                    j["done"] += 1
                    j["frac"] = 0.0
                if "ALSA" in line or "pygame" in line.lower() and "hello" in line.lower():
                    continue
                j["log"].append(line)
            p.wait()
            self.current = None
            if j["status"] != "cancelled":
                j["status"] = "done" if p.returncode == 0 and j["outputs"] else "failed"
                if j["status"] == "failed" and not j.get("error"):
                    errs = [ln for ln in j["log"] if "Error" in ln or "error" in ln or "!!" in ln]
                    j["error"] = (errs[-1] if errs else (j["log"][-1] if j["log"] else "Render failed"))[:300]


JOBS = Jobs()


def out_dir(st):
    d = (st.get("out") or "").strip() or os.path.join(HERE, "output")
    return os.path.abspath(os.path.expanduser(d))


def start_render(st, count=None):
    code, cfg, args = state_to_cfg(st)
    os.makedirs(os.path.join(HERE, "config"), exist_ok=True)
    path = os.path.join(HERE, "config", f"_run_{int(time.time() * 1000)}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False)
    n = int(count or st.get("count", 1))
    od = out_dir(st)
    os.makedirs(od, exist_ok=True)
    cmd = [PY, "-u", os.path.join(HERE, "make.py"), code, "--config", path, "--count", str(n),
           "--quality", st.get("quality", "good"), "--out", od] + args
    name = next(g[1] for g in GAME_INFO if g[0] == code)
    return JOBS.add("render", cmd, n, f"{n} × {name}" + (f" · {cfg['title']}" if cfg.get("title") else ""))


def start_clip(st):
    code, cfg, args = state_to_cfg(st, for_preview=True)
    os.makedirs(CACHE, exist_ok=True)
    cfg.setdefault("seed", random.randrange(1, 10 ** 6))
    path = os.path.join(CACHE, f"clipcfg_{int(time.time() * 1000)}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"game": code, "cfg": cfg, "music": "off" if "off" in args else "on"}, f, ensure_ascii=False)
    out = os.path.join(CACHE, f"clip_{int(time.time() * 1000)}.mp4")
    cmd = [PY, "-u", "-m", "studio.clip", path, out]
    return JOBS.add("clip", cmd, 1, "6-second preview")


def start_plan(st, jobs):
    base = {}
    try:
        _, base, args = state_to_cfg(dict(st, racers=st.get("racers") or []), for_preview=True)
    except ValueError:
        args = []
    base = {k: v for k, v in base.items() if k in ("handle", "race_seconds", "background", "style", "vibe")}
    path = os.path.join(HERE, "config", "_plan.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"base": base, "jobs": jobs}, f, ensure_ascii=False)
    od = out_dir(st)
    os.makedirs(od, exist_ok=True)
    cmd = [PY, "-u", os.path.join(HERE, "make.py"), "--plan", path, "--quality", st.get("quality", "good"), "--out", od] + args
    return JOBS.add("render", cmd, len(jobs), f"Plan: {len(jobs)} videos")


# ----------------------------------------------------------------------------- emoji search
_EMOJI = []


def emoji_index():
    if _EMOJI:
        return _EMOJI
    for f in sorted(os.listdir(EMOJI_DIR)):
        code = f[:-4]
        try:
            ch = "".join(chr(int(p, 16)) for p in code.split("-"))
        except ValueError:
            continue
        names = []
        for c in ch:
            try:
                names.append(unicodedata.name(c))
            except ValueError:
                pass
        _EMOJI.append((" ".join(names).lower(), ch, f))
    return _EMOJI


def emoji_search(q, limit=96):
    words = (q or "").lower().split()
    hits = [x for x in emoji_index() if all(w in x[0] for w in words)] if words else emoji_index()[:limit]
    return [{"ch": ch, "name": (name.split() or ["racer"])[-1].title(), "url": "/emoji/" + f} for name, ch, f in hits[:limit]]


# ----------------------------------------------------------------------------- AI glue
IDEAS = os.path.join(HERE, "config", "_ideas.json")
SPARKS = ["foods", "animals", "zodiac signs", "countries", "planets", "sports", "school subjects", "desserts", "drinks",
          "jobs", "weather", "music genres", "video game classes", "mythical creatures", "fruits", "vehicles", "seasons",
          "candy", "dinosaurs", "ocean animals", "fast food", "superpowers", "elements", "emotions", "weekdays",
          "pizza toppings", "pets", "insects", "breakfast foods", "ice cream flavors", "space", "kitchen items"]


def _recent_titles():
    try:
        with open(IDEAS, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _remember(title):
    t = _recent_titles()
    if title:
        t = ([title] + [x for x in t if x != title])[:40]
        with open(IDEAS, "w", encoding="utf-8") as f:
            json.dump(t, f)


def ai_idea(code, theme, n, art="none"):
    """Returns a patch for the page state. art: none | bg | all (AI background, + AI characters)."""
    theme = (theme or "").strip() or random.choice(SPARKS)
    patch = _ai_idea(code, theme, n)
    notes = []
    if art in ("bg", "all"):
        try:
            patch["background"] = "image:" + ai.background(f"{theme}, matching the video '{patch.get('title', '')}'")
        except Exception as e:
            notes.append(f"AI background skipped: {e}")
    if art == "all" and patch.get("racers"):
        for r in patch["racers"]:
            try:
                r["image"] = ai.character(f"{r['name']} ({theme})")
                r["kind"] = "image"
                r["shape"] = "fit"
            except Exception as e:
                notes.append(f"AI characters stopped: {e}")
                break
    patch["notes"] = notes
    patch["cost"] = ai.video_spent()
    return patch


def _ai_idea(code, theme, n):
    if code == "quiz":
        qs = ai.quiz(theme, 6)
        title = f"GUESS THE {theme.upper()}"[:40]
        _remember(title)
        return {"title": title, "extra": {"quiz_topic": "my questions", "questions": qs}}
    if code == "whatif":
        r = ai.whatif_idea(theme if random.random() < 0.5 else "")
        _remember(r["title"])
        return {"title": r["title"], "extra": {"preset": "ai", "idea": r["idea"]}}
    if code == "barrace":
        ds = random.choice(MODS["barrace"].DATASETS and list(MODS["barrace"].DATASETS))
        t = ai.ask_json(f"""Write one hook title (max 6 words, uppercase) for an animated bar chart race
of countries by "{ds}" over the decades. Avoid: {_recent_titles()[:10]}. Return JSON: {{"title": "..."}}""", 1.0)
        title = str(t.get("title", ds)).upper()[:60]
        _remember(title)
        return {"title": title, "extra": {"dataset": ds}}
    if code == "music":
        from engine.melodies import MELODIES
        song = random.choice(list(MELODIES))
        res = ai.idea(code, theme, 1)
        _remember(res["title"])
        return {"title": res["title"], "racers": res["racers"][:1], "extra": {"song": song}}
    res = ai.idea(code, theme, n)
    _remember(res["title"])
    return {"title": res["title"], "racers": res["racers"]}


# ----------------------------------------------------------------------------- HTTP
def _open_path(p):
    if sys.platform == "darwin":
        subprocess.Popen(["open", p])
    elif os.name == "nt":
        os.startfile(p)  # noqa
    else:
        subprocess.Popen(["xdg-open", p])


class H(BaseHTTPRequestHandler):
    server_version = "RaceStudio"

    def log_message(self, *a):
        pass

    # -- helpers
    def _json(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def _file(self, path, cache=False):
        if not os.path.isfile(path):
            return self._json({"error": "not found"}, 404)
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        size = os.path.getsize(path)
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].partition("-")
            start = int(a) if a else 0
            end = int(b) if b else size - 1
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        else:
            self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Cache-Control", "max-age=86400" if cache else "no-store")
        self.end_headers()
        with open(path, "rb") as f:
            f.seek(start)
            left = end - start + 1
            while left > 0:
                chunk = f.read(min(1 << 16, left))
                if not chunk:
                    break
                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    return
                left -= len(chunk)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(n) if n else b""

    def _jbody(self):
        b = self._body()
        return json.loads(b.decode("utf-8")) if b else {}

    def _local_only(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ("127.0.0.1", "localhost")

    # -- routes
    def do_GET(self):
        if not self._local_only():
            return self._json({"error": "local only"}, 403)
        u = urllib.parse.urlparse(self.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        p = u.path
        try:
            if p == "/" or p == "/index.html":
                return self._file(os.path.join(UI, "index.html"))
            if p.startswith("/ui/"):
                f = os.path.normpath(os.path.join(UI, p[4:]))
                if f.startswith(UI):
                    return self._file(f)
            if p.startswith("/emoji/"):
                f = os.path.normpath(os.path.join(EMOJI_DIR, os.path.basename(p)))
                return self._file(f, cache=True)
            if p == "/favicon.ico":
                self.send_response(204)
                self.end_headers()
                return
            if p == "/api/meta":
                return self._json(meta())
            if p == "/api/state":
                try:
                    with open(STATE, encoding="utf-8") as f:
                        return self._json(json.load(f))
                except Exception:
                    return self._json({})
            if p == "/api/emoji":
                return self._json(emoji_search(q.get("q", "")))
            if p == "/api/jobs":
                return self._json({"jobs": JOBS.public(), "busy": JOBS.busy()})
            if p == "/api/ai/assets":
                items = []
                if os.path.isdir(ai.AI_ASSETS):
                    for f in sorted(os.listdir(ai.AI_ASSETS), key=lambda f: -os.path.getmtime(os.path.join(ai.AI_ASSETS, f))):
                        full = os.path.join(ai.AI_ASSETS, f)
                        items.append({"kind": "bg" if f.startswith("bg_") else "char", "path": full,
                                      "url": "/file?p=" + urllib.parse.quote(full), "name": f})
                return self._json({"items": items[:60]})
            if p == "/api/ai/status":
                u2 = ai.usage()
                import datetime
                return self._json({"has_key": ai.has_key(), "total": u2.get("total", 0),
                                   "today": u2.get("days", {}).get(datetime.date.today().isoformat(), 0)})
            if p == "/api/update/check":
                try:
                    ok, info = updater.check()
                    return self._json({"available": ok, "info": info, "current": version()})
                except Exception as e:
                    return self._json({"available": False, "error": str(e), "current": version()})
            if p == "/api/thumb/game":
                code, look = q["game"], q.get("look", "sleek")
                th = q.get("theme") or ""
                cfg = {"racers": PRESETS["colors4"], "title": "", "seed": 11, "style": look,
                       "race_seconds": [20, 35], "dataset": "Population", "whatif_preset": "200_balls"}
                if th:
                    cfg["theme"] = th
                if q.get("background"):
                    cfg["background"] = q["background"]
                r = cached_thumb("g", {"kind": "still", "game": code, "cfg": cfg, "at": float(q.get("at", 3.0)),
                                       "size": [270, 480]}, ["g", code, th, look, q.get("background", ""), q.get("at", "3")])
                return self._file(r["out"], cache=True) if r.get("ok") else self._json(r, 500)
            if p == "/api/thumb/bg":
                r = cached_thumb("b", {"kind": "bg", "game": q.get("game", "maze"), "theme": q.get("theme"),
                                       "style": q["style"], "look": q.get("look", "sleek")},
                                 ["b", q.get("game"), q.get("theme"), q["style"], q.get("look")])
                return self._file(r["out"], cache=True) if r.get("ok") else self._json(r, 500)
            if p == "/file":
                f = os.path.abspath(q.get("p", ""))
                allowed = [CACHE, ai.AI_ASSETS, UPLOADS["racer"]] + [os.path.dirname(o) for j in JOBS.items for o in j["outputs"]] + [os.path.join(HERE, "output")]
                if any(f.startswith(os.path.abspath(a) + os.sep) for a in allowed) and f.lower().endswith((".mp4", ".png", ".jpg", ".jpeg", ".webp", ".txt")):
                    return self._file(f)
                return self._json({"error": "not allowed"}, 403)
        except Exception as e:
            traceback.print_exc()
            return self._json({"error": str(e)}, 500)
        return self._json({"error": "not found"}, 404)

    def do_POST(self):
        if not self._local_only() or self.headers.get("X-Studio") != "1":
            return self._json({"error": "forbidden"}, 403)
        p = urllib.parse.urlparse(self.path).path
        try:
            if p == "/api/upload":
                q = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
                kind = q.get("kind", "racer")
                d = UPLOADS[kind]
                os.makedirs(d, exist_ok=True)
                name = re.sub(r"[^\w.\- ]", "_", urllib.parse.unquote(self.headers.get("X-Filename", "file")))[-80:]
                ok_ext = {"racer": (".png", ".jpg", ".jpeg", ".webp"), "music": (".wav",), "csv": (".csv",)}[kind]
                if not name.lower().endswith(ok_ext):
                    return self._json({"error": f"Use a {' / '.join(ok_ext)} file."}, 400)
                path = os.path.join(d, name)
                with open(path, "wb") as f:
                    f.write(self._body())
                return self._json({"path": path, "url": "/file?p=" + urllib.parse.quote(path) if kind != "racer" else ""})
            body = self._jbody()
            if p == "/api/state":
                os.makedirs(os.path.dirname(STATE), exist_ok=True)
                with open(STATE, "w", encoding="utf-8") as f:
                    json.dump(body, f, ensure_ascii=False)
                return self._json({"ok": True})
            if p == "/api/preview":
                _preview_token["n"] += 1
                my = _preview_token["n"]
                st = body.get("state", {})
                code, cfg, _ = state_to_cfg(st, for_preview=True)
                cfg.setdefault("seed", int(body.get("seed") or 7))
                with WORKER.lock:
                    pass
                if my != _preview_token["n"]:
                    return self._json({"stale": True})
                os.makedirs(CACHE, exist_ok=True)
                out = os.path.join(CACHE, f"pv_{_key(code, cfg, body.get('at'))}.png")
                if not os.path.exists(out):
                    r = WORKER.call({"kind": "still", "game": code, "cfg": cfg, "at": float(body.get("at", 3)),
                                     "out": out, "size": [540, 960]})
                    if not r.get("ok"):
                        return self._json({"error": r.get("error", "Preview failed")}, 500)
                return self._json({"url": "/file?p=" + urllib.parse.quote(out)})
            if p == "/api/render":
                j = start_render(body["state"], body.get("count"))
                return self._json({"job": j["id"]})
            if p == "/api/clip":
                j = start_clip(body["state"])
                return self._json({"job": j["id"]})
            if p == "/api/plan/run":
                j = start_plan(body["state"], body["jobs"])
                return self._json({"job": j["id"]})
            if p.startswith("/api/jobs/") and p.endswith("/cancel"):
                JOBS.cancel(int(p.split("/")[3]))
                return self._json({"ok": True})
            if p == "/api/open":
                path = body.get("path") or out_dir(body.get("state", {}))
                if os.path.isfile(path):
                    path = os.path.dirname(path) if body.get("folder") else path
                os.makedirs(path, exist_ok=True) if not os.path.splitext(path)[1] else None
                _open_path(path)
                return self._json({"ok": True})
            if p == "/api/ai/key":
                ai.save(body.get("key", ""))
                return self._json({"ok": True, "has_key": ai.has_key()})
            if p == "/api/ai/idea":
                ai.begin_video(float(body.get("budget", 10)) / 100)
                return self._json(ai_idea(body.get("game", "maze"), body.get("theme", ""), int(body.get("n", 4)),
                                          art=body.get("art", "none")))
            if p == "/api/ai/background":
                ai.begin_video(float(body.get("budget", 10)) / 100)
                path = ai.background(body.get("prompt") or "abstract colorful space")
                return self._json({"path": path})
            if p == "/api/ai/character":
                ai.begin_video(float(body.get("budget", 10)) / 100)
                path = ai.character(body.get("desc") or "a cute blob")
                return self._json({"path": path, "url": "/file?p=" + urllib.parse.quote(path)})
            if p == "/api/ai/plan":
                return self._json({"jobs": ai.plan_week(int(body.get("n", 7)), body.get("games") or list(MODS))})
            if p == "/api/ai/comments":
                names = ai.names_from_comments(body.get("text", ""), int(body.get("n", 6)))
                return self._json({"names": names})
            if p == "/api/update/apply":
                if JOBS.busy():
                    return self._json({"error": "Wait for your videos to finish first."}, 409)
                ok, info = updater.check()
                if not ok:
                    return self._json({"error": "Already up to date."}, 409)
                updater.apply(info)
                threading.Thread(target=_restart, daemon=True).start()
                return self._json({"ok": True, "version": info["version"]})
        except ai.BudgetError as e:
            return self._json({"error": str(e)}, 402)
        except (ValueError, ai.AIError) as e:
            return self._json({"error": str(e)}, 400)
        except Exception as e:
            traceback.print_exc()
            return self._json({"error": str(e) or e.__class__.__name__}, 500)
        return self._json({"error": "not found"}, 404)


def _restart():
    time.sleep(0.8)
    subprocess.Popen([PY, os.path.join(HERE, "gui.py"), "--no-browser"], cwd=HERE, creationflags=NOFLAGS)
    os._exit(0)


def serve(port=8765, open_browser=True):
    srv = None
    for attempt in range(40):
        for pt in (port, port + 1, port + 2):
            try:
                srv = ThreadingHTTPServer(("127.0.0.1", pt), H)
                port = pt
                break
            except OSError:
                srv = None
        if srv:
            break
        time.sleep(0.25)
    if srv is None:
        raise SystemExit("Couldn't start Race Studio (ports 8765-8767 busy). Is it already open?")
    url = f"http://127.0.0.1:{port}/"
    print("Race Studio running at", url, flush=True)
    if open_browser:
        import webbrowser
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    return srv, url
