"""Race Studio launcher: starts the local web app and opens it in your browser.
A small window stays open; closing it stops Race Studio. (The old window is gui_classic.py.)"""
import os
import sys
import threading
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
os.chdir(HERE)


def main():
    from studio.server import serve, version
    srv, url = serve(open_browser="--no-browser" not in sys.argv)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        import tkinter as tk
    except Exception:
        print("Race Studio is running at", url, "- press Ctrl+C to stop.")
        try:
            threading.Event().wait()
        except KeyboardInterrupt:
            pass
        return
    root = tk.Tk()
    root.title("Race Studio")
    root.configure(bg="#14161f", padx=22, pady=18)
    root.resizable(False, False)
    tk.Label(root, text=f"Race Studio {version()} is running", bg="#14161f", fg="#eef0f6",
             font=("Segoe UI", 13, "bold")).pack(anchor="w")
    tk.Label(root, text="It opens in your web browser. Keep this window open while you work;\nclosing it stops Race Studio.",
             bg="#14161f", fg="#8b91a7", justify="left").pack(anchor="w", pady=(4, 12))
    row = tk.Frame(root, bg="#14161f")
    row.pack(anchor="w")
    tk.Button(row, text="Open Race Studio", command=lambda: webbrowser.open(url), padx=12, pady=4).pack(side="left")
    tk.Button(row, text="Quit", command=root.destroy, padx=12, pady=4).pack(side="left", padx=8)
    root.mainloop()
    srv.shutdown()
    os._exit(0)


if __name__ == "__main__":
    main()
