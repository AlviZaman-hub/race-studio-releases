"""Retro Kart: top-down kart race on a twisty loop. Item boxes give boosts, oil slicks
spin you out, drafting helps the chasers. Most laps first wins. Best with a retro look.
(Original game design and art: no characters or assets from existing games.)"""
import math
import random

import pygame.gfxdraw as gfx

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner

THEMES = {
    "grass": {"bg1": "#123a12", "bg2": "#2f7a2a", "road": "#5a5a66", "edge": "#e8e8e8", "curb": "#e03030", "line": "#f0f0f0"},
    "desert": {"bg1": "#5a3a12", "bg2": "#c98a3a", "road": "#6a5a4a", "edge": "#f2e2c0", "curb": "#e07a20", "line": "#fff2d0"},
    "snow": {"bg1": "#9ab4cc", "bg2": "#e8f2fa", "road": "#4a5466", "edge": "#ffffff", "curb": "#2a6ae0", "line": "#ffffff"},
    "neon": {"bg1": "#05030c", "bg2": "#1c0a3a", "road": "#14102a", "edge": "#3ff2ff", "curb": "#ff3fd0", "line": "#3ff2ff"},
}
RANDOM_THEMES = list(THEMES)
AX0, AX1, AY0, AY1 = 90, 990, 380, 1500
ROAD = 120


def _track(seed):
    rng = random.Random(seed * 13 + 4)
    cx, cy = (AX0 + AX1) / 2, (AY0 + AY1) / 2
    rx, ry = (AX1 - AX0) / 2 - ROAD * 0.6, (AY1 - AY0) / 2 - ROAD * 0.6
    k = rng.randint(7, 10)
    pts = []
    for i in range(k):
        a = 2 * math.pi * i / k + rng.uniform(-0.15, 0.15)
        r = rng.uniform(0.55, 1.0)
        pts.append((cx + math.cos(a) * rx * r, cy + math.sin(a) * ry * r))
    # Catmull-Rom through the control points
    out = []
    for i in range(k):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[(i + 1) % k], pts[(i + 2) % k]
        for j in range(60):
            t = j / 60
            t2, t3 = t * t, t * t * t
            x = 0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3)
            y = 0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
            out.append((x, y))
    # resample by arc length
    L = [0.0]
    for i in range(1, len(out) + 1):
        a, b = out[i - 1], out[i % len(out)]
        L.append(L[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
    total = L[-1]
    n = int(total / 6)
    res, j = [], 0
    for i in range(n):
        s = total * i / n
        while L[j + 1] < s:
            j += 1
        a, b = out[j], out[(j + 1) % len(out)]
        f = (s - L[j]) / max(1e-9, L[j + 1] - L[j])
        res.append((a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f))
    # curvature per point (for corner speed)
    curv = []
    m = len(res)
    for i in range(m):
        a, b, c = res[i - 4], res[i], res[(i + 4) % m]
        h1 = math.atan2(b[1] - a[1], b[0] - a[0])
        h2 = math.atan2(c[1] - b[1], c[0] - b[0])
        d = (h2 - h1 + math.pi) % (2 * math.pi) - math.pi
        curv.append(abs(d))
    return res, curv, total


class Kart:
    def __init__(self, i, rng):
        self.i = i
        self.s = 0.0
        self.lap = 0
        self.lat = 0.0
        self.lat_t = 0.0
        self.base = rng.uniform(0.94, 1.06)
        self.corner = rng.uniform(0.85, 1.15)
        self.boost = 0.0
        self.spin = 0.0
        self.v = 0.0
        self.done = None
        self.trail = []


class Race:
    def __init__(self, n, seed, laps, speed=420.0, sound=None):
        self.rng = random.Random(seed * 3 + 2)
        self.pts, self.curv, self.total = _track(seed)
        self.m = len(self.pts)
        self.n, self.laps, self.speed, self.sound = n, laps, speed, sound
        self.karts = [Kart(i, self.rng) for i in range(n)]
        for k, K in enumerate(self.karts):   # grid start
            K.s = -(k // 2) * 46.0
            K.lat = K.lat_t = (-1 if k % 2 else 1) * ROAD * 0.22
        self.items = [{"s": self.total * f, "lat": self.rng.uniform(-0.3, 0.3) * ROAD, "t": -9.0}
                      for f in (0.22, 0.48, 0.74)]
        self.oil = []
        self.clock = self.now = 0.0
        self.finished = []
        self.winner = None
        self.events = []

    def pos(self, s, lat=0.0):
        s %= self.total
        f = s / self.total * self.m
        i = int(f) % self.m
        a, b = self.pts[i], self.pts[(i + 1) % self.m]
        u = f - int(f)
        x, y = a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u
        h = math.atan2(b[1] - a[1], b[0] - a[0])
        return x - math.sin(h) * lat, y + math.cos(h) * lat, h

    def dist(self, K):
        return K.lap * self.total + K.s

    def step(self, dt, now):
        self.now = now
        self.clock += dt
        order = sorted(self.karts, key=lambda K: -self.dist(K))
        for rank, K in enumerate(order):
            if K.done is not None:
                K.v *= 0.97
                K.s += K.v * dt
                continue
            idx = int((K.s % self.total) / self.total * self.m)
            ahead = max(self.curv[(idx + j) % self.m] for j in range(0, 18, 3))
            v = self.speed * K.base * (1 - min(0.45, ahead * 2.2 / K.corner))
            if K.boost > 0:
                v *= 1.55
                K.boost -= dt
            if K.spin > 0:
                v *= 0.25
                K.spin -= dt
            # draft behind someone close: catch-up
            for O in self.karts:
                if O is not K and 0 < self.dist(O) - self.dist(K) < 70:
                    v *= 1.06
                    break
            v *= 1 + 0.02 * rank   # rubber band, small
            K.v += (v - K.v) * min(1, dt * 3)
            K.s += K.v * dt
            if K.s >= self.total:
                K.s -= self.total
                K.lap += 1
                if K.lap >= self.laps:
                    K.done = self.clock
                    self.finished.append(K)
                    if self.winner is None:
                        self.winner = K
                    self.events.append(("finish", K))
                else:
                    self.events.append(("lap", K))
            # lane changes: drift toward a random lane, dodge others
            if self.rng.random() < dt * 0.8:
                K.lat_t = self.rng.uniform(-0.32, 0.32) * ROAD
            for O in self.karts:
                if O is not K and abs((O.s - K.s + self.total / 2) % self.total - self.total / 2) < 34 and abs(O.lat - K.lat) < 30:
                    K.lat_t += (8 if K.lat >= O.lat else -8)
            K.lat_t = max(-0.38 * ROAD, min(0.38 * ROAD, K.lat_t))
            K.lat += (K.lat_t - K.lat) * min(1, dt * 2.5)
            # item boxes
            for it in self.items:
                if self.clock - it["t"] > 2.5 and abs((K.s - it["s"] + self.total / 2) % self.total - self.total / 2) < 18 and abs(K.lat - it["lat"]) < 34:
                    it["t"] = self.clock
                    if rank == 0 and self.rng.random() < 0.6:   # leader drops oil behind
                        self.oil.append({"s": (K.s - 60) % self.total, "lat": K.lat, "t": self.clock})
                        self.events.append(("oil", K))
                    else:
                        K.boost = 1.3
                        self.events.append(("boost", K))
            for o in list(self.oil):
                if self.clock - o["t"] > 0.6 and abs((K.s - o["s"] + self.total / 2) % self.total - self.total / 2) < 16 and abs(K.lat - o["lat"]) < 30:
                    K.spin = 0.9
                    self.oil.remove(o)
                    self.events.append(("spin", K))
            self.oil = [o for o in self.oil if self.clock - o["t"] < 9]


def tune(seed, n, t_min, t_max, fps=60):
    target = (t_min + t_max) / 2

    def run(laps, sp):
        R = Race(n, seed, laps, sp)
        while R.winner is None and R.clock < t_max * 3:
            R.step(1 / fps, R.clock)
        return R.clock
    t1 = run(1, 420.0)
    laps = max(2, min(6, round(target / max(t1, 1))))
    sp = max(300.0, min(620.0, 420.0 * laps * t1 / target))
    return laps, sp, run(laps, sp)


def _kart_sprite(color, look):
    s = pygame.Surface((64, 40), pygame.SRCALPHA)
    dark = V.darker(color, 0.55)
    pygame.draw.rect(s, (20, 20, 24), pygame.Rect(6, 0, 14, 8), border_radius=3)
    pygame.draw.rect(s, (20, 20, 24), pygame.Rect(6, 32, 14, 8), border_radius=3)
    pygame.draw.rect(s, (20, 20, 24), pygame.Rect(42, 1, 12, 7), border_radius=3)
    pygame.draw.rect(s, (20, 20, 24), pygame.Rect(42, 32, 12, 7), border_radius=3)
    pygame.draw.rect(s, dark, pygame.Rect(2, 6, 60, 28), border_radius=10)
    pygame.draw.rect(s, color, pygame.Rect(4, 8, 56, 24), border_radius=9)
    pygame.draw.rect(s, (255, 255, 255), pygame.Rect(50, 13, 8, 14), border_radius=3)
    return s


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    laps, sp, est = tune(cfg["seed"], n, t_min, t_max, cfg.get("fps", 60))
    print(f"  {laps} laps, speed {sp:.0f}, ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["grass"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, est + 6, th)
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    R = Race(n, cfg["seed"], laps, sp, sound=sound)
    sprites = [_kart_sprite(lk.color, lk) for lk in looks]
    # static track layer
    track = pygame.Surface((W, H), pygame.SRCALPHA)
    P = R.pts
    for i in range(0, R.m, 2):
        x, y = P[i]
        gfx.filled_circle(track, int(x), int(y), ROAD // 2 + 10, T["edge"])
    for i in range(0, R.m, 6):
        if (i // 6) % 2:
            x, y = P[i]
            gfx.filled_circle(track, int(x), int(y), ROAD // 2 + 10, T["curb"])
    for i in range(0, R.m, 2):
        x, y = P[i]
        gfx.filled_circle(track, int(x), int(y), ROAD // 2, T["road"])
    for i in range(0, R.m, 10):
        a, b = P[i], P[(i + 4) % R.m]
        pygame.draw.line(track, T["line"], a, b, 4)
    x, y, h = R.pos(0)
    for j in range(-5, 6):
        for q in range(2):
            col = (20, 20, 20) if (j + q) % 2 else (240, 240, 240)
            cx = x - math.sin(h) * j * 11 + math.cos(h) * (q * 11 - 5)
            cy = y + math.cos(h) * j * 11 + math.sin(h) * (q * 11 - 5)
            pygame.draw.rect(track, col, pygame.Rect(cx - 6, cy - 6, 12, 12))
    title = _wrap(cfg.get("title") or "WHO WINS THE KART RACE?", 22)
    handle = cfg.get("handle", "")
    count_in = 1.6
    win_time = None
    rank_x = {}
    seen = 0
    final_lap_said = False
    for k in range(3):
        sound.add(k * 0.5, "count")
    sound.add(1.5, "go")
    while True:
        t = run.t
        racing = t >= count_in
        if racing and (win_time is None or t - win_time < 3):
            R.step(run.dt, t)   # same step as tune()
        while seen < len(R.events):
            kind, K = R.events[seen]
            seen += 1
            x, y, _ = R.pos(K.s, K.lat)
            pan = 0.15 + 0.7 * x / W
            if kind == "boost":
                sound.add(t, "boost", pan=pan)
                fx.burst(x, y, (255, 230, 90), n=14, speed=360)
            elif kind == "spin":
                sound.add(t, "die", pan=pan)
                run.comm.say(t, "spin", weight=1.2, name=looks[K.i].name)
            elif kind == "oil":
                sound.add(t, "hit", pan=pan)
            elif kind == "lap":
                sound.add(t, "escape", who=K.i, pan=pan)
                if K.lap == R.laps - 1 and not final_lap_said:
                    final_lap_said = run.comm.say(t, "final", force=True)
            elif kind == "finish" and win_time is None:
                win_time = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
        order = sorted(R.karts, key=lambda K: (K.done is None, K.done or 0, -R.dist(K)))
        if racing and win_time is None:
            run.comm.lead(t, looks[order[0].i].name, hold=0.8)
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        cv.blit(track, (0, 0))
        for it in R.items:
            if R.clock - it["t"] > 2.5:
                x, y, h = R.pos(it["s"], it["lat"])
                bob = math.sin(t * 5) * 4
                pygame.draw.rect(cv, (255, 210, 40), pygame.Rect(x - 17, y - 17 + bob, 34, 34), border_radius=7)
                pygame.draw.rect(cv, (255, 255, 255), pygame.Rect(x - 17, y - 17 + bob, 34, 34), 3, border_radius=7)
                V.blit_center(cv, V.text("?", 28, (120, 60, 0), None), x, y + bob)
        for o in R.oil:
            x, y, h = R.pos(o["s"], o["lat"])
            gfx.filled_ellipse(cv, int(x), int(y), 26, 16, (20, 16, 30))
            gfx.filled_ellipse(cv, int(x + 6), int(y - 3), 9, 5, (90, 70, 140))
        for K in sorted(R.karts, key=lambda K: R.pos(K.s, K.lat)[1]):
            x, y, h = R.pos(K.s, K.lat)
            ang = h + (K.spin * 12 if K.spin > 0 else 0)
            K.trail.append((x, y))
            K.trail = K.trail[-10:]
            if K.boost > 0:
                for j in range(1, len(K.trail)):
                    pygame.draw.line(cv, (255, 200, 60), K.trail[j - 1], K.trail[j], 6)
            img = pygame.transform.rotozoom(sprites[K.i], -math.degrees(ang), 1.25)
            V.blit_center(cv, img, x, y)
            V.blit_center(cv, looks[K.i].badge(50), x, y - 8)
        fx.draw(cv)
        y0 = _draw_title(cv, title, t)
        lead = order[0]
        lap_txt = "FINISH!" if win_time is not None else f"LAP {min(R.laps, lead.lap + 1)}/{R.laps}"
        V.blit_center(cv, V.text(lap_txt, 44, (255, 220, 90), (0, 0, 0)), W / 2, y0 + 8)
        if t < count_in:
            k = min(2, int(t / 0.5))
            V.blit_center(cv, V.text(str(3 - k), int(220 * (1.4 - 0.4 * min(1, (t % 0.5) * 6))), (255, 255, 255), (0, 0, 0)), W / 2, (AY0 + AY1) / 2)
        elif t - count_in < 0.5 and win_time is None:
            V.blit_center(cv, V.text("GO!", 220, (255, 230, 60), (0, 0, 0)), W / 2, (AY0 + AY1) / 2)
        slot = min(120, 1000 // n)
        x0 = W / 2 - slot * (n - 1) / 2
        for pos_i, K in enumerate(order):
            tx = x0 + pos_i * slot
            cx = rank_x.get(K.i, tx)
            cx += (tx - cx) * min(1, run.dt * 8)
            rank_x[K.i] = cx
            V.blit_center(cv, looks[K.i].badge(int(slot * 0.5)), cx, 1640)
            V.blit_center(cv, V.text(str(pos_i + 1), 26, (255, 255, 255), (0, 0, 0)), cx + slot * 0.3, 1615)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1860)
        if win_time is not None:
            class _W:
                look = looks[R.winner.i]
            _draw_winner(cv, _W, t - win_time + 0.8, T, line3=f"{R.laps} laps in {R.winner.done:.1f}s")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Race ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": looks[R.winner.i].name, "level": cfg["seed"]}
