"""Game 3: Marble Elimination.

Every round the surviving marbles drop through a fresh peg board with
spinners and bumpers. The last marble to reach the bottom is OUT. Rounds
continue until one champion is left.
"""
import math
import random

from engine.video import pygame
from engine import visual as V
from games.maze import W, H, _wrap, _draw_winner, _draw_title
import pygame.gfxdraw as gfx

THEMES = {
    "arcade": {"bg1": "#0a0a1e", "bg2": "#24124a", "board": "#141a33", "peg": "#ffd23f", "wall": "#4ad6ff", "accent": "#ff4f8b"},
    "classic": {"bg1": "#0b1f14", "bg2": "#1f5a3a", "board": "#f5f1e6", "peg": "#3a3a3a", "wall": "#7a4a22", "accent": "#e83a3a"},
    "ice": {"bg1": "#04192a", "bg2": "#145a80", "board": "#eaf7ff", "peg": "#2a8ed8", "wall": "#1d4f78", "accent": "#ff5c8a"},
    "lava": {"bg1": "#1a0400", "bg2": "#5c1704", "board": "#24100a", "peg": "#ff8a2a", "wall": "#ff4a1c", "accent": "#ffe14a"},
    "candy": {"bg1": "#2e0a2a", "bg2": "#83306f", "board": "#fff0f8", "peg": "#ff5fb0", "wall": "#9b4dff", "accent": "#18c6c6"},
}

THEMES.update({
    "graphite": {"bg1": "#07080b", "bg2": "#1d2129", "board": "#14171d", "peg": "#d9dde6", "wall": "#8a93a6", "accent": "#ff3d5a"},
    "noir": {"bg1": "#030303", "bg2": "#18181b", "board": "#0c0c0f", "peg": "#f5f5f5", "wall": "#4a4a52", "accent": "#ffcc00"},
})
RANDOM_THEMES = ["arcade", "lava", "graphite", "noir"]

L, R = 60, 1020
TOP = 380
PEG_TOP, PEG_BOT = 500, 1360
FUNNEL_Y = 1410
HOLE_Y = 1525
FINISH_Y = 1560
HOLE_W = 100
G = 1700.0
E_PEG = 0.55


class Board:
    def __init__(self, seed, r_ball):
        rng = random.Random(seed)
        self.rng = rng
        self.segs = [((L, TOP - 40), (L, FUNNEL_Y)), ((R, TOP - 40), (R, FUNNEL_Y)),
                     ((L, FUNNEL_Y), (W / 2 - HOLE_W / 2, HOLE_Y)), ((R, FUNNEL_Y), (W / 2 + HOLE_W / 2, HOLE_Y)),
                     ((W / 2 - HOLE_W / 2, HOLE_Y), (W / 2 - HOLE_W / 2, FINISH_Y)),
                     ((W / 2 + HOLE_W / 2, HOLE_Y), (W / 2 + HOLE_W / 2, FINISH_Y))]
        # spinners
        self.spinners = []
        for _ in range(rng.choice([1, 2, 2, 3])):
            ln = rng.uniform(150, 230)
            cx = rng.uniform(L + ln / 2 + 20, R - ln / 2 - 20)
            cy = rng.uniform(PEG_TOP + 120, PEG_BOT - 80)
            if any(abs(cy - s["c"][1]) < 200 and abs(cx - s["c"][0]) < 260 for s in self.spinners):
                continue
            self.spinners.append({"c": (cx, cy), "len": ln, "a": rng.uniform(0, 3.14),
                                  "w": rng.choice([-1, 1]) * rng.uniform(1.6, 3.0)})
        # bumpers
        self.bumpers = []
        for _ in range(rng.choice([0, 1, 2, 3])):
            for _try in range(20):
                x, y = rng.uniform(L + 80, R - 80), rng.uniform(PEG_TOP + 60, PEG_BOT - 40)
                if all(math.hypot(x - s["c"][0], y - s["c"][1]) > s["len"] / 2 + 70 for s in self.spinners) and \
                   all(math.hypot(x - b["x"], y - b["y"]) > 140 for b in self.bumpers):
                    self.bumpers.append({"x": x, "y": y, "r": rng.uniform(26, 36), "flash": 0.0})
                    break
        # pegs (staggered rows), cleared around spinners/bumpers
        sx = rng.choice([84, 96, 108])
        sy = rng.choice([70, 78, 86])
        self.peg_r = 8
        self.rows = []
        y = PEG_TOP
        j = 0
        min_gap = 2 * r_ball + 2 * self.peg_r + 10
        sx = max(sx, min_gap)
        while y <= PEG_BOT:
            row = []
            off = sx / 2 if j % 2 else 0
            x = L + sx / 2 + off
            while x < R - 18:
                ok = rng.random() > 0.12
                wall_gap = min(x - L, R - x) - self.peg_r
                if wall_gap < 2 * r_ball + 8:
                    ok = False  # never leave a gap a marble can wedge into
                for s in self.spinners:
                    if math.hypot(x - s["c"][0], y - s["c"][1]) < s["len"] / 2 + r_ball + 14:
                        ok = False
                for b in self.bumpers:
                    if math.hypot(x - b["x"], y - b["y"]) < b["r"] + r_ball * 2 + 12:
                        ok = False
                if ok:
                    row.append([x, y, 0.0])
                x += sx
            self.rows.append((y, row))
            y += sy
            j += 1
        self.row_sy = sy

    def pegs_near(self, y, reach):
        for ry, row in self.rows:
            if abs(ry - y) <= reach:
                yield from row


import pymunk  # noqa: E402

CT_MARBLE, CT_PEG, CT_BUMPER, CT_WALL, CT_SPIN = 1, 2, 3, 4, 5


class Marble:
    def __init__(self, i, look, r):
        self.i = i
        self.look = look
        self.alive = True
        self.done = False
        self.slow = 0.0
        self.trail = []
        self.body = pymunk.Body(1.0, pymunk.moment_for_circle(1.0, 0, r))
        self.shape = pymunk.Circle(self.body, r)
        self.shape.elasticity = 0.55
        self.shape.friction = 0.6
        self.shape.collision_type = CT_MARBLE
        self.shape.marble = self

    x = property(lambda s: s.body.position.x)
    y = property(lambda s: s.body.position.y)
    vx = property(lambda s: s.body.velocity.x)
    vy = property(lambda s: s.body.velocity.y)


class Sim:
    """Rigid-body Plinko: marbles roll, spin, ricochet off pegs, get flicked by spinners."""

    def __init__(self, looks, seed, r_ball=19, sound=None, fx=None):
        self.rng = random.Random(seed * 13 + 5)
        self.seed = seed
        self.r = r_ball
        self.sound = sound
        self.fx = fx
        self.marbles = [Marble(i, lk, r_ball) for i, lk in enumerate(looks)]
        self.round = 0
        self.board = None
        self.space = None
        self.order = []
        self.out = None
        self.state = "setup"
        self.t_round = 0.0
        self.now = 0.0

    def alive(self):
        return [m for m in self.marbles if m.alive]

    def _build_space(self):
        bd = self.board
        sp = pymunk.Space()
        sp.gravity = (0, G)
        sp.iterations = 25
        st = sp.static_body
        for a_, b_ in bd.segs:
            sg = pymunk.Segment(st, a_, b_, 5)
            sg.elasticity, sg.friction, sg.collision_type = 0.4, 0.5, CT_WALL
            sp.add(sg)
        for ry, row in bd.rows:
            for p in row:
                c = pymunk.Circle(st, bd.peg_r, (p[0], p[1]))
                c.elasticity, c.friction, c.collision_type = 0.5, 0.3, CT_PEG
                c.peg = p
                sp.add(c)
        for bm in bd.bumpers:
            c = pymunk.Circle(st, bm["r"], (bm["x"], bm["y"]))
            c.elasticity, c.friction, c.collision_type = 1.25, 0.2, CT_BUMPER
            c.bumper = bm
            sp.add(c)
        for s_ in bd.spinners:
            body = pymunk.Body(body_type=pymunk.Body.KINEMATIC)
            body.position = s_["c"]
            body.angle = s_["a"]
            body.angular_velocity = s_["w"]
            sg = pymunk.Segment(body, (-s_["len"] / 2, 0), (s_["len"] / 2, 0), 6)
            sg.elasticity, sg.friction, sg.collision_type = 0.5, 0.8, CT_SPIN
            sp.add(body, sg)
            s_["body"] = body
        sp.on_collision(CT_MARBLE, CT_PEG, post_solve=self._on_peg)
        sp.on_collision(CT_MARBLE, CT_BUMPER, post_solve=self._on_bumper)
        sp.on_collision(CT_MARBLE, CT_WALL, post_solve=self._on_hit)
        sp.on_collision(CT_MARBLE, CT_SPIN, post_solve=self._on_hit)
        sp.on_collision(CT_MARBLE, CT_MARBLE, post_solve=self._on_marble)
        self.space = sp

    def start_round(self, now):
        self.round += 1
        self.board = Board(self.seed * 1000 + self.round, self.r)
        self._build_space()
        self.order = []
        self.out = None
        al = self.alive()
        self.rng.shuffle(al)
        n = len(al)
        span = (R - L - 80)
        for k, m in enumerate(al):
            m.body.position = (L + 40 + span * (k + 0.5) / n + self.rng.uniform(-6, 6), TOP + self.rng.uniform(-6, 6))
            m.body.velocity = (self.rng.uniform(-60, 60), 0)
            m.body.angle = 0
            m.body.angular_velocity = 0
            m.done = False
            m.slow = 0
            m.trail = []
            self.space.add(m.body, m.shape)
        self.state = "drop"
        self.t_round = 0.0

    def _ev(self, kind, m=None, x=None, **kw):
        if self.sound is not None:
            xx = x if x is not None else (m.x if m else W / 2)
            self.sound.add(self.now, kind, who=m.i if m else None, pan=0.15 + 0.7 * xx / W, **kw)

    @staticmethod
    def _imp(arb):
        j = arb.total_impulse
        return math.hypot(j.x, j.y)

    def _on_peg(self, arb, space, data):
        if arb.is_first_contact:
            arb.shapes[1].peg[2] = 1.0
            imp = self._imp(arb)
            if imp > 90:
                self._ev("bounce", arb.shapes[0].marble, min_gap=0.07, gain=min(1.0, imp / 500))

    def _on_bumper(self, arb, space, data):
        if arb.is_first_contact:
            arb.shapes[1].bumper["flash"] = 1.0
            self._ev("hit", arb.shapes[0].marble, min_gap=0.08)

    def _on_hit(self, arb, space, data):
        if arb.is_first_contact and self._imp(arb) > 160:
            self._ev("bounce", arb.shapes[0].marble, min_gap=0.08, gain=0.7)

    def _on_marble(self, arb, space, data):
        if arb.is_first_contact and self._imp(arb) > 120:
            self._ev("racer", arb.shapes[0].marble, min_gap=0.1)

    def step(self, dt, now):
        if self.state != "drop":
            return
        self.now = now
        self.t_round += dt
        bd = self.board
        for b in bd.bumpers:
            b["flash"] = max(0, b["flash"] - dt * 5)
        self.space.step(dt)
        for s_ in bd.spinners:
            s_["a"] = s_["body"].angle
        active = [m for m in self.marbles if m.alive and not m.done]
        for m in active:
            if m.y > FINISH_Y + self.r:
                m.done = True
                self.order.append(m)
                self.space.remove(m.body, m.shape)
                self._ev("escape", m)
                continue
            m.body.angular_velocity = max(-30, min(30, m.body.angular_velocity))
            sp = m.body.velocity.length
            m.slow = m.slow + dt if sp < 40 else 0
            if m.slow > 0.8:  # never let a marble get stuck
                m.body.velocity = ((1 if m.x < W / 2 else -1) * self.rng.uniform(280, 380), -320)
                m.slow = 0
        left = [m for m in self.marbles if m.alive and not m.done]
        if len(left) == 1 or (self.t_round > 16 and left):
            loser = min(left, key=lambda m: m.y)
            for m in left:
                if m is not loser:
                    m.done = True
                    self.order.append(m)
            loser.alive = False
            self.out = loser
            self.state = "out"
            self._ev("break", loser)
            if self.fx is not None:
                self.fx.burst(loser.x, loser.y, loser.look.color, n=40, speed=700, size=(8, 16))
            for m in left:
                if m.body.space is not None:
                    self.space.remove(m.body, m.shape)


# ---------------------------------------------------------------- render

def render(cfg, out_path, sound):
    import os
    from engine.video import make_writer
    from engine import backgrounds
    T = {k: V.hexc(v) for k, v in THEMES.get(cfg.get("theme", "arcade"), THEMES["arcade"]).items()}
    fps = cfg.get("fps", 60)
    seed = cfg["seed"]
    n = len(cfg["racers"])
    V.STYLE["mode"] = cfg.get("style", "sleek")
    V.STYLE["retro"] = cfg.get("retro")
    r_ball = 30 if n <= 4 else 26 if n <= 6 else 23
    pygame.display.init()
    pygame.font.init()
    pygame.display.set_mode((1, 1))
    canvas = pygame.Surface((W, H))
    looks = [V.Look(s, 44) for s in cfg["racers"]]
    fx = V.Particles(random.Random(seed))
    S = Sim(looks, seed, r_ball, sound=sound, fx=fx)
    bg, _ = backgrounds.make(W, H, T["bg1"], T["bg2"], cfg.get("background"), seed)
    title_lines = _wrap(cfg.get("title") or "LAST ONE DOWN IS OUT!", 22)
    handle = cfg.get("handle", "")
    writer = make_writer(cfg, out_path, W, H, fps, sound)
    from engine.commentary import Commentary
    comm = Commentary(cfg, sound)
    dt = 1 / fps
    sub = max(1, round(240 / fps))
    est_total = (n - 1) * 8.0 + 6
    frame = 0
    phase = "intro"
    phase_t = 0.0
    board_layer = None
    win_time = None
    rounds_total = n - 1
    sound.add(0.0, "whoosh")
    while True:
        t = frame * dt
        phase_t += dt
        # ------------------------------------------------ flow
        if phase == "intro" and phase_t >= 0.0:
            S.start_round(t)
            board_layer = _board_layer(S.board, T)
            phase, phase_t = "banner", 0.0
            sound.add(t, "whoosh")
        elif phase == "banner" and phase_t >= (0.0 if (V.sleek() and S.round == 1) else 0.6 if V.sleek() else 1.1):
            phase, phase_t = "drop", 0.0
            sound.add(t, "go")
        elif phase == "drop":
            for i in range(sub):
                S.step(dt / sub, t + i * dt / sub)
            if S.state == "out":
                phase, phase_t = "out", 0.0
                if S.out is not None and S.out.look:
                    comm.out(t, S.out.look.name, left=len(S.alive()))
        elif phase == "out" and phase_t >= (1.1 if V.sleek() else 1.7):
            if len(S.alive()) <= 1:
                phase, phase_t = "champ", 0.0
                win_time = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
            else:
                S.start_round(t)
                board_layer = _board_layer(S.board, T)
                phase, phase_t = "banner", 0.0
                sound.add(t, "whoosh")
        fx.update(dt)
        for m in S.marbles:
            if m.alive and not m.done and phase == "drop":
                m.trail.append((m.x, m.y))
                if len(m.trail) > 8:
                    m.trail.pop(0)
        # ------------------------------------------------ draw
        canvas.blit(bg, (0, 0))
        canvas.blit(board_layer, (0, 0))
        bd = S.board
        for ry, row in bd.rows:
            for p in row:
                if p[2] > 0:
                    p[2] = max(0, p[2] - dt * 5)
                    col = V.mix(T["peg"], (255, 255, 255), p[2])
                    rr = bd.peg_r + 3 * p[2]
                    gfx.filled_circle(canvas, int(p[0]), int(p[1]), int(rr), col)
                    gfx.aacircle(canvas, int(p[0]), int(p[1]), int(rr), col)
        for b in bd.bumpers:
            col = V.mix(T["accent"], (255, 255, 255), b["flash"] * 0.8)
            rr = int(b["r"] * (1 + 0.15 * b["flash"]))
            gfx.filled_circle(canvas, int(b["x"]), int(b["y"]), rr, V.darker(col, 0.6))
            gfx.filled_circle(canvas, int(b["x"]), int(b["y"]), int(rr * 0.8), col)
            gfx.aacircle(canvas, int(b["x"]), int(b["y"]), rr, V.darker(col, 0.6))
        for s in bd.spinners:
            cx, cy = s["c"]
            hx, hy = math.cos(s["a"]) * s["len"] / 2, math.sin(s["a"]) * s["len"] / 2
            pygame.draw.line(canvas, V.darker(T["wall"], 0.5), (cx - hx, cy - hy + 4), (cx + hx, cy + hy + 4), 14)
            pygame.draw.line(canvas, T["wall"], (cx - hx, cy - hy), (cx + hx, cy + hy), 12)
            for ex, ey in ((cx - hx, cy - hy), (cx + hx, cy + hy)):
                pygame.draw.circle(canvas, T["wall"], (round(ex), round(ey)), 6)
            pygame.draw.circle(canvas, (255, 255, 255), (round(cx), round(cy)), 7)
        for m in S.marbles:
            if not m.alive or m.done:
                continue
            for i in range(1, len(m.trail)):
                k = i / len(m.trail)
                pygame.draw.line(canvas, V.mix(T["board"], m.look.color, 0.25 + 0.5 * k), m.trail[i - 1], m.trail[i], max(2, int(r_ball * (0.75 if V.sleek() else 1.1) * k)))
        for m in S.marbles:
            if m.alive and not m.done and phase in ("banner", "drop", "out"):
                m.look.draw_body(canvas, m.x, m.y, m.body.angle, m.vx, m.vy, r_ball * 2, "ball")
        fx.draw(canvas)
        # title + round label
        y = _draw_title(canvas, title_lines, t, 110) - 20
        alive_n = len(S.alive()) + (1 if phase == "out" else 0)
        if phase != "champ":
            V.blit_center(canvas, V.text(f"ROUND {S.round}/{rounds_total}  ·  {alive_n} LEFT", 40, (255, 230, 60), (15, 15, 25), 4), W / 2, y + 4)
        _roster(canvas, S, T)
        if handle:
            V.blit_center(canvas, V.text(handle, 30, (255, 255, 255), (0, 0, 0), 3, "Medium"), W / 2, 1830)
        if phase == "banner":
            a = min(1, phase_t / 0.25)
            label = "FINAL!" if alive_n == 2 else f"ROUND {S.round}"
            V.blit_center(canvas, V.text(label, int(180 * (0.6 + 0.4 * a)), (255, 255, 255), (15, 15, 25), 12, weight="Display"), W / 2, 900)
        if phase == "out" and S.out is not None:
            a = min(1, phase_t / 0.2)
            V.blit_center(canvas, S.out.look.hero(0.6 * a + 0.01), W / 2, 820)
            V.blit_center(canvas, V.text(f"{S.out.look.name.upper()} IS OUT", int(110 * a) + 1, T["accent"] if not V.sleek() else (255, 255, 255), (255, 255, 255) if not V.sleek() else (0, 0, 0), 8, weight="Display"), W / 2, 1010)
        if phase == "champ":
            champ = S.alive()[0]
            _draw_winner(canvas, champ, phase_t + 0.8, T, line2="CHAMPION!", line3=f"Survived {rounds_total} rounds")
        comm.draw(canvas, t)
        writer.write(canvas)
        frame += 1
        if frame % 30 == 0:
            print(f"PROGRESS {frame} {int(est_total * fps)}", flush=True)
        if phase == "champ" and phase_t >= 4.0:
            break
        if t > 600:
            raise RuntimeError("Tournament ran too long")
    duration = frame * dt
    wav = out_path + ".wav"
    sound.render(duration, wav)
    writer.close(wav)
    os.remove(wav)
    pygame.quit()
    return {"duration": duration, "winner": S.alive()[0].look.name, "level": seed}


def _board_layer(bd, T):
    s = pygame.Surface((W, H), pygame.SRCALPHA)
    poly = [(L, TOP - 50), (R, TOP - 50), (R, FUNNEL_Y), (W / 2 + HOLE_W / 2, HOLE_Y), (W / 2 + HOLE_W / 2, FINISH_Y + 10),
            (W / 2 - HOLE_W / 2, FINISH_Y + 10), (W / 2 - HOLE_W / 2, HOLE_Y), (L, FUNNEL_Y)]
    shadow = [(x + 8, y + 12) for x, y in poly]
    pygame.draw.polygon(s, (0, 0, 0, 90), shadow)
    pygame.draw.polygon(s, (*T["board"], 255), poly)
    for a, b in bd.segs:
        pygame.draw.line(s, T["wall"], a, b, 10)
        pygame.draw.circle(s, T["wall"], (round(a[0]), round(a[1])), 5)
        pygame.draw.circle(s, T["wall"], (round(b[0]), round(b[1])), 5)
    for ry, row in bd.rows:
        for x, y, _ in row:
            gfx.filled_circle(s, int(x), int(y), bd.peg_r, T["peg"])
            gfx.aacircle(s, int(x), int(y), bd.peg_r, T["peg"])
    # checkered finish strip
    cell = 10
    for i in range(int(HOLE_W // cell)):
        for j in range(2):
            col = (20, 20, 20) if (i + j) % 2 else (245, 245, 245)
            pygame.draw.rect(s, col, pygame.Rect(W / 2 - HOLE_W / 2 + i * cell, FINISH_Y - 2 + j * cell, cell, cell))
    return s


def _roster(dst, S, T):
    ms = S.marbles
    n = len(ms)
    slot = min(118, 1000 // n)
    y = 1700
    x0 = W / 2 - slot * (n - 1) / 2
    for k, m in enumerate(ms):
        x = x0 + k * slot
        badge = m.look.badge(int(slot * 0.55))
        if not m.alive:
            badge = badge.copy()
            badge.set_alpha(70)
        V.blit_center(dst, badge, x, y)
        if not m.alive:
            d = slot * 0.25
            pygame.draw.line(dst, (235, 50, 60), (x - d, y - d), (x + d, y + d), 6)
            pygame.draw.line(dst, (235, 50, 60), (x - d, y + d), (x + d, y - d), 6)
        elif m.done:
            pos = S.order.index(m) + 1 if m in S.order else 0
            if pos:
                V.blit_center(dst, V.text(f"#{pos}", 28, (120, 255, 150), (0, 0, 0), 3), x, y + slot * 0.42)
