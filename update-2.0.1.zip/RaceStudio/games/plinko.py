"""Plinko: every round each racer drops a ball through the peg board into a prize slot.
Points add up over the rounds; most points wins. Jackpot slot in the middle edges."""
import math
import random

import pymunk
import pygame.gfxdraw as gfx

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner

THEMES = {
    "casino": {"bg1": "#07030c", "bg2": "#2a0c3a", "peg": "#ffe8a8", "board": "#120818", "accent": "#ffcf3f"},
    "neon": {"bg1": "#020812", "bg2": "#06243a", "peg": "#bff6ff", "board": "#061420", "accent": "#3ff2ff"},
    "candy": {"bg1": "#140410", "bg2": "#3a0f30", "peg": "#ffd6ef", "board": "#1c0818", "accent": "#ff6bc1"},
    "forest": {"bg1": "#030a04", "bg2": "#10301a", "peg": "#e2ffd8", "board": "#071209", "accent": "#9cff6b"},
}
RANDOM_THEMES = list(THEMES)
BX0, BX1, BY0 = 60, 1020, 330
ROWS = 11
SLOT_Y = 1420
SLOTS = [100, 25, 10, 5, 2, 5, 10, 25, 100]   # edges are hard to reach: jackpots
CT_BALL, CT_PEG, CT_WALL = 1, 2, 3


class Sim:
    def __init__(self, n, seed, sound=None, fx=None, looks=None):
        self.rng = random.Random(seed * 29 + 7)
        self.n, self.sound, self.fx, self.looks = n, sound, fx, looks
        self.now = self.clock = 0.0
        sp = pymunk.Space()
        sp.gravity = (0, 1500)
        sp.iterations = 15
        self.space = sp
        st = sp.static_body
        self.pegs = []
        gap = (BX1 - BX0) / 10
        for r in range(ROWS):
            y = BY0 + 70 + r * 88
            off = gap / 2 if r % 2 else 0
            x = BX0 + gap / 2 + off - gap / 2
            while x <= BX1 + 1:
                if BX0 + 64 < x < BX1 - 64:
                    c = pymunk.Circle(st, 9, (x, y))
                    c.elasticity, c.friction, c.collision_type = 0.55, 0.2, CT_PEG
                    c.peg = len(self.pegs)
                    sp.add(c)
                    self.pegs.append([x, y, -9.0])
                x += gap
        ns = len(SLOTS)
        self.slot_w = (BX1 - BX0) / ns
        for k in range(ns + 1):
            x = BX0 + k * self.slot_w
            s = pymunk.Segment(st, (x, SLOT_Y - 90), (x, SLOT_Y + 60), 5)
            s.elasticity, s.collision_type = 0.3, CT_WALL
            sp.add(s)
        for a, b in [((BX0, BY0 - 200), (BX0, SLOT_Y + 60)), ((BX1, BY0 - 200), (BX1, SLOT_Y + 60)),
                     ((BX0, SLOT_Y + 60), (BX1, SLOT_Y + 60))]:
            s = pymunk.Segment(st, a, b, 6)
            s.elasticity, s.collision_type = 0.4, CT_WALL
            sp.add(s)
        sp.on_collision(CT_BALL, CT_PEG, begin=self._peg)
        self.balls = []
        self.scores = [0] * n
        self.round = 0
        self.landed = []

    def _peg(self, arb, space, data):
        c = arb.shapes[1]
        self.pegs[c.peg][2] = self.clock
        b = arb.shapes[0].ball
        if self.sound is not None:
            self.sound.add(self.now, "bounce", who=b["i"], pan=0.15 + 0.7 * self.pegs[c.peg][0] / W, min_gap=0.05, gain=0.6)
        return True

    def drop_round(self):
        self.round += 1
        order = list(range(self.n))
        self.rng.shuffle(order)
        for k, i in enumerate(order):
            x = BX0 + 80 + self.rng.uniform(0, BX1 - BX0 - 160)
            body = pymunk.Body(1, pymunk.moment_for_circle(1, 0, 24))
            body.position = (x, BY0 - 60 - k * 70)
            body.velocity = (self.rng.uniform(-60, 60), 0)
            sh = pymunk.Circle(body, 24)
            sh.elasticity, sh.friction, sh.collision_type = 0.45, 0.3, CT_BALL
            ball = {"i": i, "body": body, "shape": sh, "slot": None, "t": self.clock}
            sh.ball = ball
            self.space.add(body, sh)
            self.balls.append(ball)

    def step(self, dt, now):
        self.now = now
        self.clock += dt
        self.space.step(dt)
        for b in self.balls:
            p = b["body"].position
            if b["slot"] is None and p.y > SLOT_Y - 92 and b["body"].velocity.length < 140:
                k = int((p.x - BX0) / self.slot_w)
                k = max(0, min(len(SLOTS) - 1, k))
                b["slot"] = k
                self.scores[b["i"]] += SLOTS[k]
                self.landed.append((self.clock, b, SLOTS[k]))
                if self.sound is not None:
                    self.sound.add(self.now, "escape" if SLOTS[k] >= 25 else "count", pan=0.15 + 0.7 * p.x / W)
            if b["slot"] is None:
                if b["body"].velocity.length > 40:
                    b["t"] = self.clock
                elif self.clock - b["t"] > 1.5:   # resting somewhere: nudge it free
                    b["body"].velocity = ((1 if p.x < W / 2 else -1) * self.rng.uniform(150, 300), -150)
                    b["t"] = self.clock

    def round_done(self):
        return all(b["slot"] is not None for b in self.balls)

    def clear(self):
        for b in self.balls:
            self.space.remove(b["body"], b["shape"])
        self.balls = []


def play(S, rounds, dt=1 / 120, on_round=None):
    """Headless run for timing."""
    for r in range(rounds):
        S.drop_round()
        while not S.round_done() and S.clock < 300:
            S.step(dt, S.clock)
        t_end = S.clock + 0.8
        while S.clock < t_end:
            S.step(dt, S.clock)
        S.clear()
    return S.clock


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    one = play(Sim(n, cfg["seed"]), 1)
    rounds = max(2, min(8, round(((t_min + t_max) / 2) / max(one, 2.5))))
    print(f"  {rounds} rounds, ~{one * rounds:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["casino"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, one * rounds + 5, th)
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    S = Sim(n, cfg["seed"], sound=sound, fx=fx, looks=looks)
    title = _wrap(cfg.get("title") or "WHO GETS THE MOST POINTS?", 22)
    handle = cfg.get("handle", "")
    sound.add(0.0, "go")
    phase, phase_t = "drop", 0.0
    S.drop_round()
    win_time = None
    winner = None
    disp = [0.0] * n
    pops = []
    seen = 0
    while True:
        t = run.t
        phase_t += run.dt
        if win_time is None:
            for i in range(run.sub):
                S.step(run.dt / run.sub, t + i * run.dt / run.sub)
            while seen < len(S.landed):
                _, b, pts = S.landed[seen]
                seen += 1
                p = b["body"].position
                pops.append([t, p.x, SLOT_Y - 120, f"+{pts}", looks[b["i"]].color])
                fx.burst(p.x, SLOT_Y - 40, looks[b["i"]].color, n=26 if pts >= 25 else 10, speed=520)
                if pts >= 100:
                    run.comm.say(t, "jackpot", force=True, weight=3)
                lead = max(range(n), key=lambda i: S.scores[i])
                run.comm.lead(t, looks[lead].name, hold=0.0)
            if phase == "drop" and S.round_done():
                phase, phase_t = "pause", 0.0
            elif phase == "pause" and phase_t > 0.9:
                S.clear()
                if S.round >= rounds:
                    win_time = t
                    winner = max(range(n), key=lambda i: (S.scores[i], -i))
                    sound.climax(t)
                    sound.add(t, "win")
                    fx.confetti(W)
                else:
                    S.drop_round()
                    sound.add(t, "whoosh")
                    phase, phase_t = "drop", 0.0
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        pygame.draw.rect(cv, T["board"], pygame.Rect(BX0 - 10, BY0 - 30, BX1 - BX0 + 20, SLOT_Y + 90 - BY0), border_radius=18)
        for (x, y, lt) in S.pegs:
            glow = max(0.0, 1 - (S.clock - lt) / 0.35)
            r = 9 + int(5 * glow)
            col = V.mix(T["peg"], T["accent"], glow)
            gfx.filled_circle(cv, int(x), int(y), r, col)
            gfx.aacircle(cv, int(x), int(y), r, col)
        for k, v in enumerate(SLOTS):
            x0 = BX0 + k * S.slot_w
            hot = v >= 25
            pygame.draw.rect(cv, V.mix(T["board"], T["accent"], 0.45 if hot else 0.15),
                             pygame.Rect(x0 + 6, SLOT_Y - 80, S.slot_w - 12, 135), border_radius=10)
            V.blit_center(cv, V.text(str(v), 36 if v < 100 else 32, (255, 255, 255), (0, 0, 0)), x0 + S.slot_w / 2, SLOT_Y + 20)
        for b in S.balls:
            p = b["body"].position
            looks[b["i"]].draw_body(cv, p.x, p.y, b["body"].angle, b["body"].velocity.x, b["body"].velocity.y, 48, "ball")
        fx.draw(cv)
        for pp in pops:
            a = t - pp[0]
            if a < 1.0:
                s = V.text(pp[3], 54, pp[4], (0, 0, 0), weight="Display")
                s.set_alpha(int(255 * min(1, (1 - a) * 3)))
                V.blit_center(cv, s, pp[1], pp[2] - a * 90)
        pops = [pp for pp in pops if t - pp[0] < 1.0]
        y = _draw_title(cv, title, t)
        if win_time is None:
            V.blit_center(cv, V.text(f"ROUND {S.round}/{rounds}", 40, T["accent"], (0, 0, 0)), W / 2, y + 6)
        order = sorted(range(n), key=lambda i: -S.scores[i])
        slot = min(130, 1000 // n)
        x0 = W / 2 - slot * (n - 1) / 2
        for pos, i in enumerate(order):
            disp[i] += (S.scores[i] - disp[i]) * min(1, run.dt * 8)
            cx = x0 + pos * slot
            V.blit_center(cv, looks[i].badge(int(slot * 0.5)), cx, 1600)
            V.blit_center(cv, V.text(str(int(round(disp[i]))), 34, (255, 255, 255), (0, 0, 0)), cx, 1680)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1860)
        if win_time is not None:
            class _W:
                look = looks[winner]
            _draw_winner(cv, _W, t - win_time + 0.8, T, line3=f"{S.scores[winner]} points")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > 200:
            raise RuntimeError("Plinko ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": looks[winner].name, "level": cfg["seed"]}
