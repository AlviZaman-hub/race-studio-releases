"""Eat & Grow: blobs roam an arena eating food pellets. A bigger blob that overlaps a
smaller one eats it. Last blob standing wins."""
import math
import random

import pygame.gfxdraw as gfx

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner

THEMES = {
    "petri": {"bg1": "#020b0e", "bg2": "#0b2a33", "floor": "#04161b", "grid": "#0f3a44", "food": "#c9fff2"},
    "space": {"bg1": "#03030a", "bg2": "#141432", "floor": "#07071a", "grid": "#1d1d44", "food": "#fff2b0"},
    "lava": {"bg1": "#0e0302", "bg2": "#3a0d06", "floor": "#160604", "grid": "#3a140a", "food": "#ffd2a0"},
    "paper": {"bg1": "#0d0d10", "bg2": "#26262e", "floor": "#f3f1ea", "grid": "#d9d6cc", "food": "#ff6b6b"},
}
RANDOM_THEMES = list(THEMES)
CX, CY, AR = 540, 1000, 470


class Blob:
    def __init__(self, i, x, y, mass):
        self.i, self.x, self.y, self.mass = i, x, y, mass
        self.vx = self.vy = 0.0
        self.alive = True
        self.wander = 0.0
        self.eaten = 0

    @property
    def r(self):
        return 6.0 * math.sqrt(self.mass)


class Sim:
    def __init__(self, n, seed, food_rate=10.0, speed=1.0, sound=None, fx=None, looks=None):
        self.rng = random.Random(seed * 41 + 9)
        self.n, self.sound, self.fx, self.looks = n, sound, fx, looks
        self.food_rate, self.speed = food_rate, speed
        self.clock = self.now = 0.0
        self.blobs = []
        for i in range(n):
            a = 2 * math.pi * i / n + self.rng.uniform(-0.2, 0.2)
            self.blobs.append(Blob(i, CX + math.cos(a) * AR * 0.6, CY + math.sin(a) * AR * 0.6, 30 + self.rng.uniform(-3, 3)))
        self.food = [self._rand_pt() for _ in range(70)]
        self.acc = 0.0
        self.winner = None
        self.comm = None
        self.out = []

    def _rand_pt(self):
        while True:
            x, y = self.rng.uniform(-AR, AR), self.rng.uniform(-AR, AR)
            if x * x + y * y < (AR - 20) ** 2:
                return [CX + x, CY + y]

    def alive(self):
        return [b for b in self.blobs if b.alive]

    def _ev(self, kind, b, **kw):
        if self.sound is not None:
            self.sound.add(self.now, kind, who=b.i, pan=0.15 + 0.7 * b.x / W, **kw)

    def step(self, dt, now):
        self.now = now
        self.clock += dt
        self.acc += dt * self.food_rate * (1 + self.clock / 20)
        while self.acc >= 1 and len(self.food) < 160:
            self.acc -= 1
            self.food.append(self._rand_pt())
        al = self.alive()
        for b in al:
            # steering: chase smaller blobs / food, flee bigger ones
            ax = ay = 0.0
            for o in al:
                if o is b:
                    continue
                dx, dy = o.x - b.x, o.y - b.y
                d = math.hypot(dx, dy) + 1e-6
                if o.mass > b.mass * 1.15 and d < o.r + 320:
                    k = (o.r + 320 - d) / 320
                    ax -= dx / d * 2.2 * k
                    ay -= dy / d * 2.2 * k
                elif b.mass > o.mass * 1.15 and d < 520:
                    ax += dx / d * 1.4
                    ay += dy / d * 1.4
            best, bd = None, 1e9
            for f in self.food:
                d = (f[0] - b.x) ** 2 + (f[1] - b.y) ** 2
                if d < bd:
                    best, bd = f, d
            if best is not None:
                d = math.sqrt(bd) + 1e-6
                ax += (best[0] - b.x) / d
                ay += (best[1] - b.y) / d
            b.wander += self.rng.uniform(-2, 2) * dt
            ax += math.cos(b.wander) * 0.4
            ay += math.sin(b.wander) * 0.4
            sp = (300 / (1 + b.mass / 120) + 60) * self.speed   # big = slow
            m = math.hypot(ax, ay) + 1e-6
            tvx, tvy = ax / m * sp, ay / m * sp
            b.vx += (tvx - b.vx) * min(1, dt * 3.5)
            b.vy += (tvy - b.vy) * min(1, dt * 3.5)
            b.x += b.vx * dt
            b.y += b.vy * dt
            d = math.hypot(b.x - CX, b.y - CY)
            lim = AR - b.r * 0.6
            if d > lim:
                b.x = CX + (b.x - CX) / d * lim
                b.y = CY + (b.y - CY) / d * lim
                b.vx *= 0.5
                b.vy *= 0.5
            # eat food
            keep = []
            rr = b.r * b.r
            for f in self.food:
                if (f[0] - b.x) ** 2 + (f[1] - b.y) ** 2 < rr:
                    b.mass += 2.2
                    self._ev("bounce", b, min_gap=0.06, gain=0.45)
                else:
                    keep.append(f)
            self.food = keep
            b.mass = max(10, b.mass - b.mass * 0.004 * dt)   # slow shrink keeps it moving
        # eat blobs
        for b in al:
            for o in al:
                if o is b or not o.alive or not b.alive:
                    continue
                if b.mass > o.mass * 1.15 and math.hypot(o.x - b.x, o.y - b.y) < b.r - o.r * 0.4:
                    o.alive = False
                    b.mass += o.mass * 0.85
                    b.eaten += 1
                    self.out.append(o)
                    self._ev("break", o)
                    if self.fx is not None and self.looks:
                        self.fx.burst(o.x, o.y, self.looks[o.i].color, n=34, speed=600)
                    if self.comm is not None and self.looks:
                        left = len(self.alive())
                        if left >= 3:
                            self.comm.say(self.now, "eat", force=True, weight=1.5, name=self.looks[b.i].name)
                        elif left == 2:
                            self.comm.out(self.now, self.looks[o.i].name, left=2)
        al = self.alive()
        if self.winner is None and len(al) == 1:
            self.winner = al[0]


def tune(seed, n, t_min, t_max, cfg_fps=60):
    target = (t_min + t_max) / 2
    best = None
    for sp in (0.7, 0.85, 1.0, 1.2, 1.45, 1.75, 2.1):
        S = Sim(n, seed, speed=sp)
        while S.winner is None and S.clock < t_max * 2:
            S.step(1 / cfg_fps, S.clock)
        t = S.clock
        if S.winner and (best is None or abs(t - target) < abs(best[1] - target)):
            best = (sp, t)
    return best or (1.4, t_max * 2)


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    sp, est = tune(cfg["seed"], n, t_min, t_max, cfg.get("fps", 60))
    print(f"  speed {sp}, ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["petri"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, est + 4.5, th)
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    S = Sim(n, cfg["seed"], speed=sp, sound=sound, fx=fx, looks=looks)
    S.comm = run.comm
    title = _wrap(cfg.get("title") or "EAT OR GET EATEN", 22)
    handle = cfg.get("handle", "")
    sound.add(0.0, "go")
    win_time = None
    rdisp = {b.i: b.r for b in S.blobs}
    while True:
        t = run.t
        if win_time is None:
            S.step(run.dt, t)   # same step size as tune() so the timing matches
            big = max(S.alive(), key=lambda b: b.mass)
            run.comm.lead(t, looks[big.i].name, hold=1.0)
            if S.winner is not None:
                win_time = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        gfx.filled_circle(cv, CX, CY, AR + 12, T["grid"])
        gfx.filled_circle(cv, CX, CY, AR, T["floor"])
        for g in range(-AR, AR + 1, 60):
            hw = int(math.sqrt(max(0, AR * AR - g * g)))
            pygame.draw.line(cv, T["grid"], (CX - hw, CY + g), (CX + hw, CY + g), 1)
            pygame.draw.line(cv, T["grid"], (CX + g, CY - hw), (CX + g, CY + hw), 1)
        for f in S.food:
            gfx.filled_circle(cv, int(f[0]), int(f[1]), 6, T["food"])
        for b in sorted(S.alive(), key=lambda b: b.mass):
            rdisp[b.i] += (b.r - rdisp[b.i]) * min(1, run.dt * 10)
            r = rdisp[b.i]
            col = looks[b.i].color
            gfx.filled_circle(cv, int(b.x), int(b.y), int(r), V.darker(col, 0.65))
            gfx.filled_circle(cv, int(b.x), int(b.y), int(r * 0.9), col)
            gfx.aacircle(cv, int(b.x), int(b.y), int(r), V.darker(col, 0.5))
            V.blit_center(cv, looks[b.i].badge(int(max(26, r * 1.1))), b.x, b.y)
        fx.draw(cv)
        _draw_title(cv, title, t)
        # size ranking
        order = sorted(S.blobs, key=lambda b: (not b.alive, -b.mass))
        slot = min(130, 1000 // n)
        x0 = W / 2 - slot * (n - 1) / 2
        for pos, b in enumerate(order):
            badge = looks[b.i].badge(int(slot * 0.5))
            if not b.alive:
                badge = badge.copy()
                badge.set_alpha(70)
            V.blit_center(cv, badge, x0 + pos * slot, 1590)
            V.blit_center(cv, V.text(str(int(b.mass)) if b.alive else "OUT", 28, (255, 255, 255) if b.alive else (150, 150, 150), (0, 0, 0)),
                          x0 + pos * slot, 1660)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1860)
        if win_time is not None:
            class _W:
                look = looks[S.winner.i]
            _draw_winner(cv, _W, t - win_time + 0.8, T, line3=f"Ate {S.winner.eaten} rival{'s' if S.winner.eaten != 1 else ''}")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Blobs ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": looks[S.winner.i].name, "level": cfg["seed"]}
