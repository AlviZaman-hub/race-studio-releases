"""Every Bounce = +1 Ball: each team starts with one ball. Every wall bounce spawns a new
ball of that team; when two different teams collide, both balls pop. First team to the
target wins (or the last team left)."""
import math
import random

import pymunk
import pygame.gfxdraw as gfx

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner

THEMES = {
    "void": {"bg1": "#05050a", "bg2": "#151830", "ring": "#e8ecff", "floor": "#0a0b14", "accent": "#ffd23f"},
    "sunset": {"bg1": "#12040a", "bg2": "#3a0f22", "ring": "#ffd0a8", "floor": "#1a0810", "accent": "#ff8a3d"},
    "mint": {"bg1": "#02100c", "bg2": "#0b3328", "ring": "#c8ffe8", "floor": "#04140f", "accent": "#5ef2c0"},
    "ice": {"bg1": "#030a12", "bg2": "#0d2a44", "ring": "#d6f1ff", "floor": "#06121c", "accent": "#7ad7ff"},
}
RANDOM_THEMES = list(THEMES)
CX, CY, AR = 540, 1010, 455
R = 19
CT_BALL, CT_WALL = 1, 2
CAP = 520


class Ball:
    __slots__ = ("team", "body", "shape", "alive", "born", "last")


class Sim:
    def __init__(self, n, seed, target, speed=480, sound=None, fx=None, looks=None, cool=1.6, limit=60.0):
        self.rng = random.Random(seed * 17 + 1)
        self.n, self.target, self.speed, self.limit = n, target, speed, limit
        self.pop_p = 0.15
        self.cool = cool
        self.sound, self.fx, self.looks = sound, fx, looks
        self.clock = self.now = 0.0
        sp = pymunk.Space()
        sp.iterations = 10
        self.space = sp
        seg = 96
        for k in range(seg):
            a0, a1 = 2 * math.pi * k / seg, 2 * math.pi * (k + 1) / seg
            s = pymunk.Segment(sp.static_body, (CX + math.cos(a0) * AR, CY + math.sin(a0) * AR),
                               (CX + math.cos(a1) * AR, CY + math.sin(a1) * AR), 6)
            s.elasticity, s.friction, s.collision_type = 1.0, 0.0, CT_WALL
            sp.add(s)
        self.balls = []
        self.count = [0] * n
        self.spawn_q, self.pop_q = [], []
        self.winner = None
        self.peak = [1] * n
        for i in range(n):
            a = 2 * math.pi * i / n + self.rng.uniform(-0.3, 0.3)
            self._spawn(i, CX + math.cos(a) * AR * 0.45, CY + math.sin(a) * AR * 0.45, a + math.pi + self.rng.uniform(-0.6, 0.6))
        sp.on_collision(CT_BALL, CT_WALL, begin=self._wall)
        sp.on_collision(CT_BALL, CT_BALL, begin=self._bb)
        self.comm = None
        self.out = []

    def _spawn(self, team, x, y, ang):
        b = Ball()
        b.team, b.alive, b.born = team, True, self.clock
        b.last = self.clock
        b.body = pymunk.Body(1, pymunk.moment_for_circle(1, 0, R))
        b.body.position = (x, y)
        b.body.velocity = (math.cos(ang) * self.speed, math.sin(ang) * self.speed)
        b.shape = pymunk.Circle(b.body, R)
        b.shape.elasticity, b.shape.friction, b.shape.collision_type = 1.0, 0.0, CT_BALL
        b.shape.b = b
        self.space.add(b.body, b.shape)
        self.balls.append(b)
        self.count[team] += 1
        self.peak[team] = max(self.peak[team], self.count[team])

    def _ev(self, kind, x, **kw):
        if self.sound is not None:
            self.sound.add(self.now, kind, pan=0.15 + 0.7 * x / W, **kw)

    def _wall(self, arb, space, data):
        b = arb.shapes[0].b
        if b.alive and len(self.balls) + len(self.spawn_q) < CAP and self.clock - b.last > self.cool:
            b.last = self.clock
            p = b.body.position
            inward = math.atan2(CY - p.y, CX - p.x) + self.rng.uniform(-0.9, 0.9)
            self.spawn_q.append((b.team, p.x + math.cos(inward) * R * 2.2, p.y + math.sin(inward) * R * 2.2, inward))
            self._ev("bounce", p.x, who=b.team, min_gap=0.05, gain=0.7)
        return True

    def _bb(self, arb, space, data):
        a, b = arb.shapes[0].b, arb.shapes[1].b
        if a.team != b.team and a.alive and b.alive and self.rng.random() < self.pop_p:
            # a team's last ball can't pop: nobody is ever fully out, so comebacks stay possible
            for x in (a, b):
                if self.count[x.team] - sum(1 for q in self.pop_q if q.team == x.team) > 1:
                    x.alive = False
                    self.pop_q.append(x)
            p = a.body.position
            self._ev("hit", p.x, min_gap=0.04, gain=0.8)
            return False
        return True

    def step(self, dt, now):
        self.now = now
        self.clock += dt
        self.space.step(dt)
        for b in self.pop_q:
            if b.body.space is not None:
                self.space.remove(b.body, b.shape)
                self.count[b.team] -= 1
                if self.fx is not None and self.looks:
                    self.fx.burst(b.body.position.x, b.body.position.y, self.looks[b.team].color, n=8, speed=300, size=(4, 8), life=(0.2, 0.4))
        self.pop_q.clear()
        for (team, x, y, ang) in self.spawn_q:
            if self.count[team] > 0 or True:
                self._spawn(team, x, y, ang)
        self.spawn_q.clear()
        self.balls = [b for b in self.balls if b.alive]
        for b in self.balls:
            v = b.body.velocity
            sp = v.length or 1
            if abs(sp - self.speed) > 5:
                b.body.velocity = v * (self.speed / sp)
            p = b.body.position
            if math.hypot(p.x - CX, p.y - CY) > AR + 10:
                b.body.position = (CX + (p.x - CX) * 0.9, CY + (p.y - CY) * 0.9)
        for i in range(self.n):
            if self.count[i] == 0 and i not in self.out:
                self.out.append(i)
                if self.comm is not None and self.looks:
                    self.comm.out(self.now, self.looks[i].name, left=self.n - len(self.out))
                self._ev("die", CX)
        if self.winner is None:
            if max(self.count) >= self.target:
                self.winner = max(range(self.n), key=lambda i: self.count[i])
            elif self.n - len(self.out) == 1:
                self.winner = next(i for i in range(self.n) if i not in self.out)
            elif self.clock >= self.limit:   # time's up: most balls wins
                self.winner = max(range(self.n), key=lambda i: (self.count[i], -i))


def tune(seed, n, t_min, t_max):
    target_t = (t_min + t_max) / 2
    best = None
    for target in (40, 60, 90, 120, 160, 200, 250):
        S = Sim(n, seed, target, limit=t_max * 1.1)
        while S.winner is None and S.clock < t_max * 2:
            S.step(1 / 120, S.clock)
        t = S.clock
        if best is None or abs(t - target_t) < abs(best[1] - target_t):
            best = (target, t)
        if t >= t_min:
            break
    return best


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    target, est = tune(cfg["seed"], n, t_min, t_max)
    print(f"  target {target}, ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["void"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, est + 4.5, th)
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    S = Sim(n, cfg["seed"], target, sound=sound, fx=fx, looks=looks, limit=t_max * 1.1)
    S.comm = run.comm
    title = _wrap(cfg.get("title") or f"FIRST TO {target} BALLS WINS", 22)
    handle = cfg.get("handle", "")
    sound.add(0.0, "go")
    win_time = None
    disp = [1.0] * n
    while True:
        t = run.t
        if win_time is None:
            for i in range(run.sub):
                S.step(run.dt / run.sub, t + i * run.dt / run.sub)
            lead = max(range(n), key=lambda i: S.count[i])
            run.comm.lead(t, looks[lead].name, hold=0.8)
            if S.winner is not None:
                win_time = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        gfx.filled_circle(cv, CX, CY, AR + 12, V.darker(T["ring"], 0.3))
        gfx.filled_circle(cv, CX, CY, AR, T["floor"])
        for k in range(3):
            gfx.aacircle(cv, CX, CY, AR + k, T["ring"])
        for b in S.balls:
            p = b.body.position
            V.blit_center(cv, looks[b.team].badge(R * 2 + 4), p.x, p.y)
        fx.draw(cv)
        y = _draw_title(cv, title, t)
        # score bars
        bx0, bw = 110, 860
        for i in range(n):
            disp[i] += (S.count[i] - disp[i]) * min(1, run.dt * 10)
            yy = 1520 + i * (300 / max(n, 4))
            f = min(1, disp[i] / target)
            pygame.draw.rect(cv, (24, 26, 36), pygame.Rect(bx0, yy - 14, bw, 28), border_radius=14)
            if f > 0:
                pygame.draw.rect(cv, looks[i].color, pygame.Rect(bx0, yy - 14, max(28, int(bw * f)), 28), border_radius=14)
            V.blit_center(cv, looks[i].badge(46), bx0 - 40, yy)
            V.blit_center(cv, V.text(str(max(0, S.count[i])), 30, (255, 255, 255), (0, 0, 0)), bx0 + bw + 40, yy)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1880)
        if win_time is not None:
            wi = S.winner

            class _W:
                look = looks[wi]
            _draw_winner(cv, _W, t - win_time + 0.8, T, line3=f"{S.peak[wi]} balls at the peak")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Race ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": looks[S.winner].name, "level": cfg["seed"]}
