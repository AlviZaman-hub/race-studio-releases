"""Pixel RPG Battle: turn-based monster fight with HP bars, named attacks, critical hits
and misses, told through a classic text box. Last one standing wins. Best with a retro look."""
import math
import random

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner

THEMES = {
    "meadow": {"bg1": "#0c1a10", "bg2": "#3f7a3a", "ground": "#c9e6a0", "box": "#f8f8f0", "ink": "#202020", "plat": "#a6c97a"},
    "cave": {"bg1": "#07060c", "bg2": "#2a2440", "ground": "#6a6488", "box": "#f0eefa", "ink": "#16141f", "plat": "#4f4870"},
    "beach": {"bg1": "#0b2a44", "bg2": "#3fa6d8", "ground": "#f2dc9e", "box": "#fffaf0", "ink": "#2a2014", "plat": "#e2c27e"},
    "volcano": {"bg1": "#140404", "bg2": "#5a1606", "ground": "#8a3a1a", "box": "#fff1e6", "ink": "#260a04", "plat": "#6a2a12"},
}
RANDOM_THEMES = list(THEMES)
ELEMENTS = ["FIRE", "WATER", "LEAF", "BOLT", "ROCK", "ICE", "WIND", "SHADOW", "STAR", "METAL"]
SHAPES = ["BLAST", "FANG", "SLAM", "STORM", "WAVE", "PUNCH", "BEAM", "CLAW", "SPIN", "RUSH"]
TURN = 1.9


def _moves(rng):
    el = rng.sample(ELEMENTS, 2)
    return [f"{rng.choice(el)} {s}" for s in rng.sample(SHAPES, 4)]


class Battle:
    """Pure dice: no physics, so the whole fight is planned before rendering."""
    def __init__(self, n, seed, hp, moves=None):
        self.rng = random.Random(seed * 37 + 11)
        self.hp = [hp] * n
        self.max = hp
        self.moves = moves or [_moves(self.rng) for _ in range(n)]
        self.log = []          # (attacker, target, move, dmg, tag)
        order = list(range(n))
        self.rng.shuffle(order)
        i = 0
        while sum(1 for h in self.hp if h > 0) > 1 and len(self.log) < 400:
            a = order[i % n]
            i += 1
            if self.hp[a] <= 0:
                continue
            foes = [j for j in range(n) if j != a and self.hp[j] > 0]
            tgt = min(foes, key=lambda j: self.hp[j]) if self.rng.random() < 0.35 else self.rng.choice(foes)
            move = self.rng.choice(self.moves[a])
            r = self.rng.random()
            if r < 0.1:
                dmg, tag = 0, "miss"
            elif r < 0.24:
                dmg, tag = self.rng.randint(22, 34), "crit"
            elif r < 0.34:
                dmg, tag = self.rng.randint(16, 24), "strong"
            else:
                dmg, tag = self.rng.randint(8, 16), ""
            if self.rng.random() < 0.06 and self.hp[a] < self.max * 0.5:
                heal = self.rng.randint(14, 24)
                self.hp[a] = min(self.max, self.hp[a] + heal)
                self.log.append((a, a, "HEAL", -heal, "heal"))
                continue
            self.hp[tgt] = max(0, self.hp[tgt] - dmg)
            self.log.append((a, tgt, move, dmg, tag))
        self.winner = next(j for j in range(n) if self.hp[j] > 0)


def tune(seed, n, t_min, t_max, moves=None):
    target_turns = max(4, ((t_min + t_max) / 2 - 2) / TURN)
    best = None
    for hp in range(40, 400, 10):
        b = Battle(n, seed, hp, moves)
        if best is None or abs(len(b.log) - target_turns) < abs(len(best.log) - target_turns):
            best = b
        if len(b.log) >= target_turns:
            break
    return best


def _positions(n):
    if n == 2:
        return [(330, 1240, 300), (760, 760, 260)]
    if n == 3:
        return [(270, 1260, 240), (810, 1260, 240), (540, 760, 240)]
    return [(280, 1270, 220), (800, 1270, 220), (280, 780, 220), (800, 780, 220)]


def render(cfg, out_path, sound):
    racers = cfg["racers"][:4]
    n = len(racers)
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    moves = cfg.get("rpg_moves")
    B = tune(cfg["seed"], n, t_min, t_max, moves)
    print(f"  HP {B.max}, {len(B.log)} turns")
    th = THEMES.get(cfg.get("theme"), THEMES["meadow"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, len(B.log) * TURN + 6, th)
    run.comm.on = False   # the text box is the commentary here
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in racers]
    pos = _positions(n)
    title = _wrap(cfg.get("title") or "WHO WINS THIS BATTLE?", 22)
    handle = cfg.get("handle", "")
    hp_disp = [float(B.max)] * n
    hp_now = [B.max] * n
    dead = [False] * n
    dead_t = [None] * n
    sound.add(0.0, "go")
    intro = 1.2
    turn_i = -1
    win_time = None
    shake = 0.0
    msg_lines, msg_t = ["A WILD BATTLE BEGINS!"], 0.0
    pops = []
    applied = -1
    bodies = [V.Look(s, pos[i][2]) for i, s in enumerate(racers)]
    while True:
        t = run.t
        k = int((t - intro) / TURN) if t >= intro else -1
        if win_time is None and k > turn_i and k < len(B.log):
            turn_i = k
            a, tg, mv, dmg, tag = B.log[k]
            msg_lines, msg_t = [f"{looks[a].name.upper()} USED {mv}!"], t
            sound.add(t, "boost" if tag == "heal" else "whoosh", gain=0.7)
        if win_time is None and turn_i >= len(B.log) - 1 and t >= intro + len(B.log) * TURN:
            win_time = t
            sound.climax(t)
            sound.add(t, "win")
            fx.confetti(W)
        # the hit lands 0.7 s into the turn
        if 0 <= turn_i < len(B.log):
            a, tg, mv, dmg, tag = B.log[turn_i]
            tt = t - (intro + turn_i * TURN)
            if tt >= 0.7 and applied != turn_i:
                applied = turn_i
                x, y, sz = pos[tg]
                if tag == "heal":
                    hp_now[a] = min(B.max, hp_now[a] - dmg)
                    pops.append([t, x, y - sz * 0.7, f"+{-dmg}", (120, 255, 140)])
                    msg_lines = msg_lines[:1] + [f"{looks[a].name.upper()} RECOVERED {-dmg} HP!"]
                elif tag == "miss":
                    pops.append([t, x, y - sz * 0.7, "MISS", (220, 220, 220)])
                    msg_lines = msg_lines[:1] + ["BUT IT MISSED!"]
                    sound.add(t, "racer")
                else:
                    hp_now[tg] = max(0, hp_now[tg] - dmg)
                    pops.append([t, x, y - sz * 0.7, f"-{dmg}", (255, 90, 80) if tag else (255, 230, 120)])
                    fx.burst(x, y, looks[tg].color, n=26 if tag else 14, speed=520)
                    shake = 0.35 if tag == "crit" else 0.18
                    sound.add(t, "break" if tag == "crit" else "hit", pan=0.15 + 0.7 * x / W)
                    extra = {"crit": "A CRITICAL HIT!", "strong": "THAT ONE HURT!"}.get(tag)
                    if extra:
                        msg_lines = msg_lines[:1] + [extra]
                    run.comm.drama += 1.5 if tag == "crit" else 0.3
                    if hp_now[tg] == 0 and not dead[tg]:
                        dead[tg], dead_t[tg] = True, t
                        msg_lines = msg_lines[:1] + [f"{looks[tg].name.upper()} FAINTED!"]
                        sound.add(t + 0.25, "die")
        fx.update(run.dt)
        shake = max(0.0, shake - run.dt)
        run.clear()
        cv = run.canvas
        sx = math.sin(t * 90) * 14 * shake / 0.35
        # ground band + platforms
        pygame.draw.rect(cv, V.mix(T["ground"], (0, 0, 0), 0.25), pygame.Rect(0, 620, W, 900))
        for i in range(n):
            x, y, sz = pos[i]
            pygame.draw.ellipse(cv, T["plat"], pygame.Rect(x - sz * 0.75 + sx, y + sz * 0.35, sz * 1.5, sz * 0.42))
            pygame.draw.ellipse(cv, V.darker(T["plat"], 0.7), pygame.Rect(x - sz * 0.75 + sx, y + sz * 0.35, sz * 1.5, sz * 0.42), 5)
        for i in range(n):
            x, y, sz = pos[i]
            bob = math.sin(t * 3 + i) * 6
            dx = 0.0
            if 0 <= turn_i < len(B.log) and win_time is None:
                a, tg, mv, dmg, tag = B.log[turn_i]
                tt = t - (intro + turn_i * TURN)
                if i == a and tag != "heal" and 0.35 < tt < 0.85:   # lunge toward the target
                    u = math.sin((tt - 0.35) / 0.5 * math.pi)
                    tx, ty, _ = pos[tg]
                    dx = (tx - x) * 0.18 * u
                    bob += (ty - y) * 0.18 * u
                if i == tg and tag not in ("miss", "heal") and 0.7 < tt < 1.1 and int(tt * 20) % 2:
                    continue   # blink when hit
            if dead[i]:
                age = t - dead_t[i]
                if age > 0.6:
                    continue
                if int(age * 16) % 2:
                    continue
            bodies[i].draw_body(cv, x + dx + sx, y + bob, 0.0, 0.0, 0.0, sz, "square")
            # HP box
            bx = x - 150
            by = y - sz * 0.62 - 92
            pygame.draw.rect(cv, T["box"], pygame.Rect(bx, by, 300, 74), border_radius=10)
            pygame.draw.rect(cv, T["ink"], pygame.Rect(bx, by, 300, 74), 4, border_radius=10)
            V.blit_center(cv, V.text(looks[i].name.upper()[:12], 26, T["ink"], None, weight="Medium"), x, by + 20)
            hp_disp[i] += (hp_now[i] - hp_disp[i]) * min(1, run.dt * 5)
            f = max(0.0, hp_disp[i] / B.max)
            col = (60, 200, 90) if f > 0.5 else (240, 190, 40) if f > 0.2 else (230, 60, 50)
            pygame.draw.rect(cv, (60, 60, 60), pygame.Rect(bx + 16, by + 42, 268, 18), border_radius=6)
            pygame.draw.rect(cv, col, pygame.Rect(bx + 16, by + 42, 268 * f, 18), border_radius=6)
        fx.draw(cv)
        for p in pops:
            age = t - p[0]
            if age < 0.9:
                s = V.text(p[3], 64, p[4], (0, 0, 0), weight="Display")
                s.set_alpha(int(255 * min(1, (0.9 - age) * 3)))
                V.blit_center(cv, s, p[1], p[2] - age * 80)
        pops = [p for p in pops if t - p[0] < 0.9]
        _draw_title(cv, title, t)
        # text box with typing effect
        box = pygame.Rect(50, 1560, W - 100, 230)
        pygame.draw.rect(cv, T["box"], box, border_radius=16)
        pygame.draw.rect(cv, T["ink"], box, 7, border_radius=16)
        pygame.draw.rect(cv, T["ink"], box.inflate(-26, -26), 2, border_radius=10)
        chars = int((t - msg_t) * 60)
        yy = 1625
        for ln in msg_lines:
            shown = ln[:max(0, chars)]
            chars -= len(ln) + 6
            if shown:
                s = V.text(shown, 40, T["ink"], None, weight="Bold")
                cv.blit(s, (95, yy - s.get_height() // 2))
            yy += 75
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1870)
        if win_time is not None:
            class _W:
                look = looks[B.winner]
            _draw_winner(cv, _W, t - win_time + 0.8, T, line3=f"{hp_now[B.winner]} HP left")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > 240:
            raise RuntimeError("Battle ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": looks[B.winner].name, "level": cfg["seed"]}
