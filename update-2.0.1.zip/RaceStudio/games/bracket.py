"""Bracket Tournament: knockout 1v1 ball battles (swords, daggers, spikes) until one
champion is left. Works with 2-8 racers (byes fill empty spots)."""
import math
import random

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner
from games import battle as B
import pygame.gfxdraw as gfx

THEMES = dict(B.THEMES)
RANDOM_THEMES = list(THEMES)
ROUND_NAMES = {1: "FINAL", 2: "SEMI-FINAL", 4: "QUARTER-FINAL", 8: "ROUND OF 16"}


def _duel_scale(seed, t_lo, t_hi, weapons):
    sc, t = B.tune(seed, 2, t_lo, t_hi, weapons=weapons)
    return sc, t


def plan(n, seed):
    rng = random.Random(seed * 5 + 3)
    size = 1
    while size < n:
        size *= 2
    order = list(range(n))
    rng.shuffle(order)
    slots = order + [None] * (size - n)
    # spread byes so two byes never meet
    if size - n:
        real, byes = order, [None] * (size - n)
        slots = []
        for k in range(size // 2):
            slots.append(real.pop(0) if real else None)
            slots.append(byes.pop() if byes else (real.pop(0) if real else None))
    return slots


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    slots = plan(n, cfg["seed"])
    real_matches = n - 1
    per = max(3.5, min(8.0, ((t_min + t_max) / 2) / max(1, real_matches) - 1.6))
    rng = random.Random(cfg["seed"])
    weapons_all = [cfg["weapons"][i % len(cfg["weapons"])] if cfg.get("weapons") else rng.choice(["sword", "sword", "dagger", "spikes"])
                   for i in range(n)]
    print(f"  {n} racers, {real_matches} duels of ~{per:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["arena"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, real_matches * (per + 1.6) + 5, th)
    run.comm.y = 530
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    title = _wrap(cfg.get("title") or "WHO WINS THE TOURNAMENT?", 22)
    handle = cfg.get("handle", "")
    rounds = [slots]          # rounds[k] = list of entrants (index or None) at that stage
    results = []              # winners per round as they happen
    cur = []
    match_i = 0
    state, state_t = "bracket", 0.0
    S = None
    duel = None
    champ = None
    win_time = None
    sound.add(0.0, "go")
    duel_n = 0

    def next_match():
        nonlocal match_i, cur
        stage = rounds[-1]
        while match_i * 2 < len(stage):
            a, b = stage[match_i * 2], stage[match_i * 2 + 1]
            if a is None or b is None:   # bye
                cur.append(a if b is None else b)
                match_i += 1
                continue
            return a, b
        rounds.append(cur)
        cur = []
        match_i = 0
        if len(rounds[-1]) == 1:
            return None
        return next_match()

    pair = next_match()
    while True:
        t = run.t
        state_t += run.dt
        if state == "bracket" and state_t > 1.3:
            if pair is None:
                champ = rounds[-1][0]
                win_time = t
                state = "champ"
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
            else:
                a, b = pair
                seed = cfg["seed"] * 100 + duel_n
                duel_n += 1
                sc, _ = _duel_scale(seed, per * 0.8, per * 1.25, [weapons_all[a], weapons_all[b]])
                S = B.Sim([looks[a], looks[b]], seed, sc, sound=sound, fx=fx, weapons=[weapons_all[a], weapons_all[b]])
                S.comm = None
                duel = (a, b)
                state, state_t = "duel", 0.0
                sound.add(t, "whoosh")
        elif state == "duel":
            if S.winner is None:
                for i in range(run.sub):
                    S.step(run.dt / run.sub, t + i * run.dt / run.sub)
                if S.winner is not None:
                    state_t = 0.0
                    w = duel[0] if S.winner.i == 0 else duel[1]
                    loser = duel[1] if w == duel[0] else duel[0]
                    cur.append(w)
                    match_i += 1
                    left_stage = len(rounds[-1])
                    run.comm.say(t, "out", force=True, weight=1.5, name=looks[loser].name)
                    sound.add(t, "break")
            elif state_t > 1.1:
                pair = next_match()
                state, state_t = "bracket", 0.0
                S = None
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        y = _draw_title(cv, title, t)
        if state == "duel" and S is not None:
            gfx.filled_circle(cv, int(B.CX), int(B.CY), int(B.AR + 14), V.darker(T["ring"], 0.35))
            gfx.filled_circle(cv, int(B.CX), int(B.CY), int(B.AR), T["floor"])
            for k in range(3):
                gfx.aacircle(cv, int(B.CX), int(B.CY), int(B.AR + k), T["ring"])
            for F in S.alive():
                B._draw_fighter(cv, F)
            for F in S.alive():
                B._hp_bar(cv, F)
            fx.draw(cv)
            for p in S.popups:
                p[3] += run.dt
                if p[3] < 0.9:
                    s = V.text(p[2], 46 if p[2] != "K.O." else 90, p[4], (0, 0, 0), weight="Display")
                    s.set_alpha(int(255 * min(1, (0.9 - p[3]) * 3)))
                    V.blit_center(cv, s, p[0], p[1] - p[3] * 70)
            S.popups = [p for p in S.popups if p[3] < 0.9]
            stage_size = len(rounds[-1])
            V.blit_center(cv, V.text(ROUND_NAMES.get(stage_size // 2, "ROUND"), 40, (255, 210, 120), (0, 0, 0)), W / 2, y + 6)
            a, b = duel
            V.blit_center(cv, V.text(f"{looks[a].name.upper()}  VS  {looks[b].name.upper()}", 50, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, y + 66)
        else:
            fx.draw(cv)
        _draw_bracket(cv, rounds, cur, looks, state, pair, t, big=(state == "bracket"))
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1880)
        if state == "champ":
            class _W:
                look = looks[champ]
            _draw_winner(cv, _W, t - win_time + 0.8, T, line2="CHAMPION!", line3=f"Won {len(rounds) - 1} fights in a row")
        run.push()
        if state == "champ" and t - win_time >= 4.2:
            break
        if t > 240:
            raise RuntimeError("Tournament ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": looks[champ].name, "level": cfg["seed"]}


def _draw_bracket(cv, rounds, cur, looks, state, pair, t, big):
    """Bracket tree. Big version mid-screen between fights, compact strip under the arena during fights."""
    size = len(rounds[0])
    levels = []
    for k in range(int(math.log2(size)) + 1):
        if k < len(rounds):
            stage = list(rounds[k])
        elif k == len(rounds):
            stage = list(cur) + [None] * (size // (2 ** k) - len(cur))
        else:
            stage = [None] * (size // (2 ** k))
        levels.append(stage)
    if big:
        x0, x1, y0, y1, bs = 70, 1010, 520, 1500, 74
    else:
        x0, x1, y0, y1, bs = 70, 1010, 1572, 1850, 32
    cols = len(levels)
    for k, stage in enumerate(levels):
        cx = x0 + (x1 - x0) * (k / max(1, cols - 1)) if cols > 1 else (x0 + x1) / 2
        m = len(stage)
        for j, who in enumerate(stage):
            cy = y0 + (y1 - y0) * (j + 0.5) / m
            if k + 1 < cols:
                ncx = x0 + (x1 - x0) * ((k + 1) / max(1, cols - 1))
                ncy = y0 + (y1 - y0) * (j // 2 + 0.5) / (m // 2)
                mx = (cx + ncx) / 2
                col = (90, 96, 116)
                pygame.draw.line(cv, col, (cx + bs * 0.5, cy), (mx, cy), 3)
                pygame.draw.line(cv, col, (mx, cy), (mx, ncy), 3)
                pygame.draw.line(cv, col, (mx, ncy), (ncx - bs * 0.5, ncy), 3)
            if who is None:
                gfx.aacircle(cv, int(cx), int(cy), int(bs * 0.42), (70, 74, 90))
                continue
            active = pair is not None and who in pair and k == len(rounds) - 1
            badge = looks[who].badge(bs)
            nxt = levels[k + 1][j // 2] if k + 1 < cols and j // 2 < len(levels[k + 1]) else None
            eliminated = nxt is not None and nxt != who
            if eliminated:
                badge = badge.copy()
                badge.set_alpha(80)
            if active and big:
                pulse = 1 + 0.08 * math.sin(t * 9)
                gfx.filled_circle(cv, int(cx), int(cy), int(bs * 0.66 * pulse), (255, 200, 80))
            V.blit_center(cv, badge, cx, cy)
