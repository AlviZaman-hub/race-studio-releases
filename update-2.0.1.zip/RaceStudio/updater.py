"""One-tap updates from GitHub.

latest.json (in the public releases repo) looks like:
  {"version": "1.1.0", "update_zip": "https://.../update.zip", "notes": "What's new"}
The update zip contains a RaceStudio/ folder with the changed files. User files
(output/, your racer images and sounds, saved settings) are never touched.
"""
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = "AlviZaman-hub/race-studio-releases"
LATEST_URL = f"https://raw.githubusercontent.com/{REPO}/main/latest.json"
DOWNLOAD_PAGE = "https://github.com/AlviZaman-hub/race-studio-releases/raw/main/RaceStudio.zip"
PROTECTED = ("output/", "config/_", "assets/racers/", "assets/sounds/", "assets/ai/", ".venv/", "launcher_log.txt")


def current_version():
    try:
        with open(os.path.join(HERE, "VERSION"), encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return "0.0.0"


def _v(s):
    out = []
    for part in s.strip().lstrip("v").split("."):
        try:
            out.append(int(part))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


def _fetch(url, timeout=30):
    """curl first (uses the system's certificates on Mac), urllib as backup."""
    curl = shutil.which("curl")
    if curl:
        flags = 0x08000000 if os.name == "nt" else 0
        p = subprocess.run([curl, "-fsSL", "--max-time", str(timeout * 4), url],
                           capture_output=True, creationflags=flags)
        if p.returncode == 0:
            return p.stdout
    req = urllib.request.Request(url, headers={"User-Agent": "RaceStudio-updater",
                                               "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def check():
    """Returns (update_available, info_dict). Raises on network errors."""
    info = json.loads(_fetch(f"{LATEST_URL}?t={int(time.time())}").decode("utf-8"))  # skip GitHub's cache
    return _v(info["version"]) > _v(current_version()), info


def apply(info, log=print):
    url = info["update_zip"]
    data = _fetch(url + ("&" if "?" in url else "?") + f"v={info['version']}", timeout=60)
    zf = zipfile.ZipFile(io.BytesIO(data))
    names = [n for n in zf.namelist() if not n.endswith("/")]
    prefix = "RaceStudio/"
    tmp = tempfile.mkdtemp(prefix="racestudio_upd_")
    count = 0
    try:
        zf.extractall(tmp)
        for n in names:
            rel = n[len(prefix):] if n.startswith(prefix) else n
            if not rel or rel.startswith(PROTECTED) or ".." in rel.split("/"):
                continue
            src = os.path.join(tmp, n)
            dst = os.path.join(HERE, *rel.split("/"))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(src, dst)
            if rel.endswith((".command", ".sh")) and os.name != "nt":
                os.chmod(dst, 0o755)
            count += 1
        with open(os.path.join(HERE, "VERSION"), "w", encoding="utf-8") as f:
            f.write(info["version"])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    log(f"Updated {count} files to v{info['version']}")
    return count


if __name__ == "__main__":
    ok, info = check()
    print("current", current_version(), "latest", info.get("version"))
    if ok and "--apply" in sys.argv:
        apply(info)
