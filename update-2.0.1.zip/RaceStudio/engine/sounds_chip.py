"""Chiptune sound pack: square/pulse, triangle and noise channels like 8-bit and handheld
consoles. Everything is synthesized here (original sounds, nothing sampled).

Two vibes: "chiptune" (upbeat 8-bit adventure) and "rpg" (handheld RPG battle/overworld)."""
import numpy as np

SR = 48000


def midi(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def _t(d):
    return np.arange(int(d * SR)) / SR


def _env(n, a=0.002, d=0.08, s=0.6, r=0.05, hold=None):
    """ADSR in samples; hold = sustain length in seconds."""
    a, d, r = int(a * SR), int(d * SR), int(r * SR)
    hold = n - a - d - r if hold is None else int(hold * SR)
    hold = max(0, hold)
    e = np.concatenate([np.linspace(0, 1, max(1, a)), np.linspace(1, s, max(1, d)),
                        np.full(hold, s), np.linspace(s, 0, max(1, r))])
    return np.pad(e, (0, max(0, n - len(e))))[:n]


def pulse(freq, dur, duty=0.5, vib=0.0):
    t = _t(dur)
    f = np.full(len(t), freq) if np.isscalar(freq) else freq
    if vib:
        f = f * (1 + vib * np.sin(2 * np.pi * 6 * t) * np.clip((t - 0.12) * 4, 0, 1))
    ph = np.cumsum(f) / SR
    return np.where((ph % 1.0) < duty, 1.0, -1.0) * 0.5


def soften(x, fc=7000.0):
    """Gentle low-pass (FFT, 2nd-order-like roll-off): keeps the 8-bit bite, removes harsh aliasing fizz."""
    n = len(x)
    if n < 16:
        return x
    spec = np.fft.rfft(x, axis=0)
    f = np.fft.rfftfreq(n, 1 / SR)
    g = 1 / (1 + (f / fc) ** 4)
    spec *= g if spec.ndim == 1 else g[:, None]
    return np.fft.irfft(spec, n, axis=0)


def tri(freq, dur):
    t = _t(dur)
    f = np.full(len(t), freq) if np.isscalar(freq) else freq
    ph = np.cumsum(f) / SR % 1.0
    return (4 * np.abs(ph - 0.5) - 1) * 0.6


def noise(dur, period=1, seed=0):
    """LFSR-ish noise: 'period' > 1 gives the metallic short-mode sound."""
    rng = np.random.default_rng(seed)
    n = int(dur * SR)
    steps = max(1, period)
    base = rng.choice([-1.0, 1.0], size=n // steps + 1)
    return np.repeat(base, steps)[:n] * 0.5


def _sweep(f0, f1, dur, curve=1.0):
    t = _t(dur)
    k = (t / dur) ** curve
    return f0 * (f1 / f0) ** k


# ---------------------------------------------------------------- effects

def blip(m, dur=0.07, duty=0.25):
    x = pulse(midi(m), dur, duty)
    return x * _env(len(x), 0.001, 0.03, 0.4, 0.02)


def jump(m):
    f = _sweep(midi(m), midi(m + 12), 0.12, 0.6)
    x = pulse(f, 0.12, 0.25)
    return x * _env(len(x), 0.001, 0.05, 0.5, 0.03)


def coin(m):
    a = pulse(midi(m + 12), 0.06, 0.5)
    b = pulse(midi(m + 17), 0.28, 0.5)
    x = np.concatenate([a, b])
    return x * _env(len(x), 0.001, 0.02, 0.7, 0.2)


def hit():
    x = noise(0.12, 2, 3)
    return x * np.exp(-_t(0.12) / 0.03)


def explode(seed=0):
    x = noise(0.5, 6, seed)
    f = np.exp(-_t(0.5) / 0.14)
    return x * f * 1.2


def powerdown():
    f = _sweep(midi(76), midi(52), 0.5, 1.0)
    x = pulse(f, 0.5, 0.5, vib=0.03)
    return x * _env(len(x), 0.001, 0.05, 0.7, 0.15)


def powerup(m):
    notes = [m, m + 4, m + 7, m + 12, m + 16, m + 19, m + 24]
    x = np.concatenate([pulse(midi(n), 0.045, 0.25) for n in notes])
    return x * _env(len(x), 0.001, 0.02, 0.8, 0.05)


def beep(m, dur=0.12):
    x = pulse(midi(m), dur, 0.5)
    return x * _env(len(x), 0.001, 0.02, 0.8, 0.03)


def swoosh():
    x = noise(0.35, 1, 9)
    k = np.sin(np.linspace(0, np.pi, len(x)))
    return x * k * 0.5


def level_up(key):
    """Victory jingle: arpeggio + held chord (original)."""
    seq = [(0, .09), (4, .09), (7, .09), (12, .09), (7, .09), (12, .09), (16, .09), (19, .55)]
    lead = np.concatenate([pulse(midi(key + 12 + n), d, 0.5) * _env(int(d * SR), 0.001, 0.02, 0.8, 0.02) for n, d in seq])
    bass = np.concatenate([tri(midi(key - 12 + n), d) for n, d in [(0, .36), (5, .18), (7, .64)]])
    n = max(len(lead), len(bass))
    out = np.pad(lead, (0, n - len(lead))) * 0.8 + np.pad(bass, (0, n - len(bass))) * 0.7
    return out * np.linspace(1, 0.6, n)


def note(m):
    x = pulse(midi(m), 0.32, 0.25, vib=0.004)
    return x * _env(len(x), 0.002, 0.06, 0.5, 0.12)


# ---------------------------------------------------------------- harmony + bed

VIBES = {
    "chiptune": {"bpm": 150, "prog": [(0, "M"), (9, "m"), (5, "M"), (7, "M")]},
    "rpg": {"bpm": 120, "prog": [(0, "m"), (8, "M"), (10, "M"), (7, "M")]},
}
QUAL = {"m": [0, 3, 7], "M": [0, 4, 7]}


class ChipHarmony:
    def __init__(self, key, vibe):
        self.vibe = vibe if vibe in VIBES else "chiptune"
        v = VIBES[self.vibe]
        self.key = key
        self.bpm = v["bpm"]
        self.prog = v["prog"]
        self.bar = 4 * 60 / self.bpm

    def chord_at(self, t):
        root, q = self.prog[int(t / self.bar) % len(self.prog)]
        return root, QUAL[q]

    def note_at(self, t, idx, octave=0):
        root, tones = self.chord_at(t)
        pool = [self.key + 12 * octave + root + x for x in tones] + [self.key + 12 * (octave + 1) + root]
        seq = [0, 1, 2, 3, 2, 1]
        return pool[seq[idx % len(seq)] % len(pool)]


def bed(duration, H, climax=None, seed=0):
    """Original 8-bit loop: pulse lead (generated melody), pulse arpeggio, triangle bass, noise drums.
    Drops out just before the climax, then a short fanfare tail plays from the win sound."""
    rng = np.random.default_rng(seed)
    n = int(duration * SR) + SR
    out = np.zeros(n)
    step = 60 / H.bpm / 4
    total = int(duration / step) + 1
    stop = (climax - 0.5) if climax else None
    # melody: random walk on chord/scale tones, 2-bar phrase repeated with variation
    scale = [0, 2, 4, 5, 7, 9, 11] if H.vibe == "chiptune" else [0, 2, 3, 5, 7, 8, 10]
    phrase = []
    deg = 4
    for i in range(32):
        if i % 2 == 0 or rng.random() < 0.3:
            deg = int(np.clip(deg + rng.choice([-2, -1, 1, 1, 2, 0]), 0, 11))
            phrase.append(deg if rng.random() > 0.15 else None)
        else:
            phrase.append("hold")

    def put(sig, t0, g):
        o = int(t0 * SR)
        if o >= n:
            return
        seg = sig[: n - o]
        out[o:o + len(seg)] += seg * g

    kick = tri(_sweep(180, 50, 0.12, 0.5), 0.12) * np.exp(-_t(0.12) / 0.05)
    snare = noise(0.1, 1, 4) * np.exp(-_t(0.1) / 0.035)
    hat = noise(0.03, 1, 5) * np.exp(-_t(0.03) / 0.008)
    for s in range(total):
        t0 = s * step
        if stop is not None and stop <= t0 < climax + 0.05:
            continue
        if climax is not None and t0 >= climax:
            break
        root, tones = H.chord_at(t0)
        k = s % 16
        # drums
        if k in (0, 8) or (H.vibe == "chiptune" and k == 11):
            put(kick, t0, 0.55)
        if k in (4, 12):
            put(snare, t0, 0.3)
        if k % 2 == 0:
            put(hat, t0, 0.12)
        # bass: root on 8ths, octave jumps
        if k % 2 == 0:
            bn = H.key - 24 + root + (12 if k % 4 == 2 else 0)
            put(tri(midi(bn), step * 1.9) * _env(int(step * 1.9 * SR), 0.001, 0.02, 0.9, 0.01), t0, 0.5)
        # arpeggio (fast 16ths, quiet)
        an = H.key + root + tones[s % len(tones)] + 12 * (s // 3 % 2)
        put(pulse(midi(an), step * 0.9, 0.125) * _env(int(step * 0.9 * SR), 0.001, 0.02, 0.6, 0.01), t0, 0.12)
        # lead
        ph = phrase[s % len(phrase)] if (s // 32) % 4 != 3 else phrase[(s + 8) % len(phrase)]
        if isinstance(ph, int):
            m = H.key + 12 + scale[ph % 7] + 12 * (ph // 7)
            ln = step * 2
            put(pulse(midi(m), ln, 0.5, vib=0.004) * _env(int(ln * SR), 0.002, 0.04, 0.6, 0.03), t0, 0.2)
    out = soften(out, 6000.0)
    st = np.stack([out, out], 1)
    return st[: int(duration * SR)] * 0.7
