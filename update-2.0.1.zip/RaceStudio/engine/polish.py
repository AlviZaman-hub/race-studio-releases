"""Finishing touches applied to every game's frames on the way to the encoder:
- the winning moment gets a white flash, a zoom punch and a short screen shake
- an end card ("Did your pick win?") is added after the winner screen, audio padded to match
"""
import math
import wave

import numpy as np

from .video import pygame
from . import visual as V

W, H = 1080, 1920
END_LINES = {
    "default": ("DID YOUR PICK WIN?", "TELL ME IN THE COMMENTS"),
    "quiz": ("HOW MANY DID YOU GET?", "COMMENT YOUR SCORE"),
    "barrace": ("DID YOU EXPECT THAT?", "COMMENT WHAT TO RANK NEXT"),
    "whatif": ("WHICH WORLD WINS?", "COMMENT WHAT TO CHANGE NEXT"),
}


class PolishWriter:
    def __init__(self, inner, cfg, fps, sound):
        self.inner, self.cfg, self.fps, self.sound = inner, cfg, fps, sound
        self.n = 0
        self.last = None
        self.buf = pygame.Surface((W, H))
        self.end = cfg.get("end_card", True)
        self.game = cfg.get("_game", "default")

    def write(self, surface):
        t = self.n / self.fps
        self.n += 1
        ct = getattr(self.sound, "climax_t", None) if self.sound is not None else None
        out = surface
        if ct is not None and 0 <= t - ct < 0.55:
            a = t - ct
            k = 1 + 0.07 * math.sin(min(1.0, a / 0.55) * math.pi)   # zoom in and back out
            sx = math.sin(a * 70) * 16 * max(0.0, 1 - a / 0.45)
            sy = math.cos(a * 55) * 12 * max(0.0, 1 - a / 0.45)
            w2, h2 = int(W * k), int(H * k)
            big = pygame.transform.smoothscale(surface, (w2, h2))
            self.buf.blit(big, (-(w2 - W) / 2 + sx, -(h2 - H) / 2 + sy))
            if a < 0.22:
                flash = pygame.Surface((W, H))
                flash.fill((255, 255, 255))
                flash.set_alpha(int(150 * (1 - a / 0.22)))
                self.buf.blit(flash, (0, 0))
            out = self.buf
        self.last = out.copy() if self.end else None
        self.inner.write(out)

    def _end_card(self):
        if not self.end or self.last is None:
            return 0
        l1, l2 = END_LINES.get(self.game, END_LINES["default"])
        handle = self.cfg.get("handle", "")
        frames = int(self.fps * 1.6)
        dim = pygame.Surface((W, H), pygame.SRCALPHA)
        for i in range(frames):
            u = min(1.0, i / (self.fps * 0.25))
            f = self.last.copy()
            dim.fill((5, 6, 10, int(215 * u)))
            f.blit(dim, (0, 0))
            pop = 0.85 + 0.15 * min(1.0, i / (self.fps * 0.2))
            s1 = V.text(l1, int(92 * pop), (255, 255, 255), (0, 0, 0), weight="Display")
            s1.set_alpha(int(255 * u))
            V.blit_center(f, s1, W / 2, H * 0.44)
            s2 = V.text(l2, 46, (255, 210, 110), (0, 0, 0), weight="Bold")
            s2.set_alpha(int(255 * u))
            V.blit_center(f, s2, W / 2, H * 0.52)
            if handle:
                s3 = V.text("FOLLOW " + handle.upper(), 40, (200, 205, 220), (0, 0, 0), weight="Medium")
                s3.set_alpha(int(255 * u))
                V.blit_center(f, s3, W / 2, H * 0.6)
            # little bouncing arrow
            ay = H * 0.68 + math.sin(i / self.fps * 9) * 14
            pygame.draw.polygon(f, (255, 210, 110), [(W / 2 - 34, ay), (W / 2 + 34, ay), (W / 2, ay + 44)])
            self.inner.write(f)
        return frames

    def close(self, wav_path=None):
        extra = self._end_card()
        if extra and wav_path:
            _pad_wav(wav_path, extra / self.fps)
        return self.inner.close(wav_path)


def _pad_wav(path, seconds):
    with wave.open(path, "rb") as w:
        params = w.getparams()
        data = np.frombuffer(w.readframes(params.nframes), "<i2").reshape(-1, params.nchannels)
    add = int(seconds * params.framerate)
    tail = data[-int(0.4 * params.framerate):].astype(np.float32)
    fade = np.zeros((add, params.nchannels), np.float32)
    k = min(len(tail), add)
    fade[:k] = tail[:k] * np.linspace(0.6, 0, k)[:, None] * 0   # quiet end card (music already resolved)
    out = np.concatenate([data, fade.astype("<i2")])
    with wave.open(path, "wb") as w:
        w.setparams(params)
        w.writeframes(out.tobytes())
