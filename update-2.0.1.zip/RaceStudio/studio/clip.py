"""python -m studio.clip job.json out.mp4  -> a ~6 second low-res preview with sound."""
import json
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
os.chdir(HERE)

from engine import preview  # noqa: E402

job = json.load(open(sys.argv[1], encoding="utf-8"))
cfg = job["cfg"]
if job.get("music") == "off":
    cfg["music"] = "off"
preview.clip(job["game"], cfg, sys.argv[2], seconds=float(job.get("seconds", 6)))
os.remove(sys.argv[1])
print(f"  -> {sys.argv[2]}  (preview)", flush=True)
