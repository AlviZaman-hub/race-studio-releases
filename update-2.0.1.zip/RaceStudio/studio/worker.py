"""Long-lived preview worker. The server sends one JSON job per line on stdin;
we answer with a line starting with @@RESULT (games print their own chatter too)."""
import json
import os
import sys
import traceback

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
os.chdir(HERE)

from engine import preview  # noqa: E402
from engine.video import pygame  # noqa: E402


def bg_thumb(job):
    import importlib
    from engine import backgrounds, visual as V
    pygame.display.init()
    pygame.display.set_mode((1, 1))
    th = {"bg1": "#0a0c14", "bg2": "#232a44"}
    try:
        mod = importlib.import_module(f"games.{job['game']}")
        th = mod.THEMES.get(job.get("theme")) or next(iter(mod.THEMES.values()))
    except Exception:
        pass
    V.STYLE["mode"] = "cartoon" if job.get("look") == "cartoon" else "sleek"
    s, _ = backgrounds.make(1080, 1920, V.hexc(th["bg1"]), V.hexc(th["bg2"]), job["style"], 7)
    pygame.image.save(pygame.transform.smoothscale(s, (216, 384)), job["out"])
    pygame.quit()


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        job = json.loads(line)
        res = {"id": job.get("id")}
        try:
            if job["kind"] == "still":
                preview.still(job["game"], job["cfg"], job["out"], job.get("at", 2.5))
            elif job["kind"] == "bg":
                bg_thumb(job)
            if job.get("size"):
                img = pygame.image.load(job["out"])
                w, h = job["size"]
                pygame.image.save(pygame.transform.smoothscale(img, (w, h)), job["out"])
            res.update(ok=True, out=job["out"])
        except Exception as e:
            traceback.print_exc(file=sys.stderr)
            res.update(ok=False, error=str(e) or e.__class__.__name__)
        sys.stdout.write("@@RESULT " + json.dumps(res) + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
