"""Fast previews for the UI: a single still frame or a short low-res clip of any game."""
import importlib
import os
import random

from .video import PreviewDone
from .audio import SoundTrack


class _Silent:
    """Stand-in SoundTrack for stills: games call add()/climax() and we ignore it."""
    music = False

    def add(self, *a, **k):
        pass

    def climax(self, *a, **k):
        pass

    def render(self, *a, **k):
        pass


def _prep(game, cfg):
    mod = importlib.import_module(f"games.{game}")
    c = dict(cfg)
    c.setdefault("seed", random.randrange(1, 10 ** 6))
    themes = list(getattr(mod, "RANDOM_THEMES", getattr(mod, "THEMES", {"x": 0})))
    if c.get("theme") not in getattr(mod, "THEMES", {}):
        c["theme"] = random.Random(c["seed"]).choice(themes)
    # previews don't need a perfectly tuned race length: keep tuning short
    c["race_seconds"] = c.get("race_seconds", [20, 35])
    c["_preview_fast"] = True
    return mod, c


def still(game, cfg, out_png, at=2.5):
    """Render a game until `at` seconds and save that frame as a PNG (half size)."""
    from .video import pygame
    mod, c = _prep(game, cfg)
    c["_preview"] = {"still": at}
    try:
        mod.render(c, out_png + ".mp4", _Silent())
        raise RuntimeError("game ended before the preview frame")
    except PreviewDone as d:
        img = pygame.transform.smoothscale(d.frame, (540, 960))
        pygame.image.save(img, out_png)
        pygame.quit()
    return out_png


def clip(game, cfg, out_mp4, seconds=6.0, vibe=None):
    mod, c = _prep(game, cfg)
    c["_preview"] = {"clip": seconds}
    rng = random.Random(c["seed"])
    vibe = vibe or c.get("vibe") or rng.choice(["dark", "phonk", "lofi", "hype"])
    snd = SoundTrack(key_midi=rng.choice([52, 53, 55, 57, 58]), vibe=vibe, bpm=96,
                     music=c.get("music", "on") != "off", seed=c["seed"])
    try:
        mod.render(c, out_mp4, snd)
    except PreviewDone as d:
        d.finish()
        from .video import pygame
        pygame.quit()
    return out_mp4
