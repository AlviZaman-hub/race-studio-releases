"""Gemini helpers. Gemini only *plans* (JSON); Race Studio renders.

Key is stored locally in config/_ai.json (never uploaded, never touched by updates).
Uses curl (works on Windows 10+ and macOS without extra certificates setup).
"""
import json
import os
import random
import re
import shutil
import subprocess
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = os.path.join(ROOT, "config", "_ai.json")
EMOJI_DIR = os.path.join(ROOT, "assets", "emoji")
MODELS = ["gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.6-flash", "gemini-3.8-flash",
          "gemini-2.5-flash-lite", "gemini-2.5-flash"]
USAGE = os.path.join(ROOT, "config", "_usage.json")
# rough USD per million tokens (input, output); unknown models use the expensive row so estimates err high
PRICES = {"flash-lite": (0.25, 1.50), "flash": (0.50, 3.00), "default": (1.25, 10.0)}


class BudgetError(Exception):
    pass


def _price(model):
    if "flash-lite" in model:
        return PRICES["flash-lite"]
    if "flash" in model:
        return PRICES["flash"]
    return PRICES["default"]


def usage():
    try:
        with open(USAGE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"total": 0.0, "days": {}, "calls": 0}


def record_cost(usd, what="text"):
    """Add spend to the local ledger and to the current video's budget counter."""
    import datetime
    u = usage()
    day = datetime.date.today().isoformat()
    u["total"] = round(u.get("total", 0) + usd, 6)
    u["days"][day] = round(u["days"].get(day, 0) + usd, 6)
    u["calls"] = u.get("calls", 0) + 1
    u.setdefault("by_kind", {})[what] = round(u.get("by_kind", {}).get(what, 0) + usd, 6)
    os.makedirs(os.path.dirname(USAGE), exist_ok=True)
    with open(USAGE, "w", encoding="utf-8") as f:
        json.dump(u, f)
    _video["spent"] += usd


# per-video budget: make.py calls begin_video(limit) before each video
_video = {"limit": None, "spent": 0.0}


def begin_video(limit_usd):
    _video["limit"], _video["spent"] = limit_usd, 0.0


def video_spent():
    return _video["spent"]


def can_spend(usd):
    return _video["limit"] is None or _video["spent"] + usd <= _video["limit"] + 1e-9


def _check_budget(est):
    if not can_spend(est):
        raise BudgetError(f"AI budget for this video used up ({_video['spent'] * 100:.1f}¢ of {_video['limit'] * 100:.0f}¢).")
API = os.environ.get("RACESTUDIO_AI_API", "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent")
PALETTE = ["#ef3b3b", "#2f6bff", "#1fbf4f", "#ffd21f", "#9b4dff", "#ff8a1f", "#19c3c3", "#ff5fb0"]


class AIError(Exception):
    pass


# ------------------------------------------------------------------ settings
def load():
    try:
        with open(CFG, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save(key, model=None):
    d = load()
    d["key"] = key.strip()
    if model:
        d["model"] = model
    os.makedirs(os.path.dirname(CFG), exist_ok=True)
    with open(CFG, "w", encoding="utf-8") as f:
        json.dump(d, f)


def has_key():
    return bool(load().get("key"))


# ------------------------------------------------------------------ transport
def _post(url, key, body, timeout=60):
    data = json.dumps(body).encode("utf-8")
    curl = shutil.which("curl")
    if curl:
        flags = 0x08000000 if os.name == "nt" else 0
        p = subprocess.run([curl, "-sS", "--max-time", str(timeout), "-w", "\n%{http_code}", "-X", "POST",
                            "-H", "Content-Type: application/json", "-H", f"x-goog-api-key: {key}",
                            "--data-binary", "@-", url], input=data, capture_output=True, creationflags=flags)
        if p.returncode == 0:
            out = p.stdout.decode("utf-8", "replace")
            body_txt, _, code = out.rpartition("\n")
            return int(code or 0), body_txt
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json", "x-goog-api-key": key})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


def ask_json(prompt, temperature=0.9):
    """Send a prompt, get parsed JSON back. Tries the saved model, then fallbacks."""
    st = load()
    key = st.get("key")
    if not key:
        raise AIError("Add your free Gemini API key first (AI section).")
    models = ([st["model"]] if st.get("model") else []) + [m for m in MODELS if m != st.get("model")]
    _check_budget(len(prompt) / 4 * 1.25e-6 + 0.002)
    last = ""
    for m in models:
        body = {"contents": [{"parts": [{"text": prompt}]}],
                "generationConfig": {"responseMimeType": "application/json", "temperature": temperature}}
        code, txt = _post(API.format(model=m), key, body)
        if code == 200:
            try:
                d = json.loads(txt)
                text = d["candidates"][0]["content"]["parts"][0]["text"]
                um = d.get("usageMetadata") or {}
                pin, pout = _price(m)
                tin = um.get("promptTokenCount", len(prompt) / 4)
                tout = um.get("candidatesTokenCount", len(text) / 4) + um.get("thoughtsTokenCount", 0)
                record_cost((tin * pin + tout * pout) / 1e6, "text")
            except Exception:
                last = "Unexpected reply from Gemini."
                continue
            if st.get("model") != m:
                save(key, m)
            return _parse(text)
        if code in (400, 401, 403) and ("API key" in txt or "PERMISSION" in txt or "API_KEY" in txt):
            raise AIError("Gemini rejected the API key. Check it was copied fully.")
        if code == 429:
            raise AIError("Gemini free limit reached for now. Wait a minute and try again.")
        last = f"{m}: HTTP {code}"
    raise AIError(f"Couldn't reach Gemini ({last}). Check your internet.")


def _parse(text):
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"(\{.*\}|\[.*\])", text, re.S)
        if m:
            return json.loads(m.group(1))
        raise AIError("Gemini sent something that wasn't valid. Try again.")


# ------------------------------------------------------------------ validation helpers
def emoji_ok(e):
    if not e:
        return False
    cps = [f"{ord(ch):x}" for ch in e]
    for n in ("-".join(cps), "-".join(c for c in cps if c != "fe0f")):
        if os.path.exists(os.path.join(EMOJI_DIR, n + ".png")):
            return True
    return False


def emoji_seq_ok(s):
    """Every emoji in a clue string must exist in our pack."""
    parts = split_emoji(s)
    return bool(parts) and all(emoji_ok(p) for p in parts)


def split_emoji(s):
    """Split a string of emojis into individual emoji (handles ZWJ, skin tones, flags, variation selectors)."""
    out, cur = [], ""
    chars = list(s.replace(" ", ""))
    i = 0
    while i < len(chars):
        ch = chars[i]
        cur += ch
        nxt = chars[i + 1] if i + 1 < len(chars) else ""
        cp = ord(ch)
        joiner = nxt in ("‍", "️") or ch == "‍" or (0x1F3FB <= ord(nxt or " ") <= 0x1F3FF)
        flag = 0x1F1E6 <= cp <= 0x1F1FF and 0x1F1E6 <= ord(nxt or " ") <= 0x1F1FF and len(cur) == 1
        keycap = nxt == "⃣"
        if not (joiner or flag or keycap):
            out.append(cur)
            cur = ""
        i += 1
    if cur:
        out.append(cur)
    return [p for p in out if p.strip()]


def clean_racers(racers, n=None):
    out = []
    for i, r in enumerate(racers or []):
        name = str(r.get("name", f"Racer {i + 1}"))[:14]
        col = r.get("color") or PALETTE[i % len(PALETTE)]
        if not re.match(r"^#[0-9a-fA-F]{6}$", col):
            col = PALETTE[i % len(PALETTE)]
        spec = {"name": name, "color": col}
        e = r.get("emoji", "")
        if e and emoji_ok(e):
            spec["emoji"] = e
        out.append(spec)
    if n:
        out = out[:n]
    return out


# ------------------------------------------------------------------ features
GAME_BLURBS = {
    "maze": "Maze Race: racers bounce through a maze and smash numbered blocks; first to the flag wins",
    "rings": "Ring Escape: balls escape spinning rings; most rings broken wins",
    "marbles": "Marble Elimination: marbles drop through peg boards; last one down each round is out",
    "territory": "Territory War: each colour's ball flips enemy tiles; biggest territory wins",
    "battle": "Ball Battle Royale: balls with swords and spikes fight; last one alive wins",
    "quiz": "Emoji Quiz: guess the answer from emoji clues before the timer ends",
    "music": "Music Bounce: every bounce of a ball plays the next note of a classical melody",
    "shrink": "Shrinking Arena: balls bounce in a shrinking arena; fall out of the gap and you're eliminated; last one inside wins",
    "chain": "Chain Reaction: balls smash a wall of bricks; most bricks broken wins",
    "track": "Marble Track: marbles race down a long winding track with obstacles; first to the bottom wins",
    "barrace": "Bar Chart Race: animated ranking over time from real data",
    "whatif": "What-if simulation: side-by-side physics comparison (normal vs changed rule)",
}


def idea(game, theme="", n=4):
    """Racers + title for one video."""
    p = f"""You plan viral YouTube Shorts for a faceless satisfying-simulation channel.
Game: {GAME_BLURBS.get(game, game)}.
{"Theme requested: " + theme if theme else "Pick a fun, broad-appeal theme people have opinions about (foods, animals, countries, sports, zodiac, school subjects, etc.). Avoid real brands, real people, politics and religion."}
Return JSON: {{"title": "on-screen hook question, max 6 words, uppercase", "theme": "short theme name",
"racers": [{n} items of {{"name": "1-2 words", "emoji": "ONE standard emoji", "color": "#rrggbb distinct and vivid"}}]}}"""
    d = ask_json(p)
    racers = clean_racers(d.get("racers"), n)
    if len(racers) < 1:
        raise AIError("Gemini didn't return racers. Try again.")
    return {"title": str(d.get("title", "")).upper()[:60], "theme": d.get("theme", theme), "racers": racers}


def caption(game, title, racer_names):
    p = f"""Write the upload text for a YouTube Short from a satisfying-simulation channel.
Game: {GAME_BLURBS.get(game, game)}. On-screen title: "{title}". Racers: {", ".join(racer_names)}.
Never reveal who wins. Return JSON: {{"title": "max 70 chars, curiosity hook, ends with #shorts",
"description": "1-2 short lines inviting viewers to guess/comment", "hashtags": ["5 relevant hashtags without spaces"],
"pinned_comment": "one question that makes people comment"}}"""
    d = ask_json(p, 0.8)
    return {"title": str(d.get("title", title))[:100], "description": str(d.get("description", "")),
            "hashtags": [str(h).lstrip("#").replace(" ", "") for h in d.get("hashtags", [])][:8],
            "pinned_comment": str(d.get("pinned_comment", ""))}


BAR_DATASETS = ["Population", "GDP (US$)", "GDP per person (US$)", "Life expectancy (years)",
                "Urban population", "Exports (US$)", "Internet users (% of people)"]


def plan_week(n, games):
    p = f"""Plan {n} varied YouTube Shorts for a faceless satisfying-simulation channel. Mix the games evenly,
vary themes (no theme repeated), broad appeal, no real brands/people/politics/religion.
Available games: {"; ".join(f"{g} = {GAME_BLURBS.get(g, g)}" for g in games)}.
Return JSON: {{"videos": [{{"game": "one of {list(games)}", "title": "on-screen hook, max 6 words, uppercase",
"theme": "short theme", "racers": [2-6 items of {{"name": "1-2 words", "emoji": "ONE emoji", "color": "#rrggbb"}}],
"quiz_topic": "only for quiz: e.g. movies, countries, animals, foods",
"idea": "only for whatif: 'what if ...' using gravity/bounciness/friction/ball count/ball size/time speed/wind",
"dataset": "only for barrace: one of {BAR_DATASETS}"}}]}}"""
    d = ask_json(p)
    out = []
    for v in d.get("videos", [])[:n]:
        g = v.get("game")
        if g not in games:
            continue
        item = {"game": g, "title": str(v.get("title", "")).upper()[:60], "theme": v.get("theme", ""),
                "racers": clean_racers(v.get("racers"), 8)}
        if g == "quiz":
            item["quiz_topic"] = v.get("quiz_topic") or v.get("theme") or "movies"
        if g == "whatif":
            item["idea"] = str(v.get("idea") or v.get("title") or "what if gravity was 2x")[:80]
        if g == "barrace":
            item["dataset"] = v.get("dataset") if v.get("dataset") in BAR_DATASETS else BAR_DATASETS[0]
        if g not in ("quiz", "whatif", "barrace") and len(item["racers"]) < 2:
            continue
        out.append(item)
    if not out:
        raise AIError("Gemini didn't return a usable plan. Try again.")
    return out


def quiz(topic, n=6):
    p = f"""Make {n} emoji quiz questions for a YouTube Short. Topic: {topic}.
Each clue is 2-4 standard emojis that clearly hint at a well-known answer (famous titles, places, animals, foods, idioms).
Answers must be correct and widely known. No offensive content.
Return JSON: {{"questions": [{{"clue": "emojis only", "answer": "the answer, max 4 words"}}]}}"""
    d = ask_json(p, 0.9)
    qs = []
    for q in d.get("questions", []):
        clue = str(q.get("clue", "")).strip()
        ans = str(q.get("answer", "")).strip()[:40]
        if ans and emoji_seq_ok(clue) and 1 <= len(split_emoji(clue)) <= 5:
            qs.append({"clue": clue, "answer": ans})
    if not qs:
        raise AIError("Gemini's emojis weren't usable. Try again or another topic.")
    return qs[:n]


def names_from_comments(text, n=8):
    p = f"""From these YouTube comments, pick up to {n} distinct commenter usernames (or names people asked to be added).
Skip anything offensive. Return JSON: {{"names": ["max 14 characters each"]}}
Comments:\n{text[:6000]}"""
    d = ask_json(p, 0.3)
    names = [str(x).lstrip("@")[:14] for x in d.get("names", []) if str(x).strip()]
    return list(dict.fromkeys(names))[:n]


def whatif(text):
    p = f"""Turn this physics 'what if' idea into simulation settings for a side-by-side comparison
(left = normal world, right = changed world). Idea: "{text}".
Allowed settings (only change what the idea needs): gravity (normal 1.0, range -1.0..5.0),
bounciness (normal 0.7, range 0..1.2), friction (normal 0.5, range 0..1.5), balls (normal 60, range 5..200),
ball_size (normal 1.0, range 0.4..2.5), time_scale (normal 1.0, range 0.25..3), wind (normal 0, range -3..3).
Return JSON: {{"title": "on-screen hook, max 6 words, uppercase", "label": "short label for the changed world, e.g. GRAVITY x2",
"settings": {{only the changed keys with numbers}}}}"""
    d = ask_json(p, 0.4)
    lim = {"gravity": (-1, 5), "bounciness": (0, 1.2), "friction": (0, 1.5), "balls": (5, 200),
           "ball_size": (0.4, 2.5), "time_scale": (0.25, 3), "wind": (-3, 3)}
    st = {}
    for k, v in (d.get("settings") or {}).items():
        if k in lim:
            try:
                st[k] = max(lim[k][0], min(lim[k][1], float(v)))
            except (TypeError, ValueError):
                pass
    if not st:
        raise AIError("Couldn't turn that idea into settings. Try rewording it.")
    return {"title": str(d.get("title", text)).upper()[:60], "label": str(d.get("label", "WHAT IF"))[:24].upper(),
            "settings": st}


def whatif_idea(theme=""):
    """Invent a fresh 'what if' physics idea (optionally around a theme)."""
    p = f"""Invent ONE fun 'what if' physics idea for a satisfying side-by-side short video
(balls pouring through an hourglass with pegs; normal world vs changed world).
It must be something these settings can show: gravity, bounciness, friction, number of balls, ball size, time speed, wind.
{('Theme: ' + theme) if theme else ''}
Return JSON: {{"idea": "what if ... (max 10 words)", "title": "on-screen hook, max 6 words, uppercase"}}"""
    d = ask_json(p, 1.0)
    if not d.get("idea"):
        raise AIError("No idea came back. Try again.")
    return {"idea": str(d["idea"])[:80], "title": str(d.get("title", "")).upper()[:60]}


# ------------------------------------------------------------------ captions without AI
TEMPLATES = {
    "maze": ["Who reaches the flag first? 🏁 #shorts", "Pick your racer before it's too late 👀 #shorts"],
    "rings": ["Who breaks the most rings? ⭕ #shorts", "Can it escape every ring? #shorts"],
    "marbles": ["Last one down is OUT 😳 #shorts", "Which marble survives? #shorts"],
    "territory": ["Which colour takes over? 🟥🟦 #shorts", "Watch the board flip 😮 #shorts"],
    "battle": ["Last ball standing wins ⚔️ #shorts", "Who survives the battle? #shorts"],
    "quiz": ["Only geniuses get all of these 🧠 #shorts", "Can you guess them all? #shorts"],
    "music": ["Every bounce plays a note 🎹 #shorts", "Wait for the melody 😌 #shorts"],
    "shrink": ["Last one inside wins 😬 #shorts", "The arena keeps shrinking… #shorts"],
    "chain": ["Who breaks the most blocks? 💥 #shorts", "So satisfying 😮‍💨 #shorts"],
    "track": ["Who wins the marble race? 🏁 #shorts", "This track is insane 😳 #shorts"],
    "barrace": ["Watch the ranking change 📊 #shorts", "Did you expect #1? #shorts"],
    "whatif": ["What if…? 🤯 #shorts", "Physics gets weird 😳 #shorts"],
}


def template_caption(game, title, racer_names, seed=0):
    r = random.Random(seed)
    t = r.choice(TEMPLATES.get(game, ["Guess the winner! #shorts"]))
    tags = ["satisfying", "oddlysatisfying", "simulation", "guessthewinner", "marblerace"]
    if game == "quiz":
        tags = ["emojiquiz", "quiz", "guessthemovie", "brainteaser", "trivia"]
    if game == "music":
        tags = ["satisfying", "piano", "classicalmusic", "bouncingball", "asmr"]
    if game == "barrace":
        tags = ["barchartrace", "data", "dataisbeautiful", "ranking", "statistics"]
    who = ", ".join(racer_names[:6])
    head = " — ".join(x for x in (title.title(), who) if x)
    if game == "quiz":
        return {"title": t, "description": (head + ". " if head else "") + "Pause if you need more time! New quizzes every day.",
                "hashtags": tags, "pinned_comment": "How many did you get? Comment your score 👇"}
    if game == "barrace":
        return {"title": t, "description": (head + ". " if head else "") + "Which one surprised you? New races every week.",
                "hashtags": tags, "pinned_comment": "Did you expect the #1? 👇"}
    if game == "whatif":
        return {"title": t, "description": (head + ". " if head else "") + "What should we test next? Comment your idea!",
                "hashtags": tags, "pinned_comment": "What should we change next? 👇"}
    return {"title": t, "description": (head + ". " if head else "") + "Comment your pick before the end! New videos every day.",
            "hashtags": tags, "pinned_comment": "Who did you pick? Be honest 👇"}


def write_caption_file(path, cap):
    lines = ["TITLE", cap["title"], "", "DESCRIPTION", cap["description"], "",
             " ".join("#" + h for h in cap["hashtags"]), "", "PINNED COMMENT", cap["pinned_comment"], "",
             "CREDITS (paste at the end of the description)", "Emoji graphics: Twemoji by Twitter, CC-BY 4.0"]
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
