"""Shared visuals: fonts, outlined text, racer sprites, particles."""
import math
import os
import random

from .video import pygame

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "assets")

# ---------------------------------------------------------------- colors

def hexc(c):
    if isinstance(c, (tuple, list)):
        return tuple(c[:3])
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def darker(c, k=0.55):
    return tuple(int(v * k) for v in c)


def lighter(c, k=0.45):
    return mix(c, (255, 255, 255), k)


# ---------------------------------------------------------------- text

_fonts = {}


# "sleek" (default, modern) or "cartoon" (original look). Games set this from the config.
STYLE = {"mode": "sleek", "faces": True}

SLEEK_FONTS = {"Bold": "Inter-Black.ttf", "Medium": "Inter-SemiBold.ttf", "Display": "Anton-Regular.ttf",
               "ExtraBold": "Inter-ExtraBold.ttf"}
CARTOON_FONTS = {"Bold": "Poppins-Bold.ttf", "Medium": "Poppins-Medium.ttf", "Display": "Poppins-Bold.ttf",
                 "ExtraBold": "Poppins-Bold.ttf"}


def sleek():
    return STYLE["mode"] != "cartoon"


def font(size, weight="Bold"):
    key = (size, weight, STYLE["mode"])
    if key not in _fonts:
        name = (SLEEK_FONTS if sleek() else CARTOON_FONTS).get(weight, "Inter-Black.ttf")
        _fonts[key] = pygame.font.Font(os.path.join(ASSETS, "fonts", name), size)
    return _fonts[key]


_text_cache = {}


def _forget_fonts():
    _fonts.clear()


from .video import QUIT_HOOKS  # noqa: E402
QUIT_HOOKS.append(_forget_fonts)


def text(s, size, color=(255, 255, 255), outline=(20, 20, 30), ow=None, weight="Bold"):
    key = (s, size, color, outline, ow, weight, STYLE["mode"])
    if key in _text_cache:
        return _text_cache[key]
    f = font(size, weight)
    if sleek():
        surf = _sleek_text(f, s, size, color, outline)
        if len(_text_cache) > 4000:
            _text_cache.clear()
        _text_cache[key] = surf
        return surf
    ow = ow if ow is not None else max(2, size // 12)
    base = f.render(s, True, color)
    if not outline:
        _text_cache[key] = base
        return base
    w, h = base.get_width() + ow * 2, base.get_height() + ow * 2
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    o = f.render(s, True, outline)
    steps = 16
    for i in range(steps):
        a = 2 * math.pi * i / steps
        surf.blit(o, (ow + round(math.cos(a) * ow), ow + round(math.sin(a) * ow)))
    surf.blit(base, (ow, ow))
    if len(_text_cache) > 4000:
        _text_cache.clear()
    _text_cache[key] = surf
    return surf


def _sleek_text(f, s, size, color, outline):
    """Clean text: hairline dark edge + soft drop shadow (no thick cartoon outline)."""
    base = f.render(s, True, color)
    if not outline:
        return base
    pad = max(4, size // 6)
    w, h = base.get_width() + pad * 2, base.get_height() + pad * 2
    # soft shadow: render dark text, blur by down/up scaling
    sh = pygame.Surface((w, h), pygame.SRCALPHA)
    dark = f.render(s, True, (0, 0, 0))
    sh.blit(dark, (pad, pad + max(2, size // 18)))
    k = 4
    small = pygame.transform.smoothscale(sh, (max(1, w // k), max(1, h // k)))
    sh = pygame.transform.smoothscale(small, (w, h))
    sh.fill((255, 255, 255, 170), special_flags=pygame.BLEND_RGBA_MULT)
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    surf.blit(sh, (0, 0))
    ow = max(1, round(size * 0.028))
    edge = f.render(s, True, (8, 8, 12))
    for dx, dy in ((-ow, 0), (ow, 0), (0, -ow), (0, ow), (-ow, -ow), (ow, ow), (-ow, ow), (ow, -ow)):
        surf.blit(edge, (pad + dx, pad + dy))
    surf.blit(base, (pad, pad))
    return surf


def blit_center(dst, surf, cx, cy):
    dst.blit(surf, (round(cx - surf.get_width() / 2), round(cy - surf.get_height() / 2)))


# ---------------------------------------------------------------- emoji / images

def emoji_path(e):
    cps = [f"{ord(ch):x}" for ch in e]
    names = ["-".join(cps), "-".join(c for c in cps if c != "fe0f")]
    for n in names:
        p = os.path.join(ASSETS, "emoji", n + ".png")
        if os.path.exists(p):
            return p
    raise FileNotFoundError(f"No emoji image for {e!r}")


def _circle_crop(img, size):
    img = pygame.transform.smoothscale(_cover(img, size), (size, size))
    mask = pygame.Surface((size, size), pygame.SRCALPHA)
    pygame.draw.circle(mask, (255, 255, 255, 255), (size // 2, size // 2), size // 2)
    out = pygame.Surface((size, size), pygame.SRCALPHA)
    out.blit(img, (0, 0))
    out.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return out


def _cover(img, size):
    w, h = img.get_size()
    s = min(w, h)
    return img.subsurface(((w - s) // 2, (h - s) // 2, s, s)).copy()


def _fit(img, size):
    w, h = img.get_size()
    k = size / max(w, h)
    return pygame.transform.smoothscale(img, (max(1, round(w * k)), max(1, round(h * k))))


# ---------------------------------------------------------------- racers

class Look:
    """How one racer looks. kind = square | emoji | image."""

    def __init__(self, spec, size):
        self.name = spec.get("name", "?")
        self.color = hexc(spec.get("color", "#e74c3c"))
        self.size = size
        self.kind = "square"
        self.img = None
        self.big = None
        if spec.get("emoji"):
            self.kind = "emoji"
            raw = pygame.image.load(emoji_path(spec["emoji"])).convert_alpha()
            self.img = _fit(raw, int(size * 1.25))
            self.big = _fit(raw, 260)
        elif spec.get("image"):
            self.kind = "image"
            p = spec["image"]
            if not os.path.isabs(p):
                p2 = os.path.join(ASSETS, "racers", p)
                p = p2 if os.path.exists(p2) else p
            raw = pygame.image.load(p).convert_alpha()
            shape = spec.get("shape", "fit")
            if shape == "circle":
                ring = max(3, size // 14)
                inner = _circle_crop(raw, size * 2 - ring * 4)
                self.img = self._ringed(pygame.transform.smoothscale(inner, (size + 8 - ring * 2,) * 2), ring)
                self.big = self._ringed(_circle_crop(raw, 250), 8)
            else:
                self.img = _fit(raw, int(size * 1.35))
                self.big = _fit(raw, 280)

    def _ringed(self, inner, ring):
        d = inner.get_width() + ring * 2
        s = pygame.Surface((d, d), pygame.SRCALPHA)
        pygame.draw.circle(s, self.color, (d // 2, d // 2), d // 2)
        pygame.draw.circle(s, darker(self.color), (d // 2, d // 2), d // 2, max(2, ring // 2))
        s.blit(inner, (ring, ring))
        return s

    def _sleek_square(self, w, h):
        key = ("sq", w, h)
        c = self.__dict__.setdefault("_sprites", {})
        if key in c:
            return c[key]
        pad = max(6, w // 3)
        S = pygame.Surface((w + pad * 2, h + pad * 2), pygame.SRCALPHA)
        rad = max(3, int(min(w, h) * 0.2))
        # soft glow in the racer's colour
        glow = pygame.Surface(S.get_size(), pygame.SRCALPHA)
        pygame.draw.rect(glow, (*self.color, 90), pygame.Rect(pad - 4, pad - 2, w + 8, h + 8), border_radius=rad + 4)
        k = 5
        glow = pygame.transform.smoothscale(pygame.transform.smoothscale(glow, (max(1, S.get_width() // k), max(1, S.get_height() // k))), S.get_size())
        S.blit(glow, (0, 0))
        # body: vertical gradient, lighter on top
        body = pygame.Surface((w, h), pygame.SRCALPHA)
        top, bot = lighter(self.color, 0.28), darker(self.color, 0.72)
        for yy in range(h):
            pygame.draw.line(body, mix(top, bot, yy / max(1, h - 1)), (0, yy), (w, yy))
        mask = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(mask, (255, 255, 255, 255), pygame.Rect(0, 0, w, h), border_radius=rad)
        body.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        S.blit(body, (pad, pad))
        # crisp rim + thin top highlight
        pygame.draw.rect(S, darker(self.color, 0.45), pygame.Rect(pad, pad, w, h), max(1, w // 22), border_radius=rad)
        pygame.draw.line(S, lighter(self.color, 0.6), (pad + rad, pad + max(2, h // 12)), (pad + w - rad, pad + max(2, h // 12)), max(1, w // 26))
        c[key] = S
        return S

    def _sleek_ball(self, r):
        key = ("ball", r)
        c = self.__dict__.setdefault("_sprites", {})
        if key in c:
            return c[key]
        pad = max(6, r)
        d = r * 2
        S = pygame.Surface((d + pad * 2, d + pad * 2), pygame.SRCALPHA)
        cx = cy = pad + r
        glow = pygame.Surface(S.get_size(), pygame.SRCALPHA)
        pygame.draw.circle(glow, (*self.color, 85), (cx, cy), r + 5)
        k = 5
        glow = pygame.transform.smoothscale(pygame.transform.smoothscale(glow, (max(1, S.get_width() // k), max(1, S.get_height() // k))), S.get_size())
        S.blit(glow, (0, 0))
        # shaded sphere: concentric circles from dark rim to lit centre (offset up-left)
        steps = max(6, r)
        for i in range(steps):
            f = i / steps
            col = mix(darker(self.color, 0.55), lighter(self.color, 0.35), f ** 1.4)
            rr = r * (1 - f * 0.9)
            ox, oy = -r * 0.28 * f, -r * 0.32 * f
            pygame.draw.circle(S, col, (round(cx + ox), round(cy + oy)), max(1, round(rr)))
        pygame.draw.circle(S, darker(self.color, 0.4), (cx, cy), r, max(1, r // 10))
        c[key] = S
        return S

    # ---------------------------------------------------------- physics-driven drawing
    def _rot(self, key, base, deg):
        c = self.__dict__.setdefault("_rotc", {})
        k = (key, deg)
        if k not in c:
            if len(c) > 3000:
                c.clear()
            c[k] = pygame.transform.rotozoom(base, deg, 1.0)
        return c[k]

    def draw_body(self, dst, x, y, angle=0.0, vx=0.0, vy=0.0, size=None, shape="square"):
        """Draw the racer rotated by the physics angle (radians), eyes follow the body,
        pupils look where it is moving. Smooth anti-aliased rotation."""
        size = int(round(size or self.size))
        deg = int(round(-math.degrees(angle))) % 360
        if not sleek():
            if shape == "ball":
                self.draw_ball(dst, x, y, size / 2, vx, vy)
            else:
                self.draw(dst, x, y, vx, vy)
            return
        if self.kind == "square":
            if shape == "ball":
                blit_center(dst, self._sleek_ball(max(3, size // 2)), x, y)
                eye_dx, eye_dy, er = 0.3 * size / 2, -0.12 * size / 2, 0.24 * size / 2
            else:
                blit_center(dst, self._rot(("sq", size), self._sleek_square(size, size), deg), x, y)
                eye_dx, eye_dy, er = 0.19 * size, -0.05 * size, 0.135 * size
            if STYLE.get("faces", True):
                self._eyes(dst, x, y, angle, vx, vy, eye_dx, eye_dy, er)
        else:
            src = self.big
            k = (size * (1.25 if shape == "square" else 1.15)) / max(src.get_width(), src.get_height())
            key = ("img", size, shape)
            base_c = self.__dict__.setdefault("_basec", {})
            if key not in base_c:
                base_c[key] = pygame.transform.smoothscale(src, (max(1, round(src.get_width() * k)), max(1, round(src.get_height() * k))))
            blit_center(dst, self._rot(key, base_c[key], deg), x, y)

    def _eyes(self, dst, x, y, angle, vx, vy, dx, dy, er):
        import pygame.gfxdraw as gfx
        ca, sa = math.cos(angle), math.sin(angle)
        sp = math.hypot(vx, vy)
        lx, ly = ((vx / sp, vy / sp) if sp > 30 else (0.0, 0.0))
        for side in (-1, 1):
            ox, oy = side * dx, dy
            ex, ey = x + ox * ca - oy * sa, y + ox * sa + oy * ca
            r = max(2, int(round(er)))
            gfx.filled_circle(dst, int(round(ex)), int(round(ey)), r, (250, 250, 252))
            gfx.aacircle(dst, int(round(ex)), int(round(ey)), r, (40, 40, 48))
            pr = max(1, int(round(er * 0.55)))
            px, py = ex + lx * er * 0.38, ey + ly * er * 0.38
            gfx.filled_circle(dst, int(round(px)), int(round(py)), pr, (18, 18, 24))
            gfx.aacircle(dst, int(round(px)), int(round(py)), pr, (18, 18, 24))
            hr = max(1, int(round(er * 0.18)))
            gfx.filled_circle(dst, int(round(px - pr * 0.35)), int(round(py - pr * 0.4)), hr, (255, 255, 255))

    def draw(self, dst, x, y, vx=0.0, vy=0.0, scale=1.0, squash=0.0):
        """x,y = centre. squash>0 briefly flattens on impact (juice)."""
        s = self.size * scale
        if self.kind == "square" and sleek():
            w = max(4, round(s * (1 + squash * 0.18)))
            h = max(4, round(s * (1 - squash * 0.18)))
            blit_center(dst, self._sleek_square(w, h), x, y)
            return
        if self.kind == "square":
            w = s * (1 + squash * 0.25)
            h = s * (1 - squash * 0.25)
            r = pygame.Rect(0, 0, round(w), round(h))
            r.center = (round(x), round(y))
            sh = r.move(4, 6)
            pygame.draw.rect(dst, (0, 0, 0, 60) if dst.get_flags() & pygame.SRCALPHA else (30, 30, 40), sh, border_radius=int(s * 0.22))
            pygame.draw.rect(dst, darker(self.color, 0.45), r, border_radius=int(s * 0.22))
            inner = r.inflate(-max(4, s * 0.12), -max(4, s * 0.12))
            pygame.draw.rect(dst, self.color, inner, border_radius=int(s * 0.18))
            hl = pygame.Rect(inner.x + s * 0.12, inner.y + s * 0.08, inner.w * 0.5, s * 0.12)
            pygame.draw.rect(dst, lighter(self.color, 0.35), hl, border_radius=int(s * 0.06))
            # eyes look where it's going
            sp = math.hypot(vx, vy) or 1
            lx, ly = vx / sp * s * 0.07, vy / sp * s * 0.07
            for ex in (-0.19, 0.19):
                cx, cy = x + ex * s, y - 0.02 * s
                pygame.draw.ellipse(dst, (255, 255, 255), pygame.Rect(cx - s * 0.13, cy - s * 0.16, s * 0.26, s * 0.32))
                pygame.draw.circle(dst, (20, 20, 28), (round(cx + lx), round(cy + ly)), max(2, round(s * 0.08)))
                pygame.draw.circle(dst, (255, 255, 255), (round(cx + lx - s * 0.03), round(cy + ly - s * 0.04)), max(1, round(s * 0.025)))
        else:
            img = self.img
            if scale != 1.0 or squash:
                w = img.get_width() * scale * (1 + squash * 0.2)
                h = img.get_height() * scale * (1 - squash * 0.2)
                img = pygame.transform.smoothscale(img, (max(1, round(w)), max(1, round(h))))
            blit_center(dst, img, x, y)

    def draw_ball(self, dst, x, y, r, vx=0.0, vy=0.0, squash=0.0):
        """Round version of the racer (used by ball games)."""
        if self.kind == "square" and sleek():
            blit_center(dst, self._sleek_ball(max(3, round(r))), x, y)
            return
        if self.kind == "square":
            ir = max(3, round(r))
            pygame.draw.circle(dst, darker(self.color, 0.45), (round(x), round(y)), ir)
            pygame.draw.circle(dst, self.color, (round(x), round(y)), max(2, round(ir * 0.86)))
            pygame.draw.circle(dst, lighter(self.color, 0.4), (round(x - ir * 0.32), round(y - ir * 0.36)), max(1, round(ir * 0.22)))
            sp = math.hypot(vx, vy) or 1
            lx, ly = vx / sp * r * 0.12, vy / sp * r * 0.12
            for ex in (-0.32, 0.32):
                cx, cy = x + ex * r, y + 0.02 * r
                pygame.draw.circle(dst, (255, 255, 255), (round(cx), round(cy)), max(2, round(r * 0.24)))
                pygame.draw.circle(dst, (20, 20, 28), (round(cx + lx), round(cy + ly)), max(1, round(r * 0.13)))
        else:
            src = self.big
            k = (2.3 * r) / max(src.get_width(), src.get_height())
            img = pygame.transform.smoothscale(src, (max(1, round(src.get_width() * k)), max(1, round(src.get_height() * k))))
            blit_center(dst, img, x, y)

    def badge(self, size):
        """Small icon for leaderboards."""
        bc = self.__dict__.setdefault("_badges", {})
        if (size, STYLE["mode"]) in bc:
            return bc[(size, STYLE["mode"])]
        surf = self._badge(size)
        bc[(size, STYLE["mode"])] = surf
        return surf

    def _badge(self, size):
        surf = pygame.Surface((size + 8, size + 8), pygame.SRCALPHA)
        if self.kind == "square" and sleek():
            self.draw_body(surf, (size + 8) / 2, (size + 8) / 2, 0.0, 0, 0, size - 4)
            return surf
        if self.kind == "square":
            old = self.size
            self.size = size
            self.draw(surf, (size + 8) / 2 - 2, (size + 8) / 2 - 3)
            self.size = old
        else:
            blit_center(surf, _fit(self.big, size + 6), (size + 8) / 2, (size + 8) / 2)
        return surf

    def hero(self, scale=1.0):
        """Large version for the winner screen."""
        if self.kind == "square" and sleek():
            img = pygame.Surface((330, 330), pygame.SRCALPHA)
            self.draw_body(img, 165, 165, 0.0, 0, 1, 230)
            if scale != 1.0:
                img = pygame.transform.smoothscale(img, (max(1, round(img.get_width() * scale)), max(1, round(img.get_height() * scale))))
            return img
        if self.kind == "square":
            s = pygame.Surface((340, 340), pygame.SRCALPHA)
            old = self.size
            self.size = 240
            self.draw(s, 166, 166, 0, 1)
            self.size = old
            img = s
        else:
            img = self.big
        if scale != 1.0:
            img = pygame.transform.smoothscale(img, (max(1, round(img.get_width() * scale)), max(1, round(img.get_height() * scale))))
        return img


# ---------------------------------------------------------------- particles

class Particles:
    def __init__(self, rng=None):
        self.p = []
        self.rng = rng or random.Random(0)

    def burst(self, x, y, color, n=18, speed=520, size=(6, 14), life=(0.4, 0.9), gravity=900):
        r = self.rng
        for _ in range(n):
            a = r.uniform(0, 2 * math.pi)
            sp = r.uniform(0.3, 1) * speed
            self.p.append([x, y, math.cos(a) * sp, math.sin(a) * sp - speed * 0.3,
                           r.uniform(*life), 0.0, color, r.uniform(*size), gravity, r.uniform(0, 6.28)])

    def confetti(self, w, n=140, colors=None):
        r = self.rng
        if sleek():
            colors = colors or [(255, 255, 255), (255, 214, 120), (200, 200, 210)]
            n = int(n * 0.6)
        colors = colors or [(255, 82, 82), (255, 214, 0), (0, 200, 120), (60, 140, 255), (190, 90, 255)]
        for _ in range(n):
            self.p.append([r.uniform(0, w), r.uniform(-300, -10), r.uniform(-80, 80), r.uniform(200, 520),
                           r.uniform(2.5, 4.5), 0.0, r.choice(colors), r.uniform(10, 20), 260, r.uniform(0, 6.28)])

    def update(self, dt):
        alive = []
        for q in self.p:
            q[5] += dt
            if q[5] < q[4]:
                q[3] += q[8] * dt
                q[0] += q[2] * dt
                q[1] += q[3] * dt
                q[9] += dt * 8
                alive.append(q)
        self.p = alive

    def draw(self, dst):
        for x, y, vx, vy, life, age, col, size, g, rot in self.p:
            k = 1 - age / life
            s = max(1, size * (0.4 + 0.6 * k))
            w = max(1, abs(math.cos(rot)) * s)
            pygame.draw.rect(dst, col, pygame.Rect(round(x - w / 2), round(y - s / 2), round(w), round(s)), border_radius=2)
