"""Render satisfying race videos.

Examples
  python make.py maze                        # 1 video, 4 colour squares
  python make.py maze --count 10             # 10 different races
  python make.py maze --racers drinks        # emoji preset
  python make.py maze --config config/my_race.json
  python make.py maze --seed 42 --theme ember --vibe phonk
  python make.py maze --style cartoon          # the original cartoon look + sounds
  python make.py rings --racers colors6       # Ring Escape
  python make.py marbles --racers colors6     # Marble Elimination
  python make.py territory --racers animals   # Territory War
"""
import argparse
import json
import os
import random
import sys
import time

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from engine.audio import SoundTrack  # noqa: E402

PRESETS = {
    "colors4": [{"name": "Red", "color": "#ef3b3b"}, {"name": "Blue", "color": "#2f6bff"},
                {"name": "Green", "color": "#1fbf4f"}, {"name": "Yellow", "color": "#ffd21f"}],
    "colors6": [{"name": "Red", "color": "#ef3b3b"}, {"name": "Blue", "color": "#2f6bff"},
                {"name": "Green", "color": "#1fbf4f"}, {"name": "Yellow", "color": "#ffd21f"},
                {"name": "Purple", "color": "#9b4dff"}, {"name": "Orange", "color": "#ff8a1f"}],
    "drinks": [{"name": "Cola", "emoji": "🥤", "color": "#e8433b"}, {"name": "Coffee", "emoji": "☕", "color": "#8a5a3a"},
               {"name": "Bubble Tea", "emoji": "🧋", "color": "#d8a26a"}, {"name": "Juice", "emoji": "🧃", "color": "#ffb21f"}],
    "food": [{"name": "Burger", "emoji": "🍔", "color": "#e8a33b"}, {"name": "Pizza", "emoji": "🍕", "color": "#ef5b3b"},
             {"name": "Taco", "emoji": "🌮", "color": "#f2c94c"}, {"name": "Sushi", "emoji": "🍣", "color": "#ff7a7a"}],
    "animals": [{"name": "Cat", "emoji": "🐱", "color": "#ffb347"}, {"name": "Dog", "emoji": "🐶", "color": "#c98b5a"},
                {"name": "Frog", "emoji": "🐸", "color": "#4cd964"}, {"name": "Panda", "emoji": "🐼", "color": "#555555"}],
}

GAMES = {"maze": "games.maze", "rings": "games.rings", "marbles": "games.marbles", "territory": "games.territory", "battle": "games.battle", "quiz": "games.quiz",
         "music": "games.music", "shrink": "games.shrink", "chain": "games.chain",
         "track": "games.track", "barrace": "games.barrace", "whatif": "games.whatif"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("game", nargs="?", choices=list(GAMES))
    ap.add_argument("--count", type=int, default=1)
    ap.add_argument("--config")
    ap.add_argument("--racers", default=None, help="preset name: " + ", ".join(PRESETS))
    ap.add_argument("--seed", type=int)
    ap.add_argument("--theme")
    ap.add_argument("--background", help="wavy_checker, stripes, dots, grid, radial, bokeh, zigzag")
    ap.add_argument("--vibe", choices=["dark", "phonk", "lofi", "hype", "playful"])
    ap.add_argument("--style", choices=["sleek", "cartoon"], help="sleek (default) or the original cartoon look")
    ap.add_argument("--music", default=None, help="'off' or path to your own WAV")
    ap.add_argument("--fps", type=int)
    ap.add_argument("--quality", choices=["fast", "good", "best"])
    ap.add_argument("--out", default="output")
    ap.add_argument("--topic", help="quiz topic (movies, countries, foods, phrases, mixed); what-if preset or your own idea; bar-race dataset")
    ap.add_argument("--ai-captions", action="store_true", help="write captions with Gemini (needs a key)")
    ap.add_argument("--ai-budget", type=float, default=None, help="max AI spend per video in cents (default: no limit)")
    ap.add_argument("--plan", help="JSON file with a list of jobs (from 'Plan my week')")
    a = ap.parse_args()

    cfg = {}
    if a.config:
        with open(a.config, encoding="utf-8") as f:
            cfg = json.load(f)
    if a.racers:
        cfg["racers"] = PRESETS[a.racers]
    cfg.setdefault("racers", PRESETS["colors4"])
    if a.topic:
        cfg["quiz_topic"] = a.topic
    for k in ("theme", "background", "vibe", "style", "fps", "quality"):
        if getattr(a, k):
            cfg[k] = getattr(a, k)
    os.makedirs(a.out, exist_ok=True)
    base = a.seed if a.seed is not None else random.randrange(1, 10 ** 6)
    jobs = []
    if a.plan:
        with open(a.plan, encoding="utf-8") as f:
            plan = json.load(f)
        for j in plan["jobs"]:
            c = dict(cfg)
            c.update(plan.get("base", {}))
            c["title"] = j.get("title", "")
            if j.get("racers"):
                c["racers"] = j["racers"]
            if j["game"] == "quiz":
                c["quiz_topic"] = j.get("quiz_topic", "mixed")
            if j["game"] == "whatif" and j.get("idea"):
                c["quiz_topic"] = j["idea"]
            if j["game"] == "barrace" and j.get("dataset"):
                c["dataset"] = j["dataset"]
            jobs.append((j["game"], c))
    else:
        if not a.game:
            ap.error("choose a game (or use --plan)")
        jobs = [(a.game, dict(cfg)) for _ in range(a.count)]
    for i, (game, c) in enumerate(jobs):
        c["seed"] = base + i
        try:
            render_one(game, c, a, i, len(jobs))
        except Exception as e:
            if not a.plan:
                raise
            print(f"  !! skipped {game}: {e}")


def render_one(game, c, a, i, total):
    from engine import ai as _ai
    _ai.begin_video(a.ai_budget / 100 if a.ai_budget is not None else None)
    module = __import__(GAMES[game], fromlist=["render"])
    cartoon = c.get("style") == "cartoon"
    themes = list(getattr(module, "THEMES", {"ocean": 0})) if cartoon else \
        list(getattr(module, "RANDOM_THEMES", getattr(module, "THEMES", {"ocean": 0})))
    rng = random.Random(c["seed"])
    if c.get("theme") not in getattr(module, "THEMES", {}):
        c["theme"] = rng.choice(themes)
    if game == "quiz" and not c.get("questions") and c.get("quiz_topic") not in (None, "mixed", "movies", "countries", "foods", "phrases"):
        from engine import ai  # topic outside the built-in bank: ask Gemini if possible
        if ai.has_key():
            try:
                c["questions"] = ai.quiz(c["quiz_topic"], c.get("quiz_count", 6))
                c.setdefault("title", f"GUESS THE {c['quiz_topic'].upper()}"[:40])
            except Exception as e:
                print(f"  (AI quiz failed, using built-in questions: {e})")
    if game == "whatif" and not isinstance(c.get("whatif"), dict) and c.get("quiz_topic"):
        idea = c["quiz_topic"]
        if idea in module.PRESETS:
            c["whatif_preset"] = idea
        else:
            from engine import ai
            if ai.has_key():
                try:
                    c["whatif"] = ai.whatif(idea)
                except Exception as e:
                    print(f"  (AI what-if failed, using a built-in one: {e})")
    if game == "barrace" and c.get("quiz_topic") and not c.get("dataset"):
        c["dataset"] = c["quiz_topic"]
    vibe = c.get("vibe") or ("playful" if cartoon else rng.choice(["dark", "phonk", "lofi", "hype"]))
    key = rng.choice([57, 60, 62, 64, 65, 67]) if vibe == "playful" else rng.choice([52, 53, 55, 57, 58])
    music = a.music or c.get("music", "on")
    snd = SoundTrack(key_midi=key, vibe=vibe, bpm=96, music=(music != "off"), seed=c["seed"],
                     music_file=music if music not in ("on", "off") else None)
    out = os.path.join(a.out, f"{game}_{c['seed']}.mp4")
    t0 = time.time()
    print(f"[{i + 1}/{total}] {game} seed {c['seed']} theme {c['theme']} vibe {vibe}", flush=True)
    info = module.render(c, out, snd)
    write_caption(game, c, out, a.ai_captions or c.get("ai_captions"))
    print(f"  -> {out}  ({info['duration']:.1f}s video, winner {info['winner']}, took {time.time() - t0:.0f}s)", flush=True)
    if _ai.video_spent():
        print(f"AICOST {_ai.video_spent():.5f}", flush=True)


def write_caption(game, c, out, use_ai):
    """Ready-to-paste upload text next to every video (Gemini if available, otherwise a template)."""
    from engine import ai
    names = [r.get("name", "") for r in c.get("racers", [])] if game not in ("quiz", "barrace", "whatif") else []
    title = c.get("title") or ""
    cap = None
    if use_ai and ai.has_key():
        try:
            cap = ai.caption(game, title, names)
        except Exception as e:
            print(f"  (AI caption skipped: {e})")
    if cap is None:
        cap = ai.template_caption(game, title, names, c["seed"])
    ai.write_caption_file(os.path.splitext(out)[0] + ".txt", cap)


if __name__ == "__main__":
    main()
