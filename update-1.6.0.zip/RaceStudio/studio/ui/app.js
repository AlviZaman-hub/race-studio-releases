// Race Studio page. State lives in `S`; every change saves (debounced) and refreshes the live preview.
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const h = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") e.className = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (v !== undefined && v !== null && v !== false) e.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat()) if (k !== null && k !== undefined) e.append(k.nodeType ? k : document.createTextNode(k));
  return e;
};
const api = async (path, body) => {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `Error ${r.status}`);
  return j;
};
const toast = (msg, bad = false, ms = 3500) => {
  const t = $("#toast"); t.textContent = msg; t.className = "toast" + (bad ? " bad" : ""); t.hidden = false;
  clearTimeout(toast._t); toast._t = setTimeout(() => (t.hidden = true), ms);
};
const q = encodeURIComponent;

let META = null;
let S = {
  game: "maze", look: "sleek", theme: "random", background: "random", title: "", handle: "",
  racers: [], vibe: "random", music: "on", music_file: "", tmin: 20, tmax: 35, count: 1, quality: "good",
  out: "", ai_caps: false, budget: 10, extra: {}, seed: 7, at: 3,
};
const G = () => META.games.find(g => g.code === S.game);

// ------------------------------------------------------------------ persistence + preview
let saveT, pvT, pvN = 0;
function changed(preview = true) {
  clearTimeout(saveT);
  saveT = setTimeout(() => api("/api/state", S).catch(() => {}), 400);
  if (preview) schedulePreview();
}
function schedulePreview(delay = 450) { clearTimeout(pvT); pvT = setTimeout(preview, delay); }
async function preview() {
  const my = ++pvN;
  $("#pvVideo").hidden = true; $("#pvVideo").pause(); $("#pvImg").hidden = false;
  $("#pvBusy").hidden = false; $("#pvErr").hidden = true;
  try {
    const r = await api("/api/preview", { state: S, at: S.at, seed: S.seed });
    if (my !== pvN || r.stale) return;
    await new Promise((ok) => { const im = $("#pvImg"); im.onload = ok; im.onerror = ok; im.src = r.url + "&v=" + my; });
  } catch (e) {
    if (my === pvN) { $("#pvErr").textContent = e.message; $("#pvErr").hidden = false; }
  } finally {
    if (my === pvN) $("#pvBusy").hidden = true;
  }
}

// ------------------------------------------------------------------ games list
function renderGames() {
  const box = $("#games"); box.innerHTML = "";
  for (const g of META.games) {
    box.append(h("div", { class: "gcard" + (g.code === S.game ? " sel" : ""), onclick: () => pickGame(g.code) },
      h("img", { src: `/api/thumb/game?game=${g.code}&look=sleek&at=4`, loading: "lazy" }),
      h("div", {}, h("b", {}, g.name), h("span", {}, g.blurb))));
  }
}
function pickGame(code) {
  if (S.game === code) return;
  S.game = code; S.theme = "random"; S.extra = {}; S.title = "";
  const g = G();
  if (g.min && S.racers.length < Math.max(g.min, 2)) S.racers = presetRacers("colors4");
  renderAll(); changed();
}

// ------------------------------------------------------------------ tiles
function tile(label, url, sel, onclick, icon) {
  const im = h("div", { class: "im" + (url ? " loading" : "") }, icon || "");
  if (url) { const i = new Image(); i.onload = () => { im.style.backgroundImage = `url("${url}")`; im.classList.remove("loading"); }; i.src = url; }
  return h("div", { class: "tile" + (sel ? " sel" : ""), onclick }, im, h("div", {}, label));
}
function renderLooks() {
  const box = $("#looks"); box.innerHTML = "";
  for (const [code, name] of META.looks) {
    box.append(tile(name, `/api/thumb/game?game=${S.game}&look=${code}&at=3`, S.look === code, () => { S.look = code; renderLooks(); renderThemes(); renderBgs(); changed(); }));
  }
}
function renderThemes() {
  const box = $("#themes"); box.innerHTML = "";
  box.append(tile("Random", null, S.theme === "random", () => { S.theme = "random"; renderThemes(); renderBgs(); changed(); }, "🎲"));
  for (const th of G().themes) {
    box.append(tile(th[0].toUpperCase() + th.slice(1), `/api/thumb/game?game=${S.game}&theme=${th}&look=${S.look}&at=3`,
      S.theme === th, () => { S.theme = th; renderThemes(); renderBgs(); changed(); }));
  }
}
function renderBgs() {
  const box = $("#bgs"); box.innerHTML = "";
  const th = S.theme === "random" ? (G().themes[0] || "") : S.theme;
  box.append(tile("Random", null, S.background === "random", () => { S.background = "random"; renderBgs(); changed(); }, "🎲"));
  for (const b of META.backgrounds) {
    box.append(tile(b.replace("_", " "), `/api/thumb/game?game=${S.game}&theme=${S.theme === "random" ? "" : S.theme}&look=${S.look}&background=${b}&at=3`,
      S.background === b, () => { S.background = b; renderBgs(); changed(); }));
  }
}

// ------------------------------------------------------------------ racers
function presetRacers(name) {
  return META.presets[name].map(r => ({ kind: r.emoji ? "emoji" : "color", name: r.name, color: r.color, emoji: r.emoji || "" }));
}
function emojiUrl(ch) {
  const cps = [...ch].map(c => c.codePointAt(0).toString(16));
  return "/emoji/" + cps.join("-") + ".png";
}
function renderRacers() {
  const g = G();
  $("#racersCard").hidden = !g.min;
  if (!g.min) return;
  $("#racerHint").textContent = `${g.min}–8 racers`;
  const chips = $("#presetChips"); chips.innerHTML = "";
  for (const p of Object.keys(META.presets)) chips.append(h("span", { class: "chip", onclick: () => { S.racers = presetRacers(p); renderRacers(); changed(); } }, p));
  const box = $("#racers"); box.innerHTML = "";
  S.racers.forEach((r, i) => {
    const kinds = h("div", { class: "kind" }, ...[["color", "Colour"], ["emoji", "Emoji"], ["image", "Image"]].map(([k, n]) =>
      h("button", { class: r.kind === k ? "sel" : "", onclick: () => { r.kind = k; renderRacers(); changed(); } }, n)));
    const color = h("input", { type: "color", value: r.color || "#ef3b3b", oninput: e => { r.color = e.target.value; changed(); } });
    const name = h("input", { class: "name", value: r.name || "", placeholder: "Name", oninput: e => { r.name = e.target.value; changed(); } });
    let pick = null;
    if (r.kind === "emoji") {
      pick = h("button", { class: "pick", title: "Pick emoji", onclick: () => openEmoji(ch => { r.emoji = ch.ch; if (!r.name || r.autoName) { r.name = ch.name; r.autoName = true; } renderRacers(); changed(); }) },
        r.emoji ? h("img", { src: emojiUrl(r.emoji) }) : "🙂");
    } else if (r.kind === "image") {
      const f = h("input", { type: "file", accept: "image/*", hidden: true, onchange: async e => {
        const file = e.target.files[0]; if (!file) return;
        try { const res = await upload(file, "racer"); r.image = res.path; renderRacers(); changed(); } catch (er) { toast(er.message, true); }
      } });
      pick = h("button", { class: "pick", title: r.image ? r.image : "Upload image", onclick: () => f.click() }, r.image ? "🖼" : "⬆", f);
      const shape = h("select", { onchange: e => { r.shape = e.target.value; changed(); } },
        ...["circle", "fit"].map(v => h("option", { value: v, selected: (r.shape || "circle") === v }, v)));
      pick = h("span", { class: "row gap" }, pick, shape);
    }
    const del = h("button", { class: "del", title: "Remove", onclick: () => { S.racers.splice(i, 1); renderRacers(); changed(); } }, "✕");
    box.append(h("div", { class: "racer" }, kinds, color, pick, name, del));
  });
  $("#addRacer").disabled = S.racers.length >= 8;
}
async function upload(file, kind) {
  const r = await fetch(`/api/upload?kind=${kind}`, { method: "POST", headers: { "X-Studio": "1", "X-Filename": encodeURIComponent(file.name) }, body: file });
  const j = await r.json(); if (!r.ok) throw new Error(j.error || "Upload failed"); return j;
}

// emoji picker
let emojiCb = null, emojiT;
function openEmoji(cb) { emojiCb = cb; $("#emojiModal").hidden = false; $("#emojiQ").value = ""; $("#emojiQ").focus(); loadEmoji("face"); }
async function loadEmoji(text) {
  const list = await api("/api/emoji?q=" + q(text));
  const g = $("#emojiGrid"); g.innerHTML = "";
  for (const e of list) g.append(h("button", { title: e.name, onclick: () => { $("#emojiModal").hidden = true; emojiCb && emojiCb(e); } }, h("img", { src: e.url, loading: "lazy" })));
}

// ------------------------------------------------------------------ per-game options
function sel(label, key, opts, def) {
  const cur = S.extra[key] ?? def;
  return h("label", {}, label, h("select", { onchange: e => { S.extra[key] = e.target.value; changed(); } },
    ...opts.map(([v, n]) => h("option", { value: v, selected: String(cur) === String(v) }, n))));
}
function num(label, key, def, min, max) {
  return h("label", {}, label, h("input", { type: "number", class: "num", min, max, value: S.extra[key] ?? def, onchange: e => { S.extra[key] = +e.target.value; changed(); } }));
}
function renderExtra() {
  const g = G(), box = $("#extra"); box.innerHTML = "";
  const grid = h("div", { class: "grid2" });
  const R = [["random", "Random"]];
  if (g.code === "territory") {
    grid.append(sel("Starting layout", "layout", R.concat(["voronoi", "blocks", "bands"].map(v => [v, v])), "random"),
      sel("Arena shape", "shape", R.concat(["square", "circle", "diamond", "plus"].map(v => [v, v])), "random"));
  } else if (g.code === "battle") {
    grid.append(sel("Weapons", "weapons", [["mixed", "Mixed"], ["sword", "Swords"], ["dagger", "Daggers"], ["spikes", "Spikes"]], "mixed"));
  } else if (g.code === "music") {
    grid.append(sel("Song", "song", R.concat(g.extra.songs.map(s => [s, s])), "random"));
  } else if (g.code === "quiz") {
    grid.append(sel("Topic", "quiz_topic", g.extra.topics.map(t => [t, t]).concat([["my questions", "My / AI questions"]]), "mixed"),
      num("Questions", "quiz_count", 6, 3, 10));
    const n = (S.extra.questions || []).length;
    box.append(grid, h("div", { class: "row gap" }, h("button", { class: "ghost", onclick: openQuiz }, `✏ Edit questions (${n})`),
      h("span", { class: "muted small" }, "✨ Idea writes questions with AI")));
    $("#extraCard").hidden = false; return;
  } else if (g.code === "barrace") {
    const ds = R.concat(g.extra.datasets.map(d => [d, d])).concat([["csv", "My CSV file…"]]);
    grid.append(sel("Data", "dataset", ds, "random"), num("Bars", "top", 10, 5, 12), num("From year", "from", 1980, 1960, 2030), num("To year", "to", 2023, 1960, 2030));
    box.append(grid);
    if (S.extra.dataset === "csv") {
      const f = h("input", { type: "file", accept: ".csv", hidden: true, onchange: async e => {
        try { const r = await upload(e.target.files[0], "csv"); S.extra.csv = r.path; renderExtra(); changed(); } catch (er) { toast(er.message, true); } } });
      box.append(h("div", { class: "row gap" }, h("button", { class: "ghost", onclick: () => f.click() }, "Upload CSV"), f,
        h("span", { class: "muted small" }, S.extra.csv ? S.extra.csv.split(/[\\/]/).pop() : "Columns: name, then one column per year (or name, year, value)")));
    }
    box.append(h("p", { class: "muted small" }, "Real numbers from World Bank Open Data, downloaded when you render (needs internet). The source is credited in the video."));
    $("#extraCard").hidden = false; return;
  } else if (g.code === "whatif") {
    const opts = R.concat(Object.entries(g.extra.presets)).concat([["ai", "✨ My own idea (AI)"]]);
    grid.append(sel("Scenario", "preset", opts, "random"));
    if (S.extra.preset === "ai") grid.append(h("label", { class: "wide" }, "Your idea",
      h("input", { value: S.extra.idea || "", placeholder: "what if gravity was 5x stronger", oninput: e => { S.extra.idea = e.target.value; changed(false); } })));
  }
  if (!grid.children.length) { $("#extraCard").hidden = true; return; }
  $("#extraCard").hidden = false; box.append(grid);
}
function openQuiz() {
  $("#quizText").value = (S.extra.questions || []).map(x => `${x.clue} | ${x.answer}`).join("\n");
  $("#quizModal").hidden = false;
}

// ------------------------------------------------------------------ sound / output
function renderSound() {
  const v = $("#vibes"); v.innerHTML = "";
  for (const x of META.vibes) v.append(h("span", { class: "chip" + (S.vibe === x ? " sel" : ""), onclick: () => { S.vibe = x; renderSound(); changed(false); } }, x));
  const m = $("#musicChips"); m.innerHTML = "";
  for (const [k, n] of [["on", "Built-in"], ["off", "No music"], ["file", "My own WAV…"]])
    m.append(h("span", { class: "chip" + (S.music === k ? " sel" : ""), onclick: () => { if (k === "file") $("#musicFile").click(); else { S.music = k; renderSound(); changed(false); } } }, n));
  $("#musicName").textContent = S.music === "file" && S.music_file ? S.music_file.split(/[\\/]/).pop() : "";
}
function bindInputs() {
  const bind = (id, key, pv = true, conv = x => x) => { const e = $("#" + id); e.value = S[key]; e.oninput = () => { S[key] = conv(e.value); changed(pv); }; };
  bind("title", "title"); bind("handle", "handle");
  bind("tmin", "tmin", false, Number); bind("tmax", "tmax", false, Number);
  bind("count", "count", false, Number); bind("out", "out", false);
  $("#quality").value = S.quality; $("#quality").onchange = e => { S.quality = e.target.value; changed(false); };
  $("#aiCaps").checked = !!S.ai_caps; $("#aiCaps").onchange = e => { S.ai_caps = e.target.checked; changed(false); };
  $("#at").value = S.at; $("#atVal").textContent = S.at + "s";
  $("#at").oninput = e => { S.at = +e.target.value; $("#atVal").textContent = S.at + "s"; changed(); };
  $("#budget").value = S.budget; $("#budget").onchange = e => { S.budget = Math.max(1, +e.target.value || 10); changed(false); };
}
function updateMakeLabel() { $("#makeBtn").textContent = S.count > 1 ? `Make ${S.count} videos` : "Make video"; }

function renderAll() {
  renderGames(); renderLooks(); renderThemes(); renderBgs(); renderRacers(); renderExtra(); renderSound(); bindInputs();
  $("#gameBlurb").textContent = G().blurb;
  $("#title").placeholder = G().title || "Leave empty for the game's default";
  updateMakeLabel();
}

// ------------------------------------------------------------------ jobs
let lastJobs = "";
async function pollJobs() {
  try {
    const r = await api("/api/jobs");
    const sig = JSON.stringify(r.jobs);
    if (sig !== lastJobs) { lastJobs = sig; renderJobs(r.jobs); }
  } catch (e) {}
  setTimeout(pollJobs, 1000);
}
const shown = new Set();
function renderJobs(jobs) {
  const box = $("#jobs"); box.innerHTML = "";
  for (const j of jobs) {
    if (j.kind === "clip") {
      if (j.status === "done" && !shown.has(j.id)) { shown.add(j.id); playClip(j.outputs[0]); }
      if (j.status === "failed" && !shown.has(j.id)) { shown.add(j.id); $("#pvBusy").hidden = true; toast("Preview failed: " + (j.error || ""), true); }
      continue;
    }
    const frac = j.total ? (j.done + (j.status === "running" ? j.frac : 0)) / j.total : 0;
    const st = { queued: "Waiting…", running: `Video ${Math.min(j.done + 1, j.total)} of ${j.total} · ${Math.round(j.frac * 100)}%`,
      done: `Done · ${j.outputs.length} video${j.outputs.length === 1 ? "" : "s"}`, failed: "Failed", cancelled: "Stopped" }[j.status];
    const outs = h("div", { class: "outs" }, ...j.outputs.slice(-8).map((o, i) =>
      h("button", { onclick: () => playClip(o) }, "▶ " + o.split(/[\\/]/).pop().replace(".mp4", ""))));
    if (j.outputs.length) outs.append(h("button", { onclick: () => api("/api/open", { path: j.outputs[0], folder: true }) }, "📂 Folder"));
    box.append(h("div", { class: "job " + j.status },
      h("div", { class: "row" }, h("b", { class: "grow" }, j.label),
        ["queued", "running"].includes(j.status) ? h("button", { class: "ghost tiny", onclick: () => api(`/api/jobs/${j.id}/cancel`, {}) }, "Stop") : null),
      h("div", { class: "bar" }, h("i", { style: `width:${Math.round((j.status === "done" ? 1 : frac) * 100)}%` })),
      h("div", { class: "muted small" }, st + (j.cost ? ` · AI ${(j.cost * 100).toFixed(2)}¢` : "")),
      j.error ? h("div", { class: "err small" }, j.error) : null, outs));
  }
}
function playClip(path) {
  const v = $("#pvVideo");
  $("#pvImg").hidden = true; $("#pvBusy").hidden = true; v.hidden = false;
  v.src = "/file?p=" + q(path); v.play().catch(() => {});
}

// ------------------------------------------------------------------ AI
async function refreshAI() {
  try {
    const r = await api("/api/ai/status");
    const p = $("#aiPill");
    p.className = "pill" + (r.has_key ? " on" : "");
    p.textContent = r.has_key ? `AI ✓ · today ${(r.today * 100).toFixed(1)}¢` : "AI off · add key";
    $("#usageText").textContent = `Spent so far: today ${(r.today * 100).toFixed(2)}¢, all time $${r.total.toFixed(3)} (estimated from Gemini's token counts).`;
    return r.has_key;
  } catch (e) { return false; }
}
async function needKey() {
  if (await refreshAI()) return true;
  toast("Add your free Gemini key first (Settings).", true); $("#settingsModal").hidden = false; return false;
}
async function doIdea(btn) {
  if (!(await needKey())) return;
  const old = btn.textContent; btn.disabled = true; btn.textContent = "✨ Thinking…";
  try {
    const n = Math.max(G().min >= 2 ? 2 : 1, S.racers.length || 4);
    const r = await api("/api/ai/idea", { game: S.game, theme: $("#ideaTheme").value, n });
    if (r.title !== undefined) S.title = r.title;
    if (r.racers) S.racers = r.racers.map(x => ({ kind: x.emoji ? "emoji" : "color", name: x.name, color: x.color, emoji: x.emoji || "" }));
    if (r.extra) S.extra = Object.assign({}, S.extra, r.extra);
    S.seed = Math.floor(Math.random() * 1e6);
    renderAll(); changed(); toast("New idea ✨"); refreshAI();
  } catch (e) { toast(e.message, true); }
  finally { btn.disabled = false; btn.textContent = old; }
}

// ------------------------------------------------------------------ plan
let PLAN = [];
function renderPlanGames() {
  const box = $("#planGames"); box.innerHTML = "";
  S.planGames = S.planGames || META.games.map(g => g.code);
  for (const g of META.games) box.append(h("span", { class: "chip" + (S.planGames.includes(g.code) ? " sel" : ""), onclick: () => {
    S.planGames = S.planGames.includes(g.code) ? S.planGames.filter(x => x !== g.code) : S.planGames.concat(g.code); renderPlanGames(); changed(false); } }, g.name));
}
function renderPlan() {
  const box = $("#planList"); box.innerHTML = "";
  PLAN.forEach(p => {
    const name = (META.games.find(g => g.code === p.game) || {}).name || p.game;
    const who = p.quiz_topic || p.idea || p.dataset || (p.racers || []).map(r => r.emoji || r.name).join(" ");
    box.append(h("div", { class: "plan-item" }, h("input", { type: "checkbox", checked: p.on !== false, onchange: e => (p.on = e.target.checked) }),
      h("div", { class: "grow" }, h("b", {}, p.title), h("div", { class: "muted small" }, `${name} · ${who}`))));
  });
  $("#planRun").disabled = !PLAN.length;
}

// ------------------------------------------------------------------ wire up
async function init() {
  META = await api("/api/meta");
  const saved = await api("/api/state");
  S = Object.assign(S, saved);
  if (!META.games.find(g => g.code === S.game)) S.game = META.games[0].code;
  if (!S.racers.length) S.racers = presetRacers("colors4");
  $("#ver").textContent = "v" + META.version;
  renderAll(); preview(); pollJobs(); refreshAI();

  $("#addRacer").onclick = () => { const p = META.palette; S.racers.push({ kind: "color", name: "Racer " + (S.racers.length + 1), color: p[S.racers.length % p.length] }); renderRacers(); changed(); };
  $("#ideaBtn").onclick = e => doIdea(e.currentTarget);
  $("#surprise").onclick = e => { const gs = META.games; pickGame(gs[Math.floor(Math.random() * gs.length)].code); $("#ideaTheme").value = ""; doIdea($("#ideaBtn")); };
  $("#reroll").onclick = () => { S.seed = Math.floor(Math.random() * 1e6); changed(); };
  $("#makeBtn").onclick = async () => {
    try { await api("/api/render", { state: S }); toast(`Started ${S.count} video${S.count > 1 ? "s" : ""} 🎬`); }
    catch (e) { toast(e.message, true); }
  };
  $("#count").addEventListener("input", updateMakeLabel);
  $("#clipBtn").onclick = async () => {
    try { $("#pvBusy").hidden = false; await api("/api/clip", { state: S }); toast("Making a 6-second preview…", false, 2500); }
    catch (e) { $("#pvBusy").hidden = true; toast(e.message, true); }
  };
  $("#openOut").onclick = () => api("/api/open", { state: S }).catch(e => toast(e.message, true));
  $("#musicFile").onchange = async e => {
    try { const r = await upload(e.target.files[0], "music"); S.music = "file"; S.music_file = r.path; renderSound(); changed(false); }
    catch (er) { toast(er.message, true); }
  };
  // modals
  $$(".modal").forEach(m => { m.addEventListener("click", e => { if (e.target === m || e.target.classList.contains("close")) m.hidden = true; }); });
  $("#emojiQ").oninput = e => { clearTimeout(emojiT); emojiT = setTimeout(() => loadEmoji(e.target.value), 200); };
  $("#settingsBtn").onclick = () => { $("#settingsModal").hidden = false; refreshAI(); };
  $("#aiPill").onclick = () => { $("#settingsModal").hidden = false; refreshAI(); };
  $("#keySave").onclick = async () => {
    try { await api("/api/ai/key", { key: $("#keyInput").value }); $("#keyInput").value = ""; await refreshAI(); toast("Key saved ✓"); }
    catch (e) { toast(e.message, true); }
  };
  $("#fromComments").onclick = async () => { if (await needKey()) $("#commentsModal").hidden = false; };
  $("#commentsGo").onclick = async () => {
    try {
      const r = await api("/api/ai/comments", { text: $("#commentsText").value, n: +$("#commentsN").value });
      S.racers = r.names.map((n, i) => ({ kind: "color", name: n, color: META.palette[i % META.palette.length] }));
      $("#commentsModal").hidden = true; renderRacers(); changed();
    } catch (e) { toast(e.message, true); }
  };
  $("#quizSave").onclick = () => {
    S.extra.questions = $("#quizText").value.split("\n").map(l => l.split("|")).filter(p => p.length >= 2 && p[0].trim() && p[1].trim())
      .map(p => ({ clue: p[0].trim(), answer: p[1].trim() }));
    S.extra.quiz_topic = "my questions"; $("#quizModal").hidden = true; renderExtra(); changed();
  };
  $("#planBtn").onclick = async () => { if (await needKey()) { renderPlanGames(); renderPlan(); $("#planModal").hidden = false; } };
  $("#planGo").onclick = async e => {
    const b = e.currentTarget; b.disabled = true; b.textContent = "✨ Planning…";
    try { PLAN = (await api("/api/ai/plan", { n: +$("#planN").value, games: S.planGames })).jobs; renderPlan(); refreshAI(); }
    catch (er) { toast(er.message, true); }
    finally { b.disabled = false; b.textContent = "✨ Plan"; }
  };
  $("#planRun").onclick = async () => {
    const jobs = PLAN.filter(p => p.on !== false);
    try { await api("/api/plan/run", { state: S, jobs }); $("#planModal").hidden = true; toast(`Making ${jobs.length} videos 🎬`); }
    catch (e) { toast(e.message, true); }
  };
  $("#updBtn").onclick = async () => {
    const b = $("#updBtn"); b.disabled = true; b.textContent = "Checking…";
    try {
      const r = await api("/api/update/check");
      if (r.error) toast("Couldn't check for updates: " + r.error, true);
      else if (!r.available) toast(`You're on the latest version (${r.current}).`);
      else if (confirm(`Race Studio ${r.info.version} is ready.\n\n${r.info.notes || ""}\n\nUpdate now?`)) {
        b.textContent = "Updating…";
        await api("/api/update/apply", {});
        toast("Updated! Reloading…", false, 6000);
        setTimeout(function wait() { fetch("/api/meta").then(() => location.reload()).catch(() => setTimeout(wait, 700)); }, 2500);
        return;
      }
    } catch (e) { toast(e.message, true); }
    b.disabled = false; b.textContent = "Check for updates";
  };
  // quiet automatic check on open
  api("/api/update/check").then(r => { if (r.available) { $("#updBtn").textContent = `⬆ Update to ${r.info.version}`; $("#updBtn").classList.add("primary"); } }).catch(() => {});
}
init().catch(e => toast("Couldn't start: " + e.message, true, 10000));
