@echo off
title Race Studio
cd /d "%~dp0"
echo ===== Race Studio launcher ===== > launcher_log.txt
echo [1/3] Looking for Python...
set "PY="
py -3 -c "import sys" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys" >nul 2>nul && set "PY=python"
if not defined PY goto nopython
echo Using: %PY% >> launcher_log.txt
%PY% --version >> launcher_log.txt 2>&1
%PY% -c "import sys; print(sys.executable)" >> launcher_log.txt 2>&1
%PY% -c "import tkinter" >> launcher_log.txt 2>&1
if errorlevel 1 (
  echo.
  echo Your Python is missing Tkinter ^(the window toolkit^).
  echo Reinstall Python from python.org and keep "tcl/tk and IDLE" ticked.
  pause
  exit /b
)
echo [2/3] Installing libraries ^(first run can take a few minutes, please wait^)...
%PY% -m pip install --disable-pip-version-check -r requirements.txt >> launcher_log.txt 2>&1
if errorlevel 1 (
  echo.
  echo Library install failed. Details are in launcher_log.txt
  pause
  exit /b
)
echo [3/3] Opening Race Studio... ^(keep this black window open while you use it^)
%PY% gui.py >> launcher_log.txt 2>&1
if errorlevel 1 (
  echo.
  echo Race Studio closed with an error. Details are in launcher_log.txt
  pause
)
exit /b

:nopython
echo Python was not found. >> launcher_log.txt
echo Python is not installed ^(or only the Microsoft Store shortcut is^).
echo Installing Python 3.12 with winget...
winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
echo.
echo Done. Close this window and double-click "Start Race Studio" again.
pause
