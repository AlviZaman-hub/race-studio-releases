"""Series: a running league across many videos (Country World Cup, Zodiac League, your own
racers). Each episode is a different game with racers from the series; wins are counted and
the league table is shown at the start of the next episode."""
import json
import os
import random
import time

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILE = os.path.join(HERE, "config", "_series.json")
GAMES = ["course", "track", "maze", "kart", "ladders", "plinko", "battle", "shrink", "blobs", "bracket",
         "multiply", "marbles", "sand"]
MAXR = {"rpg": 4, "multiply": 6}

ZODIAC = [("Aries", "♈", "#e5484d"), ("Taurus", "♉", "#46a758"), ("Gemini", "♊", "#ffc53d"), ("Cancer", "♋", "#8ec8f6"),
          ("Leo", "♌", "#f76b15"), ("Virgo", "♍", "#a18072"), ("Libra", "♎", "#f3a6c8"), ("Scorpio", "♏", "#8e4ec6"),
          ("Sagittarius", "♐", "#3e63dd"), ("Capricorn", "♑", "#6b7280"), ("Aquarius", "♒", "#12a594"), ("Pisces", "♓", "#7ce2fe")]
COUNTRIES = [("USA", "🇺🇸", "#3c5bd6"), ("Brazil", "🇧🇷", "#1fa84a"), ("Japan", "🇯🇵", "#e8e8e8"), ("India", "🇮🇳", "#ff9a2e"),
             ("Germany", "🇩🇪", "#ffcc00"), ("Canada", "🇨🇦", "#e3262b"), ("Mexico", "🇲🇽", "#0b8a4a"), ("Bangladesh", "🇧🇩", "#006a4e"),
             ("Pakistan", "🇵🇰", "#01411c"), ("Nigeria", "🇳🇬", "#008751"), ("Egypt", "🇪🇬", "#ce1126"), ("Turkey", "🇹🇷", "#e30a17"),
             ("Argentina", "🇦🇷", "#74acdf"), ("Portugal", "🇵🇹", "#006600"), ("Spain", "🇪🇸", "#f1bf00"), ("Italy", "🇮🇹", "#009246"),
             ("South Korea", "🇰🇷", "#cd2e3a"), ("Saudi Arabia", "🇸🇦", "#006c35")]


def load():
    try:
        with open(FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def save(items):
    os.makedirs(os.path.dirname(FILE), exist_ok=True)
    with open(FILE, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=1)


def create(kind, racers=None, name=None):
    if kind == "zodiac":
        pool, name = [{"name": n, "emoji": e, "color": c} for n, e, c in ZODIAC], name or "ZODIAC LEAGUE"
    elif kind == "worldcup":
        pool, name = [{"name": n, "emoji": e, "color": c} for n, e, c in COUNTRIES], name or "COUNTRY WORLD CUP"
    else:
        pool = [r for r in (racers or []) if r.get("name")]
        if len(pool) < 2:
            raise ValueError("Add at least 2 racers first, then start the series.")
        name = (name or "MY LEAGUE").upper()
    items = load()
    s = {"id": int(time.time() * 1000), "kind": kind, "name": name, "pool": pool, "wins": {}, "played": {},
         "episode": 0, "games": []}
    items.insert(0, s)
    save(items)
    return s


def table(s, top=5):
    rows = sorted(s["pool"], key=lambda r: (-s["wins"].get(r["name"], 0), s["played"].get(r["name"], 0), r["name"]))
    return [(r["name"], s["wins"].get(r["name"], 0)) for r in rows[:top]]


def next_episode(sid):
    """Pick the game and racers for the next episode. Returns (series, game, racers, title)."""
    items = load()
    s = next((x for x in items if x["id"] == sid), None)
    if s is None:
        raise ValueError("That series doesn't exist any more.")
    rng = random.Random(s["id"] + s["episode"] * 7919)
    recent = s["games"][-4:]
    game = rng.choice([g for g in GAMES if g not in recent] or GAMES)
    n = min(len(s["pool"]), MAXR.get(game, 8), rng.choice([4, 6, 8]))
    # people who have played least go first; the leader always plays (everyone wants to see them lose)
    pool = sorted(s["pool"], key=lambda r: (s["played"].get(r["name"], 0), rng.random()))
    pick = pool[:n]
    lead = table(s, 1)
    if lead and lead[0][1] > 0 and lead[0][0] not in [r["name"] for r in pick]:
        pick[-1] = next(r for r in s["pool"] if r["name"] == lead[0][0])
    title = f"{s['name']} · EPISODE {s['episode'] + 1}"
    return s, game, pick, title


def record(sid, game, racers, winner):
    items = load()
    s = next((x for x in items if x["id"] == sid), None)
    if s is None:
        return
    s["episode"] += 1
    s["games"].append(game)
    for r in racers:
        s["played"][r["name"]] = s["played"].get(r["name"], 0) + 1
    if winner:
        for r in s["pool"]:
            if r["name"].lower() == str(winner).lower():
                s["wins"][r["name"]] = s["wins"].get(r["name"], 0) + 1
    save(items)


def delete(sid):
    save([x for x in load() if x["id"] != sid])
