"""Race Studio web app: a small local server (127.0.0.1 only) + the page in studio/ui.

Everything runs on this computer. The page talks to these JSON endpoints; renders run
make.py in a subprocess exactly like the old window did; previews run in a long-lived
worker process so they come back in about a second.
"""
import hashlib
import importlib
import json
import mimetypes
import os
import queue
import random
import re
import subprocess
import sys
import threading
import time
import traceback
import unicodedata
import urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
UI = os.path.join(HERE, "studio", "ui")
CACHE = os.path.join(HERE, "config", "_cache")
STATE = os.path.join(HERE, "config", "_studio.json")
EMOJI_DIR = os.path.join(HERE, "assets", "emoji")
UPLOADS = {"racer": os.path.join(HERE, "assets", "racers"), "music": os.path.join(HERE, "assets", "sounds"),
           "csv": os.path.join(HERE, "config", "_uploads")}
NOFLAGS = 0x08000000 if os.name == "nt" else 0

from make import PRESETS, GAMES  # noqa: E402
from engine import ai  # noqa: E402
from engine.backgrounds import STYLES  # noqa: E402
from studio import thumbs as TH  # noqa: E402
import updater  # noqa: E402

PY = sys.executable.replace("pythonw", "python")

# ----------------------------------------------------------------------------- games
GAME_INFO = [
    # code, name, min racers (0 = no racers), default title, blurb
    ("maze", "Maze Race", 2, "WHO REACHES THE FLAG FIRST?", "Racers bounce through a maze and smash numbered blocks. First to the flag wins."),
    ("track", "Marble Track", 2, "WHO WINS THE MARBLE RACE?", "Marbles race down a long track with gates, spinners and bumpers."),
    ("battle", "Ball Battle", 2, "LAST BALL STANDING WINS", "Balls fight with swords, daggers and spikes. Last one alive wins."),
    ("shrink", "Shrinking Arena", 2, "LAST ONE INSIDE WINS", "A spinning arena shrinks. Fall out through the gap and you're out."),
    ("rings", "Ring Escape", 1, "WHO BREAKS THE MOST RINGS?", "Balls break out of spinning rings. 1 racer = 'can it escape?'"),
    ("marbles", "Marble Elimination", 2, "LAST ONE DOWN IS OUT!", "A new peg board every round; last marble down is eliminated."),
    ("territory", "Territory War", 2, "WHICH COLOUR TAKES OVER?", "Balls flip enemy tiles. Biggest territory wins."),
    ("chain", "Chain Reaction", 1, "WHO BREAKS THE MOST BLOCKS?", "Balls smash a wall of bricks. Most bricks broken wins."),
    ("music", "Music Bounce", 1, "", "Every bounce plays the next note of a classical melody."),
    ("quiz", "Emoji Quiz", 0, "", "Emoji clues, a ticking timer, then the answer."),
    ("barrace", "Bar Chart Race", 0, "", "Animated country ranking from real World Bank data or your CSV."),
    ("whatif", "What If…?", 0, "", "Normal world vs a changed rule, side by side."),
    ("kart", "Retro Kart", 2, "WHO WINS THE KART RACE?", "Top-down kart race with boosts and oil slicks. Try a retro look."),
    ("rpg", "Pixel RPG Battle", 2, "WHO WINS THIS BATTLE?", "Turn-based monster fight with named attacks and crits (2-4 racers). Try a retro look."),
    ("bracket", "Tournament", 2, "WHO WINS THE TOURNAMENT?", "Knockout 1v1 battles until one champion is left (up to 8)."),
    ("plinko", "Plinko", 1, "WHO GETS THE MOST POINTS?", "Each round everyone drops through the pegs into prize slots."),
    ("multiply", "+1 Ball", 2, "", "Every wall bounce spawns a new ball. First team to the target wins."),
    ("blobs", "Eat & Grow", 2, "EAT OR GET EATEN", "Blobs eat food and each other. Last blob standing wins."),
    ("sand", "Sand Fill", 2, "WHO FILLS THE JAR MOST?", "Everyone pours coloured sand into one jar. Most sand wins."),
]
MAX_RACERS = {"rpg": 4, "multiply": 6}
LOOKS = [("sleek", "Sleek"), ("cartoon", "Cartoon"), ("gameboy", "Game Boy"), ("8bit", "8-bit"), ("16bit", "16-bit")]
VIBES = ["random", "dark", "phonk", "lofi", "hype", "playful", "chiptune", "rpg"]


def _game_modules():
    out = {}
    for code, *_ in GAME_INFO:
        try:
            out[code] = importlib.import_module(f"games.{code}")
        except Exception:
            traceback.print_exc()
    return out


MODS = _game_modules()


def version():
    return updater.current_version()


def meta():
    games = []
    for code, name, mn, title, blurb in GAME_INFO:
        if code not in MODS:
            continue
        m = MODS[code]
        extra = {}
        if code == "quiz":
            extra["categories"] = {k: v[0].title() for k, v in m.CATEGORIES.items()}
            extra["builtin"] = [k for k in m.BANK if k != "mixed"]
        if code == "barrace":
            extra["datasets"] = list(m.DATASETS)
        if code == "whatif":
            extra["presets"] = {k: v[1].title() for k, v in m.PRESETS.items()}
        if code == "music":
            from engine.melodies import MELODIES
            extra["songs"] = list(MELODIES)
        games.append({"code": code, "name": name, "min": mn, "max": MAX_RACERS.get(code, 8), "title": title, "blurb": blurb,
                      "themes": list(getattr(m, "THEMES", {})), "extra": extra})
    return {"version": version(), "games": games, "backgrounds": STYLES, "looks": LOOKS, "vibes": VIBES,
            "presets": PRESETS, "palette": ai.PALETTE}


# ----------------------------------------------------------------------------- state -> render config
def state_to_cfg(st, for_preview=False):
    """The page's state -> (game, cfg dict, extra make.py args). Raises ValueError with a friendly message."""
    code = st.get("game", "maze")
    info = next((g for g in GAME_INFO if g[0] == code), None)
    if info is None or code not in MODS:
        raise ValueError("Pick a game first.")
    mn = info[2]
    racers = []
    for r in st.get("racers", []):
        s = {"name": (r.get("name") or "Racer").strip()[:24], "color": r.get("color") or "#ef3b3b"}
        if r.get("kind") == "emoji" and r.get("emoji"):
            s["emoji"] = r["emoji"]
        elif r.get("kind") == "image" and r.get("image") and os.path.exists(r["image"]):
            s["image"] = r["image"]
            s["shape"] = r.get("shape", "circle")
        racers.append(s)
    mx = MAX_RACERS.get(code, 8)
    if mn and not for_preview and not (mn <= len(racers) <= mx):
        raise ValueError(f"Use {mn} to {mx} racers for this game.")
    racers = racers[:mx]
    if mn and not racers:
        racers = PRESETS["colors4"]
    tmin, tmax = int(st.get("tmin", 20)), int(st.get("tmax", 35))
    if tmax < tmin + 6:
        tmax = tmin + 6
    cfg = {"title": (st.get("title") or "").strip().upper(), "handle": st.get("handle", ""),
           "racers": racers or PRESETS["colors4"], "race_seconds": [tmin, tmax]}
    for k in ("theme", "background", "vibe"):
        if st.get(k) and st[k] != "random":
            cfg[k] = st[k]
    if st.get("look") == "cartoon":
        cfg["style"] = "cartoon"
    elif st.get("look") in ("gameboy", "8bit", "16bit"):
        cfg["style"], cfg["retro"] = "cartoon", st["look"]
    cfg["end_card"] = st.get("end_card", True) is not False
    com = st.get("commentary", "ai")
    cfg["commentary"] = com != "off"
    cfg["commentary_ai"] = com == "ai"
    if st.get("background", "").startswith("image:") and not os.path.exists(st["background"][6:]):
        cfg.pop("background", None)
    if st.get("seed"):
        cfg["seed"] = int(st["seed"])
    ex = st.get("extra", {})
    if code == "territory":
        for k in ("layout", "shape"):
            if ex.get(k, "random") != "random":
                cfg[k] = ex[k]
    if code == "battle" and ex.get("weapons", "mixed") != "mixed":
        cfg["weapons"] = [ex["weapons"]] * 8
    if code == "music" and ex.get("song", "random") != "random":
        cfg["song"] = ex["song"]
    if code == "quiz":
        cfg["quiz_count"] = int(ex.get("quiz_count", 6))
        qs = [q for q in ex.get("questions", []) if q.get("clue") and q.get("answer")]
        if ex.get("quiz_topic") == "my questions":
            if not qs and not for_preview:
                raise ValueError("Add some questions first (or let AI write them).")
            if qs:
                cfg["questions"] = qs[: cfg["quiz_count"]]
                if ex.get("category"):
                    cfg["quiz_topic"] = ex["category"]
        else:
            topic = ex.get("quiz_topic", "countries")
            if topic == "custom":
                topic = (ex.get("custom") or "").strip().lower()
                if not topic and not for_preview:
                    raise ValueError("Type your quiz category first (e.g. 'football clubs').")
                topic = topic or "countries"
            if topic not in MODS["quiz"].BANK and not ai.has_key() and not for_preview:
                raise ValueError("That category needs the AI key. Without it, pick Movies, Countries, Foods or Phrases.")
            cfg["quiz_topic"] = topic if (topic in MODS["quiz"].BANK or not for_preview) else "countries"
    if code == "barrace":
        if ex.get("dataset") == "csv":
            if not ex.get("csv") or not os.path.exists(ex["csv"]):
                raise ValueError("Upload your CSV first.")
            cfg["csv"] = ex["csv"]
        elif ex.get("dataset", "random") != "random":
            cfg["dataset"] = ex["dataset"]
        a, b = sorted((int(ex.get("from", 1980)), int(ex.get("to", 2023))))
        cfg["years"] = [a, b]
        cfg["top_n"] = int(ex.get("top", 10))
    if code == "whatif":
        if isinstance(ex.get("whatif"), dict):
            cfg["whatif"] = ex["whatif"]
        elif ex.get("preset", "random") not in ("random", "ai"):
            cfg["whatif_preset"] = ex["preset"]
        elif ex.get("preset") == "ai" and (ex.get("idea") or "").strip():
            if for_preview:
                pass
            elif not ai.has_key():
                raise ValueError("Your own what-if idea needs the AI key. Or pick a built-in scenario.")
            else:
                cfg["quiz_topic"] = ex["idea"].strip()
    args = []
    music = st.get("music", "on")
    if music == "off":
        args += ["--music", "off"]
    elif music == "file" and st.get("music_file") and os.path.exists(st["music_file"]):
        args += ["--music", st["music_file"]]
    if st.get("ai_caps") and ai.has_key():
        args += ["--ai-captions"]
    if st.get("budget"):
        args += ["--ai-budget", str(float(st["budget"]))]
    return code, cfg, args


# ----------------------------------------------------------------------------- preview worker
class Worker:
    def __init__(self):
        self.lock = threading.Lock()
        self.proc = None
        self.results = {}
        self.cv = threading.Condition()
        self.n = 0

    def _start(self):
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        self.proc = subprocess.Popen([PY, "-u", "-m", "studio.worker"], cwd=HERE, stdin=subprocess.PIPE,
                                     stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
                                     encoding="utf-8", errors="replace", env=env, creationflags=NOFLAGS)
        threading.Thread(target=self._read, args=(self.proc,), daemon=True).start()

    def _read(self, proc):
        for line in proc.stdout:
            if line.startswith("@@RESULT "):
                r = json.loads(line[9:])
                with self.cv:
                    self.results[r["id"]] = r
                    self.cv.notify_all()
        with self.cv:
            self.cv.notify_all()

    def call(self, job, timeout=120):
        with self.lock:
            if self.proc is None or self.proc.poll() is not None:
                self._start()
            self.n += 1
            job["id"] = self.n
            self.proc.stdin.write(json.dumps(job) + "\n")
            self.proc.stdin.flush()
            t0 = time.time()
            with self.cv:
                while job["id"] not in self.results:
                    if self.proc.poll() is not None or time.time() - t0 > timeout:
                        try:
                            self.proc.kill()
                        except Exception:
                            pass
                        self.proc = None
                        return {"ok": False, "error": "Preview crashed. Try again."}
                    self.cv.wait(0.5)
                return self.results.pop(job["id"])


WORKER = Worker()                       # live preview: never waits behind thumbnails
THUMBS = [Worker(), Worker()]           # thumbnails, two at a time
_th_n = [0]


def thumb_call(job):
    _th_n[0] += 1
    return THUMBS[_th_n[0] % len(THUMBS)].call(job)


_preview_token = {"n": 0}


def _key(*parts):
    return hashlib.sha1(json.dumps(parts, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]


def cached_thumb(fname, job):
    """Draw a tile once on this computer and keep it (survives updates unless that game changed)."""
    os.makedirs(CACHE, exist_ok=True)
    out = os.path.join(CACHE, "t_" + hashlib.sha1(fname.encode()).hexdigest()[:20] + ".png")
    if os.path.exists(out):
        return {"ok": True, "out": out}
    return thumb_call(dict(job, out=out))


# ----------------------------------------------------------------------------- jobs (renders + clips)
class Jobs:
    def __init__(self):
        self.items = []
        self.q = queue.Queue()
        self.lock = threading.Lock()
        self.current = None
        threading.Thread(target=self._loop, daemon=True).start()

    def add(self, kind, cmd, total, label, cfg_path=None):
        j = {"id": len(self.items) + 1, "kind": kind, "label": label, "cmd": cmd, "total": total, "done": 0,
             "frac": 0.0, "status": "queued", "log": [], "outputs": [], "cost": 0.0, "created": time.time()}
        with self.lock:
            self.items.append(j)
        self.q.put(j)
        return j

    def public(self):
        with self.lock:
            return [{k: v for k, v in j.items() if k != "cmd"} | {"log": j["log"][-12:]} for j in self.items[-30:]][::-1]

    def cancel(self, jid):
        for j in self.items:
            if j["id"] == jid:
                if j["status"] == "queued":
                    j["status"] = "cancelled"
                elif j["status"] == "running" and self.current is not None:
                    j["status"] = "cancelled"
                    try:
                        self.current.kill()
                    except Exception:
                        pass

    def busy(self):
        return any(j["status"] in ("queued", "running") for j in self.items)

    def _loop(self):
        while True:
            j = self.q.get()
            if j["status"] == "cancelled":
                continue
            j["status"] = "running"
            env = dict(os.environ, PYTHONIOENCODING="utf-8")
            try:
                p = subprocess.Popen(j["cmd"], cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                     encoding="utf-8", errors="replace", env=env, creationflags=NOFLAGS)
            except Exception as e:
                j["status"], j["error"] = "failed", str(e)
                continue
            self.current = p
            for line in p.stdout:
                line = line.rstrip()
                m = re.match(r"PROGRESS (\d+) (\d+)", line)
                if m:
                    j["frac"] = min(1.0, int(m.group(1)) / max(1, int(m.group(2))))
                    continue
                m = re.match(r"DRAMA ([\d.]+)", line)
                if m:
                    j.setdefault("drama", []).append(float(m.group(1)))
                    continue
                m = re.match(r"AICOST ([\d.]+)", line)
                if m:
                    j["cost"] += float(m.group(1))
                    continue
                m = re.search(r"-> (.+\.mp4)", line)
                if m:
                    path = m.group(1).split("  (")[0].strip()
                    j["outputs"].append(os.path.abspath(os.path.join(HERE, path)))
                    j["done"] += 1
                    j["frac"] = 0.0
                if "ALSA" in line or "pygame" in line.lower() and "hello" in line.lower():
                    continue
                j["log"].append(line)
            p.wait()
            self.current = None
            if j["status"] != "cancelled":
                j["status"] = "done" if p.returncode == 0 and j["outputs"] else "failed"
                if j["status"] == "failed" and not j.get("error"):
                    errs = [ln for ln in j["log"] if "Error" in ln or "error" in ln or "!!" in ln]
                    j["error"] = (errs[-1] if errs else (j["log"][-1] if j["log"] else "Render failed"))[:300]


JOBS = Jobs()


def out_dir(st):
    d = (st.get("out") or "").strip() or os.path.join(HERE, "output")
    return os.path.abspath(os.path.expanduser(d))


def start_render(st, count=None):
    code, cfg, args = state_to_cfg(st)
    os.makedirs(os.path.join(HERE, "config"), exist_ok=True)
    path = os.path.join(HERE, "config", f"_run_{int(time.time() * 1000)}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False)
    n = int(count or st.get("count", 1))
    od = out_dir(st)
    os.makedirs(od, exist_ok=True)
    cmd = [PY, "-u", os.path.join(HERE, "make.py"), code, "--config", path, "--count", str(n),
           "--quality", st.get("quality", "good"), "--out", od] + args
    name = next(g[1] for g in GAME_INFO if g[0] == code)
    return JOBS.add("render", cmd, n, f"{n} × {name}" + (f" · {cfg['title']}" if cfg.get("title") else ""))


def start_clip(st):
    code, cfg, args = state_to_cfg(st, for_preview=True)
    os.makedirs(CACHE, exist_ok=True)
    cfg.setdefault("seed", random.randrange(1, 10 ** 6))
    path = os.path.join(CACHE, f"clipcfg_{int(time.time() * 1000)}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"game": code, "cfg": cfg, "music": "off" if "off" in args else "on"}, f, ensure_ascii=False)
    out = os.path.join(CACHE, f"clip_{int(time.time() * 1000)}.mp4")
    cmd = [PY, "-u", "-m", "studio.clip", path, out]
    return JOBS.add("clip", cmd, 1, "6-second preview")


def start_plan(st, jobs):
    base = {}
    try:
        _, base, args = state_to_cfg(dict(st, racers=st.get("racers") or []), for_preview=True)
    except ValueError:
        args = []
    base = {k: v for k, v in base.items() if k in ("handle", "race_seconds", "background", "style", "vibe", "retro", "commentary", "commentary_ai", "end_card")}
    path = os.path.join(HERE, "config", "_plan.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"base": base, "jobs": jobs}, f, ensure_ascii=False)
    od = out_dir(st)
    os.makedirs(od, exist_ok=True)
    cmd = [PY, "-u", os.path.join(HERE, "make.py"), "--plan", path, "--quality", st.get("quality", "good"), "--out", od] + args
    return JOBS.add("render", cmd, len(jobs), f"Plan: {len(jobs)} videos")


# ----------------------------------------------------------------------------- emoji search
_EMOJI = []


def emoji_index():
    if _EMOJI:
        return _EMOJI
    for f in sorted(os.listdir(EMOJI_DIR)):
        code = f[:-4]
        try:
            ch = "".join(chr(int(p, 16)) for p in code.split("-"))
        except ValueError:
            continue
        names = []
        for c in ch:
            try:
                names.append(unicodedata.name(c))
            except ValueError:
                pass
        _EMOJI.append((" ".join(names).lower(), ch, f))
    return _EMOJI


def emoji_search(q, limit=96):
    words = (q or "").lower().split()
    hits = [x for x in emoji_index() if all(w in x[0] for w in words)] if words else emoji_index()[:limit]
    return [{"ch": ch, "name": (name.split() or ["racer"])[-1].title(), "url": "/emoji/" + f} for name, ch, f in hits[:limit]]


# ----------------------------------------------------------------------------- AI glue
IDEAS = os.path.join(HERE, "config", "_ideas.json")
SPARKS = ["foods", "animals", "zodiac signs", "countries", "planets", "sports", "school subjects", "desserts", "drinks",
          "jobs", "weather", "music genres", "video game classes", "mythical creatures", "fruits", "vehicles", "seasons",
          "candy", "dinosaurs", "ocean animals", "fast food", "superpowers", "elements", "emotions", "weekdays",
          "pizza toppings", "pets", "insects", "breakfast foods", "ice cream flavors", "space", "kitchen items",
          "countries", "flags", "cities", "football clubs colours", "anime-style elements", "fantasy classes"]


def _recent_titles():
    try:
        with open(IDEAS, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _remember(title):
    t = _recent_titles()
    if title:
        t = ([title] + [x for x in t if x != title])[:40]
        with open(IDEAS, "w", encoding="utf-8") as f:
            json.dump(t, f)


def ai_idea(code, theme, n, art="none"):
    """Returns a patch for the page state. art: none | bg | all (AI background, + AI characters)."""
    if code == "quiz":
        return _ai_idea(code, (theme or "").strip(), n)
    theme = (theme or "").strip() or random.choice(SPARKS)
    patch = _ai_idea(code, theme, n)
    notes = []
    if art in ("bg", "all"):
        try:
            patch["background"] = "image:" + ai.background(f"{theme}, matching the video '{patch.get('title', '')}'")
        except Exception as e:
            notes.append(f"AI background skipped: {e}")
    if art == "all" and patch.get("racers"):
        for r in patch["racers"]:
            try:
                r["image"] = ai.character(f"{r['name']} ({theme})")
                r["kind"] = "image"
                r["shape"] = "fit"
            except Exception as e:
                notes.append(f"AI characters stopped: {e}")
                break
    patch["notes"] = notes
    patch["cost"] = ai.video_spent()
    return patch


def _ai_idea(code, theme, n):
    if code == "quiz":
        cats = MODS["quiz"].CATEGORIES
        typed = theme
        key = typed.lower() if typed else random.choice(list(cats))
        label, must = cats.get(key, (key.upper(), None))
        qs = ai.quiz(key, 6, must)
        title = f"GUESS THE {label} BY EMOJI"[:44]
        _remember(title)
        return {"title": title, "extra": {"quiz_topic": "my questions", "questions": qs, "category": key}}
    if code == "whatif":
        r = ai.whatif_idea(theme if random.random() < 0.5 else "")
        _remember(r["title"])
        return {"title": r["title"], "extra": {"preset": "ai", "idea": r["idea"]}}
    if code == "barrace":
        ds = random.choice(MODS["barrace"].DATASETS and list(MODS["barrace"].DATASETS))
        t = ai.ask_json(f"""Write one hook title (max 6 words, uppercase) for an animated bar chart race
of countries by "{ds}" over the decades. Avoid: {_recent_titles()[:10]}. Return JSON: {{"title": "..."}}""", 1.0)
        title = str(t.get("title", ds)).upper()[:60]
        _remember(title)
        return {"title": title, "extra": {"dataset": ds}}
    if code == "music":
        from engine.melodies import MELODIES
        song = random.choice(list(MELODIES))
        res = ai.idea(code, theme, 1)
        _remember(res["title"])
        return {"title": res["title"], "racers": res["racers"][:1], "extra": {"song": song}}
    res = ai.idea(code, theme, n)
    _remember(res["title"])
    return {"title": res["title"], "racers": res["racers"]}


# ----------------------------------------------------------------------------- phone access
PHONE = os.path.join(HERE, "config", "_phone.json")
_fails = []   # times of wrong PIN attempts (rate limit)


def phone_cfg():
    try:
        with open(PHONE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"enabled": False, "pin": "", "tokens": []}


def phone_save(c):
    os.makedirs(os.path.dirname(PHONE), exist_ok=True)
    with open(PHONE, "w", encoding="utf-8") as f:
        json.dump(c, f)


def new_pin():
    import secrets
    return "".join(secrets.choice("0123456789") for _ in range(6))


def local_ips():
    """Addresses a phone can actually reach: the computer's real Wi-Fi/LAN address (the one its
    internet traffic uses) and Tailscale (100.64-127.x). Virtual adapters (VMware, VirtualBox,
    Hyper-V, WSL) are left out: phones can never reach those."""
    import socket
    out = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        main_ip = s.getsockname()[0]
        s.close()
        if not main_ip.startswith(("127.", "169.254.")):
            out.append({"ip": main_ip, "kind": "Same Wi-Fi"})
    except Exception:
        main_ip = None
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            a, b = (int(x) for x in ip.split(".")[:2])
            if a == 100 and 64 <= b <= 127:
                out.append({"ip": ip, "kind": "Tailscale (works anywhere)"})
    except Exception:
        pass
    return out


def firewall_ok():
    """Windows only: is our 'allow phones' firewall rule there? None = unknown / not Windows."""
    if os.name != "nt":
        return None
    try:
        r = subprocess.run(["netsh", "advfirewall", "firewall", "show", "rule", "name=Race Studio phone access"],
                           capture_output=True, text=True, timeout=8, creationflags=NOFLAGS,
                           stdin=subprocess.DEVNULL)
        return r.returncode == 0 and "Race Studio" in r.stdout
    except Exception:
        return None


def qr_svg(text):
    try:
        import io
        vend = os.path.join(HERE, "studio", "_vendor")   # bundled copy: no extra install needed
        if vend not in sys.path:
            sys.path.insert(0, vend)
        import qrcode
        import qrcode.image.svg
        img = qrcode.make(text, image_factory=qrcode.image.svg.SvgPathImage, box_size=10, border=2)
        b = io.BytesIO()
        img.save(b)
        return b.getvalue()
    except Exception:
        return None


# ----------------------------------------------------------------------------- HTTP
def _open_path(p):
    if sys.platform == "darwin":
        subprocess.Popen(["open", p])
    elif os.name == "nt":
        os.startfile(p)  # noqa
    else:
        subprocess.Popen(["xdg-open", p])


class H(BaseHTTPRequestHandler):
    server_version = "RaceStudio"

    def log_message(self, *a):
        pass

    # -- helpers
    def _login(self):
        return _login_impl(self)

    def _json(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def _file(self, path, cache=False, download=None):
        if not os.path.isfile(path):
            return self._json({"error": "not found"}, 404)
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        size = os.path.getsize(path)
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].partition("-")
            start = int(a) if a else 0
            end = int(b) if b else size - 1
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        else:
            self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Cache-Control", "max-age=86400" if cache else "no-store")
        if download:
            self.send_header("Content-Disposition", f'attachment; filename="{download}"')
        self.end_headers()
        with open(path, "rb") as f:
            f.seek(start)
            left = end - start + 1
            while left > 0:
                chunk = f.read(min(1 << 16, left))
                if not chunk:
                    break
                try:
                    self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError):
                    return
                left -= len(chunk)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(n) if n else b""

    def _jbody(self):
        b = self._body()
        return json.loads(b.decode("utf-8")) if b else {}

    def _is_pc(self):
        """A request from this computer itself (the Host check also blocks DNS-rebinding tricks)."""
        host = (self.headers.get("Host") or "").split(":")[0]
        return self.client_address[0] in ("127.0.0.1", "::1") and host in ("127.0.0.1", "localhost")

    def _phone_ok(self):
        c = phone_cfg()
        if not c.get("enabled"):
            return False
        ck = self.headers.get("Cookie") or ""
        for part in ck.split(";"):
            k, _, v = part.strip().partition("=")
            if k == "rs_session" and v and v in c.get("tokens", []):
                return True
        return False

    def _local_only(self):
        return self._is_pc() or self._phone_ok()

    # -- routes
    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = dict(urllib.parse.parse_qsl(u.query))
        p = u.path
        if not self._local_only():
            if phone_cfg().get("enabled") and not self._is_pc():
                if p in ("/", "/index.html", "/login"):
                    return self._file(os.path.join(UI, "login.html"))
                if p == "/ui/style.css":
                    return self._file(os.path.join(UI, "style.css"))
            return self._json({"error": "Sign in with your PIN first."}, 401)
        if p == "/api/phone":
            if not self._is_pc():
                return self._json({"remote": True})
            c = phone_cfg()
            port = self.server.server_address[1]
            return self._json({"remote": False, "windows": os.name == "nt", "firewall": firewall_ok(), "enabled": c.get("enabled", False), "pin": c.get("pin", ""),
                               "devices": len(c.get("tokens", [])), "bound_all": self.server.server_address[0] == "0.0.0.0",
                               "urls": [dict(d, url=f"http://{d['ip']}:{port}/") for d in local_ips()]})
        if p == "/api/phone/qr" and self._is_pc():
            svg = qr_svg(q.get("u", ""))
            if svg is None:
                return self._json({"error": "QR not available"}, 404)
            self.send_response(200)
            self.send_header("Content-Type", "image/svg+xml")
            self.send_header("Content-Length", str(len(svg)))
            self.end_headers()
            self.wfile.write(svg)
            return
        try:
            if p == "/" or p == "/index.html":
                return self._file(os.path.join(UI, "index.html"))
            if p.startswith("/ui/"):
                f = os.path.normpath(os.path.join(UI, p[4:]))
                if f.startswith(UI):
                    return self._file(f)
            if p.startswith("/emoji/"):
                f = os.path.normpath(os.path.join(EMOJI_DIR, os.path.basename(p)))
                return self._file(f, cache=True)
            if p == "/favicon.ico":
                self.send_response(204)
                self.end_headers()
                return
            if p == "/api/meta":
                return self._json(meta())
            if p == "/api/state":
                try:
                    with open(STATE, encoding="utf-8") as f:
                        return self._json(json.load(f))
                except Exception:
                    return self._json({})
            if p == "/api/emoji":
                return self._json(emoji_search(q.get("q", "")))
            if p == "/api/jobs":
                return self._json({"jobs": JOBS.public(), "busy": JOBS.busy()})
            if p == "/api/ai/assets":
                items = []
                if os.path.isdir(ai.AI_ASSETS):
                    for f in sorted(os.listdir(ai.AI_ASSETS), key=lambda f: -os.path.getmtime(os.path.join(ai.AI_ASSETS, f))):
                        full = os.path.join(ai.AI_ASSETS, f)
                        items.append({"kind": "bg" if f.startswith("bg_") else "char", "path": full,
                                      "url": "/file?p=" + urllib.parse.quote(full), "name": f})
                return self._json({"items": items[:60]})
            if p == "/api/ai/status":
                u2 = ai.usage()
                days = sorted(u2["days"].items())[-14:]
                return self._json({"has_key": ai.has_key(), "total": u2["total"], "today": u2["today"],
                                   "month": u2["month"], "calls": u2["calls"], "by_kind": u2["by_kind"], "days": days})
            if p == "/api/update/check":
                try:
                    ok, info = updater.check()
                    return self._json({"available": ok, "info": info, "current": version()})
                except Exception as e:
                    return self._json({"available": False, "error": str(e), "current": version()})
            if p == "/api/thumb/game":
                code, look = q["game"], q.get("look", "sleek")
                th, bgs = q.get("theme") or "", q.get("background") or ""
                if bgs:
                    look, th = TH.bg_look(look), ""
                ship = TH.shipped_path(code, look, th, bgs)
                if ship:
                    return self._file(ship, cache=True)
                cfg = TH.cfg_for(code, look, th, bgs)
                r = cached_thumb(TH.name(code, look, th, bgs) + "_" + TH.signature(code),
                                 {"kind": "still", "game": code, "cfg": cfg, "at": TH.AT, "size": TH.SIZE})
                return self._file(r["out"], cache=True) if r.get("ok") else self._json(r, 500)
            if p == "/file":
                f = os.path.abspath(q.get("p", ""))
                allowed = [CACHE, ai.AI_ASSETS, UPLOADS["racer"]] + [os.path.dirname(o) for j in JOBS.items for o in j["outputs"]] + [os.path.join(HERE, "output")]
                if any(f.startswith(os.path.abspath(a) + os.sep) for a in allowed) and f.lower().endswith((".mp4", ".png", ".jpg", ".jpeg", ".webp", ".txt")):
                    return self._file(f, download=os.path.basename(f) if q.get("dl") else None)
                return self._json({"error": "not allowed"}, 403)
        except Exception as e:
            traceback.print_exc()
            return self._json({"error": str(e)}, 500)
        return self._json({"error": "not found"}, 404)

    def do_POST(self):
        p = urllib.parse.urlparse(self.path).path
        if p == "/api/login" and self.headers.get("X-Studio") == "1":
            return self._login()
        if not self._local_only() or self.headers.get("X-Studio") != "1":
            return self._json({"error": "Sign in with your PIN first."}, 401)
        if p in ("/api/phone", "/api/phone/newpin", "/api/phone/firewall") and not self._is_pc():
            return self._json({"error": "Change phone settings on the computer itself."}, 403)
        if p == "/api/phone":
            c = phone_cfg()
            on = bool(self._jbody().get("enabled"))
            c["enabled"] = on
            if on and not c.get("pin"):
                c["pin"] = new_pin()
            phone_save(c)
            restart = on != (self.server.server_address[0] == "0.0.0.0")
            if restart and not JOBS.busy():
                threading.Thread(target=_restart, daemon=True).start()
            return self._json({"ok": True, "restart": restart, "busy": JOBS.busy()})
        if p == "/api/phone/firewall":
            if os.name != "nt":
                return self._json({"error": "Only needed on Windows. On a Mac, click Allow when macOS asks about incoming connections."}, 400)
            port = self.server.server_address[1]
            args = (f'advfirewall firewall add rule name="Race Studio phone access" dir=in action=allow '
                    f'protocol=TCP localport={port} profile=any')

            def ask():   # Windows' own "allow changes?" prompt; runs in the background so the page doesn't wait
                try:
                    import ctypes
                    ctypes.windll.shell32.ShellExecuteW(None, "runas", "netsh.exe", args, None, 0)
                except Exception:
                    traceback.print_exc()
            threading.Thread(target=ask, daemon=True).start()
            return self._json({"ok": True})
        if p == "/api/phone/newpin":
            c = phone_cfg()
            c["pin"], c["tokens"] = new_pin(), []
            phone_save(c)
            return self._json({"ok": True, "pin": c["pin"]})
        try:
            if p == "/api/upload":
                q = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
                kind = q.get("kind", "racer")
                d = UPLOADS[kind]
                os.makedirs(d, exist_ok=True)
                name = re.sub(r"[^\w.\- ]", "_", urllib.parse.unquote(self.headers.get("X-Filename", "file")))[-80:]
                ok_ext = {"racer": (".png", ".jpg", ".jpeg", ".webp"), "music": (".wav",), "csv": (".csv",)}[kind]
                if not name.lower().endswith(ok_ext):
                    return self._json({"error": f"Use a {' / '.join(ok_ext)} file."}, 400)
                path = os.path.join(d, name)
                with open(path, "wb") as f:
                    f.write(self._body())
                return self._json({"path": path, "url": "/file?p=" + urllib.parse.quote(path) if kind != "racer" else ""})
            body = self._jbody()
            if p == "/api/state":
                os.makedirs(os.path.dirname(STATE), exist_ok=True)
                with open(STATE, "w", encoding="utf-8") as f:
                    json.dump(body, f, ensure_ascii=False)
                return self._json({"ok": True})
            if p == "/api/preview":
                _preview_token["n"] += 1
                my = _preview_token["n"]
                st = body.get("state", {})
                code, cfg, _ = state_to_cfg(st, for_preview=True)
                cfg.setdefault("seed", int(body.get("seed") or 7))
                with WORKER.lock:
                    pass
                if my != _preview_token["n"]:
                    return self._json({"stale": True})
                os.makedirs(CACHE, exist_ok=True)
                out = os.path.join(CACHE, f"pv_{_key(code, cfg, body.get('at'))}.png")
                if not os.path.exists(out):
                    r = WORKER.call({"kind": "still", "game": code, "cfg": cfg, "at": float(body.get("at", 3)),
                                     "out": out, "size": [540, 960]})
                    if not r.get("ok"):
                        return self._json({"error": r.get("error", "Preview failed")}, 500)
                return self._json({"url": "/file?p=" + urllib.parse.quote(out)})
            if p == "/api/render":
                j = start_render(body["state"], body.get("count"))
                return self._json({"job": j["id"]})
            if p == "/api/clip":
                j = start_clip(body["state"])
                return self._json({"job": j["id"]})
            if p == "/api/plan/run":
                j = start_plan(body["state"], body["jobs"])
                return self._json({"job": j["id"]})
            if p.startswith("/api/jobs/") and p.endswith("/cancel"):
                JOBS.cancel(int(p.split("/")[3]))
                return self._json({"ok": True})
            if p == "/api/open" and not self._is_pc():
                return self._json({"error": "That opens a folder on your computer. Use ⬇ Save on the video instead."}, 400)
            if p == "/api/open":
                path = body.get("path") or out_dir(body.get("state", {}))
                if os.path.isfile(path):
                    path = os.path.dirname(path) if body.get("folder") else path
                os.makedirs(path, exist_ok=True) if not os.path.splitext(path)[1] else None
                _open_path(path)
                return self._json({"ok": True})
            if p == "/api/ai/key":
                ai.save(body.get("key", ""))
                return self._json({"ok": True, "has_key": ai.has_key()})
            if p == "/api/ai/idea":
                ai.begin_video(float(body.get("budget", 10)) / 100)
                return self._json(ai_idea(body.get("game", "maze"), body.get("theme", ""), int(body.get("n", 4)),
                                          art=body.get("art", "none")))
            if p == "/api/ai/background":
                ai.begin_video(float(body.get("budget", 10)) / 100)
                path = ai.background(body.get("prompt") or "abstract colorful space")
                return self._json({"path": path})
            if p == "/api/ai/character":
                ai.begin_video(float(body.get("budget", 10)) / 100)
                path = ai.character(body.get("desc") or "a cute blob")
                return self._json({"path": path, "url": "/file?p=" + urllib.parse.quote(path)})
            if p == "/api/ai/plan":
                return self._json({"jobs": ai.plan_week(int(body.get("n", 7)), body.get("games") or list(MODS))})
            if p == "/api/ai/comments":
                names = ai.names_from_comments(body.get("text", ""), int(body.get("n", 6)))
                return self._json({"names": names})
            if p == "/api/update/apply":
                if JOBS.busy():
                    return self._json({"error": "Wait for your videos to finish first."}, 409)
                ok, info = updater.check()
                if not ok:
                    return self._json({"error": "Already up to date."}, 409)
                updater.apply(info)
                threading.Thread(target=_restart, daemon=True).start()
                return self._json({"ok": True, "version": info["version"]})
        except ai.BudgetError as e:
            return self._json({"error": str(e)}, 402)
        except (ValueError, ai.AIError) as e:
            return self._json({"error": str(e)}, 400)
        except Exception as e:
            traceback.print_exc()
            return self._json({"error": str(e) or e.__class__.__name__}, 500)
        return self._json({"error": "not found"}, 404)


def _login_impl(handler):
    import secrets
    now = time.time()
    _fails[:] = [t for t in _fails if now - t < 300]
    c = phone_cfg()
    if not c.get("enabled"):
        return handler._json({"error": "Phone access is off. Turn it on in Settings on your computer."}, 403)
    if len(_fails) >= 8:
        return handler._json({"error": "Too many wrong PINs. Wait 5 minutes."}, 429)
    pin = str(handler._jbody().get("pin", "")).strip()
    if not pin or not secrets.compare_digest(pin, c.get("pin", "")):
        _fails.append(now)
        return handler._json({"error": "Wrong PIN."}, 403)
    tok = secrets.token_urlsafe(24)
    c["tokens"] = (c.get("tokens", []) + [tok])[-10:]
    phone_save(c)
    b = json.dumps({"ok": True}).encode()
    handler.send_response(200)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Set-Cookie", f"rs_session={tok}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Strict")
    handler.send_header("Content-Length", str(len(b)))
    handler.end_headers()
    handler.wfile.write(b)


def _restart():
    time.sleep(0.8)
    subprocess.Popen([PY, os.path.join(HERE, "gui.py"), "--no-browser"], cwd=HERE, creationflags=NOFLAGS)
    os._exit(0)


def serve(port=8765, open_browser=True):
    srv = None
    for attempt in range(40):
        for pt in (port, port + 1, port + 2):
            try:
                srv = ThreadingHTTPServer(("0.0.0.0" if phone_cfg().get("enabled") else "127.0.0.1", pt), H)
                port = pt
                break
            except OSError:
                srv = None
        if srv:
            break
        time.sleep(0.25)
    if srv is None:
        raise SystemExit("Couldn't start Race Studio (ports 8765-8767 busy). Is it already open?")
    url = f"http://127.0.0.1:{port}/"

    def warm():   # start the preview helpers now so the first preview is quick; draw missing game cards
        try:
            os.makedirs(CACHE, exist_ok=True)
            WORKER.call({"kind": "still", "game": "maze", "cfg": TH.cfg_for("maze", "sleek"), "at": 0.1,
                         "out": os.path.join(CACHE, "_warm.png")})
        except Exception:
            pass
        for code, *_ in GAME_INFO:
            if code in MODS and not TH.shipped_path(code, "sleek", "", ""):
                try:
                    cached_thumb(TH.name(code, "sleek", "", "") + "_" + TH.signature(code),
                                 {"kind": "still", "game": code, "cfg": TH.cfg_for(code, "sleek"), "at": TH.AT, "size": TH.SIZE})
                except Exception:
                    pass
    threading.Thread(target=warm, daemon=True).start()
    print("Race Studio running at", url, flush=True)
    if open_browser:
        import webbrowser
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    return srv, url
