"""Picker thumbnails: what gets drawn for each tile, and where it's stored.

Ready-made thumbnails ship with the app in assets/thumbs (built before each release), so the
pickers appear instantly. Anything not shipped (a theme + background combo, your AI background)
is drawn on this computer once and kept in config/_cache, keyed by the game's code so it
survives updates unless that game actually changed."""
import hashlib
import os

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHIPPED = os.path.join(HERE, "assets", "thumbs")
LOOKS = ["sleek", "cartoon", "gameboy", "8bit", "16bit"]
RETRO = ("gameboy", "8bit", "16bit")
SIZE = [216, 384]
AT = 3.0
# shared code that changes how every game looks
SHARED = ["games/maze.py", "engine/visual.py", "engine/backgrounds.py", "engine/retro.py", "engine/runner.py",
          "engine/commentary.py", "engine/preview.py", "studio/thumbs.py"]
NO_SHIP = {"barrace"}   # needs live World Bank data: drawn on your computer instead
_sig = {}


def signature(game):
    if game not in _sig:
        h = hashlib.sha1()
        for f in SHARED + [f"games/{game}.py"] + (["games/battle.py"] if game == "bracket" else []):
            try:
                with open(os.path.join(HERE, f), "rb") as fh:
                    h.update(fh.read())
            except OSError:
                pass
        _sig[game] = h.hexdigest()[:10]
    return _sig[game]


def bg_look(look):
    """Background tiles: retro looks reuse the cartoon pictures (same backdrop, before pixelation)."""
    return "cartoon" if look in RETRO else look


def name(game, look, theme="", background=""):
    return f"{game}__{look}__{theme or 'x'}__{(background or 'x').replace(':', '_').replace('/', '_').replace(chr(92), '_')[:60]}"


def cfg_for(game, look, theme="", background=""):
    from make import PRESETS
    c = {"racers": PRESETS["colors4"], "title": "", "seed": 11, "race_seconds": [20, 35],
         "style": "sleek" if look == "sleek" else "cartoon", "retro": look if look in RETRO else None,
         "dataset": "Population", "whatif_preset": "200_balls", "commentary": False, "quiz_topic": "countries"}
    if theme:
        c["theme"] = theme
    if background:
        c["background"] = background
    return c


def specs(game, mod):
    """Every tile the page asks for by default: game card, looks, themes per look, backgrounds."""
    out = set()
    for look in LOOKS:
        out.add((look, "", ""))
        for th in getattr(mod, "THEMES", {}):
            out.add((look, th, ""))
    from engine.backgrounds import STYLES
    for look in ("sleek", "cartoon"):
        for b in STYLES:
            out.add((look, "", b))
    return sorted(out)


def shipped_file(game, look, theme, background):
    """File name includes the game's code signature: a picture of an older version is never shown."""
    return name(game, look, theme, background) + "__" + signature(game) + ".jpg"


def shipped_path(game, look, theme, background):
    p = os.path.join(SHIPPED, shipped_file(game, look, theme, background))
    return p if os.path.exists(p) else None
