# Race Studio

Easiest way: double-click `Start Race Studio.bat` and use the window.

## Games
- Maze Race, Ring Escape, Marble Elimination, Territory War

Makes satisfying race videos (1080x1920, 60fps, with synced sound) for Shorts / TikTok / Reels.

## Setup (once)
Mac: double-click "Start Race Studio.command". Windows: double-click "Start Race Studio.bat". The first run installs everything it needs.

## Make videos
```
python make.py maze                         # 1 race, colour squares
python make.py maze --count 10              # 10 different races
python make.py maze --racers food           # presets: colors4, colors6, drinks, food, animals
python make.py maze --theme candy --vibe hype
python make.py maze --music off             # or --music path/to/your_track.wav
python make.py maze --config config/example.json
python make.py rings --count 5               # Ring Escape (1 racer = solo 'Can it escape?' mode)
python make.py marbles --racers colors6      # Marble Elimination (rounds = racers - 1)
python make.py territory --racers animals    # Territory War
--background wavy_checker|stripes|dots|grid|radial|bokeh|zigzag
```
Videos land in `output/`.

## Your own racers
Put PNGs (transparent background works best) in `assets/racers/`, then in a config file:
```json
{"racers": [
  {"name": "Pepsi", "image": "pepsi.png", "color": "#1e5bd6"},
  {"name": "Creator", "image": "face.png", "shape": "circle", "color": "#ff3b3b"},
  {"name": "Pizza", "emoji": "🍕", "color": "#ef5b3b"}
]}
```
Other options: `"title"`, `"handle"` (your @ shown under the board), `"theme"`, `"race_seconds": [30, 50]`, `"speed"`.

## Your own sounds
Drop WAV files into `assets/sounds/` named `bounce.wav`, `hit.wav`, `break.wav`, `die.wav`, `win.wav`, `count.wav`, `go.wav` to replace the built-in ones. Only use sounds/music you have rights to.

Emoji graphics: Twemoji by Twitter, CC-BY 4.0.
