#!/bin/bash
# Race Studio launcher for Mac. Double-click to open.
cd "$(dirname "$0")" || exit 1
LOG="launcher_log.txt"
echo "===== Race Studio (Mac) =====" > "$LOG"
clear
echo "Race Studio"
echo "-----------"
echo "[1/3] Looking for Python..."

PY=""
for p in /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.14/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.11/bin/python3 \
         /opt/homebrew/bin/python3 /usr/local/bin/python3; do
  if [ -x "$p" ] && "$p" -c "import sys, tkinter; assert sys.version_info >= (3, 9)" >/dev/null 2>&1; then
    PY="$p"; break
  fi
done

if [ -z "$PY" ]; then
  echo "Python not found" >> "$LOG"
  echo ""
  echo "Python isn't installed yet (one-time step)."
  echo "Your browser will open python.org:"
  echo "  1. Click the yellow 'Download Python' button for macOS"
  echo "  2. Open the downloaded file and click Continue / Agree / Install"
  echo "  3. Then double-click 'Start Race Studio' again"
  open "https://www.python.org/downloads/macos/"
  echo ""
  read -r -p "Press Enter to close this window..."
  exit 0
fi
echo "Using $PY" >> "$LOG"
"$PY" --version >> "$LOG" 2>&1

if [ ! -x ".venv/bin/python" ]; then
  echo "[2/3] First-time setup (2-5 minutes, please wait)..."
  "$PY" -m venv .venv >> "$LOG" 2>&1
else
  echo "[2/3] Checking libraries..."
fi
./.venv/bin/python -m pip install --disable-pip-version-check -q -r requirements.txt >> "$LOG" 2>&1
if [ $? -ne 0 ]; then
  echo ""
  echo "Setup failed (check your internet). Details are in launcher_log.txt"
  read -r -p "Press Enter to close..."
  exit 1
fi

echo "[3/3] Opening Race Studio... (leave this window open while you use it)"
./.venv/bin/python gui.py >> "$LOG" 2>&1
if [ $? -ne 0 ]; then
  echo ""
  echo "Race Studio closed with an error. Send launcher_log.txt to Alvi."
  read -r -p "Press Enter to close..."
fi
