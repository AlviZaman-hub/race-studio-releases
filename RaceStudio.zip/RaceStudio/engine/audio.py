"""Sound engine.

Every sound is synthesized in code (no copyright issues) and placed at the
exact sample where the physics event happened, so audio can never drift
from the picture. Everything is tuned to one musical key so bounces turn
into a melody that fits the background bed.

Custom sounds: drop a WAV into assets/sounds/<name>.wav (e.g. bounce.wav,
break.wav, win.wav) and it replaces the built-in one.
"""
import os
import wave
import numpy as np

from . import sounds_modern as MOD

SR = 48000
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOUND_DIR = os.path.join(ROOT, "assets", "sounds")

# ---------------------------------------------------------------- helpers

def _t(dur):
    return np.arange(int(dur * SR)) / SR


def _midi(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def _exp(t, tau):
    return np.exp(-t / tau)


def _fade(x, ms_in=1.0, ms_out=8.0):
    n_in = max(1, int(SR * ms_in / 1000))
    n_out = max(1, int(SR * ms_out / 1000))
    x = x.copy()
    x[:n_in] *= np.linspace(0, 1, n_in)
    x[-n_out:] *= np.linspace(1, 0, n_out)
    return x


def _noise(n, rng):
    return rng.standard_normal(n)


def _bandnoise(n, rng, lo, hi):
    """Band-limited noise via FFT masking (fast, any length)."""
    spec = np.fft.rfft(rng.standard_normal(n))
    f = np.fft.rfftfreq(n, 1 / SR)
    spec[(f < lo) | (f > hi)] = 0
    y = np.fft.irfft(spec, n)
    return y / (np.max(np.abs(y)) + 1e-9)


def _sweep_sine(f0, f1, dur, curve=3.0):
    t = _t(dur)
    k = (t / dur) ** (1 / curve) if f1 < f0 else (t / dur) ** curve
    f = f0 + (f1 - f0) * k
    phase = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(phase)


# ---------------------------------------------------------------- voices

def pluck(freq, dur=0.55, bright=1.0):
    """Marimba / kalimba style tone: the core 'satisfying bounce'."""
    t = _t(dur)
    # tiny downward pitch blip at the attack gives it a mallet feel
    f = freq * (1 + 0.03 * _exp(t, 0.006))
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = (np.sin(ph) * _exp(t, 0.16)
         + 0.35 * bright * np.sin(4.0 * ph) * _exp(t, 0.035)
         + 0.12 * bright * np.sin(9.2 * ph) * _exp(t, 0.012))
    rng = np.random.default_rng(int(freq))
    click = _bandnoise(len(t), rng, 2500, 9000) * _exp(t, 0.0025) * 0.25 * bright
    return _fade(x + click, 0.5, 30)


def wood(freq, dur=0.18):
    """Woodblock tick for hitting numbered blocks."""
    t = _t(dur)
    rng = np.random.default_rng(7 + int(freq))
    body = np.sin(2 * np.pi * freq * t) * _exp(t, 0.028)
    over = np.sin(2 * np.pi * freq * 2.43 * t) * _exp(t, 0.012) * 0.4
    knock = _bandnoise(len(t), rng, 900, 4000) * _exp(t, 0.006) * 0.5
    return _fade(body + over + knock, 0.3, 10)


def crunch(seed=0, dur=0.9):
    """Block shatter: thump + crunchy noise + glassy shimmer."""
    rng = np.random.default_rng(100 + seed)
    t = _t(dur)
    thump = _sweep_sine(180, 45, 0.35) * _exp(_t(0.35), 0.09)
    thump = np.pad(thump, (0, len(t) - len(thump)))
    crack = _bandnoise(len(t), rng, 300, 7000) * _exp(t, 0.06)
    glass = np.zeros_like(t)
    for _ in range(9):
        f = rng.uniform(2200, 6500)
        d = rng.uniform(0, 0.08)
        tt = np.clip(t - d, 0, None)
        glass += np.sin(2 * np.pi * f * tt) * _exp(tt, rng.uniform(0.05, 0.22)) * (t >= d) * 0.12
    return _fade(0.9 * thump + 0.55 * crack + glass, 0.3, 40)


def pop_down(seed=0):
    """Racer hits spikes: descending bloop + splat."""
    rng = np.random.default_rng(200 + seed)
    dur = 0.45
    t = _t(dur)
    s = _sweep_sine(700, 110, 0.3) * _exp(_t(0.3), 0.12)
    s = np.pad(s, (0, len(t) - len(s)))
    splat = _bandnoise(len(t), rng, 200, 3000) * _exp(t, 0.04) * 0.6
    return _fade(s + splat, 0.3, 30)


def whoosh(dur=0.5, up=True, seed=0):
    rng = np.random.default_rng(300 + seed)
    t = _t(dur)
    n = _bandnoise(len(t), rng, 400, 6000)
    env = np.sin(np.pi * t / dur) ** 2
    tone = _sweep_sine(300, 1200, dur) if up else _sweep_sine(1200, 300, dur)
    return _fade(n * env * 0.6 + tone * env * 0.25, 2, 20)


def bell(freq, dur=1.6):
    t = _t(dur)
    x = (np.sin(2 * np.pi * freq * t) * _exp(t, 0.5)
         + 0.5 * np.sin(2 * np.pi * freq * 2.0 * t) * _exp(t, 0.3)
         + 0.25 * np.sin(2 * np.pi * freq * 2.76 * t) * _exp(t, 0.18)
         + 0.12 * np.sin(2 * np.pi * freq * 5.4 * t) * _exp(t, 0.08))
    return _fade(x, 0.5, 60)


def beep(freq, dur=0.16):
    t = _t(dur)
    x = np.sin(2 * np.pi * freq * t) + 0.25 * np.sin(2 * np.pi * freq * 3 * t)
    return _fade(x * _exp(t, dur * 0.8), 2, 25)


def fanfare(key_midi):
    """Victory: fast rising arpeggio of bells + sparkle + low hit."""
    out = np.zeros(int(SR * 2.6))
    notes = [0, 4, 7, 12, 16, 19, 24]
    for i, n in enumerate(notes):
        s = bell(_midi(key_midi + 12 + n), 1.8) * (0.55 if i < 6 else 0.8)
        o = int(i * 0.07 * SR)
        out[o:o + len(s)] += s[: len(out) - o]
    rng = np.random.default_rng(9)
    for k in range(14):
        f = _midi(key_midi + 36 + rng.choice([0, 4, 7, 12]))
        s = pluck(f, 0.35, 0.6) * 0.18
        o = int((0.45 + k * 0.05) * SR)
        out[o:o + len(s)] += s[: len(out) - o]
    hit = _sweep_sine(120, 40, 0.6) * _exp(_t(0.6), 0.2)
    out[: len(hit)] += hit * 0.9
    return out


# ---------------------------------------------------------------- music bed

PROGRESSIONS = {
    # semitone offsets of chord roots from key, chord quality
    "chill": [(0, "maj7"), (9, "m7"), (5, "maj7"), (7, "dom")],
    "hype": [(9, "m"), (5, "maj"), (0, "maj"), (7, "maj")],
}
CHORDS = {
    "maj": [0, 4, 7], "m": [0, 3, 7], "maj7": [0, 4, 7, 11],
    "m7": [0, 3, 7, 10], "dom": [0, 4, 7, 10],
}


class Harmony:
    """Knows which chord is playing at any time so hit sounds stay in key."""

    def __init__(self, key_midi=60, vibe="chill", bpm=100):
        self.key = key_midi
        self.vibe = vibe if vibe in PROGRESSIONS else "chill"
        self.bpm = bpm
        self.bar = 4 * 60 / bpm
        self.prog = PROGRESSIONS[self.vibe]

    def chord_at(self, t):
        root, q = self.prog[int(t / self.bar) % len(self.prog)]
        return root, CHORDS[q]

    def note_at(self, t, idx, octave=1):
        """A consonant melody note for event number idx at time t."""
        root, tones = self.chord_at(t)
        pool = []
        for o in range(2):
            pool += [self.key + 12 * (octave + o) + root + x for x in tones]
        # wander up and down the chord so repeated hits form a little tune
        seq = list(range(len(pool))) + list(range(len(pool) - 2, 0, -1))
        return pool[seq[idx % len(seq)]]


def music_bed(duration, harmony, seed=0):
    """Soft pad + gentle arpeggio + light pulse, generated to exact length."""
    n = int(duration * SR) + SR
    out = np.zeros((n, 2))
    rng = np.random.default_rng(seed)
    beat = 60 / harmony.bpm
    bar = harmony.bar
    # pad: detuned additive saws, slow swell, per bar
    for b in range(int(duration / bar) + 2):
        t0 = b * bar
        root, tones = harmony.chord_at(t0 + 0.01)
        tt = _t(bar + 0.6)
        pad = np.zeros_like(tt)
        for x in tones:
            f = _midi(harmony.key - 12 + root + x)
            for det in (-0.12, 0.12):
                ff = f * 2 ** (det / 12)
                for h in range(1, 6):
                    pad += np.sin(2 * np.pi * ff * h * tt + rng.uniform(0, 6)) / (h * 1.4)
        env = np.minimum(1, tt / 0.5) * np.minimum(1, (bar + 0.6 - tt) / 0.6)
        pad *= env * 0.02
        o = int(t0 * SR)
        seg = pad[: max(0, n - o)]
        out[o:o + len(seg), 0] += seg
        out[o:o + len(seg), 1] += np.roll(seg, 240)
        # sub bass on the root
        sub = np.sin(2 * np.pi * _midi(harmony.key - 24 + root) * tt) * env * 0.09
        out[o:o + len(seg), :] += sub[: len(seg), None]
    # arpeggio 8th notes, quiet, panned
    step = beat / 2
    k = 0
    t = 0.0
    while t < duration:
        m = harmony.note_at(t, k, octave=1)
        s = pluck(_midi(m), 0.5, 0.5) * 0.05
        o = int(t * SR)
        seg = s[: max(0, n - o)]
        p = 0.5 + 0.3 * np.sin(k * 0.7)
        out[o:o + len(seg), 0] += seg * (1 - p)
        out[o:o + len(seg), 1] += seg * p
        k += 1
        t += step
    # pulse: soft kick on beats + shaker on offbeats (hype gets more)
    kick = _sweep_sine(110, 45, 0.25) * _exp(_t(0.25), 0.08)
    shk = _bandnoise(int(0.06 * SR), rng, 5000, 12000) * _exp(_t(0.06), 0.012)
    kg = 0.16 if harmony.vibe == "hype" else 0.07
    t = 0.0
    while t < duration:
        o = int(t * SR)
        seg = kick[: max(0, n - o)]
        out[o:o + len(seg), :] += seg[:, None] * kg
        o2 = int((t + beat / 2) * SR)
        seg2 = shk[: max(0, n - o2)]
        out[o2:o2 + len(seg2), :] += seg2[:, None] * 0.03
        t += beat
    return out[: int(duration * SR)]


# ---------------------------------------------------------------- mixer

class SoundTrack:
    """Collects timed events during the simulation, renders a final mix."""

    def __init__(self, key_midi=62, vibe="chill", bpm=100, music=True, seed=0,
                 music_file=None):
        self.events = []  # (time, kind, params dict)
        # "playful" = the original marimba/bell pack; everything else = modern pack
        self.style = "playful" if vibe in ("playful", "chill") else "modern"
        if self.style == "modern":
            self.harmony = MOD.ModernHarmony(key_midi, vibe)
        else:
            self.harmony = Harmony(key_midi, "chill", bpm)
        self.climax_t = None
        self.music = music
        self.music_file = music_file
        self.seed = seed
        self._cache = {}
        self._last = {}  # (kind, who) -> time, for anti-machine-gun
        self._count = {}  # kind -> event counter for melodies
        self._custom = self._load_custom()

    # ------------------------------------------------------- event API
    def add(self, t, kind, who=None, pan=0.5, gain=1.0, min_gap=0.0, **p):
        key = (kind, who)
        if min_gap and t - self._last.get(key, -9) < min_gap:
            return
        self._last[key] = t
        idx = self._count.get(kind, 0)
        self._count[kind] = idx + 1
        self.events.append((t, kind, dict(p, pan=pan, gain=gain, idx=idx, who=who)))

    def climax(self, t):
        """Games call this at the winning moment: music drops out right before it and hits on it."""
        if self.climax_t is None:
            self.climax_t = t

    # ------------------------------------------------------- sounds
    def _modern_voice(self, t, kind, p):
        H = self.harmony
        i = p["idx"]
        who = p.get("who") or 0
        c = self._cached
        if kind == "bounce":
            m = H.note_at(t, i + who * 3, octave=0)
            return c(("m_tick", m, i % 4), lambda: MOD.tick(MOD.midi(m), i % 4))
        if kind == "racer":
            m = H.note_at(t, i, octave=-1)
            return c(("m_tick2", m), lambda: MOD.tick(MOD.midi(m), 9, 0.7) * 0.8)
        if kind == "hit":
            root, _ = H.chord_at(t)
            f = MOD.midi(H.key - 24 + root) * 1.5
            return c(("m_thud", round(f), i % 3), lambda: MOD.thud(f, i % 3))
        if kind == "break":
            return c(("m_impact", i % 3), lambda: MOD.impact(i % 3))
        if kind == "escape":
            m = H.key - 12 + min(i, 24)  # climbs one semitone per ring: builds tension
            return c(("m_escape", m), lambda: _pad_mix(MOD.impact(i % 3, 0.6) * 0.7, MOD.tick(MOD.midi(m), 3, 1.3) * 0.9))
        if kind == "die":
            return c(("m_zap", i % 3), lambda: MOD.zap_down(i % 3))
        if kind == "spawn":
            return c(("m_spawn",), lambda: MOD.swish(0.3, True) * 0.5)
        if kind == "boost":
            return c(("m_boost",), lambda: MOD.swish(0.4, True, 2))
        if kind == "count":
            return c(("m_count", i % 2), lambda: MOD.clock_tick(i % 2 == 0))
        if kind == "go":
            return c(("m_go",), lambda: MOD.impact(5, 0.5) * 0.6)
        if kind == "win":
            return c(("m_win",), lambda: MOD.win_hit(H.key))
        if kind == "whoosh":
            return c(("m_whoosh",), lambda: MOD.swish(0.5, False, 4))
        if kind == "note":
            m = p["m"]
            return c(("m_note", m), lambda: MOD.piano(MOD.midi(m)))
        raise KeyError(kind)

    def _load_custom(self):
        out = {}
        if os.path.isdir(SOUND_DIR):
            for f in os.listdir(SOUND_DIR):
                if f.lower().endswith(".wav"):
                    try:
                        out[f[:-4].lower()] = _read_wav(os.path.join(SOUND_DIR, f))
                    except Exception as e:  # pragma: no cover
                        print("Could not read custom sound", f, e)
        return out

    def _voice(self, t, kind, p):
        h = self.harmony
        if kind in self._custom and kind not in ("bounce", "hit"):
            return self._custom[kind]
        if self.style == "modern":
            if kind in self._custom:
                return self._custom[kind]
            return self._modern_voice(t, kind, p)
        if kind == "bounce":
            if "bounce" in self._custom:
                return self._custom["bounce"]
            m = h.note_at(t, p["idx"] + (p.get("who") or 0) * 2, octave=1)
            return self._cached(("pluck", m), lambda: pluck(_midi(m)))
        if kind == "racer":  # racer-vs-racer bump
            m = h.note_at(t, p["idx"], octave=0)
            return self._cached(("pluck2", m), lambda: pluck(_midi(m), 0.4, 0.6) * 0.8)
        if kind == "hit":
            if "hit" in self._custom:
                return self._custom["hit"]
            m = h.note_at(t, p["idx"], octave=0) + 12
            return self._cached(("wood", m), lambda: wood(_midi(m) * 0.5))
        if kind == "break":
            return self._cached(("break", p["idx"] % 4), lambda: crunch(p["idx"] % 4))
        if kind == "die":
            return self._cached(("die", p["idx"] % 3), lambda: pop_down(p["idx"] % 3))
        if kind == "spawn":
            return self._cached(("spawn",), lambda: whoosh(0.35, True) * 0.5)
        if kind == "boost":
            return self._cached(("boost",), lambda: whoosh(0.4, True, 3) * 0.7)
        if kind == "count":
            return self._cached(("count",), lambda: beep(_midi(h.key + 24)))
        if kind == "go":
            return self._cached(("go",), lambda: beep(_midi(h.key + 31), 0.4) * 1.2)
        if kind == "win":
            return self._cached(("win",), lambda: fanfare(h.key))
        if kind == "escape":
            # ring shatter: light crunch + a bell that climbs the scale ring by ring
            steps = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24]
            m = h.key + 12 + steps[p["idx"] % len(steps)] + 12 * (p["idx"] // len(steps) % 2)
            return self._cached(("escape", m), lambda: _pad_mix(crunch(p["idx"] % 4, 0.7) * 0.55, bell(_midi(m), 1.4) * 0.8))
        if kind == "whoosh":
            return self._cached(("whoosh",), lambda: whoosh(0.6, False, 5))
        if kind == "note":
            m = p["m"]
            return self._cached(("note", m), lambda: bell(_midi(m), 1.4))
        raise KeyError(kind)

    def _cached(self, key, fn):
        if key not in self._cache:
            self._cache[key] = fn()
        return self._cache[key]

    # ------------------------------------------------------- render
    LEVELS = {"note": 0.7, "escape": 0.8, "bounce": 0.32, "racer": 0.22, "hit": 0.42, "break": 0.85,
              "die": 0.55, "spawn": 0.25, "boost": 0.4, "count": 0.45,
              "go": 0.55, "win": 0.75, "whoosh": 0.4}
    MODERN_LEVELS = {"note": 0.9, "bounce": 0.5, "racer": 0.3, "hit": 0.55, "break": 0.9, "escape": 0.75,
                     "die": 0.6, "spawn": 0.3, "boost": 0.45, "count": 0.55, "go": 0.6,
                     "win": 1.0, "whoosh": 0.45}
    # how many of one kind may start inside the same 1/60 s (keeps it clean)
    MAX_PER_TICK = {"bounce": 3, "hit": 2, "racer": 2}

    def render(self, duration, path):
        n = int(duration * SR)
        mix = np.zeros((n + SR * 3, 2))
        ticks = {}
        for t, kind, p in sorted(self.events, key=lambda e: e[0]):
            if t >= duration:
                continue
            tk = (kind, int(t * 60))
            lim = self.MAX_PER_TICK.get(kind)
            if lim:
                ticks[tk] = ticks.get(tk, 0) + 1
                if ticks[tk] > lim:
                    continue
            s = self._voice(t, kind, p)
            if s.ndim == 1:
                pan = min(1, max(0, p["pan"]))
                l, r = np.cos(pan * np.pi / 2), np.sin(pan * np.pi / 2)
                s = np.stack([s * l, s * r], 1) * 1.41
            levels = self.MODERN_LEVELS if self.style == "modern" else self.LEVELS
            g = levels.get(kind, 0.5) * p["gain"]
            o = int(round(t * SR))  # exact sample of the physics event
            seg = s[: len(mix) - o]
            mix[o:o + len(seg)] += seg * g
        mix = mix[:n]
        mix = _reverb(mix, wet=0.14 if self.style == "playful" else 0.08)
        if self.music_file:
            bed = _read_wav(self.music_file)
            if bed.ndim == 1:
                bed = np.stack([bed, bed], 1)
            reps = int(np.ceil(n / len(bed)))
            bed = np.tile(bed, (reps, 1))[:n]
            mix += bed * 0.35
        elif self.music and self.style == "modern":
            mix += MOD.bed(duration, self.harmony, self.climax_t, self.seed)
        elif self.music:
            mix += music_bed(duration, self.harmony, self.seed)
        mix = _master(mix)
        _write_wav(path, mix)
        return path


def _pad_mix(a, b):
    n = max(len(a), len(b))
    return np.pad(a, (0, n - len(a))) + np.pad(b, (0, n - len(b)))


def _reverb(x, wet=0.15, length=1.4, seed=1):
    rng = np.random.default_rng(seed)
    n = int(length * SR)
    t = np.arange(n) / SR
    ir = rng.standard_normal((n, 2)) * np.exp(-t / 0.35)[:, None]
    # darker tail
    spec = np.fft.rfft(ir, axis=0)
    f = np.fft.rfftfreq(n, 1 / SR)
    spec *= (1 / (1 + (f / 4000) ** 2))[:, None]
    ir = np.fft.irfft(spec, n, axis=0)
    ir /= np.sqrt(np.sum(ir ** 2, 0)) + 1e-9
    L = len(x) + n
    N = 1 << (L - 1).bit_length()
    X = np.fft.rfft(x, N, axis=0)
    H = np.fft.rfft(ir, N, axis=0)
    y = np.fft.irfft(X * H, N, axis=0)[: len(x)]
    return x + wet * y


def _master(x):
    """Loudness up, peaks controlled, no clipping."""
    ref = np.percentile(np.abs(x), 99.7) + 1e-9
    x = x / ref * 0.45
    drive = 1.0
    x = np.tanh(drive * x) / np.tanh(drive)
    return x * 0.92


def _write_wav(path, x):
    x = np.clip(x, -1, 1)
    data = (x * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(data.tobytes())


def _read_wav(path):
    with wave.open(path, "rb") as w:
        ch, sw, sr, nf = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        raw = w.readframes(nf)
    dt = {1: np.int8, 2: np.int16, 4: np.int32}[sw]
    x = np.frombuffer(raw, dt).astype(np.float64) / float(np.iinfo(dt).max)
    x = x.reshape(-1, ch)
    if sr != SR:  # simple resample
        idx = np.arange(0, len(x), sr / SR)
        x = np.stack([np.interp(idx, np.arange(len(x)), x[:, c]) for c in range(ch)], 1)
    return x if ch == 2 else x[:, 0]
