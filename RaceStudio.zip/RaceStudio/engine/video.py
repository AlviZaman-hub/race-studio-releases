"""Frame output: pygame surfaces -> ffmpeg -> MP4, then audio muxed in."""
import os
import subprocess
import shutil

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
import pygame  # noqa: E402


def ffmpeg_bin():
    exe = shutil.which("ffmpeg")
    if not exe:
        try:
            import imageio_ffmpeg
            exe = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            exe = None
    if not exe:
        raise SystemExit("ffmpeg not found. Install it and make sure it's on PATH.")
    return exe


class VideoWriter:
    def __init__(self, path, w, h, fps, quality="good"):
        self.path = path
        self.tmp = path + ".noaudio.mp4"
        preset = {"fast": "ultrafast", "good": "veryfast", "best": "slow"}[quality]
        crf = {"fast": "23", "good": "18", "best": "16"}[quality]
        self.proc = subprocess.Popen(
            [ffmpeg_bin(), "-y", "-loglevel", "error",
             "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(fps),
             "-i", "-",
             "-c:v", "libx264", "-preset", preset, "-crf", crf,
             "-pix_fmt", "yuv420p", "-r", str(fps), self.tmp],
            stdin=subprocess.PIPE)

    def write(self, surface):
        self.proc.stdin.write(pygame.image.tobytes(surface, "RGB"))

    def close(self, wav_path=None):
        self.proc.stdin.close()
        self.proc.wait()
        if wav_path:
            subprocess.run(
                [ffmpeg_bin(), "-y", "-loglevel", "error", "-i", self.tmp, "-i", wav_path,
                 "-c:v", "copy", "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-ar", "48000",
                 "-c:a", "aac", "-b:a", "256k",
                 "-shortest", "-movflags", "+faststart", self.path], check=True)
            os.remove(self.tmp)
        else:
            os.replace(self.tmp, self.path)
        return self.path
