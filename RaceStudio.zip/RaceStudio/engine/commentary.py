"""On-screen commentary: short punchy pop-ups at the moments that matter
(lead changes, eliminations, final duel, last stretch). Lines come from Gemini once per
video (about 0.05 cents) or from built-in templates. Also counts drama for batch ranking."""
import math
import random

from . import visual as V
from .video import pygame

W, H = 1080, 1920

TEMPLATES = {
    "start": ["HERE WE GO!", "PICK ONE NOW!", "WHO'S YOUR PICK?", "LOCK IT IN!"],
    "lead": ["{name} TAKES THE LEAD!", "{name} IN FRONT!", "{name} PULLS AHEAD!", "NEW LEADER: {name}!", "{name} IS COOKING!"],
    "comeback": ["{name} IS BACK?!", "COMEBACK BY {name}!", "DON'T COUNT {name} OUT!", "{name} FROM NOWHERE!"],
    "out": ["{name} IS OUT!", "BYE BYE {name}", "{name} ELIMINATED!", "NOT {name}!", "RIP {name}"],
    "final2": ["FINAL TWO!", "ONE ON ONE!", "IT'S A DUEL!"],
    "close": ["SO CLOSE!", "NECK AND NECK!", "THIS IS TIGHT!", "TOO CLOSE TO CALL!"],
    "final": ["FINAL STRETCH!", "ALMOST THERE!", "LAST CHANCE!"],
    "big": ["HUGE!", "WHAT A HIT!", "BOOM!", "INSANE!"],
    "jackpot": ["JACKPOT!", "100 POINTS!", "MASSIVE!", "NO WAY!"],
    "eat": ["{name} ATE SOMEONE!", "{name} IS HUNGRY!", "GULP!", "{name} GOT BIGGER!"],
    "spin": ["{name} SPUN OUT!", "OIL SLICK!", "{name} WENT SPINNING!", "WATCH THE OIL!"],
    "ladder": ["{name} CLIMBS!", "LADDER FOR {name}!", "{name} SKIPS AHEAD!", "UP GOES {name}!"],
    "snake": ["{name} GOT BITTEN!", "SNAKE! BYE {name}", "DOWN GOES {name}!", "NOT THE SNAKE!"],
    "flip": ["FLIP IT!", "AND AGAIN!", "WATCH THIS!", "ONE MORE TIME!"],
    "half": ["HALFWAY THERE!", "KEEP GOING!", "SO SATISFYING"],
}
LAST = None
COLORS = [(255, 210, 60), (255, 255, 255), (120, 230, 255), (255, 120, 170)]


class Commentary:
    def __init__(self, cfg, sound=None, lines=None, y=None):
        self.on = cfg.get("commentary", True)
        self.sound = sound
        self.rng = random.Random(cfg.get("seed", 0) * 13 + 5)
        self.lines = dict(TEMPLATES)
        for k, v in (lines or cfg.get("commentary_lines") or {}).items():
            if v:
                self.lines[k] = list(v)
        self.used = {}
        self.pops = []          # (t0, text, color)
        self.last_t = -9.0
        self.leader = None
        self.lead_since = 0.0
        self.lead_hist = []
        self.drama = 0.0
        self.events = 0
        self.y = y if y is not None else cfg.get("commentary_y", 470)
        self.gap = 2.2
        global LAST
        LAST = self
        if self.on and cfg.get("hook", True):
            self.say(0.35, "start", force=True, weight=0)

    # -------------------------------------------------- events
    def _line(self, kind, **kw):
        opts = self.lines.get(kind) or TEMPLATES.get(kind) or [kind.upper()]
        used = self.used.setdefault(kind, [])
        fresh = [o for o in opts if o not in used] or opts
        s = self.rng.choice(fresh)
        used.append(s)
        try:
            s = s.format(**{k: str(v).upper() for k, v in kw.items()})
        except (KeyError, IndexError):
            pass
        # the display font has no emoji: drop them (and stray variation selectors)
        s = "".join(ch for ch in s if ord(ch) < 0x2190 or ch in "’…").strip()
        return " ".join(s.split())

    def say(self, t, kind, force=False, weight=1.0, **kw):
        self.drama += weight
        self.events += 1
        if not self.on or (not force and t - self.last_t < self.gap):
            return False
        self.last_t = t
        self.pops.append((t, self._line(kind, **kw), self.rng.choice(COLORS)))
        if self.sound is not None:
            self.sound.add(t, "whoosh", gain=0.5)
        return True

    def lead(self, t, name, hold=0.5):
        """Call every frame with the current leader's name; announces stable lead changes."""
        if name is None:
            return
        if name != self.leader:
            if self.leader is not None and t - self.lead_since >= hold:
                # announce once the new leader has held it a moment: we do that next frames
                pass
            self.leader, self.lead_since = name, t
            self._announced = False
            return
        if not getattr(self, "_announced", True) and t - self.lead_since >= hold and t > 2.0:
            self._announced = True
            back = name in self.lead_hist[-6:-1] if self.lead_hist else False
            self.lead_hist.append(name)
            if len(self.lead_hist) > 1:
                self.say(t, "comeback" if back else "lead", weight=1.5, name=name)

    def out(self, t, name, left=None):
        if left == 2:
            self.say(t, "final2", force=True, weight=2)
        else:
            self.say(t, "out", force=left is not None and left <= 3, weight=1.2, name=name)

    # -------------------------------------------------- drawing
    def draw(self, dst, t):
        keep = []
        for (t0, text, col) in self.pops:
            age = t - t0
            if age < 0:
                keep.append((t0, text, col))
                continue
            if age > 1.6:
                continue
            keep.append((t0, text, col))
            u = min(1.0, age / 0.18)
            scale = 0.6 + 0.5 * u - 0.1 * max(0.0, (age - 0.18) / 0.15) if age < 0.33 else 1.0
            alpha = 255 if age < 1.25 else int(255 * (1 - (age - 1.25) / 0.35))
            size = 74 if len(text) < 14 else 60 if len(text) < 20 else 48
            txt = V.text(text, size, col, (0, 0, 0), weight="Display")
            surf = pygame.Surface((txt.get_width() + 56, txt.get_height() + 22), pygame.SRCALPHA)
            pygame.draw.rect(surf, (8, 9, 14, 200), surf.get_rect(), border_radius=surf.get_height() // 2)
            pygame.draw.rect(surf, (*col, 255), surf.get_rect(), 4, border_radius=surf.get_height() // 2)
            surf.blit(txt, (28, 11))
            if abs(scale - 1) > 0.01:
                surf = pygame.transform.rotozoom(surf, 0, scale)
            ang = math.sin(t0 * 7.1) * 4
            surf = pygame.transform.rotozoom(surf, ang, 1)
            surf.set_alpha(max(0, alpha))
            V.blit_center(dst, surf, W / 2, self.y - 10 * (1 - u))
        self.pops = keep
