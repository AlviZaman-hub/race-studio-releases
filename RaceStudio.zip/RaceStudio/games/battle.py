"""Ball Battle Royale: balls with health bars fight with spinning swords, daggers or spikes.
Blade hits deal damage scaled by impact speed, blades clash and reverse spin, KOs explode.
Last ball standing wins.
"""
import math
import random

import pymunk

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_winner, _draw_title
import pygame.gfxdraw as gfx

THEMES = {
    "arena": {"bg1": "#07070c", "bg2": "#20182e", "floor": "#121019", "ring": "#e8e4f2"},
    "blood": {"bg1": "#0a0303", "bg2": "#2e0a0a", "floor": "#160909", "ring": "#ff4d4d"},
    "steel": {"bg1": "#05080c", "bg2": "#1b2633", "floor": "#0e141b", "ring": "#9fb4cc"},
    "neon": {"bg1": "#030309", "bg2": "#12093a", "floor": "#0b0820", "ring": "#00e5ff"},
}
RANDOM_THEMES = list(THEMES)

CX, CY, AR = W / 2, 1060, 470
CT_BALL, CT_BLADE, CT_WALL = 1, 2, 3
BIT_BALL, BIT_BLADE, BIT_WALL = 1, 2, 4
WEAPONS = {
    "sword": {"len": 2.05, "spin": 3.4, "dmg": 9.0},
    "dagger": {"len": 1.35, "spin": 6.0, "dmg": 6.0},
    "spikes": {"len": 0.0, "spin": 1.2, "dmg": 0.0},
}


class Fighter:
    def __init__(self, i, look, r, weapon, rng):
        self.i, self.look, self.r, self.weapon = i, look, r, weapon
        self.hp = self.max_hp = 100.0
        self.alive = True
        self.spin = rng.choice([-1, 1])
        self.rage = 0.0
        self.flash = 0.0
        self.kos = 0
        self.ko_time = None
        self.cool = {}
        self.body = pymunk.Body(1.0, pymunk.moment_for_circle(1.0, 0, r))
        self.ball = pymunk.Circle(self.body, r)
        self.ball.elasticity, self.ball.friction, self.ball.collision_type = 1.0, 0.0, CT_BALL
        self.ball.filter = pymunk.ShapeFilter(categories=BIT_BALL, mask=BIT_BALL | BIT_BLADE | BIT_WALL)
        self.ball.f = self
        self.blade = None
        w = WEAPONS[weapon]
        if w["len"] > 0:
            self.blade = pymunk.Segment(self.body, (r * 0.85, 0), (r * (0.85 + w["len"]), 0), max(4, r * 0.12))
            self.blade.elasticity, self.blade.friction, self.blade.collision_type = 1.0, 0.0, CT_BLADE
            self.blade.filter = pymunk.ShapeFilter(categories=BIT_BLADE, mask=BIT_BALL | BIT_BLADE)
            self.blade.f = self

    x = property(lambda s: s.body.position.x)
    y = property(lambda s: s.body.position.y)


class Sim:
    def __init__(self, looks, seed, hp_scale=1.0, speed=600, sound=None, fx=None, weapons=None):
        self.rng = random.Random(seed * 11 + 3)
        self.sound, self.fx = sound, fx
        self.speed = speed
        self.now = 0.0
        self.clock = 0.0
        self.todo = []
        self.popups = []
        self.events = []
        n = len(looks)
        r = 68 if n <= 2 else 58 if n <= 4 else 49 if n <= 6 else 42
        self.r = r
        sp = pymunk.Space()
        sp.iterations = 20
        self.space = sp
        seg = 120
        for k in range(seg):
            a0, a1 = 2 * math.pi * k / seg, 2 * math.pi * (k + 1) / seg
            s = pymunk.Segment(sp.static_body, (CX + math.cos(a0) * AR, CY + math.sin(a0) * AR),
                               (CX + math.cos(a1) * AR, CY + math.sin(a1) * AR), 6)
            s.elasticity, s.friction, s.collision_type = 1.0, 0.0, CT_WALL
            s.filter = pymunk.ShapeFilter(categories=BIT_WALL, mask=BIT_BALL)
            sp.add(s)
        self.f = []
        for i, lk in enumerate(looks):
            wpn = (weapons[i] if weapons and i < len(weapons) else None) or self.rng.choice(["sword", "sword", "dagger", "spikes"])
            F = Fighter(i, lk, r, wpn, self.rng)
            F.hp = F.max_hp = 100.0 * hp_scale
            a = 2 * math.pi * i / n + self.rng.uniform(-0.2, 0.2)
            F.body.position = (CX + math.cos(a) * AR * 0.55, CY + math.sin(a) * AR * 0.55)
            d = a + math.pi + self.rng.uniform(-0.8, 0.8)
            F.body.velocity = (math.cos(d) * speed, math.sin(d) * speed)
            F.body.angle = self.rng.uniform(0, 6.28)
            sp.add(F.body, F.ball)
            if F.blade:
                sp.add(F.blade)
            self.f.append(F)
        sp.on_collision(CT_BLADE, CT_BALL, post_solve=self._blade_ball)
        sp.on_collision(CT_BLADE, CT_BLADE, post_solve=self._clash)
        sp.on_collision(CT_BALL, CT_BALL, post_solve=self._bump)
        sp.on_collision(CT_BALL, CT_WALL, post_solve=self._wall)
        self.orbs = []
        self.next_orb = 6.0
        self.winner = None

    def alive(self):
        return [F for F in self.f if F.alive]

    def _ev(self, kind, F=None, x=None, **kw):
        if self.sound is not None:
            xx = x if x is not None else (F.x if F else W / 2)
            self.sound.add(self.now, kind, who=F.i if F else None, pan=0.15 + 0.7 * xx / W, **kw)

    @staticmethod
    def _imp(arb):
        j = arb.total_impulse
        return math.hypot(j.x, j.y)

    def _blade_ball(self, arb, space, data):
        att, vic = arb.shapes[0].f, arb.shapes[1].f
        if att is vic or not arb.is_first_contact:
            return
        if self.clock - att.cool.get(vic.i, -9) < 0.22:
            return
        att.cool[vic.i] = self.clock
        rel = (att.body.velocity - vic.body.velocity).length
        dmg = WEAPONS[att.weapon]["dmg"] * (0.8 + rel / 1400) * (1.6 if att.rage > 0 else 1.0)
        n = arb.normal
        self.todo.append(("dmg", vic, dmg, att, (n.x, n.y)))

    def _clash(self, arb, space, data):
        if arb.is_first_contact:
            a, b = arb.shapes[0].f, arb.shapes[1].f
            self.todo.append(("clash", a, b, arb.contact_point_set.points[0].point_a if arb.contact_point_set.points else a.body.position))

    def _bump(self, arb, space, data):
        if not arb.is_first_contact:
            return
        a, b = arb.shapes[0].f, arb.shapes[1].f
        imp = self._imp(arb)
        if imp > 60:
            self._ev("racer", a, x=(a.x + b.x) / 2, min_gap=0.08)
        for att, vic in ((a, b), (b, a)):
            if att.weapon == "spikes" and self.clock - att.cool.get(vic.i, -9) > 0.22:
                att.cool[vic.i] = self.clock
                self.todo.append(("dmg", vic, 8.0 * (1.6 if att.rage > 0 else 1.0), att, (0, 0)))

    def _wall(self, arb, space, data):
        if arb.is_first_contact and self._imp(arb) > 80:
            F = arb.shapes[0].f
            self._ev("bounce", F, min_gap=0.07, gain=0.6)

    def _apply(self):
        todo, self.todo = self.todo, []
        for it in todo:
            if it[0] == "dmg":
                _, vic, dmg, att, nrm = it
                if not vic.alive:
                    continue
                vic.hp -= dmg
                vic.flash = 1.0
                self.popups.append([vic.x, vic.y - vic.r - 30, f"-{int(round(dmg))}", 0.0, att.look.color if att.look else (255, 255, 255)])
                self._ev("hit", vic, gain=min(1.0, 0.5 + dmg / 20))
                if nrm != (0, 0):
                    vic.body.apply_impulse_at_local_point((nrm[0] * 220, nrm[1] * 220))
                if self.fx and vic.look:
                    self.fx.burst(vic.x, vic.y, vic.look.color, n=8, speed=380, size=(5, 10), life=(0.25, 0.5))
                if vic.hp <= 0:
                    self._ko(vic, att)
            elif it[0] == "clash":
                _, a, b, pt = it
                a.spin *= -1
                b.spin *= -1
                self._ev("count", a, x=pt.x, min_gap=0.06)
                if self.fx:
                    self.fx.burst(pt.x, pt.y, (255, 230, 150), n=12, speed=520, size=(3, 7), life=(0.15, 0.35), gravity=0)

    def _ko(self, vic, att):
        vic.alive = False
        vic.hp = 0
        vic.ko_time = self.clock
        att.kos += 1
        self.space.remove(vic.body, vic.ball, *([vic.blade] if vic.blade else []))
        self._ev("break", vic)
        self.popups.append([vic.x, vic.y - 20, "K.O.", 0.0, (255, 255, 255)])
        if self.fx and vic.look:
            self.fx.burst(vic.x, vic.y, vic.look.color, n=46, speed=760, size=(8, 18))
        if len(self.alive()) == 1:
            self.winner = self.alive()[0]

    def _orbs(self, dt):
        self.next_orb -= dt
        if self.next_orb <= 0:
            self.next_orb = self.rng.uniform(5, 8)
            a, rr = self.rng.uniform(0, 6.28), self.rng.uniform(0, AR * 0.6)
            self.orbs.append({"x": CX + math.cos(a) * rr, "y": CY + math.sin(a) * rr,
                              "kind": self.rng.choice(["heal", "rage"]), "age": 0.0})
        for o in list(self.orbs):
            o["age"] += dt
            for F in self.alive():
                if math.hypot(F.x - o["x"], F.y - o["y"]) < F.r + 22:
                    self.orbs.remove(o)
                    self._ev("boost", F)
                    if o["kind"] == "heal":
                        F.hp = min(F.max_hp, F.hp + F.max_hp * 0.25)
                        self.popups.append([F.x, F.y - F.r - 30, "+HP", 0.0, (90, 255, 140)])
                    else:
                        F.rage = 4.0
                        self.popups.append([F.x, F.y - F.r - 30, "RAGE!", 0.0, (255, 90, 60)])
                    break
        self.orbs = [o for o in self.orbs if o["age"] < 9]

    def step(self, dt, now):
        self.now = now
        self.clock += dt
        for F in self.alive():
            F.body.angular_velocity = WEAPONS[F.weapon]["spin"] * F.spin * (1.5 if F.rage > 0 else 1)
        self.space.step(dt)
        self._apply()
        for F in self.alive():
            F.flash = max(0, F.flash - dt * 5)
            F.rage = max(0, F.rage - dt)
            v = F.body.velocity
            sp = v.length or 1
            target = self.speed * (1.25 if F.rage > 0 else 1)
            k = 1 + (target / sp - 1) * min(1, dt * 4)
            F.body.velocity = v * k
            # keep inside the arena even after big knockbacks
            dx, dy = F.x - CX, F.y - CY
            d = math.hypot(dx, dy)
            if d > AR - F.r:
                F.body.position = (CX + dx / d * (AR - F.r - 1), CY + dy / d * (AR - F.r - 1))
        self._orbs(dt)


def tune(seed, looks_n, t_min, t_max, weapons=None):
    target = (t_min + t_max) / 2
    scale = 1.0
    best = None
    for _ in range(12):
        S = Sim([None] * looks_n, seed, scale, weapons=weapons)
        t = 0.0
        while S.winner is None and t < t_max * 2.5:
            S.step(1 / 240, t)
            t += 1 / 240
        if S.winner is not None:
            if best is None or abs(t - target) < abs(best[1] - target):
                best = (scale, t)
            if t_min <= t <= t_max:
                return scale, t
            scale *= max(0.5, min(2.0, (target / t) ** 0.85))
        else:
            scale *= 0.5
    return best if best else (scale, t_max)


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    weapons = cfg.get("weapons")
    hp_scale, est = tune(cfg["seed"], n, t_min, t_max, weapons)
    print(f"  HP x{hp_scale:.2f}, battle ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["arena"])
    run = Runner(cfg, out_path, sound, est + 4.5, th)
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    S = Sim(looks, cfg["seed"], hp_scale, sound=sound, fx=fx, weapons=weapons)
    title_lines = _wrap(cfg.get("title") or "LAST BALL STANDING WINS", 22)
    handle = cfg.get("handle", "")
    T = {k: V.hexc(v) for k, v in th.items()}
    sound.add(0.0, "go")
    win_time = None
    duel_t = None
    while True:
        t = run.t
        if win_time is None:
            for i in range(run.sub):
                S.step(run.dt / run.sub, t + i * run.dt / run.sub)
            if len(S.alive()) == 2 and duel_t is None and n > 2:
                duel_t = t
                sound.add(t, "whoosh")
            if S.winner is not None:
                win_time = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        gfx.filled_circle(cv, int(CX), int(CY), int(AR + 14), V.darker(T["ring"], 0.35))
        gfx.filled_circle(cv, int(CX), int(CY), int(AR), T["floor"])
        for k in range(3):
            gfx.aacircle(cv, int(CX), int(CY), int(AR + k), T["ring"])
        for o in S.orbs:
            pulse = 1 + 0.15 * math.sin(o["age"] * 8)
            col = (90, 255, 140) if o["kind"] == "heal" else (255, 90, 60)
            gfx.filled_circle(cv, int(o["x"]), int(o["y"]), int(17 * pulse), col)
            gfx.aacircle(cv, int(o["x"]), int(o["y"]), int(17 * pulse), (255, 255, 255))
            V.blit_center(cv, V.text("+" if o["kind"] == "heal" else "!", 26, (10, 10, 14), None), o["x"], o["y"])
        for F in S.alive():
            _draw_fighter(cv, F)
        for F in S.alive():
            _hp_bar(cv, F)
        fx.draw(cv)
        for p in S.popups:
            p[3] += run.dt
            a = p[3]
            if a < 0.9:
                s = V.text(p[2], 46 if p[2] != "K.O." else 90, p[4], (0, 0, 0), weight="Display")
                s.set_alpha(int(255 * min(1, (0.9 - a) * 3)))
                V.blit_center(cv, s, p[0], p[1] - a * 70)
        S.popups = [p for p in S.popups if p[3] < 0.9]
        y = _draw_title(cv, title_lines, t)
        if win_time is None:
            V.blit_center(cv, V.text(f"{len(S.alive())} LEFT", 44, (255, 210, 120), (0, 0, 0)), W / 2, y + 6)
        _roster(cv, S)
        if handle:
            V.blit_center(cv, V.text(handle, 30, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1840)
        if duel_t is not None and win_time is None and t - duel_t < 1.2:
            a = min(1, (t - duel_t) / 0.15)
            V.blit_center(cv, V.text("FINAL DUEL", int(150 * (0.7 + 0.3 * a)), (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, CY)
        if win_time is not None:
            w = S.winner
            _draw_winner(cv, w, t - win_time + 0.8, T, line3=f"{w.kos} K.O.{'s' if w.kos != 1 else ''} · {int(w.hp)} HP left")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > t_max * 3:
            raise RuntimeError("Battle ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": S.winner.look.name, "level": cfg["seed"]}


def _draw_fighter(cv, F):
    x, y, r = F.x, F.y, F.r
    a = F.body.angle
    if F.blade is not None:
        L = r * (0.85 + WEAPONS[F.weapon]["len"])
        ca, sa = math.cos(a), math.sin(a)
        nx, ny = -sa, ca
        w = max(4, r * 0.16)
        base = r * 0.75
        tip = (x + ca * L, y + sa * L)
        p0 = (x + ca * base + nx * w, y + sa * base + ny * w)
        p1 = (x + ca * (L - w * 2) + nx * w * 0.8, y + sa * (L - w * 2) + ny * w * 0.8)
        p3 = (x + ca * (L - w * 2) - nx * w * 0.8, y + sa * (L - w * 2) - ny * w * 0.8)
        p4 = (x + ca * base - nx * w, y + sa * base - ny * w)
        blade_col = (226, 232, 242) if F.rage <= 0 else (255, 140, 110)
        gfx.filled_polygon(cv, [p0, p1, tip, p3, p4], blade_col)
        gfx.aapolygon(cv, [p0, p1, tip, p3, p4], (120, 126, 140))
        g0 = (x + ca * base + nx * w * 2.4, y + sa * base + ny * w * 2.4)
        g1 = (x + ca * base - nx * w * 2.4, y + sa * base - ny * w * 2.4)
        pygame.draw.line(cv, V.darker(F.look.color, 0.6), g0, g1, max(4, int(w * 0.9)))
    elif F.weapon == "spikes":
        for k in range(9):
            b = a + 2 * math.pi * k / 9
            ca, sa = math.cos(b), math.sin(b)
            nx, ny = -sa, ca
            tip = (x + ca * r * 1.45, y + sa * r * 1.45)
            l = (x + ca * r * 0.92 + nx * r * 0.22, y + sa * r * 0.92 + ny * r * 0.22)
            rr = (x + ca * r * 0.92 - nx * r * 0.22, y + sa * r * 0.92 - ny * r * 0.22)
            gfx.filled_polygon(cv, [l, tip, rr], (200, 206, 220))
            gfx.aapolygon(cv, [l, tip, rr], (110, 116, 130))
    if F.rage > 0:
        gfx.filled_circle(cv, int(x), int(y), int(r * 1.18), (255, 80, 50, 70))
    F.look.draw_body(cv, x, y, 0.0, F.body.velocity.x, F.body.velocity.y, r * 2, "ball")
    if F.flash > 0:
        gfx.filled_circle(cv, int(x), int(y), int(r), (255, 255, 255, int(150 * F.flash)))


def _hp_bar(cv, F):
    w, h = F.r * 2.1, 12
    x0, y0 = F.x - w / 2, F.y - F.r - 26
    frac = max(0.0, F.hp / F.max_hp)
    col = (80, 230, 120) if frac > 0.5 else (255, 200, 60) if frac > 0.25 else (255, 70, 70)
    pygame.draw.rect(cv, (10, 10, 14), pygame.Rect(x0 - 2, y0 - 2, w + 4, h + 4), border_radius=6)
    pygame.draw.rect(cv, col, pygame.Rect(x0, y0, max(0, w * frac), h), border_radius=5)


def _roster(cv, S):
    n = len(S.f)
    slot = min(120, 980 // n)
    y = 1660
    x0 = W / 2 - slot * (n - 1) / 2
    for k, F in enumerate(sorted(S.f, key=lambda F: (not F.alive, -(F.ko_time or 0), -F.hp))):
        x = x0 + k * slot
        b = F.look.badge(int(slot * 0.5))
        if not F.alive:
            b = b.copy()
            b.set_alpha(70)
        V.blit_center(cv, b, x, y)
        w = slot * 0.62
        frac = max(0, F.hp / F.max_hp)
        pygame.draw.rect(cv, (20, 20, 26), pygame.Rect(x - w / 2, y + slot * 0.38, w, 8), border_radius=4)
        if frac > 0:
            pygame.draw.rect(cv, (80, 230, 120) if frac > 0.5 else (255, 200, 60) if frac > 0.25 else (255, 70, 70),
                             pygame.Rect(x - w / 2, y + slot * 0.38, w * frac, 8), border_radius=4)
        if not F.alive:
            d = slot * 0.22
            pygame.draw.line(cv, (235, 50, 60), (x - d, y - d), (x + d, y + d), 5)
            pygame.draw.line(cv, (235, 50, 60), (x - d, y + d), (x + d, y - d), 5)
