"""Bar Chart Race: animated ranking over time from REAL data.
Sources: World Bank Open Data (downloaded on your computer when you render, then cached),
or your own CSV (wide: name,1990,1991,... or long: name,year,value).
Numbers are never invented.
"""
import csv
import json
import math
import os
import time
import random
import shutil
import subprocess
import urllib.request
import zlib

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE = os.path.join(ROOT, "config", "_data")
WB = os.environ.get("RACESTUDIO_WB_API", "https://api.worldbank.org/v2")
DATASETS = {
    "Population": ("SP.POP.TOTL", ""),
    "GDP (US$)": ("NY.GDP.MKTP.CD", "$"),
    "GDP per person (US$)": ("NY.GDP.PCAP.CD", "$"),
    "Life expectancy (years)": ("SP.DYN.LE00.IN", ""),
    "Urban population": ("SP.URB.TOTL", ""),
    "Exports (US$)": ("NE.EXP.GNFS.CD", "$"),
    "Internet users (% of people)": ("IT.NET.USER.ZS", "%"),
}
THEMES = {
    "dark": {"bg1": "#06070c", "bg2": "#161a2c", "text": "#f2f4fa", "muted": "#8a90a6"},
    "navy": {"bg1": "#030a18", "bg2": "#0d2347", "text": "#f2f6ff", "muted": "#8fa3c6"},
    "plum": {"bg1": "#0c0510", "bg2": "#2c1238", "text": "#fbf3ff", "muted": "#a68fb2"},
}
RANDOM_THEMES = list(THEMES)
PALETTE = ["#ef476f", "#ffd166", "#06d6a0", "#118ab2", "#f78c6b", "#9b5de5", "#00bbf9", "#f15bb5",
           "#83e377", "#fee440", "#2ec4b6", "#ff9f1c", "#e76f51", "#8ecae6", "#c77dff"]


# ------------------------------------------------------------------ data
def _get(url, timeout=60):
    curl = shutil.which("curl")
    if curl:
        flags = 0x08000000 if os.name == "nt" else 0
        p = subprocess.run([curl, "-fsSL", "--max-time", str(timeout), url], capture_output=True, creationflags=flags)
        if p.returncode == 0:
            return p.stdout
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.read()


NAME_FIX = {"Korea, Rep.": "South Korea", "Korea, Dem. People's Rep.": "North Korea", "Russian Federation": "Russia",
            "Iran, Islamic Rep.": "Iran", "Egypt, Arab Rep.": "Egypt", "Venezuela, RB": "Venezuela", "Yemen, Rep.": "Yemen",
            "Hong Kong SAR, China": "Hong Kong", "Macao SAR, China": "Macao", "Congo, Dem. Rep.": "DR Congo",
            "Congo, Rep.": "Congo", "Lao PDR": "Laos", "Syrian Arab Republic": "Syria", "Viet Nam": "Vietnam",
            "Slovak Republic": "Slovakia", "Kyrgyz Republic": "Kyrgyzstan", "Turkiye": "Türkiye", "Czechia": "Czechia",
            "United States": "USA", "United Kingdom": "UK", "United Arab Emirates": "UAE", "Brunei Darussalam": "Brunei",
            "Micronesia, Fed. Sts.": "Micronesia", "Gambia, The": "Gambia", "Bahamas, The": "Bahamas"}


def nice_name(n):
    return NAME_FIX.get(n) or n.split(",")[0].strip()


def world_bank(code):
    """{name: {"iso2":.., "values": {year: value}}} for real countries only (no regions/aggregates)."""
    os.makedirs(CACHE, exist_ok=True)
    cpath = os.path.join(CACHE, f"wb_{code}.json")
    if os.path.exists(cpath) and time.time() - os.path.getmtime(cpath) < 14 * 86400:
        with open(cpath, encoding="utf-8") as f:
            cached = json.load(f)
        if len(cached) >= 5:
            return {nice_name(k): v for k, v in cached.items()}
    meta = json.loads(_get(f"{WB}/country?format=json&per_page=400"))[1]
    countries = {m["id"]: (m["name"], m.get("iso2Code", "")) for m in meta
                 if (m.get("region") or {}).get("value", "Aggregates") != "Aggregates"}
    rows = json.loads(_get(f"{WB}/country/all/indicator/{code}?format=json&per_page=20000&date=1960:2030"))
    if len(rows) < 2 or not rows[1]:
        raise RuntimeError("World Bank returned no data for this indicator")
    out = {}
    for r in rows[1]:
        iso3 = r.get("countryiso3code") or (r.get("country") or {}).get("id")
        if iso3 not in countries or r.get("value") is None:
            continue
        name, iso2 = countries[iso3]
        name = nice_name(name)
        d = out.setdefault(name, {"iso2": iso2, "values": {}})
        d["values"][str(int(r["date"]))] = float(r["value"])
    if len(out) < 5:
        raise RuntimeError("World Bank data came back nearly empty. Check your internet and try again.")
    with open(cpath, "w", encoding="utf-8") as f:
        json.dump(out, f)
    return out


def from_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    if not rows:
        raise RuntimeError("CSV is empty")
    head = [h.strip() for h in rows[0]]
    out = {}

    def num(x):
        x = str(x).replace(",", "").replace("$", "").replace("%", "").strip()
        return float(x) if x not in ("", "-", "NA", "nan") else None
    if len(head) == 3 and not head[1].strip().lstrip("-").isdigit():  # long format: name, time, value
        for r in rows[1:]:
            if len(r) >= 3 and num(r[2]) is not None:
                out.setdefault(r[0].strip(), {"iso2": "", "values": {}})["values"][r[1].strip()] = num(r[2])
    else:  # wide format: name, t1, t2, ...
        for r in rows[1:]:
            if not r or not r[0].strip():
                continue
            d = out.setdefault(r[0].strip(), {"iso2": "", "values": {}})
            for h, v in zip(head[1:], r[1:]):
                if num(v) is not None:
                    d["values"][h] = num(v)
    if not out:
        raise RuntimeError("No numbers found in the CSV")
    return out


def _times(data):
    ts = sorted({t for d in data.values() for t in d["values"]}, key=lambda s: (float(s) if _isnum(s) else 0, s))
    return ts


def _isnum(s):
    try:
        float(s)
        return True
    except ValueError:
        return False


def _series(data, times):
    """Fill gaps by linear interpolation (no extrapolation) -> {name: [v or None per time]}."""
    out = {}
    for name, d in data.items():
        vals = [d["values"].get(t) for t in times]
        known = [i for i, v in enumerate(vals) if v is not None]
        if not known:
            continue
        for a, b in zip(known, known[1:]):
            for i in range(a + 1, b):
                vals[i] = vals[a] + (vals[b] - vals[a]) * (i - a) / (b - a)
        out[name] = vals
    return out


def fmt(v, unit):
    a = abs(v)
    if unit == "%" or (a < 1000 and unit != "$"):
        s = f"{v:,.1f}" if a < 100 else f"{v:,.0f}"
        return s + ("%" if unit == "%" else "")
    for div, suf in ((1e12, "T"), (1e9, "B"), (1e6, "M"), (1e3, "K")):
        if a >= div:
            return f"{unit}{v / div:,.2f}{suf}" if a / div < 100 else f"{unit}{v / div:,.0f}{suf}"
    return f"{unit}{v:,.0f}"


def flag(iso2):
    if not iso2 or len(iso2) != 2 or not iso2.isalpha():
        return None
    return "".join(chr(0x1F1E6 + ord(c) - ord("A")) for c in iso2.upper())


# ------------------------------------------------------------------ render
def render(cfg, out_path, sound):
    rng = random.Random(cfg["seed"])
    unit = ""
    if cfg.get("csv"):
        data = from_csv(cfg["csv"])
        label = cfg.get("dataset_label") or os.path.splitext(os.path.basename(cfg["csv"]))[0]
        source = cfg.get("source", "Your data")
    else:
        label = cfg.get("dataset") if cfg.get("dataset") in DATASETS else rng.choice(list(DATASETS))
        code, unit = DATASETS[label]
        print(f"  downloading World Bank data: {label} …", flush=True)
        data = world_bank(code)
        source = "Source: World Bank Open Data (CC BY 4.0)"
    times = _times(data)
    y0, y1 = cfg.get("years", [None, None])
    if y0:
        times = [t for t in times if not _isnum(t) or float(t) >= float(y0)]
    if y1:
        times = [t for t in times if not _isnum(t) or float(t) <= float(y1)]
    series = _series({k: v for k, v in data.items()}, times)
    # drop trailing times where almost nobody has data yet
    while len(times) > 2 and sum(1 for s in series.values() if s[-1] is not None) < 5:
        times.pop()
        series = {k: v[:-1] for k, v in series.items()}
    if len(times) < 2:
        raise RuntimeError("Not enough time points in the data")
    top_n = int(cfg.get("top_n", 10))
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    race = (t_min + t_max) / 2
    hold = 3.5
    print(f"  {label}: {times[0]}–{times[-1]}, {len(series)} entries, top {top_n}")
    th = THEMES.get(cfg.get("theme"), THEMES["dark"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, race + hold, th)
    title_lines = _wrap(cfg.get("title") or f"{label.upper()}", 24)
    handle = cfg.get("handle", "")
    names = list(series)
    colors = {}
    for i, nm in enumerate(sorted(names, key=lambda s: sum(ord(c) for c in s))):
        colors[nm] = V.hexc(PALETTE[(zlib.crc32(nm.encode('utf-8')) + i) % len(PALETTE)])
    flags = {}
    for nm in names:
        f = flag(data[nm].get("iso2", ""))
        if f:
            try:
                raw = pygame.image.load(V.emoji_path(f)).convert_alpha()
                flags[nm] = pygame.transform.smoothscale(raw, (54, 54))
            except Exception:
                pass
    shown_rank = {}
    last_leader = None
    last_tick = -1
    X0, X1 = 70, 1010
    TOP, ROW = 420, 112
    bar_h = 84
    sound.add(0.0, "go")
    done_t = None
    while True:
        t = run.t
        prog = min(1.0, t / race)
        pos = prog * (len(times) - 1)
        i0 = int(math.floor(pos))
        i1 = min(len(times) - 1, i0 + 1)
        f = pos - i0
        cur = {}
        for nm, vals in series.items():
            a, b = vals[i0], vals[i1]
            if a is None and b is None:
                continue
            a = b if a is None else a
            b = a if b is None else b
            cur[nm] = a + (b - a) * f
        ranked = sorted(cur.items(), key=lambda kv: -kv[1])
        rank_of = {nm: r for r, (nm, _) in enumerate(ranked)}
        if i0 != last_tick and prog < 1.0:
            last_tick = i0
            sound.add(t, "count")
        if ranked and ranked[0][0] != last_leader:
            if last_leader is not None and prog < 1.0:
                sound.add(t, "escape")
            last_leader = ranked[0][0]
        if prog >= 1.0 and done_t is None:
            done_t = t
            sound.climax(t)
            sound.add(t, "win")
        vmax = max([v for _, v in ranked[:top_n]] + [1e-9])
        run.clear()
        cv = run.canvas
        y = _draw_title(cv, title_lines, t)
        # bars (smooth rank changes)
        for nm, v in ranked[: top_n + 2]:
            target = rank_of[nm]
            r = shown_rank.get(nm, target)
            r += (target - r) * min(1.0, run.dt * 6)
            shown_rank[nm] = r
            if r > top_n - 0.01:
                continue
            yy = TOP + r * ROW
            w = max(6, (X1 - X0 - 220) * v / vmax)
            col = colors[nm]
            rect = pygame.Rect(X0 + 60, yy, w, bar_h)
            pygame.draw.rect(cv, V.darker(col, 0.55), rect.move(0, 5), border_radius=10)
            pygame.draw.rect(cv, col, rect, border_radius=10)
            pygame.draw.rect(cv, V.lighter(col, 0.3), pygame.Rect(rect.x, rect.y, rect.w, 8), border_radius=6)
            if nm in flags:
                V.blit_center(cv, flags[nm], X0 + 28, yy + bar_h / 2)
            label_s = V.text(nm if len(nm) <= 22 else nm[:21] + "…", 34, (255, 255, 255), (0, 0, 0), weight="ExtraBold")
            vs = V.text(fmt(v, unit), 32, T["text"], (0, 0, 0), weight="Medium")
            cy_ = yy + bar_h / 2
            if label_s.get_width() + 30 < w:  # name inside the bar, value after it
                cv.blit(label_s, (rect.x + 14, cy_ - label_s.get_height() / 2))
                cv.blit(vs, (rect.right + 12, cy_ - vs.get_height() / 2))
            else:  # short bar: name then value to the right
                cv.blit(label_s, (rect.right + 12, cy_ - label_s.get_height() / 2))
                cv.blit(vs, (rect.right + 24 + label_s.get_width(), cy_ - vs.get_height() / 2))
        # big time label
        cur_t = times[min(len(times) - 1, int(round(pos)))]
        V.blit_center(cv, V.text(str(cur_t), 170, T["text"], (0, 0, 0), weight="Display"), W - 230, TOP + top_n * ROW - 40)
        V.blit_center(cv, V.text(source, 26, T["muted"], None, weight="Medium"), W / 2, 1800)
        if handle:
            V.blit_center(cv, V.text(handle, 30, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1850)
        run.push()
        if done_t is not None and t - done_t >= hold:
            break
    dur = run.finish()
    return {"duration": dur, "winner": ranked[0][0] if ranked else "-", "level": cfg["seed"]}
