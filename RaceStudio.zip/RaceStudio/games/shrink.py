"""Shrinking Arena: balls bounce inside a spinning ring with one gap. The ring keeps
shrinking; anyone who slips out through the gap is eliminated. Last one inside wins.
"""
import math
import random

import pymunk

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner
import pygame.gfxdraw as gfx

THEMES = {
    "void": {"bg1": "#030306", "bg2": "#161626", "floor": "#0d0d18", "ring": "#f2f2f7", "gap": "#ff3b4e"},
    "toxic": {"bg1": "#020803", "bg2": "#0d2a12", "floor": "#071309", "ring": "#7dff6a", "gap": "#ff3bd0"},
    "lava": {"bg1": "#0c0301", "bg2": "#3a0d03", "floor": "#160603", "ring": "#ffb347", "gap": "#ff2a2a"},
    "ice": {"bg1": "#020a10", "bg2": "#0c2c40", "floor": "#061520", "ring": "#bfe9ff", "gap": "#ff5c8a"},
}
RANDOM_THEMES = list(THEMES)
CX, CY = W / 2, 1050
R_START, R_MIN = 470.0, 150.0


class Ball:
    def __init__(self, i, look, r, rng):
        self.i, self.look, self.r = i, look, r
        self.body = pymunk.Body(1.0, pymunk.moment_for_circle(1.0, 0, r))
        self.shape = pymunk.Circle(self.body, r)
        self.shape.elasticity, self.shape.friction, self.shape.collision_type = 1.0, 0.3, 1
        self.shape.ball = self
        self.alive = True
        self.out_time = None
        self.place = None
        self.trail = []

    x = property(lambda s: s.body.position.x)
    y = property(lambda s: s.body.position.y)


class Sim:
    def __init__(self, looks, seed, gap=0.55, shrink_time=26.0, speed=560, sound=None, fx=None):
        self.rng = random.Random(seed * 3 + 9)
        self.sound, self.fx = sound, fx
        self.gap = gap
        self.shrink_time = shrink_time
        self.speed = speed
        self.clock = 0.0
        self.now = 0.0
        self.R = R_START
        self.rot = self.rng.uniform(0, 6.28)
        self.w = self.rng.choice([-1, 1]) * self.rng.uniform(0.7, 1.1)
        sp = pymunk.Space()
        sp.iterations = 20
        self.space = sp
        self.ring_body = pymunk.Body(body_type=pymunk.Body.KINEMATIC)
        self.ring_body.position = (CX, CY)
        sp.add(self.ring_body)
        self.ring_shapes = []
        self._build_ring()
        n = len(looks)
        r = 40 if n <= 3 else 34 if n <= 5 else 29
        self.balls = []
        for i, lk in enumerate(looks):
            b = Ball(i, lk, r, self.rng)
            a = 2 * math.pi * i / n
            b.body.position = (CX + math.cos(a) * R_START * 0.45, CY + math.sin(a) * R_START * 0.45)
            d = self.rng.uniform(0, 6.28)
            b.body.velocity = (math.cos(d) * speed, math.sin(d) * speed)
            sp.add(b.body, b.shape)
            self.balls.append(b)
        sp.on_collision(1, 2, post_solve=self._wall)
        sp.on_collision(1, 1, post_solve=self._bump)
        self.out_order = []
        self.winner = None
        self.last_build = 0.0

    def alive(self):
        return [b for b in self.balls if b.alive]

    def _build_ring(self):
        if self.ring_shapes:
            self.space.remove(*self.ring_shapes)
        segs = 90
        span = 2 * math.pi - self.gap
        pts = [(math.cos(self.gap / 2 + span * i / segs) * self.R, math.sin(self.gap / 2 + span * i / segs) * self.R)
               for i in range(segs + 1)]
        self.ring_shapes = []
        for i in range(segs):
            s = pymunk.Segment(self.ring_body, pts[i], pts[i + 1], 5)
            s.elasticity, s.friction, s.collision_type = 1.0, 0.3, 2
            self.ring_shapes.append(s)
        self.space.add(*self.ring_shapes)

    def _ev(self, kind, b=None, **kw):
        if self.sound is not None:
            x = b.x if b else W / 2
            self.sound.add(self.now, kind, who=b.i if b else None, pan=0.15 + 0.7 * x / W, **kw)

    def _wall(self, arb, space, data):
        if arb.is_first_contact:
            self._ev("bounce", arb.shapes[0].ball, min_gap=0.06)

    def _bump(self, arb, space, data):
        if arb.is_first_contact:
            self._ev("racer", arb.shapes[0].ball, min_gap=0.1)

    def step(self, dt, now):
        self.now = now
        self.clock += dt
        # shrink smoothly; rebuild the ring shapes a few times per second
        k = min(1.0, self.clock / self.shrink_time)
        target = R_START - (R_START - R_MIN) * (1 - (1 - k) ** 1.6)
        # if it's taking too long, the gap slowly opens
        if self.clock > self.shrink_time:
            self.gap = min(2.2, self.gap + dt * 0.06)
        if abs(target - self.R) > 3 or self.clock - self.last_build > 0.25:
            self.R = target
            self._build_ring()
            self.last_build = self.clock
        self.ring_body.angular_velocity = self.w
        self.space.step(dt)
        self.rot = self.ring_body.angle
        for b in self.alive():
            v = b.body.velocity
            sp = v.length or 1
            b.body.velocity = v * (1 + (self.speed / sp - 1) * min(1, dt * 3))
            d = math.hypot(b.x - CX, b.y - CY)
            if d - b.r > self.R + 6:
                self._eliminate(b)
            elif d + b.r > self.R + 12:  # squeezed by the shrinking wall: push back in (not at the gap)
                ang = math.atan2(b.y - CY, b.x - CX)
                off = abs((ang - self.rot + math.pi) % (2 * math.pi) - math.pi)
                if off > self.gap / 2 + b.r / max(self.R, 1):
                    k2 = (self.R - b.r - 1) / d
                    b.body.position = (CX + (b.x - CX) * k2, CY + (b.y - CY) * k2)

    def _eliminate(self, b):
        b.alive = False
        b.out_time = self.clock
        self.out_order.append(b)
        b.place = len(self.balls) - len(self.out_order) + 1
        self.space.remove(b.body, b.shape)
        self._ev("break", b)
        if self.fx and b.look:
            self.fx.burst(b.x, b.y, b.look.color, n=30, speed=600)
        if len(self.alive()) == 1:
            self.winner = self.alive()[0]
            self.winner.place = 1


def tune(seed, n, t_min, t_max):
    target = (t_min + t_max) / 2
    best = None
    for gap in (0.55, 0.45, 0.65, 0.38, 0.75, 0.32, 0.85, 0.5, 0.6):
        S = Sim([None] * n, seed, gap, shrink_time=target * 0.85)
        while S.winner is None and S.clock < t_max * 2:
            S.step(1 / 240, S.clock)
        t = S.clock
        if S.winner is not None and (best is None or abs(t - target) < abs(best[1] - target)):
            best = (gap, t)
        if S.winner is not None and t_min <= t <= t_max:
            return gap, t, target * 0.85
    return (best[0], best[1], target * 0.85) if best else (0.55, t_max, target * 0.85)


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    gap, est, shrink_time = tune(cfg["seed"], n, t_min, t_max)
    print(f"  gap {gap:.2f}, ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["void"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, est + 4.5, th)
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    S = Sim(looks, cfg["seed"], gap, shrink_time, sound=sound, fx=fx)
    title_lines = _wrap(cfg.get("title") or "LAST ONE INSIDE WINS", 22)
    handle = cfg.get("handle", "")
    sound.add(0.0, "go")
    win_time = None
    seen_out = 0
    banners = []
    while True:
        t = run.t
        if win_time is None:
            for i in range(run.sub):
                S.step(run.dt / run.sub, t + i * run.dt / run.sub)
            while seen_out < len(S.out_order):
                banners.append([S.out_order[seen_out], t])
                seen_out += 1
            if S.winner is not None:
                win_time = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
        for b in S.alive():
            b.trail.append((b.x, b.y))
            b.trail = b.trail[-8:]
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        gfx.filled_circle(cv, int(CX), int(CY), int(S.R), T["floor"])
        a0 = S.rot + S.gap / 2
        span = 2 * math.pi - S.gap
        segs = 120
        pts_o = [(CX + math.cos(a0 + span * i / segs) * (S.R + 6), CY + math.sin(a0 + span * i / segs) * (S.R + 6)) for i in range(segs + 1)]
        pts_i = [(CX + math.cos(a0 + span * i / segs) * (S.R - 6), CY + math.sin(a0 + span * i / segs) * (S.R - 6)) for i in range(segs, -1, -1)]
        for s0 in range(0, segs, 30):
            e0 = min(segs, s0 + 30)
            poly = pts_o[s0:e0 + 1] + pts_i[segs - e0:segs - s0 + 1]
            gfx.filled_polygon(cv, poly, T["ring"])
            gfx.aapolygon(cv, poly, T["ring"])
        for ang in (S.rot - S.gap / 2, S.rot + S.gap / 2):
            pygame.draw.circle(cv, T["gap"], (round(CX + math.cos(ang) * S.R), round(CY + math.sin(ang) * S.R)), 10)
        for b in S.alive():
            for i in range(1, len(b.trail)):
                k = i / len(b.trail)
                pygame.draw.line(cv, V.mix(T["floor"], b.look.color, 0.1 + 0.4 * k), b.trail[i - 1], b.trail[i], max(2, int(b.r * 0.9 * k)))
        for b in S.alive():
            b.look.draw_body(cv, b.x, b.y, b.body.angle, b.body.velocity.x, b.body.velocity.y, b.r * 2, "ball")
        fx.draw(cv)
        y = _draw_title(cv, title_lines, t)
        if win_time is None:
            V.blit_center(cv, V.text(f"{len(S.alive())} LEFT", 44, (255, 210, 120), (0, 0, 0)), W / 2, y + 6)
        for bn in banners:
            age = t - bn[1]
            if age < 1.1:
                s = V.text(f"{bn[0].look.name.upper()} IS OUT", 96, (255, 255, 255), (0, 0, 0), weight="Display")
                s.set_alpha(int(255 * min(1, (1.1 - age) * 3)))
                V.blit_center(cv, s, W / 2, CY - S.R - 80)
        _roster(cv, S)
        if handle:
            V.blit_center(cv, V.text(handle, 30, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1840)
        if win_time is not None:
            _draw_winner(cv, S.winner, t - win_time + 0.8, T, line3="Last one inside")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Arena ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": S.winner.look.name, "level": cfg["seed"]}


def _roster(cv, S):
    n = len(S.balls)
    slot = min(120, 980 // n)
    y = 1660
    x0 = W / 2 - slot * (n - 1) / 2
    order = sorted(S.balls, key=lambda b: (not b.alive, -(b.out_time or 0)))
    for k, b in enumerate(order):
        x = x0 + k * slot
        img = b.look.badge(int(slot * 0.5))
        if not b.alive:
            img = img.copy()
            img.set_alpha(70)
        V.blit_center(cv, img, x, y)
        if not b.alive:
            d = slot * 0.22
            pygame.draw.line(cv, (235, 50, 60), (x - d, y - d), (x + d, y + d), 5)
            pygame.draw.line(cv, (235, 50, 60), (x - d, y + d), (x + d, y - d), 5)
