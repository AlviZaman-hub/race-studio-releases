"""Emoji Quiz: clue emojis drop onto a shelf with physics, a timer ticks, the answer is
revealed, then the shelf opens and the emojis tumble away. Questions come from Gemini,
your own list, or the built-in bank.
"""
import math
import random

import pymunk

from engine import visual as V
from engine import ai
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _glow

THEMES = {
    "night": {"bg1": "#06070d", "bg2": "#1a1d3a", "card": "#12152a", "accent": "#ffcf4a"},
    "grape": {"bg1": "#0d0614", "bg2": "#35124a", "card": "#1c0c29", "accent": "#7cf2c2"},
    "ocean": {"bg1": "#030d16", "bg2": "#0d3550", "card": "#0a1d2b", "accent": "#ffd166"},
    "ember": {"bg1": "#0d0503", "bg2": "#3a1206", "card": "#1d0b06", "accent": "#7ad7ff"},
}
RANDOM_THEMES = list(THEMES)

BANK = {
    "movies": [("🦁👑", "The Lion King"), ("🧊👸", "Frozen"), ("🦈🌊", "Jaws"), ("🐠🔍", "Finding Nemo"),
               ("🚢🧊💔", "Titanic"), ("🦖🏝️", "Jurassic Park"), ("🐀👨‍🍳", "Ratatouille"), ("🎈🏠", "Up"),
               ("🤖🌱", "WALL-E"), ("🐼🥋", "Kung Fu Panda"), ("🍫🏭", "Charlie and the Chocolate Factory"),
               ("👽📞🏠", "E.T."), ("🦍🏙️", "King Kong"), ("👻🚫", "Ghostbusters"), ("🧙‍♂️💍🌋", "The Lord of the Rings"),
               ("⚡👓🧙", "Harry Potter"), ("🐭🏰", "Mickey Mouse"), ("🧸🤠🚀", "Toy Story"), ("🐝🎬", "Bee Movie")],
    "countries": [("🗼🥐", "France"), ("🍣🗻", "Japan"), ("🌮🌵", "Mexico"), ("🦘🏄", "Australia"), ("🍁🏒", "Canada"),
                  ("🐼🧧", "China"), ("🐫🏜️🔺", "Egypt"), ("🌷🚲", "Netherlands"), ("⚽🌴🥁", "Brazil"),
                  ("🍺🥨", "Germany"), ("🗽🍔", "USA"), ("🕌🐅🍛", "India"), ("🍕🛵", "Italy"), ("🐨🦘", "Australia"),
                  ("💂☕🌧️", "United Kingdom"), ("🐂💃", "Spain")],
    "foods": [("🥜🧈", "Peanut Butter"), ("🍫🍪", "Chocolate Chip Cookie"), ("🍿🎬", "Popcorn"), ("🍦🍌", "Banana Split"),
              ("🧀🍔", "Cheeseburger"), ("🍓🥛", "Strawberry Milkshake"), ("🥚🥓", "Bacon and Eggs"),
              ("🍕🍍", "Hawaiian Pizza"), ("🌭🌭", "Hot Dogs"), ("🍎🥧", "Apple Pie"), ("🍗🪣", "Fried Chicken Bucket"),
              ("🥞🍯", "Pancakes"), ("🍝🍅", "Spaghetti"), ("🧁🎂", "Birthday Cake")],
    "phrases": [("🌧️🐱🐶", "Raining cats and dogs"), ("🧊🔨", "Break the ice"), ("🐘🏠", "Elephant in the room"),
                ("🍎👁️", "Apple of my eye"), ("⏰💸", "Time is money"), ("🌙🔵", "Once in a blue moon"),
                ("🙈🙉🙊", "See no evil"), ("🐦🐦🪨", "Two birds, one stone"), ("🍰🚶", "Piece of cake"),
                ("🔥🔥🔥", "On fire"), ("🦋🤢", "Butterflies in my stomach"), ("💡🧠", "Bright idea")],
}
BANK["mixed"] = [q for k in ("movies", "countries", "foods", "phrases") for q in BANK[k]]
# category code -> (singular shown on screen, what every answer must be: used in the AI prompt)
CATEGORIES = {
    "countries": ("COUNTRY", "a country name (no flag emojis in the clue)"),
    "movies": ("MOVIE", "a famous movie title"),
    "foods": ("FOOD", "a food or dish name"),
    "animals": ("ANIMAL", "an animal name (don't use that animal's own emoji)"),
    "cities": ("CITY", "a famous city name"),
    "landmarks": ("LANDMARK", "a famous landmark or monument"),
    "jobs": ("JOB", "a job or profession"),
    "sports": ("SPORT", "a sport (don't use that sport's own ball emoji)"),
    "tvshows": ("TV SHOW", "a famous TV series title"),
    "games": ("VIDEO GAME", "a famous video game title"),
    "songs": ("SONG", "a very famous song title"),
    "fairytales": ("FAIRY TALE", "a classic fairy tale or children's story"),
    "holidays": ("HOLIDAY", "a holiday or celebration"),
    "phrases": ("PHRASE", "a common English idiom or phrase"),
    "superpowers": ("SUPERPOWER", "a superpower"),
    "brands": ("BRAND", "a world-famous brand name (answer only, no logos)"),
}
TOPIC_TITLES = {k: f"GUESS THE {v[0]}" for k, v in CATEGORIES.items()}
TOPIC_TITLES["mixed"] = "GUESS THEM ALL"
T_THINK, T_REVEAL, T_GAP = 3.6, 1.6, 0.6


def pick_questions(cfg, rng):
    qs = cfg.get("questions")
    if qs:
        good = [q for q in qs if ai.emoji_seq_ok(q.get("clue", "")) and q.get("answer")]
        if good:
            return good
    topic = cfg.get("quiz_topic", "mixed")
    if topic not in BANK:
        raise RuntimeError(f"No built-in questions for '{topic}'. Add your Gemini key so AI can write them, "
                           "or pick movies, countries, foods or phrases.")
    pool = BANK[topic]
    pool = [q for q in pool if ai.emoji_seq_ok(q[0])]
    rng.shuffle(pool)
    n = cfg.get("quiz_count", 6)
    return [{"clue": c, "answer": a} for c, a in pool[:n]]


def render(cfg, out_path, sound):
    rng = random.Random(cfg["seed"])
    qs = pick_questions(cfg, rng)
    n = len(qs)
    per = T_THINK + T_REVEAL + T_GAP
    est = n * per + 3.5
    print(f"  {n} questions, ~{est:.0f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["night"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, est, th)
    topic = cfg.get("quiz_topic", "mixed")
    title_lines = _wrap(cfg.get("title") or TOPIC_TITLES.get(topic, "GUESS THE EMOJIS"), 22)
    handle = cfg.get("handle", "")
    fx = V.Particles(random.Random(cfg["seed"]))
    space = pymunk.Space()
    space.gravity = (0, 2600)
    SHELF_Y = 1150
    shelf = [pymunk.Segment(space.static_body, (150, SHELF_Y), (930, SHELF_Y), 6),
             pymunk.Segment(space.static_body, (150, SHELF_Y), (150, SHELF_Y - 260), 6),
             pymunk.Segment(space.static_body, (930, SHELF_Y), (930, SHELF_Y - 260), 6)]
    for s in shelf:
        s.elasticity, s.friction = 0.55, 0.8
    space.add(*shelf)
    shelf_open = False
    imgs = {}

    def emoji_img(e, size):
        k = (e, size)
        if k not in imgs:
            raw = pygame.image.load(V.emoji_path(e)).convert_alpha()
            imgs[k] = pygame.transform.smoothscale(raw, (size, size))
        return imgs[k]

    bodies = []

    def drop(q, t0):
        parts = ai.split_emoji(q["clue"])[:5]
        k = len(parts)
        size = 190 if k <= 3 else 160
        r = size * 0.45
        span = min(700, k * (size + 30))
        out = []
        for j, e in enumerate(parts):
            b = pymunk.Body(1.0, float("inf"))  # stays upright so the clue is readable
            x = W / 2 - span / 2 + span * (j + 0.5) / k + rng.uniform(-10, 10)
            b.position = (x, 520 - j * 140)
            b.velocity = (rng.uniform(-40, 40), 0)
            sh = pymunk.Circle(b, r)
            sh.elasticity, sh.friction = 0.5, 0.7
            space.add(b, sh)
            out.append({"body": b, "shape": sh, "e": e, "size": size, "landed": False})
        return out

    qi = -1
    q_start = 0.0
    sound.add(0.0, "go")
    score_t = None
    landed_sound = {}
    while True:
        t = run.t
        idx = int(t // per)
        local = t - idx * per
        if idx < n and idx != qi:
            # next question: close the shelf, drop new emojis
            qi = idx
            q_start = t
            if shelf_open:
                space.add(*shelf)
                shelf_open = False
            for it in bodies:
                if it["body"].space is not None:
                    space.remove(it["body"], it["shape"])
            bodies = drop(qs[qi], t)
            for k in range(1, 4):
                sound.add(t + T_THINK - k, "count")
            sound.add(t + T_THINK, "escape")
        if idx < n and local >= T_THINK + T_REVEAL and not shelf_open:
            space.remove(*shelf)
            shelf_open = True
            for it in bodies:  # now let them tumble away
                b = it["body"]
                b.moment = pymunk.moment_for_circle(1.0, 0, it["size"] * 0.45)
                b.angular_velocity = rng.uniform(-6, 6)
                b.velocity = (rng.uniform(-250, 250), -300)
            sound.add(t, "whoosh")
        if idx >= n and score_t is None:
            score_t = t
            sound.climax(t)
            sound.add(t, "win")
            fx.confetti(W)
        for _ in range(run.sub):
            space.step(run.dt / run.sub)
        for it in bodies:
            b = it["body"]
            if not it["landed"] and b.position.y > SHELF_Y - 260 and abs(b.velocity.y) < 600 and t - q_start > 0.2:
                it["landed"] = True
                sound.add(t, "bounce", who=bodies.index(it), pan=0.2 + 0.6 * b.position.x / W)
        fx.update(run.dt)
        # ------------------------------------------------ draw
        run.clear()
        cv = run.canvas
        y = _draw_title(cv, title_lines, t)
        if score_t is None and qi < n:
            label = CATEGORIES[topic][0] if topic in CATEGORIES else \
                ("QUESTION" if topic in ("mixed", "my questions", None) else str(topic).upper()[:14])
            V.blit_center(cv, V.text(f"{label} {qi + 1} / {n}", 42, T["accent"], (0, 0, 0)), W / 2, y + 6)
        card = pygame.Rect(110, 470, W - 220, 780)
        pygame.draw.rect(cv, (0, 0, 0), card.move(0, 10), border_radius=36)
        pygame.draw.rect(cv, T["card"], card, border_radius=36)
        pygame.draw.rect(cv, V.mix(T["card"], T["accent"], 0.35), card, 3, border_radius=36)
        if not shelf_open:
            pygame.draw.line(cv, V.mix(T["card"], (255, 255, 255), 0.25), (150, SHELF_Y + 4), (930, SHELF_Y + 4), 6)
        for it in bodies:
            b = it["body"]
            if b.position.y < H + 200:
                img = pygame.transform.rotozoom(emoji_img(it["e"], it["size"]), -math.degrees(b.angle), 1.0)
                V.blit_center(cv, img, b.position.x, b.position.y)
        if score_t is None and qi < n:
            if local < T_THINK:
                frac = 1 - local / T_THINK
                bw = 760
                col = V.mix((255, 70, 70), (80, 230, 120), frac)
                pygame.draw.rect(cv, (20, 20, 28), pygame.Rect(W / 2 - bw / 2 - 4, 1300 - 4, bw + 8, 30), border_radius=15)
                pygame.draw.rect(cv, col, pygame.Rect(W / 2 - bw / 2, 1300, bw * frac, 22), border_radius=11)
                sec = min(3, int(math.ceil(T_THINK - local)))
                V.blit_center(cv, V.text(str(sec), 120, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, 1420)
            else:
                a = min(1, (local - T_THINK) / 0.25)
                ans = qs[qi]["answer"].upper()
                size = 110 if len(ans) <= 12 else 84 if len(ans) <= 20 else 64
                lines = _wrap(ans, 18 if size >= 84 else 24)
                yy = 1400 - (len(lines) - 1) * size * 0.55
                g = _glow(tuple(T["accent"]), 180)
                g2 = g.copy()
                g2.set_alpha(int(160 * a))
                V.blit_center(cv, g2, W / 2, 1420)
                for ln in lines:
                    s = V.text(ln, int(size * (0.8 + 0.2 * a)), (255, 255, 255), (0, 0, 0), weight="Display")
                    V.blit_center(cv, s, W / 2, yy)
                    yy += size * 1.05
        if score_t is not None:
            a = min(1, (t - score_t) / 0.3)
            dim = pygame.Surface((W, H), pygame.SRCALPHA)
            dim.fill((4, 5, 9, int(190 * a)))
            cv.blit(dim, (0, 0))
            V.blit_center(cv, V.text("HOW MANY", 150, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, 820)
            V.blit_center(cv, V.text("DID YOU GET?", 150, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, 980)
            V.blit_center(cv, V.text(f"Comment your score  /{n}", 48, T["accent"], (0, 0, 0), weight="Medium"), W / 2, 1130)
        fx.draw(cv)
        if handle:
            V.blit_center(cv, V.text(handle, 30, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1840)
        run.push()
        if score_t is not None and t - score_t >= 3.5:
            break
    dur = run.finish()
    return {"duration": dur, "winner": f"{n} questions", "level": cfg["seed"]}
