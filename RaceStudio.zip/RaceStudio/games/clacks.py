"""Pi Collisions: a heavy block slides into a small one next to a wall. Count every clack.
With mass ratios of 1, 100, 10 000, 1 000 000... the count spells out the digits of pi
(3, 31, 314, 3141). Exact physics (no friction, perfectly elastic), event by event."""
import math
import random

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title

THEMES = {
    "chalk": {"bg1": "#08100c", "bg2": "#173326", "floor": "#e8f2ea", "small": "#7ad7ff", "big": "#ffcf4a", "ink": "#ffffff"},
    "night": {"bg1": "#03040a", "bg2": "#141a33", "floor": "#c9d2ff", "small": "#ff6b9a", "big": "#7ad7ff", "ink": "#ffffff"},
    "paper": {"bg1": "#121212", "bg2": "#2a2a2a", "floor": "#f2f2f2", "small": "#ff8a1f", "big": "#3f8cff", "ink": "#ffffff"},
}
RANDOM_THEMES = list(THEMES)
FLOOR = 1180
WALL_X = 90
PI = "3.14159265358979"


def collisions(ratio, v_big=-1.0, x_small=3.0, x_big=6.0):
    """Exact event list for blocks on a frictionless line with a wall at 0.
    Returns [(time, x_small, x_big, v_small, v_big, kind)] at each collision."""
    m1, m2 = 1.0, float(ratio)
    v1, v2 = 0.0, v_big
    x1, x2 = x_small, x_big
    t = 0.0
    ev = [(0.0, x1, x2, v1, v2, "start")]
    while True:
        cand = []
        if v2 < v1:   # blocks approach each other
            cand.append(((x2 - x1) / (v1 - v2), "blocks"))
        if v1 < 0:
            cand.append((-x1 / v1, "wall"))
        cand = [c for c in cand if c[0] > 1e-12]
        if not cand:
            break
        dt, kind = min(cand)
        t += dt
        x1 += v1 * dt
        x2 += v2 * dt
        if kind == "blocks":
            u1 = ((m1 - m2) * v1 + 2 * m2 * v2) / (m1 + m2)
            u2 = ((m2 - m1) * v2 + 2 * m1 * v1) / (m1 + m2)
            v1, v2 = u1, u2
            x1 = min(x1, x2)
        else:
            v1 = -v1
            x1 = 0.0
        ev.append((t, x1, x2, v1, v2, kind))
        if len(ev) > 400000:
            break
    return ev


def render(cfg, out_path, sound):
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    target = (t_min + t_max) / 2
    digits = int(cfg.get("pi_digits") or (4 if target >= 22 else 3))
    ratios = [100 ** k for k in range(digits)]
    per = max(4.5, (target - 2.0) / len(ratios))
    th = THEMES.get(cfg.get("theme"), THEMES["chalk"])
    T = {k: V.hexc(v) for k, v in th.items()}
    sound.music = False
    run = Runner(cfg, out_path, sound, per * len(ratios) + 6, th)
    run.comm.on = False
    fx = V.Particles(random.Random(cfg["seed"]))
    title = _wrap(cfg.get("title") or "COUNT THE COLLISIONS", 22)
    handle = cfg.get("handle", "")
    rounds = []
    for ratio in ratios:
        ev = collisions(ratio)
        hits = [e for e in ev if e[5] != "start"]
        first = hits[0][0] if hits else 1.0
        last = hits[-1][0] if hits else 1.0
        rounds.append((ratio, ev, len(hits), first, last))
    print("  collisions:", [r[2] for r in rounds])
    scale = 120.0                       # pixels per unit of distance
    end_t = None
    count_disp = 0
    last_snd = -1.0
    cur_round = 0
    while True:
        t = run.t
        k = min(len(rounds) - 1, int(t // per))
        ratio, ev, total, first, last = rounds[k]
        u = t - k * per
        # time map: approach in 1.2 s, all collisions in the middle, slide away at the end
        a_len, c_len = 1.0, per - 2.6
        if u < a_len:
            st = first * (u / a_len)
        elif u < a_len + c_len:
            st = first + (last - first) * ((u - a_len) / c_len) ** 1.6
        else:
            st = last + (u - a_len - c_len) * max(0.6, last * 0.1)
        # find state at sim time st
        lo, hi = 0, len(ev) - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if ev[mid][0] <= st:
                lo = mid
            else:
                hi = mid - 1
        e = ev[lo]
        dt = st - e[0]
        x1, x2 = e[1] + e[3] * dt, e[2] + e[4] * dt
        if k != cur_round:
            cur_round, count_disp = k, 0
            if k > 0:
                sound.add(t, "whoosh")
        count = lo
        if count > count_disp:
            n_new = count - count_disp
            if t - last_snd > 0.035:
                sound.add(t, "hit", gain=0.8, pan=0.3)
                last_snd = t
            count_disp = count
        if k == len(rounds) - 1 and u > a_len + c_len + 0.4 and end_t is None:
            end_t = t
            sound.climax(t)
            sound.add(t, "win")
            fx.confetti(W)
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        pygame.draw.line(cv, T["floor"], (WALL_X, FLOOR), (W - 40, FLOOR), 6)
        pygame.draw.line(cv, T["floor"], (WALL_X, FLOOR), (WALL_X, FLOOR - 520), 6)
        for j in range(12):
            y = FLOOR - j * 44
            pygame.draw.line(cv, T["floor"], (WALL_X, y), (WALL_X - 26, y + 26), 3)
        s_small = 70
        s_big = int(min(290, 70 + 40 * math.log10(ratio + 1)))
        bx1 = WALL_X + 3 + x1 * scale
        bx2 = WALL_X + 3 + x2 * scale + s_small
        if bx2 < W + 400:
            pygame.draw.rect(cv, T["big"], pygame.Rect(bx2, FLOOR - 3 - s_big, s_big, s_big), border_radius=8)
            V.blit_center(cv, V.text(f"{ratio:,} kg", 34 if ratio < 10 ** 5 else 28, (20, 20, 20), None, weight="Bold"),
                          bx2 + s_big / 2, FLOOR - 3 - s_big / 2)
        pygame.draw.rect(cv, T["small"], pygame.Rect(bx1, FLOOR - 3 - s_small, s_small, s_small), border_radius=8)
        V.blit_center(cv, V.text("1 kg", 30, (20, 20, 20), None, weight="Bold"), bx1 + s_small / 2, FLOOR - 3 - s_small / 2)
        fx.draw(cv)
        y = _draw_title(cv, title, t)
        V.blit_center(cv, V.text(f"MASS RATIO {ratio:,} : 1", 48, T["big"], (0, 0, 0)), W / 2, y + 20)
        V.blit_center(cv, V.text(f"{count_disp:,}", 210, T["ink"], (0, 0, 0), weight="Display"), W / 2, 560)
        V.blit_center(cv, V.text("COLLISIONS", 50, (200, 205, 220), (0, 0, 0)), W / 2, 690)
        if u > a_len + c_len + 0.2 or end_t is not None:
            got = str(total)
            V.blit_center(cv, V.text(f"PI = {PI[:len(got) + 1]}...", 80, T["big"], (0, 0, 0), weight="Display"), W / 2, 1440)
        if end_t is not None:
            V.blit_center(cv, V.text("THE COUNT IS PI!", 84, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, 1560)
        # earlier rounds as a small scoreboard
        for j in range(k + (1 if u > a_len + c_len else 0)):
            V.blit_center(cv, V.text(f"{rounds[j][0]:,} : 1   =   {rounds[j][2]:,} clacks", 34, (210, 214, 228), (0, 0, 0), weight="Medium"),
                          W / 2, 1650 + j * 46)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1880)
        run.push()
        if end_t is not None and t - end_t >= 3.4:
            break
        if t > 200:
            raise RuntimeError("Simulation ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": f"{rounds[-1][2]} collisions", "level": cfg["seed"]}
