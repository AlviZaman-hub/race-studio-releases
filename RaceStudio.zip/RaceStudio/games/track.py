"""Marble Track: marbles race down a long winding course (ramps, peg fields, spinners,
bumpers, funnels). The camera follows the leader; a progress bar shows everyone.
"""
import math
import random

import pymunk

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner
import pygame.gfxdraw as gfx

THEMES = {
    "night": {"bg1": "#04050b", "bg2": "#141a33", "track": "#9fb3ff", "peg": "#e8ecff", "accent": "#ffcf4a", "panel": "#0b0e1c"},
    "jungle": {"bg1": "#020a05", "bg2": "#0e3018", "track": "#79e08f", "peg": "#e6ffe9", "accent": "#ffb347", "panel": "#06140a"},
    "ember": {"bg1": "#0c0402", "bg2": "#361206", "track": "#ff9a5a", "peg": "#ffe9d6", "accent": "#7ad7ff", "panel": "#160805"},
    "ice": {"bg1": "#020a10", "bg2": "#0c2c40", "track": "#9fe3ff", "peg": "#ffffff", "accent": "#ff6b9a", "panel": "#061520"},
}
RANDOM_THEMES = list(THEMES)
L, R = 50, 1030
G = 1900.0
VIEW_TOP, VIEW_BOT = 330, 1640
CT_M, CT_S, CT_PEG, CT_BUMP = 1, 2, 3, 4


class Marble:
    def __init__(self, i, look, r):
        self.i, self.look, self.r = i, look, r
        self.body = pymunk.Body(1.0, pymunk.moment_for_circle(1.0, 0, r))
        self.shape = pymunk.Circle(self.body, r)
        self.shape.elasticity, self.shape.friction, self.shape.collision_type = 0.5, 0.7, CT_M
        self.shape.m = self
        self.done = False
        self.place = None
        self.slow = 0.0
        self.trail = []

    x = property(lambda s: s.body.position.x)
    y = property(lambda s: s.body.position.y)


class Course:
    """Static geometry + moving parts, generated section by section from a seed."""

    def __init__(self, seed, n_sections, r):
        rng = random.Random(seed)
        self.segs, self.pegs, self.bumpers, self.spinners, self.gates = [], [], [], [], []
        y = 120
        side = rng.choice([-1, 1])
        kinds = []
        mids = ["pegs", "spinner", "bumpers", "funnel", "pegs"]
        for k in range(n_sections):
            if k == 0:
                kinds.append("pegs")
            elif k % 2 == 0 and n_sections >= 6 and k in (n_sections // 2 - n_sections // 2 % 2, n_sections - 2 - n_sections % 2):
                kinds.append("gate")
            elif k % 2:
                kinds.append("ramp")
            else:
                kinds.append(rng.choice([m for m in mids if m != kinds[-2]] or mids))
        for kind in kinds:
            if False:
                gap = r * 2 + rng.uniform(40, 60)
                mid = rng.uniform(L + 380, R - 380)
                self.segs.append(((mid, y), (L + gap, y + 150)))
                self.segs.append(((mid, y), (R - gap, y + 150)))
                y += 150 + r * 3.5
            elif kind == "ramp":
                drop = rng.uniform(150, 210)
                gap = r * 2 + rng.uniform(40, 70)
                if side > 0:  # slopes down to the right, opening at the right
                    self.segs.append(((L, y), (R - gap, y + drop)))
                else:
                    self.segs.append(((R, y), (L + gap, y + drop)))
                y += drop + r * 3.5
                side *= -1
            elif kind == "pegs":
                rows = rng.randint(4, 6)
                sx = max(r * 2 + 30, rng.choice([92, 104]))
                for j in range(rows):
                    off = sx / 2 if j % 2 else 0
                    x = L + r * 2 + 30 + off
                    while x < R - r * 2 - 30:
                        self.pegs.append((x, y + j * 78))
                        x += sx
                y += rows * 78 + 40
            elif kind == "spinner":
                ln = rng.uniform(300, 420)
                for cx in ((L + R) / 2,) if rng.random() < 0.5 else ((L + R) / 2 - 230, (L + R) / 2 + 230):
                    self.spinners.append({"c": (cx, y + 170), "len": ln * (0.6 if cx != (L + R) / 2 else 1),
                                          "w": rng.choice([-1, 1]) * rng.uniform(1.5, 2.6), "a": rng.uniform(0, 3)})
                y += 360
            elif kind == "bumpers":
                for _ in range(rng.randint(3, 5)):
                    br = rng.uniform(30, 44)
                    self.bumpers.append((rng.uniform(L + br + r * 2 + 30, R - br - r * 2 - 30), y + rng.uniform(40, 190), br))
                y += 360
            elif kind == "gate":
                hole = r * 2 + 90
                cx = (L + R) / 2
                self.segs.append(((L, y), (cx - hole / 2, y + 120)))
                self.segs.append(((R, y), (cx + hole / 2, y + 120)))
                self.gates.append({"x": cx, "y": y + 120, "w": hole + 30, "open": 0.0})
                y += 120 + r * 3
                for j in range(4):  # plinko right under the gate to scatter the pack
                    off = 49 if j % 2 else 0
                    x = L + r * 2 + 30 + off
                    while x < R - r * 2 - 30:
                        self.pegs.append((x, y + j * 80))
                        x += 98
                y += 4 * 80 + 30
            elif kind == "funnel":
                hole = r * 2 + 50
                cx = rng.uniform(L + 260, R - 260)
                self.segs.append(((L, y), (cx - hole / 2, y + 230)))
                self.segs.append(((R, y), (cx + hole / 2, y + 230)))
                y += 230 + r * 4
        self.finish_y = y + 140
        self.segs.append(((L, self.finish_y + 220), (R, self.finish_y + 220)))
        self.length = self.finish_y


class Sim:
    def __init__(self, looks, seed, n_sections, sound=None, fx=None):
        self.rng = random.Random(seed * 23 + 2)
        n = len(looks)
        self.r = r = 34 if n <= 6 else 28
        self.course = C = Course(seed, n_sections, r)
        self.sound, self.fx = sound, fx
        self.clock, self.now = 0.0, 0.0
        sp = pymunk.Space()
        sp.gravity = (0, G)
        sp.iterations = 25
        self.space = sp
        st = sp.static_body
        for a, b in [((L, -400), (L, C.finish_y + 240)), ((R, -400), (R, C.finish_y + 240))] + C.segs:
            s = pymunk.Segment(st, a, b, 7)
            s.elasticity, s.friction, s.collision_type = 0.4, 0.6, CT_S
            sp.add(s)
        for (x, y) in C.pegs:
            c = pymunk.Circle(st, 9, (x, y))
            c.elasticity, c.friction, c.collision_type = 0.5, 0.3, CT_PEG
            sp.add(c)
        for (x, y, br) in C.bumpers:
            c = pymunk.Circle(st, br, (x, y))
            c.elasticity, c.friction, c.collision_type = 1.2, 0.2, CT_BUMP
            sp.add(c)
        for s_ in C.spinners:
            body = pymunk.Body(body_type=pymunk.Body.KINEMATIC)
            body.position = s_["c"]
            body.angle = s_["a"]
            body.angular_velocity = s_["w"]
            sg = pymunk.Segment(body, (-s_["len"] / 2, 0), (s_["len"] / 2, 0), 8)
            sg.elasticity, sg.friction, sg.collision_type = 0.5, 0.8, CT_S
            sp.add(body, sg)
            s_["body"] = body
        for g in C.gates:
            body = pymunk.Body(body_type=pymunk.Body.KINEMATIC)
            body.position = (g["x"], g["y"])
            sg = pymunk.Segment(body, (-g["w"] / 2, 0), (g["w"] / 2, 0), 9)
            sg.elasticity, sg.friction, sg.collision_type = 0.2, 0.8, CT_S
            sp.add(body, sg)
            g["body"] = body
            g["t"] = None
        self.marbles = []
        slots = list(range(n))
        self.rng.shuffle(slots)
        for i, lk in enumerate(looks):
            m = Marble(i, lk, r)
            m.body.position = (L + 60 + (R - L - 120) * (slots[i] + 0.5) / n, 40 + self.rng.uniform(-10, 10))
            m.body.velocity = (self.rng.uniform(-40, 40), 0)
            m.shape.friction = self.rng.uniform(0.45, 0.95)
            m.shape.elasticity = self.rng.uniform(0.35, 0.65)
            sp.add(m.body, m.shape)
            self.marbles.append(m)
        sp.on_collision(CT_M, CT_S, post_solve=self._hit)
        sp.on_collision(CT_M, CT_PEG, post_solve=self._hit)
        sp.on_collision(CT_M, CT_BUMP, post_solve=self._bump)
        sp.on_collision(CT_M, CT_M, post_solve=self._mm)
        self.finished = []
        self.winner = None

    def _ev(self, kind, m, **kw):
        if self.sound is not None:
            self.sound.add(self.now, kind, who=m.i, pan=0.15 + 0.7 * m.x / W, **kw)

    def _hit(self, arb, space, data):
        if arb.is_first_contact:
            j = arb.total_impulse
            if math.hypot(j.x, j.y) > 150:
                self._ev("bounce", arb.shapes[0].m, min_gap=0.08, gain=0.7)

    def _bump(self, arb, space, data):
        if arb.is_first_contact:
            self._ev("hit", arb.shapes[0].m, min_gap=0.08)

    def _mm(self, arb, space, data):
        if arb.is_first_contact:
            j = arb.total_impulse
            if math.hypot(j.x, j.y) > 120:
                self._ev("racer", arb.shapes[0].m, min_gap=0.12)

    def step(self, dt, now):
        self.now = now
        self.clock += dt
        self.space.step(dt)
        for s_ in self.course.spinners:
            s_["a"] = s_["body"].angle
        for g in self.course.gates:
            if g["t"] is None:
                here = sum(1 for m in self.marbles if not m.done and g["y"] - 260 < m.y < g["y"])
                if here:
                    first = g.setdefault("first", self.clock)
                    behind = sum(1 for m in self.marbles if not m.done and m.y < g["y"])
                    if here >= behind or self.clock - first > 3.5:
                        g["t"] = self.clock + 0.6
                        if self.sound is not None:
                            self.sound.add(now, "count")
                            self.sound.add(now + 0.6, "whoosh")
            elif self.clock > g["t"] and g["open"] < 1:
                g["open"] = min(1.0, g["open"] + dt * 3)
                g["body"].position = (g["x"] + g["open"] * (g["w"] + 20), g["y"])
        for m in self.marbles:
            if m.done:
                continue
            m.body.angular_velocity = max(-40, min(40, m.body.angular_velocity))
            if m.y > self.course.finish_y:
                m.done = True
                self.finished.append(m)
                m.place = len(self.finished)
                self._ev("escape", m)
                if self.winner is None:
                    self.winner = m
                continue
            sp = m.body.velocity.length
            if sp > 1400:
                m.body.velocity = m.body.velocity * (1400 / sp)
            m.slow = m.slow + dt if sp < 50 else 0
            if m.slow > 0.9:
                m.body.velocity = ((1 if m.x < (L + R) / 2 else -1) * self.rng.uniform(250, 420), -300)
                m.slow = 0

    def ranking(self):
        return sorted(self.marbles, key=lambda m: (m.place or 99, -m.y))


def tune(seed, n, t_min, t_max):
    target = (t_min + t_max) / 2
    k, best = 10, None
    for _ in range(8):
        S = Sim([None] * n, seed, k)
        while S.winner is None and S.clock < t_max * 2.5:
            S.step(1 / 240, S.clock)
        t = S.clock
        if S.winner and (best is None or abs(t - target) < abs(best[1] - target)):
            best = (k, t)
        if S.winner and t_min <= t <= t_max:
            return k, t
        k = max(3, int(round(k * target / max(t, 1))))
        if best and k == best[0]:
            break
    return best if best else (k, t_max)


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    k, est = tune(cfg["seed"], n, t_min, t_max)
    print(f"  {k} sections, ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["night"])
    T = {kk: V.hexc(v) for kk, v in th.items()}
    run = Runner(cfg, out_path, sound, est + 4.5, th)
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    S = Sim(looks, cfg["seed"], k, sound=sound, fx=fx)
    C = S.course
    title_lines = _wrap(cfg.get("title") or "WHO WINS THE MARBLE RACE?", 22)
    handle = cfg.get("handle", "")
    sound.add(0.0, "go")
    cam = 0.0
    view_h = VIEW_BOT - VIEW_TOP
    win_time = None
    rank_x = {}
    while True:
        t = run.t
        if win_time is None or t - win_time < 2.5:
            for i in range(run.sub):
                S.step(run.dt / run.sub, t + i * run.dt / run.sub)
        if S.winner is not None and win_time is None:
            win_time = t
            sound.climax(t)
            sound.add(t, "win")
            fx.confetti(W)
        # camera: follow the leader, keep it ~60% down the viewport, smooth
        lead = max((m for m in S.marbles if not m.done), key=lambda m: m.y, default=S.winner)
        target = min(C.finish_y + 260 - view_h, max(0, (lead.y if lead else 0) - view_h * 0.6))
        cam += (target - cam) * min(1, run.dt * 4)
        for m in S.marbles:
            m.trail.append((m.x, m.y))
            m.trail = m.trail[-8:]
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        oy = VIEW_TOP - cam
        clip = pygame.Rect(L - 20, VIEW_TOP, R - L + 40, view_h)
        pygame.draw.rect(cv, T["panel"], clip, border_radius=18)
        cv.set_clip(clip)
        top, bot = cam - 60, cam + view_h + 60
        for (a, b) in [((L, cam - 50), (L, cam + view_h + 50)), ((R, cam - 50), (R, cam + view_h + 50))] + C.segs:
            if max(a[1], b[1]) < top or min(a[1], b[1]) > bot:
                continue
            pygame.draw.line(cv, T["track"], (a[0], a[1] + oy), (b[0], b[1] + oy), 12)
            for p in (a, b):
                pygame.draw.circle(cv, T["track"], (round(p[0]), round(p[1] + oy)), 6)
        for (x, y) in C.pegs:
            if top < y < bot:
                gfx.filled_circle(cv, int(x), int(y + oy), 9, T["peg"])
                gfx.aacircle(cv, int(x), int(y + oy), 9, T["peg"])
        for (x, y, br) in C.bumpers:
            if top - br < y < bot + br:
                gfx.filled_circle(cv, int(x), int(y + oy), int(br), V.darker(T["accent"], 0.6))
                gfx.filled_circle(cv, int(x), int(y + oy), int(br * 0.78), T["accent"])
        for s_ in C.spinners:
            cx, cy = s_["c"]
            if top - 300 < cy < bot + 300:
                hx, hy = math.cos(s_["a"]) * s_["len"] / 2, math.sin(s_["a"]) * s_["len"] / 2
                pygame.draw.line(cv, T["accent"], (cx - hx, cy - hy + oy), (cx + hx, cy + hy + oy), 14)
                pygame.draw.circle(cv, (255, 255, 255), (round(cx), round(cy + oy)), 9)
        for g in C.gates:
            if top < g["y"] < bot and g["open"] < 1:
                gx = g["body"].position.x
                pygame.draw.line(cv, T["accent"], (gx - g["w"] / 2, g["y"] + oy), (gx + g["w"] / 2, g["y"] + oy), 16)
                if g["t"] is not None and S.clock < g["t"]:
                    V.blit_center(cv, V.text("GO!", 46, T["accent"], (0, 0, 0), weight="Display"), g["x"], g["y"] + oy + 50)
        fy = C.finish_y + oy
        for i in range(int((R - L) / 24)):
            for j in range(2):
                col = (20, 20, 24) if (i + j) % 2 else (245, 245, 245)
                pygame.draw.rect(cv, col, pygame.Rect(L + i * 24, fy + j * 24 - 24, 24, 24))
        for m in S.marbles:
            pts = [(x, y + oy) for x, y in m.trail]
            for i in range(1, len(pts)):
                kk = i / len(pts)
                pygame.draw.line(cv, V.mix(T["panel"], m.look.color, 0.15 + 0.45 * kk), pts[i - 1], pts[i], max(2, int(m.r * kk)))
        for m in S.marbles:
            if -60 < m.y + oy - VIEW_TOP < view_h + 60:
                m.look.draw_body(cv, m.x, m.y + oy, m.body.angle, m.body.velocity.x, m.body.velocity.y, m.r * 2, "ball")
        cv.set_clip(None)
        fx.draw(cv)
        y = _draw_title(cv, title_lines, t)
        # progress bar with every marble
        px0, px1, py = 90, 990, 1700
        pygame.draw.rect(cv, (20, 22, 30), pygame.Rect(px0, py - 6, px1 - px0, 12), border_radius=6)
        for m in S.marbles:
            f = min(1, max(0, m.y / C.finish_y))
            V.blit_center(cv, m.look.badge(44), px0 + (px1 - px0) * f, py - 34 - (m.i % 2) * 0)
        order = S.ranking()
        slot = min(110, 980 // len(order))
        x0 = W / 2 - slot * (len(order) - 1) / 2
        for pos, m in enumerate(order):
            tx = x0 + pos * slot
            cx = rank_x.get(m.i, tx)
            cx += (tx - cx) * min(1, run.dt * 8)
            rank_x[m.i] = cx
            V.blit_center(cv, m.look.badge(int(slot * 0.45)), cx, 1780)
            V.blit_center(cv, V.text(str(pos + 1), 26, (255, 255, 255), (0, 0, 0)), cx + slot * 0.28, 1760)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1860)
        if win_time is not None:
            _draw_winner(cv, S.winner, t - win_time + 0.8, T, line3="First to the finish")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Race ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": S.winner.look.name, "level": cfg["seed"]}
