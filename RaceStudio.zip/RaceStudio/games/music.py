"""Music Bounce: a ball bounces inside a circle; every bounce plays the next note of a
public-domain melody, and the ball grows a little with each note until it fills the circle.
"""
import colorsys
import math
import random

import pymunk

from engine import visual as V
from engine.melodies import MELODIES
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner
import pygame.gfxdraw as gfx

THEMES = {
    "midnight": {"bg1": "#04050b", "bg2": "#141a35", "floor": "#0a0d1c"},
    "rose": {"bg1": "#0e0409", "bg2": "#3a1028", "floor": "#1a0812"},
    "aqua": {"bg1": "#020c10", "bg2": "#0b3340", "floor": "#06161c"},
    "gold": {"bg1": "#0c0803", "bg2": "#33240a", "floor": "#160f05"},
}
RANDOM_THEMES = list(THEMES)
CX, CY, R = W / 2, 1040, 430
G = 1700.0
R0 = 26.0


class Sim:
    def __init__(self, seed, growth, n_notes):
        self.rng = random.Random(seed * 5 + 1)
        self.growth = growth
        self.n_notes = n_notes
        sp = pymunk.Space()
        sp.gravity = (0, G)
        sp.iterations = 20
        self.space = sp
        segs = 160
        for k in range(segs):
            a0, a1 = 2 * math.pi * k / segs, 2 * math.pi * (k + 1) / segs
            s = pymunk.Segment(sp.static_body, (CX + math.cos(a0) * R, CY + math.sin(a0) * R),
                               (CX + math.cos(a1) * R, CY + math.sin(a1) * R), 4)
            s.elasticity, s.friction, s.collision_type = 1.0, 0.4, 2
            sp.add(s)
        self.r = R0
        self.body = pymunk.Body(1.0, pymunk.moment_for_circle(1.0, 0, R0))
        self.body.position = (CX + self.rng.uniform(-60, 60), CY - R * 0.45)
        self.body.velocity = (self.rng.uniform(-260, 260), 0)
        self.shape = pymunk.Circle(self.body, R0)
        self.shape.elasticity, self.shape.friction, self.shape.collision_type = 1.0, 0.4, 1
        sp.add(self.body, self.shape)
        sp.on_collision(1, 2, post_solve=self._hit)
        self.notes = 0
        self.hits = []  # (time, x, y)
        self.clock = 0.0
        self.last_hit = -1.0
        self.done = False
        self._pending = False

    def _hit(self, arb, space, data):
        # one note per bounce: the wall is many small segments, so ignore extra contacts
        if arb.is_first_contact and not self.done and not self._pending and self.clock - self.last_hit > 0.06:
            self.last_hit = self.clock
            pts = arb.contact_point_set.points
            p = pts[0].point_b if pts else self.body.position
            self.hits.append((self.clock, p.x, p.y))
            self._pending = True

    def step(self, dt):
        self.clock += dt
        self.space.step(dt)
        if self._pending:
            self._pending = False
            self.notes += 1
            # grow (shape can't be resized mid-step, so do it here)
            self.r = min(R * 0.93, self.r + self.growth)
            self.shape.unsafe_set_radius(self.r)
            self.body.moment = pymunk.moment_for_circle(1.0, 0, self.r)
            # keep enough energy to reach the top of the remaining space
            room = (R - self.r) * 2
            v = self.body.velocity
            vmin = math.sqrt(2 * G * room * 0.75)
            sp = v.length or 1
            if sp < vmin:
                self.body.velocity = v * (vmin / sp)
            if self.notes >= self.n_notes or self.r >= R * 0.93:
                self.done = True
        # never escape the circle on a fast hit
        d = (self.body.position - (CX, CY)).length
        if d > R - self.r:
            k = (R - self.r - 0.5) / d
            self.body.position = (CX + (self.body.position.x - CX) * k, CY + (self.body.position.y - CY) * k)


def tune(seed, n_notes, t_min, t_max):
    target = (t_min + t_max) / 2
    growth = (R * 0.93 - R0) / n_notes
    best = None
    for _ in range(10):
        S = Sim(seed, growth, n_notes)
        while not S.done and S.clock < t_max * 3:
            S.step(1 / 240)
        t = S.clock
        if best is None or abs(t - target) < abs(best[2] - target):
            best = (growth, n_notes, t)
        if t_min <= t <= t_max:
            return growth, n_notes, t
        # more notes (melody repeats) to go longer, fewer to go shorter
        n_notes = max(12, int(n_notes * target / max(t, 1)))
        growth = (R * 0.93 - R0) / n_notes
    return best


def render(cfg, out_path, sound):
    rng = random.Random(cfg["seed"])
    song = cfg.get("song")
    if song not in MELODIES:
        song = rng.choice(list(MELODIES))
    composer, melody = MELODIES[song]
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    growth, n_notes, est = tune(cfg["seed"], len(melody), t_min, t_max)
    print(f"  {song} ({composer}): {n_notes} notes, ~{est:.1f}s")
    if not getattr(sound, "music_file", None):
        sound.music = False  # the melody IS the music
    th = THEMES.get(cfg.get("theme"), THEMES["midnight"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, est + 4.5, th)
    fx = V.Particles(random.Random(cfg["seed"]))
    spec = (cfg.get("racers") or [{"name": "Ball", "color": "#ffffff"}])[0]
    look = V.Look(spec, 60)
    S = Sim(cfg["seed"], growth, n_notes)
    title_lines = _wrap(cfg.get("title") or "EVERY BOUNCE PLAYS A NOTE", 22)
    handle = cfg.get("handle", "")
    seen = 0
    glows = []  # (time, x, y, hue)
    win_time = None
    trail = []
    while True:
        t = run.t
        if win_time is None:
            for _ in range(run.sub):
                S.step(run.dt / run.sub)
            while seen < len(S.hits):
                ht, x, y = S.hits[seen]
                m = melody[seen % len(melody)]
                sound.add(t, "note", m=m, pan=0.2 + 0.6 * x / W)
                hue = (seen * 0.045) % 1.0
                glows.append([t, x, y, hue])
                r, g, b = colorsys.hsv_to_rgb(hue, 0.6, 1.0)
                fx.burst(x, y, (int(r * 255), int(g * 255), int(b * 255)), n=10, speed=300, size=(4, 9), life=(0.3, 0.6), gravity=0)
                seen += 1
            if S.done:
                win_time = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
        fx.update(run.dt)
        trail.append((S.body.position.x, S.body.position.y))
        trail = trail[-10:]
        run.clear()
        cv = run.canvas
        gfx.filled_circle(cv, int(CX), int(CY), int(R), T["floor"])
        # ring lights up around recent hits
        segs = 180
        for k in range(segs):
            a0, a1 = 2 * math.pi * k / segs, 2 * math.pi * (k + 1) / segs
            col = (70, 74, 96)
            for gt, gx, gy, hue in glows[-6:]:
                age = t - gt
                if age < 0.6:
                    ga = math.atan2(gy - CY, gx - CX)
                    dang = abs((a0 - ga + math.pi) % (2 * math.pi) - math.pi)
                    if dang < 0.5:
                        r, g, b = colorsys.hsv_to_rgb(hue, 0.65, 1.0)
                        k2 = (1 - age / 0.6) * (1 - dang / 0.5)
                        col = V.mix(col, (int(r * 255), int(g * 255), int(b * 255)), k2)
            pygame.draw.line(cv, col, (CX + math.cos(a0) * R, CY + math.sin(a0) * R),
                             (CX + math.cos(a1) * R, CY + math.sin(a1) * R), 8)
        glows = [g for g in glows if t - g[0] < 0.6]
        # fill progress
        frac = 1.0 if win_time is not None else (S.r - R0) / (R * 0.93 - R0)
        hue = (seen * 0.045) % 1.0
        rr, gg, bb = colorsys.hsv_to_rgb(hue, 0.55, 1.0)
        bcol = (int(rr * 255), int(gg * 255), int(bb * 255))
        for i in range(1, len(trail)):
            k = i / len(trail)
            pygame.draw.line(cv, V.mix(T["floor"], bcol, 0.1 + 0.35 * k), trail[i - 1], trail[i], max(2, int(S.r * 0.6 * k)))
        if look.kind == "square":
            gfx.filled_circle(cv, int(S.body.position.x), int(S.body.position.y), int(S.r), bcol)
            gfx.aacircle(cv, int(S.body.position.x), int(S.body.position.y), int(S.r), V.lighter(bcol, 0.4))
            if V.STYLE.get("faces", True) and S.r > 14:
                look._eyes(cv, S.body.position.x, S.body.position.y, 0.0, S.body.velocity.x, S.body.velocity.y,
                           S.r * 0.32, -S.r * 0.1, S.r * 0.24)
        else:
            look.draw_body(cv, S.body.position.x, S.body.position.y, S.body.angle, S.body.velocity.x, S.body.velocity.y, S.r * 2, "ball")
        fx.draw(cv)
        y = _draw_title(cv, title_lines, t)
        V.blit_center(cv, V.text(f"{song.upper()} · {composer.upper()}", 40, (255, 215, 140), (0, 0, 0)), W / 2, y + 6)
        V.blit_center(cv, V.text(f"{int(frac * 100)}%", 64, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, CY + R + 90)
        if handle:
            V.blit_center(cv, V.text(handle, 30, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1840)
        if win_time is not None:
            a = min(1, (t - win_time) / 0.35)
            dim = pygame.Surface((W, H), pygame.SRCALPHA)
            dim.fill((4, 5, 9, int(170 * a)))
            cv.blit(dim, (0, 0))
            lab = V.text("C O M P L E T E", 40, (200, 205, 220), None, weight="ExtraBold")
            lab.set_alpha(int(255 * a))
            V.blit_center(cv, lab, W / 2, CY - 120)
            nm = song.upper()
            V.blit_center(cv, V.text(nm, 130 if len(nm) < 12 else 90 if len(nm) < 20 else 64, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, CY)
            if t - win_time > 1.0:
                V.blit_center(cv, V.text(f"{seen} bounces · {composer}", 46, (255, 210, 120), None, weight="Medium"), W / 2, CY + 120)
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Song ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": song, "level": cfg["seed"]}
