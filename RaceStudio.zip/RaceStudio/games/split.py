"""Split & Crush: balls bounce inside a circle with spinning blades. Every ball a blade
crushes splits into N new balls. How many can it handle? Ends when the circle maxes out."""
import colorsys
import math
import random

import pymunk
import pygame.gfxdraw as gfx

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title

THEMES = {
    "deep": {"bg1": "#020308", "bg2": "#0a1222", "ring": "#7fa6c4", "floor": "#050a14", "blade": "#7aa0c8", "accent": "#ff4d4d"},
    "lava": {"bg1": "#0a0202", "bg2": "#2a0806", "ring": "#ffb08a", "floor": "#120403", "blade": "#ffcf4a", "accent": "#ff6a3d"},
    "mint": {"bg1": "#010806", "bg2": "#06241c", "ring": "#9cf2d4", "floor": "#03100c", "blade": "#c8fff0", "accent": "#ffd23f"},
    "violet": {"bg1": "#06020c", "bg2": "#1c0a33", "ring": "#c9a8ff", "floor": "#0a0516", "blade": "#e2d4ff", "accent": "#ff5ec8"},
}
RANDOM_THEMES = list(THEMES)
CX, CY, AR = 540, 1000, 470
R = 13
CT_BALL, CT_WALL, CT_BLADE = 1, 2, 3


class Sim:
    def __init__(self, seed, splits=3, blades=4, cap=700, speed=420, sound=None, fx=None, immune=0.25):
        self.rng = random.Random(seed * 11 + 5)
        self.splits, self.cap, self.speed, self.immune = splits, cap, speed, immune
        self.sound, self.fx = sound, fx
        self.clock = self.now = 0.0
        self.crushed = 0
        self.hue = 0.0
        sp = pymunk.Space()
        sp.iterations = 8
        self.space = sp
        segs = 120
        for k in range(segs):
            a0, a1 = 2 * math.pi * k / segs, 2 * math.pi * (k + 1) / segs
            s = pymunk.Segment(sp.static_body, (CX + math.cos(a0) * AR, CY + math.sin(a0) * AR),
                               (CX + math.cos(a1) * AR, CY + math.sin(a1) * AR), 6)
            s.elasticity, s.friction, s.collision_type = 1.0, 0.0, CT_WALL
            sp.add(s)
        self.blades = []
        for k in range(blades):
            a = 2 * math.pi * k / blades + math.pi / 4
            d = AR * 0.55
            body = pymunk.Body(body_type=pymunk.Body.KINEMATIC)
            body.position = (CX + math.cos(a) * d, CY + math.sin(a) * d)
            body.angular_velocity = (1 if k % 2 else -1) * self.rng.uniform(2.2, 3.2)
            shapes = []
            for j in range(3):
                b = 2 * math.pi * j / 3
                s = pymunk.Segment(body, (0, 0), (math.cos(b) * 95, math.sin(b) * 95), 9)
                s.elasticity, s.collision_type = 1.0, CT_BLADE
                shapes.append(s)
            sp.add(body, *shapes)
            self.blades.append(body)
        self.balls = []
        self.queue, self.dead = [], []
        self._spawn(CX, CY - 60, self.rng.uniform(0, 6.28), 0)
        sp.on_collision(CT_BALL, CT_BLADE, begin=self._crush)
        sp.on_collision(CT_BALL, CT_WALL, post_solve=self._wall)
        self.maxed = None

    def _spawn(self, x, y, ang, gen):
        b = pymunk.Body(1, pymunk.moment_for_circle(1, 0, R))
        b.position = (x, y)
        b.velocity = (math.cos(ang) * self.speed, math.sin(ang) * self.speed)
        s = pymunk.Circle(b, R)
        s.elasticity, s.friction, s.collision_type = 1.0, 0.0, CT_BALL
        self.hue = (self.hue + 0.137) % 1
        s.color = tuple(int(c * 255) for c in colorsys.hsv_to_rgb(self.hue, 0.65, 1.0))
        s.born = self.clock
        s.gen = gen
        self.space.add(b, s)
        self.balls.append(s)

    def _crush(self, arb, space, data):
        s = arb.shapes[0]
        if self.clock - s.born < self.immune or s in self.dead:
            return False
        self.dead.append(s)
        p = s.body.position
        if len(self.balls) - len(self.dead) + len(self.queue) + self.splits <= self.cap:
            for k in range(self.splits):
                a = math.atan2(CY - p.y, CX - p.x) + (k - (self.splits - 1) / 2) * 0.8 + self.rng.uniform(-0.2, 0.2)
                self.queue.append((p.x + math.cos(a) * R * 2.2, p.y + math.sin(a) * R * 2.2, a, s.gen + 1))
        self.crushed += 1
        if self.sound is not None:
            self.sound.add(self.now, "break" if self.crushed % 3 == 0 else "hit", pan=0.15 + 0.7 * p.x / W, min_gap=0.05)
        if self.fx is not None:
            self.fx.burst(p.x, p.y, s.color, n=6, speed=260, size=(3, 6), life=(0.15, 0.35))
        return False

    def _wall(self, arb, space, data):
        if arb.is_first_contact and self.sound is not None and len(self.balls) < 40:
            p = arb.shapes[0].body.position
            self.sound.add(self.now, "bounce", pan=0.15 + 0.7 * p.x / W, min_gap=0.07, gain=0.5)

    def step(self, dt, now):
        self.now = now
        self.clock += dt
        for b in self.blades:
            b.angle += b.angular_velocity * dt
        self.space.step(dt)
        for s in self.dead:
            if s.body.space is not None:
                self.space.remove(s.body, s)
        dead = set(self.dead)
        self.balls = [s for s in self.balls if s not in dead]
        self.dead = []
        for q in self.queue:
            self._spawn(*q)
        self.queue = []
        for s in self.balls:
            v = s.body.velocity
            l = v.length or 1
            if abs(l - self.speed) > 4:
                s.body.velocity = v * (self.speed / l)
            p = s.body.position
            if (p.x - CX) ** 2 + (p.y - CY) ** 2 > (AR - 5) ** 2:
                s.body.position = (CX + (p.x - CX) * 0.95, CY + (p.y - CY) * 0.95)
        if self.maxed is None and len(self.balls) >= self.cap - self.splits:
            self.maxed = self.clock


def tune(seed, splits, blades, t_min, t_max):
    """Newborn balls are safe for a moment; that 'immune' time sets how fast it snowballs."""
    target = (t_min + t_max) / 2 - 2
    best = None
    for immune in (0.3, 0.6, 1.0, 1.5, 2.2, 3.0, 4.0):
        S = Sim(seed, splits, blades, 700, 420, immune=immune)
        while S.maxed is None and S.clock < t_max * 1.5:
            S.step(1 / 120, S.clock)
        t = S.maxed if S.maxed is not None else S.clock
        if best is None or abs(t - target) < abs(best[2] - target):
            best = (700, immune, t)
        if t > target:
            break
    return best


def render(cfg, out_path, sound):
    rng = random.Random(cfg["seed"])
    splits = int(cfg.get("splits") or rng.choice([2, 3, 3, 4]))
    blades = int(cfg.get("blades") or rng.choice([3, 4, 4, 5]))
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    cap, immune, est = tune(cfg["seed"], splits, blades, t_min, t_max)
    spd = 420
    print(f"  splits {splits}, blades {blades}, max {cap} balls, immune {immune}s, ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["deep"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, est + 5, th)
    run.comm.on = False
    fx = V.Particles(random.Random(cfg["seed"]))
    S = Sim(cfg["seed"], splits, blades, cap, spd, sound=sound, fx=fx, immune=immune)
    title = _wrap(cfg.get("title") or f"EVERY BALL CRUSHED SPLITS INTO {splits}", 22)
    handle = cfg.get("handle", "")
    sound.add(0.0, "go")
    end_t = None
    shown = 1.0
    cache = {}
    marks = [10, 50, 100, 250, 500, 1000]
    said = set()
    while True:
        t = run.t
        if end_t is None:
            for i in range(run.sub):
                S.step(run.dt / run.sub, t + i * run.dt / run.sub)
            n = len(S.balls)
            for m in marks:
                if n >= m and m not in said:
                    said.add(m)
                    run.comm.drama += 1
                    sound.add(t, "escape")
            if S.maxed is not None:
                end_t = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        gfx.filled_circle(cv, CX, CY, AR + 14, V.darker(T["ring"], 0.35))
        gfx.filled_circle(cv, CX, CY, AR, T["floor"])
        for k in range(4):
            gfx.aacircle(cv, CX, CY, AR + k, T["ring"])
        for s in S.balls:
            key = s.color
            if key not in cache:
                im = pygame.Surface((R * 2 + 2, R * 2 + 2), pygame.SRCALPHA)
                gfx.filled_circle(im, R + 1, R + 1, R, V.darker(s.color, 0.75))
                gfx.filled_circle(im, R + 1, R + 1, R - 2, s.color)
                gfx.aacircle(im, R + 1, R + 1, R, V.darker(s.color, 0.6))
                gfx.filled_circle(im, R - 3, R - 3, 3, V.lighter(s.color, 0.6))
                cache[key] = im
            p = s.body.position
            cv.blit(cache[key], (p.x - R - 1, p.y - R - 1))
        for b in S.blades:
            for s in b.shapes:
                a, c = b.local_to_world(s.a), b.local_to_world(s.b)
                pygame.draw.line(cv, T["blade"], a, c, 20)
                gfx.filled_circle(cv, int(c.x), int(c.y), 10, T["blade"])
            gfx.filled_circle(cv, int(b.position.x), int(b.position.y), 14, (255, 255, 255))
            gfx.filled_circle(cv, int(b.position.x), int(b.position.y), 6, (20, 20, 20))
        fx.draw(cv)
        _draw_title(cv, title, t)
        n = len(S.balls)
        shown += (n - shown) * min(1, run.dt * 12)
        big = 96 if end_t is None else int(96 + 20 * min(1, (t - end_t) * 4))
        V.blit_center(cv, V.text(f"BALLS: {int(round(shown))}", big, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, 1600)
        if end_t is not None:
            a = min(1, (t - end_t) / 0.3)
            s2 = V.text("MAXED OUT!", 110, T["accent"], (0, 0, 0), weight="Display")
            s2.set_alpha(int(255 * a))
            V.blit_center(cv, s2, W / 2, 1735)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1870)
        run.push()
        if end_t is not None and t - end_t >= 3.6:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Simulation ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": f"{len(S.balls)} balls", "level": cfg["seed"]}
