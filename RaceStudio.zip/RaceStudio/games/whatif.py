"""What If…? — the same scene twice, side by side: the normal world on top, a changed
world (gravity x2, no friction, 200 balls…) underneath. Same seed, so the only
difference is the rule you changed.
"""
import colorsys
import math
import random

import pymunk
import pygame.gfxdraw as gfx

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title

THEMES = {
    "lab": {"bg1": "#05060a", "bg2": "#151a26", "wall": "#cfd6e6", "panel": "#0b0d14", "accent": "#5ee0ff"},
    "neon": {"bg1": "#07020c", "bg2": "#22093a", "wall": "#f2d7ff", "panel": "#0e0618", "accent": "#ff5ec8"},
    "sand": {"bg1": "#0b0804", "bg2": "#2b2010", "wall": "#ffe6b8", "panel": "#140f07", "accent": "#ffb347"},
}
RANDOM_THEMES = list(THEMES)

NORMAL = {"gravity": 1.0, "bounciness": 0.7, "friction": 0.5, "balls": 60, "ball_size": 1.0, "time_scale": 1.0, "wind": 0.0}
PRESETS = {
    "gravity_x2": ("WHAT IF GRAVITY WAS 2X?", "GRAVITY X2", {"gravity": 2.0}),
    "low_gravity": ("WHAT IF GRAVITY WAS WEAK?", "MOON GRAVITY", {"gravity": 0.25}),
    "zero_gravity": ("WHAT IF GRAVITY TURNED OFF?", "ZERO GRAVITY", {"gravity": 0.0}),
    "reverse_gravity": ("WHAT IF GRAVITY FLIPPED?", "REVERSE GRAVITY", {"gravity": -1.0}),
    "super_bouncy": ("WHAT IF EVERYTHING BOUNCED?", "SUPER BOUNCY", {"bounciness": 1.05}),
    "no_bounce": ("WHAT IF NOTHING BOUNCED?", "NO BOUNCE", {"bounciness": 0.0}),
    "no_friction": ("WHAT IF FRICTION DISAPPEARED?", "NO FRICTION", {"friction": 0.0}),
    "giant_balls": ("WHAT IF THE BALLS WERE GIANT?", "GIANT BALLS", {"ball_size": 2.2, "balls": 25}),
    "200_balls": ("WHAT IF THERE WERE 200 BALLS?", "200 BALLS", {"balls": 200, "ball_size": 0.6}),
    "slow_motion": ("WHAT IF TIME SLOWED DOWN?", "SLOW MOTION", {"time_scale": 0.35}),
    "strong_wind": ("WHAT IF A STORM HIT?", "STRONG WIND", {"wind": 2.0}),
}

PW, PH = 960, 700          # panel size
PX = (W - PW) // 2
PANEL_Y = (335, 1095)      # top of each panel
G = 1500.0
BASE_R = 15


MID = PH / 2


def _scene(rng, min_neck=0):
    """A symmetric hourglass with peg fields under (and over) the neck, in panel coordinates.
    Symmetric so the whole thing can be flipped over like a real hourglass."""
    neck = max(min_neck, rng.uniform(210, 240))
    cx = PW / 2
    segs = [((14, 24), (cx - neck / 2, MID)), ((PW - 14, 24), (cx + neck / 2, MID)),
            ((14, PH - 24), (cx - neck / 2, MID)), ((PW - 14, PH - 24), (cx + neck / 2, MID))]
    pegs = []
    for side in (1, -1):
        for j in range(3):
            yy = MID + side * (95 + j * 58)
            half = (PW / 2 - 14 - neck / 2) * (abs(yy - MID) / (MID - 24)) + neck / 2 - (2.4 * max(30, min_neck / 4.2) + 22)
            off = 0 if j % 2 else 41
            x = cx - half + off
            while x < cx + half:
                pegs.append((x, yy))
                x += 82
    return segs, pegs, neck


def _inside_top(x, y, r, neck):
    """Is a ball at (x, y) fully inside the top bowl?"""
    if y < 24 + r * 1.5 or y > MID - r * 2:
        return False
    half = (PW / 2 - 14 - neck / 2) * ((MID - y) / (MID - 24)) + neck / 2
    return abs(x - PW / 2) < half - r * 1.6


class World:
    def __init__(self, seed, st, sound=None, panel=0, min_neck=0):
        rng = random.Random(seed)
        self.st = st
        self.sound, self.panel = sound, panel
        self.now = 0.0
        sp = pymunk.Space()
        g = G * st["gravity"]
        self.gdir = 1
        sp.gravity = (G * 0.45 * st["wind"], g)
        sp.iterations = 20
        sp.damping = 0.995 if st["friction"] > 0.05 else 1.0
        self.space = sp
        segs, self.pegs, neck = _scene(rng, min_neck)
        self.segs = segs + [((0, 0), (PW, 0)), ((PW, 0), (PW, PH)), ((PW, PH), (0, PH)), ((0, PH), (0, 0))]
        for a, b in self.segs:
            s = pymunk.Segment(sp.static_body, a, b, 5)
            s.elasticity, s.friction, s.collision_type = st["bounciness"], st["friction"], 2
            sp.add(s)
        for (x, y) in self.pegs:
            c = pymunk.Circle(sp.static_body, 7, (x, y))
            c.elasticity, c.friction, c.collision_type = st["bounciness"], st["friction"], 2
            sp.add(c)
        n = int(st["balls"])
        self.r = r = BASE_R * st["ball_size"]
        self.balls = []
        # same spawn pattern in both worlds: a loose grid in the top bowl
        prng = random.Random(seed * 7 + 1)
        spots = []
        y = 24 + r * 1.6
        while y < MID - r * 2:
            x = r + 4 + (r * 1.15 if len(spots) % 2 else 0)
            while x < PW - r:
                if _inside_top(x, y, r, neck):
                    spots.append((x, y))
                x += r * 2.25
            y += r * 2.2
        spots.sort(key=lambda p: (p[1], p[0]))
        fit = max(1, int(len(spots) * 0.6))
        for i in range(n):
            x, y = spots[i % fit]
            b = pymunk.Body(1.0, pymunk.moment_for_circle(1.0, 0, r))
            b.position = (x + prng.uniform(-2, 2), y)
            if abs(st["gravity"]) < 0.3:   # floating world: everything drifts
                a_ = prng.uniform(0, 2 * math.pi)
                b.velocity = (math.cos(a_) * 220, math.sin(a_) * 220)
            else:
                b.velocity = (prng.uniform(-30, 30), 0)
            b.delay = (i // fit) * 1.1   # extra waves drop in once there's room
            s = pymunk.Circle(b, r)
            s.elasticity, s.friction, s.collision_type = st["bounciness"], st["friction"] * 0.25, 1
            hue = (i / max(1, n)) * 0.85
            s.color = tuple(int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.72, 1.0))
            self.balls.append((b, s))
        self.pending = [(b, s) for b, s in self.balls if b.delay > 0]
        for b, s in self.balls:
            if b.delay == 0:
                sp.add(b, s)
        sp.on_collision(1, 2, post_solve=self._hit)
        sp.on_collision(1, 1, post_solve=self._hit)
        self.clock = 0.0
        self.hits = 0

    def _hit(self, arb, space, data):
        if arb.is_first_contact and self.sound is not None:
            j = arb.total_impulse
            if math.hypot(j.x, j.y) > 90:
                self.hits += 1
                x = arb.contact_point_set.points[0].point_a.x if arb.contact_point_set.points else PW / 2
                self.sound.add(self.now, "bounce", who=self.panel * 10 + int(x / PW * 6), pan=0.15 + 0.7 * x / PW,
                               min_gap=0.07, gain=0.45)

    def flip(self):
        """Turn the hourglass over: gravity reverses in world coordinates; the renderer rotates the panel."""
        self.gdir *= -1
        self.space.gravity = (self.gdir * G * 0.45 * self.st["wind"], self.gdir * G * self.st["gravity"])
        krng = random.Random(len(self.balls) * 31 + self.gdir)
        for b, s in self.balls:
            if b.space is not None:
                b.activate()
                if abs(self.st["gravity"]) < 0.3:   # turning it over shakes floating balls loose
                    a_ = krng.uniform(0, 2 * math.pi)
                    b.velocity = (b.velocity.x + math.cos(a_) * 260, b.velocity.y + math.sin(a_) * 260)

    def step(self, dt, now):
        self.now = now
        dt *= self.st["time_scale"]
        self.clock += dt
        for b, s in list(self.pending):
            if self.clock >= b.delay:
                self.space.add(b, s)
                self.pending.remove((b, s))
        self.space.step(dt)
        for b, s in self.balls:
            v = b.velocity.length
            if v > 2400:
                b.velocity = b.velocity * (2400 / v)
            # anything that tunnelled out comes back in
            if not (0 < b.position.x < PW and 0 < b.position.y < PH):
                b.position = (min(PW - self.r - 8, max(self.r + 8, b.position.x)), min(PH - self.r - 8, max(self.r + 8, b.position.y)))
                b.velocity = (0, 0)


def pick(cfg):
    """Resolve the scenario: an explicit dict, a preset name, or a random preset."""
    if isinstance(cfg.get("whatif"), dict):
        d = cfg["whatif"]
        return d.get("title", "WHAT IF…?"), d.get("label", "WHAT IF"), d.get("settings", {})
    name = cfg.get("whatif_preset")
    if name not in PRESETS:
        name = random.Random(cfg["seed"]).choice(list(PRESETS))
    return PRESETS[name]


def render(cfg, out_path, sound):
    title, label, changes = pick(cfg)
    st = dict(NORMAL)
    st.update({k: float(v) for k, v in changes.items() if k in NORMAL})
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    dur = max(14.0, min(30.0, (t_min + t_max) / 2))
    th = THEMES.get(cfg.get("theme"), THEMES["lab"])
    T = {k: V.hexc(v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, dur + 0.5, th)
    min_neck = BASE_R * 2 * max(1.0, st["ball_size"]) * 4.2
    worlds = [World(cfg["seed"], dict(NORMAL), sound, 0, min_neck), World(cfg["seed"], st, sound, 1, min_neck)]
    title_lines = _wrap(cfg.get("title") or title, 20)
    labels = ["NORMAL", label.upper()]
    handle = cfg.get("handle", "")
    sound.add(0.0, "go")
    sound.climax(dur - 2.6)
    ball_cache = {}

    def ball_img(r, col):
        key = (round(r * 2), col)
        if key not in ball_cache:
            d = max(4, round(r * 2))
            s = pygame.Surface((d + 2, d + 2), pygame.SRCALPHA)
            c = d / 2 + 1
            gfx.filled_circle(s, int(c), int(c), int(d / 2), V.darker(col, 0.7))
            gfx.filled_circle(s, int(c), int(c), int(d / 2 * 0.86), col)
            gfx.aacircle(s, int(c), int(c), int(d / 2), V.darker(col, 0.7))
            gfx.filled_circle(s, int(c - d * 0.16), int(c - d * 0.17), max(1, int(d * 0.13)), V.lighter(col, 0.6))
            ball_cache[key] = s
        return ball_cache[key]

    flips, t_f = [], 5.0
    while t_f < dur - 4.0:
        flips.append(t_f)
        t_f += 6.0
    FLIP_T = 0.6
    done = 0
    surf = pygame.Surface((PW, PH), pygame.SRCALPHA)
    while run.t < dur:
        t = run.t
        if done < len(flips) and t >= flips[done]:
            for w in worlds:
                w.flip()
            sound.add(t, "whoosh")
            done += 1
        for i in range(run.sub):
            for w in worlds:
                w.step(run.dt / run.sub, t + i * run.dt / run.sub)
        run.clear()
        cv = run.canvas
        _draw_title(cv, title_lines, t, y0=100)
        # panel rotation: 180 degrees per completed flip, eased while turning
        u = min(1, (t - flips[done - 1]) / FLIP_T) if done else 1
        ease = u * u * (3 - 2 * u)
        ang = 180 * (done - 1 + ease) if done else 0
        zoom = 1 - 0.28 * math.sin(math.pi * u) if done and u < 1 else 1
        for k, w in enumerate(worlds):
            oy = PANEL_Y[k]
            surf.fill((0, 0, 0, 0))
            pygame.draw.rect(surf, T["panel"], surf.get_rect(), border_radius=22)
            for a, b in w.segs[:4]:
                pygame.draw.line(surf, T["wall"], a, b, 8)
            for (x, y) in w.pegs:
                gfx.filled_circle(surf, int(x), int(y), 7, T["wall"])
                gfx.aacircle(surf, int(x), int(y), 7, T["wall"])
            for b, s in w.balls:
                if b.space is None:
                    continue
                V.blit_center(surf, ball_img(w.r, s.color), b.position.x, b.position.y)
            pygame.draw.rect(surf, T["accent"] if k else (90, 96, 110), surf.get_rect(), 4, border_radius=22)
            if ang % 360 == 0 and zoom == 1:
                cv.blit(surf, (PX, oy))
            elif ang % 360 == 180 and zoom == 1:
                cv.blit(pygame.transform.rotate(surf, 180), (PX, oy))
            else:
                V.blit_center(cv, pygame.transform.rotozoom(surf, ang, zoom), W / 2, oy + PH / 2)
            tag = V.text(labels[k], 40, (255, 255, 255) if k == 0 else T["accent"], (0, 0, 0), weight="ExtraBold")
            V.blit_center(cv, tag, W / 2, oy + PH + 32 if k else oy - 32)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1880)
        if t > dur - 2.6:
            a = min(1, (t - (dur - 2.6)) / 0.4)
            q = V.text("WHICH WORLD DO YOU PICK?", 64, (255, 255, 255), (0, 0, 0), weight="Display")
            pill = pygame.Surface((q.get_width() + 80, q.get_height() + 40), pygame.SRCALPHA)
            pygame.draw.rect(pill, (6, 7, 12, 225), pill.get_rect(), border_radius=28)
            pill.blit(q, (40, 20))
            pill.set_alpha(int(255 * a))
            V.blit_center(cv, pill, W / 2, (PANEL_Y[0] + PH + PANEL_Y[1]) / 2)
        run.push()
    d = run.finish()
    return {"duration": d, "winner": label, "level": cfg["seed"]}
