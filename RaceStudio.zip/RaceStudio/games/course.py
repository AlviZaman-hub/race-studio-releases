"""Obstacle Course: racers drop through a long course built from obstacle zones
(hammers, pistons, conveyor belts, flippers, portals, trapdoors, gears, windmills,
launch pads, moving platforms...). Every level is a new mix; higher levels are harder
and faster. Nobody stays stuck on one obstacle for long.
"""
import math
import random

import pymunk
import pygame.gfxdraw as gfx

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner

THEMES = {
    "neon": {"bg1": "#05030c", "bg2": "#1a0a33", "wall": "#b9a8ff", "peg": "#f2ecff", "accent": "#ff4fd8", "hot": "#ffd23f", "panel": "#0c0818"},
    "factory": {"bg1": "#0a0806", "bg2": "#2e2618", "wall": "#e0c890", "peg": "#fff2d6", "accent": "#ff8a1f", "hot": "#ffe14d", "panel": "#15110b"},
    "ocean": {"bg1": "#020a12", "bg2": "#0a2c46", "wall": "#8fd6ff", "peg": "#e6f7ff", "accent": "#3ff2c8", "hot": "#ffcf4a", "panel": "#061524"},
    "candy": {"bg1": "#12040e", "bg2": "#3a0c2c", "wall": "#ffb3dc", "peg": "#fff0f8", "accent": "#7ad7ff", "hot": "#fff36b", "panel": "#1a0814"},
    "jungle": {"bg1": "#020a04", "bg2": "#0d3018", "wall": "#9be39a", "peg": "#eaffe6", "accent": "#ffb347", "hot": "#ff5e5e", "panel": "#06140a"},
}
RANDOM_THEMES = list(THEMES)

STYLES = {
    "mixed": ("OBSTACLE MIX", None),
    "factory": ("HAMMER FACTORY", ["hammers", "pistons", "conveyors", "gears", "trapdoors", "stairs"]),
    "pinball": ("PINBALL MADNESS", ["flippers", "bumpers", "launch", "spinners", "pegs", "windmills"]),
    "chaos": ("TOTAL CHAOS", ["portals", "windmills", "platforms", "hammers", "launch", "gears"]),
    "classic": ("CLASSIC DROP", ["pegs", "stairs", "funnel", "spinners", "bumpers", "platforms"]),
    "portal": ("PORTAL MAZE", ["portals", "pegs", "conveyors", "trapdoors", "portals", "spinners"]),
}
ZONES = {
    "pegs": "PEG FIELD", "spinners": "SPINNERS", "hammers": "HAMMER TIME", "pistons": "PISTON ALLEY",
    "conveyors": "CONVEYOR BELTS", "flippers": "FLIPPERS", "portals": "PORTALS", "trapdoors": "TRAPDOORS",
    "gears": "GEAR GRINDER", "bumpers": "BUMPER PIT", "launch": "LAUNCH PADS", "stairs": "STAIRS",
    "platforms": "MOVING PLATFORMS", "windmills": "WINDMILLS", "funnel": "FUNNEL",
}
ALL_ZONES = list(ZONES)

L, R = 50, 1030
CX = (L + R) / 2
G = 1900.0
VIEW_TOP, VIEW_BOT = 330, 1640
CT_M, CT_S, CT_BUMP, CT_LAUNCH, CT_PORTAL = 1, 2, 3, 4, 5


class Mover:
    """A kinematic body whose motion is a function of time (rotor, swing, slide, door)."""
    def __init__(self, space, kind, pos, shapes_fn, **p):
        self.kind, self.p = kind, p
        self.body = pymunk.Body(body_type=pymunk.Body.KINEMATIC)
        self.body.position = pos
        self.base = pos
        self.shapes = shapes_fn(self.body)
        for s in self.shapes:
            s.elasticity = p.get("el", 0.5)
            s.friction = p.get("fr", 0.6)
            s.collision_type = CT_S
        space.add(self.body, *self.shapes)
        self.color = p.get("color", "accent")

    def update(self, t, dt):
        b, p = self.body, self.p
        if self.kind == "rotor":
            b.angular_velocity = p["w"]
            b.angle = p.get("a0", 0) + p["w"] * t
        elif self.kind == "swing":
            w, amp, a0 = p["w"], p["amp"], p["a0"]
            b.angle = a0 + amp * math.sin(w * t + p.get("ph", 0))
            b.angular_velocity = amp * w * math.cos(w * t + p.get("ph", 0))
        elif self.kind == "slide":
            w, amp, ph = p["w"], p["amp"], p.get("ph", 0)
            dx, dy = p.get("dir", (1, 0))
            off = amp * math.sin(w * t + ph)
            vel = amp * w * math.cos(w * t + ph)
            b.position = (self.base[0] + dx * off, self.base[1] + dy * off)
            b.velocity = (dx * vel, dy * vel)
        elif self.kind == "door":   # snaps open for a moment every period
            per, open_t, ph = p["per"], p["open"], p.get("ph", 0)
            u = (t + ph) % per
            target = p["dist"] if u < open_t else 0.0
            cur = b.position.x - self.base[0]
            v = (target - cur) * 14
            b.velocity = (v, 0)
            b.position = (self.base[0] + cur + v * dt, self.base[1])
        elif self.kind == "flip":   # pinball flipper: rests down, flicks up periodically
            per, ph = p["per"], p.get("ph", 0)
            u = (t + ph) % per
            k = u / 0.1 if u < 0.1 else 1.0 if u < 0.25 else max(0.0, 1 - (u - 0.25) / 0.35)
            target = p["rest"] + (p["up"] - p["rest"]) * k
            av = max(-12.0, min(12.0, (target - b.angle) / max(dt, 1e-3)))   # a firm flick, not a cannon
            b.angular_velocity = av
            b.angle += av * dt


class Course:
    def __init__(self, seed, n_zones, r, level, style):
        self.rng = rng = random.Random(seed * 7 + level)
        self.level = level
        self.diff = min(1.0, (level - 1) / 60)         # 0 easy .. 1 brutal
        self.speed = 1.0 + 0.6 * self.diff
        self.segs, self.pegs, self.bumpers, self.launch = [], [], [], []
        self.conveyors, self.portals, self.mover_specs = [], [], []
        self.zones = []            # (y0, y1, kind)
        pool = STYLES.get(style, STYLES["mixed"])[1] or ALL_ZONES
        y = 140
        last = None
        kinds = []
        for k in range(n_zones):
            options = [z for z in pool if z != last] or pool
            z = rng.choice(options)
            kinds.append(z)
            last = z
        self.kinds = kinds
        self.r = r
        for k, z in enumerate(kinds):
            y0 = y
            y = getattr(self, "_" + z)(y)
            self.zones.append((y0, y, z))
            if k % 2 == 1 and k < n_zones - 1:
                y = self._ramp(y)
        self.finish_y = y + 120
        self.segs.append(((L, self.finish_y + 240), (R, self.finish_y + 240), 0.3))

    # ------------------------------------------------------------------ helpers
    def seg(self, a, b, el=0.4):
        self.segs.append((a, b, el))

    def _ramp(self, y):
        """A short funnel that collects everyone toward a random side before the next zone."""
        hole = self.r * 2 + 70
        cx = self.rng.uniform(L + 200, R - 200)
        self.seg((L, y), (cx - hole / 2, y + 140))
        self.seg((R, y), (cx + hole / 2, y + 140))
        return y + 140 + self.r * 3

    # ------------------------------------------------------------------ zones
    def _pegs(self, y):
        rows = self.rng.randint(4, 6)
        sx = self.r * 2 + 34
        for j in range(rows):
            off = sx / 2 if j % 2 else 0
            x = L + self.r * 2 + 30 + off
            while x < R - self.r * 2 - 30:
                self.pegs.append((x, y + 40 + j * 80))
                x += sx
        return y + 60 + rows * 80

    def _spinners(self, y):
        n = self.rng.choice([1, 2, 3])
        xs = [CX] if n == 1 else [CX - 250, CX + 250] if n == 2 else [L + 170, CX, R - 170]
        ln = {1: 520, 2: 380, 3: 260}[n]
        for i, x in enumerate(xs):
            w = (1 if i % 2 else -1) * self.rng.uniform(1.6, 2.4) * self.speed
            self.mover_specs.append(("rotor", (x, y + 200), "bar", {"len": ln, "w": w, "a0": self.rng.uniform(0, 3)}))
        return y + 400

    def _windmills(self, y):
        xs = [CX - 240, CX + 240]
        for i, x in enumerate(xs):
            w = (1 if i % 2 else -1) * self.rng.uniform(1.0, 1.6) * self.speed
            self.mover_specs.append(("rotor", (x, y + 230), "cross", {"len": 400, "w": w, "a0": self.rng.uniform(0, 3), "arms": 4}))
        return y + 470

    def _gears(self, y):
        rows = 2
        for j in range(rows):
            for i, x in enumerate([L + 170, CX, R - 170] if j % 2 == 0 else [CX - 245, CX + 245]):
                w = ((i + j) % 2 * 2 - 1) * self.rng.uniform(1.4, 2.2) * self.speed
                self.mover_specs.append(("rotor", (x, y + 140 + j * 230), "cross", {"len": 210, "w": w, "a0": self.rng.uniform(0, 3), "arms": 3}))
        return y + 140 + rows * 230 + 40

    def _hammers(self, y):
        """Giant hammers swing across a sloped floor and bat racers along (or back!)."""
        n = self.rng.choice([2, 3])
        s = self.rng.choice([-1, 1])
        py = y + 40                      # pivots sit inside the zone, never in the entry funnel
        hi, lo = py + 230, py + 420      # floor slopes down toward the exit gap
        gap = self.r * 2 + 70
        if s > 0:
            self.seg((L, hi), (R - gap, lo))
        else:
            self.seg((R, hi), (L + gap, lo))
        for i in range(n):
            px = L + 90 + (R - L - 180) * (i + 0.5) / n
            self.mover_specs.append(("swing", (px, py), "hammer",
                                     {"len": 175, "w": self.rng.uniform(2.2, 3.0) * self.speed, "amp": 0.85, "a0": math.pi / 2,
                                      "ph": i * 1.7, "el": 0.45}))
        return lo + self.r * 3.2

    def _pistons(self, y):
        rows = 3
        for j in range(rows):
            side = 1 if j % 2 == 0 else -1
            yy = y + 80 + j * 150
            x0 = L + 150 if side > 0 else R - 150
            self.mover_specs.append(("slide", (x0, yy), "box", {"w2": 140, "h2": 26, "w": self.rng.uniform(2.0, 3.0) * self.speed,
                                                                "amp": 260, "dir": (side, 0), "ph": j * 1.3, "el": 0.7}))
        return y + 80 + rows * 150 + 40

    def _conveyors(self, y):
        rows = 2
        for j in range(rows):
            yy = y + 100 + j * 190
            d = 1 if j % 2 == 0 else -1
            gap = self.r * 2 + 70
            if d > 0:
                a, b = (L, yy - 45), (R - gap, yy + 45)
            else:
                a, b = (R, yy - 45), (L + gap, yy + 45)
            sp = (520 + 260 * self.diff) * self.rng.uniform(0.75, 1.25)   # fast belts toward the gap, each a different speed
            self.conveyors.append((a, b, sp))
        return y + 100 + rows * 190 + 30

    def _flippers(self, y):
        hole = self.r * 2 + 120
        self.seg((L, y), (CX - hole / 2 - 70, y + 260))
        self.seg((R, y), (CX + hole / 2 + 70, y + 260))
        for s in (-1, 1):
            px = CX + s * (hole / 2 + 70)
            # arm points toward the middle and hangs down at rest (hole open), flicks up to bat racers
            self.mover_specs.append(("flip", (px, y + 262), "flipper",
                                     {"len": 120, "dirx": -s, "rest": -0.75 * s, "up": 0.3 * s,
                                      "per": self.rng.uniform(1.6, 2.2), "ph": 0.4 if s > 0 else 0.0, "el": 0.6}))
        for _ in range(3):
            br = self.rng.uniform(30, 40)
            self.bumpers.append((self.rng.uniform(L + 160, R - 160), y + self.rng.uniform(40, 150), br))
        return y + 262 + self.r * 4

    def _bumpers(self, y):
        for _ in range(self.rng.randint(4, 6)):
            br = self.rng.uniform(30, 46)
            self.bumpers.append((self.rng.uniform(L + br + self.r * 2 + 30, R - br - self.r * 2 - 30), y + self.rng.uniform(60, 260), br))
        return y + 360

    def _launch(self, y):
        # bouncy pads on a V floor that throw racers around before they drain through the middle
        hole = self.r * 2 + 140
        a, b = (L, y + 40), (CX - hole / 2, y + 300)
        c, d = (R, y + 40), (CX + hole / 2, y + 300)
        self.launch += [(a, b), (c, d)]
        return y + 300 + self.r * 3.5

    def _stairs(self, y):
        steps = self.rng.randint(5, 7)
        s = self.rng.choice([-1, 1])
        w = (R - L) / steps
        for i in range(steps):
            x0 = L + i * w if s > 0 else R - (i + 1) * w
            yy = y + 40 + i * 60
            last = i == steps - 1
            if s > 0:
                self.seg((x0, yy), (x0 + w - (self.r * 2 + 50 if last else self.r * 0.6), yy + 12))
            else:
                self.seg((x0 + (self.r * 2 + 50 if last else self.r * 0.6), yy + 12), (x0 + w, yy))
        return y + 40 + steps * 60 + self.r * 3

    def _platforms(self, y):
        rows = 3
        for j in range(rows):
            yy = y + 90 + j * 150
            self.mover_specs.append(("slide", (CX, yy), "box", {"w2": 120, "h2": 14, "w": self.rng.uniform(1.4, 2.2) * self.speed,
                                                              "amp": 300, "dir": (1, 0), "ph": j * 2.1, "el": 0.3, "fr": 0.4}))
        return y + 90 + rows * 150 + 30

    def _trapdoors(self, y):
        # a funnel floor whose middle is a sliding door: opens briefly, so the pack drops in bursts
        hole = self.r * 2 + 110
        self.seg((L, y), (CX - hole / 2, y + 200))
        self.seg((R, y), (CX + hole / 2, y + 200))
        per = max(1.2, 2.0 - 0.8 * self.diff)
        self.mover_specs.append(("door", (CX, y + 202), "box", {"w2": hole / 2 + 18, "h2": 8, "per": per, "open": 0.9,
                                                              "dist": hole + 40, "ph": self.rng.uniform(0, per), "el": 0.2}))
        return y + 202 + self.r * 3.5

    def _portals(self, y):
        # a cup floor with two holes: each drops you through a portal to a different spot lower down
        self.seg((L, y + 140), (CX - 90, y + 200))
        self.seg((R, y + 140), (CX + 90, y + 200))
        exits = [(self.rng.uniform(L + 120, CX - 120), y + 520), (self.rng.uniform(CX + 120, R - 120), y + 520)]
        ents = [(L + 120, y + 120), (R - 120, y + 120)]
        for (ex, ey), (nx, ny) in zip(exits, ents):
            self.portals.append({"in": (nx, ny + 10), "out": (ex, ey), "r": self.r + 26})
        for j in range(2):   # pegs under the exits
            xx = L + 90 + (j % 2) * 50
            while xx < R - 60:
                self.pegs.append((xx, y + 640 + j * 80))
                xx += self.r * 2 + 34
        return y + 820

    def _funnel(self, y):
        hole = self.r * 2 + 60
        cx = self.rng.uniform(L + 260, R - 260)
        self.seg((L, y), (cx - hole / 2, y + 240))
        self.seg((R, y), (cx + hole / 2, y + 240))
        return y + 240 + self.r * 4


class Racer:
    def __init__(self, i, look, r):
        self.i, self.look, self.r = i, look, r
        self.body = pymunk.Body(1.0, pymunk.moment_for_circle(1.0, 0, r))
        self.shape = pymunk.Circle(self.body, r)
        self.shape.elasticity, self.shape.friction, self.shape.collision_type = 0.5, 0.7, CT_M
        self.shape.m = self
        self.done = False
        self.place = None
        self.best_y = 0.0
        self.best_t = 0.0
        self.slow = 0.0
        self.trail = []
        self.portal_t = -9

    x = property(lambda s: s.body.position.x)
    y = property(lambda s: s.body.position.y)


class Sim:
    def __init__(self, looks, seed, n_zones, level, style, sound=None, fx=None):
        self.rng = random.Random(seed * 23 + 2)
        n = len(looks)
        self.r = r = 30 if n <= 6 else 26
        self.course = C = Course(seed, n_zones, r, level, style)
        self.sound, self.fx = sound, fx
        self.clock = self.now = 0.0
        sp = pymunk.Space()
        sp.gravity = (0, G)
        sp.iterations = 25
        self.space = sp
        st = sp.static_body
        for a, b in [((L, -400), (L, C.finish_y + 260)), ((R, -400), (R, C.finish_y + 260))]:
            s = pymunk.Segment(st, a, b, 8)
            s.elasticity, s.friction, s.collision_type = 0.4, 0.5, CT_S
            sp.add(s)
        for a, b, el in C.segs:
            s = pymunk.Segment(st, a, b, 7)
            s.elasticity, s.friction, s.collision_type = el, 0.6, CT_S
            sp.add(s)
        for (x, y) in C.pegs:
            c = pymunk.Circle(st, 9, (x, y))
            c.elasticity, c.friction, c.collision_type = 0.5, 0.3, CT_S
            sp.add(c)
        for (x, y, br) in C.bumpers:
            c = pymunk.Circle(st, br, (x, y))
            c.elasticity, c.friction, c.collision_type = 1.25, 0.2, CT_BUMP
            sp.add(c)
        for a, b in C.launch:
            s = pymunk.Segment(st, a, b, 10)
            s.elasticity, s.friction, s.collision_type = 1.2, 0.3, CT_LAUNCH
            sp.add(s)
        for a, b, v in C.conveyors:
            s = pymunk.Segment(st, a, b, 9)
            s.elasticity, s.friction, s.collision_type = 0.2, 1.2, CT_S
            dx, dy = b[0] - a[0], b[1] - a[1]
            ln = math.hypot(dx, dy)
            s.surface_velocity = (dx / ln * v, dy / ln * v)
            sp.add(s)
        self.movers = []
        for kind, pos, shape, p in C.mover_specs:
            self.movers.append(Mover(sp, kind, pos, _shape_fn(shape, p), **p))
        self.racers = []
        slots = list(range(n))
        self.rng.shuffle(slots)
        for i, lk in enumerate(looks):
            m = Racer(i, lk, r)
            m.body.position = (L + 70 + (R - L - 140) * (slots[i] + 0.5) / n, 40 + self.rng.uniform(-10, 10))
            m.shape.friction = self.rng.uniform(0.45, 0.95)
            m.shape.elasticity = self.rng.uniform(0.35, 0.65)
            sp.add(m.body, m.shape)
            self.racers.append(m)
        sp.on_collision(CT_M, CT_S, post_solve=self._hit)
        sp.on_collision(CT_M, CT_BUMP, post_solve=self._bump)
        sp.on_collision(CT_M, CT_LAUNCH, post_solve=self._launch)
        sp.on_collision(CT_M, CT_M, post_solve=self._mm)
        self.finished = []
        self.winner = None
        self.events = []
        self.max_stuck = 0.0

    def _ev(self, kind, m, **kw):
        if self.sound is not None:
            self.sound.add(self.now, kind, who=m.i, pan=0.15 + 0.7 * m.x / W, **kw)

    def _hit(self, arb, space, data):
        if arb.is_first_contact:
            j = arb.total_impulse
            if math.hypot(j.x, j.y) > 160:
                self._ev("bounce", arb.shapes[0].m, min_gap=0.08, gain=0.7)

    def _bump(self, arb, space, data):
        if arb.is_first_contact:
            self._ev("hit", arb.shapes[0].m, min_gap=0.08)

    def _launch(self, arb, space, data):
        if arb.is_first_contact:
            self._ev("boost", arb.shapes[0].m, min_gap=0.15)

    def _mm(self, arb, space, data):
        if arb.is_first_contact:
            j = arb.total_impulse
            if math.hypot(j.x, j.y) > 140:
                self._ev("racer", arb.shapes[0].m, min_gap=0.12)

    def step(self, dt, now):
        self.now = now
        self.clock += dt
        for mv in self.movers:
            mv.update(self.clock, dt)
        self.space.step(dt)
        C = self.course
        for m in self.racers:
            if m.done:
                continue
            m.body.angular_velocity = max(-40, min(40, m.body.angular_velocity))
            v = m.body.velocity
            sp = v.length
            if sp > 1500:
                m.body.velocity = v * (1500 / sp)
            if m.y > C.finish_y:
                m.done = True
                self.finished.append(m)
                m.place = len(self.finished)
                self._ev("escape", m)
                self.events.append(("finish", m))
                if self.winner is None:
                    self.winner = m
                continue
            # portals
            for pt in C.portals:
                px, py = pt["in"]
                if self.clock - m.portal_t > 1.0 and (m.x - px) ** 2 + (m.y - py) ** 2 < pt["r"] ** 2:
                    m.body.position = pt["out"]
                    m.body.velocity = (self.rng.uniform(-120, 120), 200)
                    m.portal_t = self.clock
                    self._ev("spawn", m)
                    self.events.append(("portal", m))
                    break
            # anti-stuck: progress = deepest point reached; small nudges first, then a real push
            if m.y > m.best_y + 25:
                m.best_y, m.best_t = m.y, self.clock
            stuck = self.clock - m.best_t
            self.max_stuck = max(self.max_stuck, stuck)
            m.slow = m.slow + dt if sp < 45 else 0
            if m.slow > 0.8:
                m.body.velocity = ((1 if m.x < CX else -1) * self.rng.uniform(260, 420), -260)
                m.slow = 0
            if stuck > 2.6:   # never held by one obstacle for long: hop past it
                m.body.position = (min(R - 60, max(L + 60, m.x + self.rng.uniform(-120, 120))), m.y + 70)
                m.body.velocity = (0, 300)
                m.best_t = self.clock - 1.6

    def ranking(self):
        return sorted(self.racers, key=lambda m: (m.place or 99, -m.y))

    def zone_at(self, y):
        for (y0, y1, z) in self.course.zones:
            if y0 <= y < y1:
                return (y0, z)
        return None


def _shape_fn(shape, p):
    def fn(body):
        if shape == "bar":
            h = p["len"] / 2
            return [pymunk.Segment(body, (-h, 0), (h, 0), 9)]
        if shape == "cross":
            arms = p.get("arms", 4)
            out = []
            for k in range(arms):
                a = math.pi * 2 * k / arms
                out.append(pymunk.Segment(body, (0, 0), (math.cos(a) * p["len"] / 2, math.sin(a) * p["len"] / 2), 10))
            return out
        if shape == "hammer":
            ln = p["len"]
            return [pymunk.Segment(body, (0, 0), (ln, 0), 7), pymunk.Circle(body, 46, (ln, 0))]
        if shape == "box":
            w2, h2 = p["w2"], p["h2"]
            return [pymunk.Poly(body, [(-w2, -h2), (w2, -h2), (w2, h2), (-w2, h2)], radius=2)]
        if shape == "flipper":
            ln, d = p["len"], p["dirx"]
            return [pymunk.Segment(body, (0, 0), (ln * d, 0), 13)]
        raise ValueError(shape)
    return fn


def tune(seed, n, t_min, t_max, level, style):
    target = (t_min + t_max) / 2
    k, best = 7, None
    for _ in range(7):
        S = Sim([None] * n, seed, k, level, style)
        while S.winner is None and S.clock < t_max * 2.5:
            S.step(1 / 240, S.clock)
        t = S.clock
        if S.winner and (best is None or abs(t - target) < abs(best[1] - target)):
            best = (k, t)
        if S.winner and t_min <= t <= t_max:
            return k, t
        nk = max(3, int(round(k * target / max(t, 1))))
        if nk == k:
            nk = k + (1 if t < target else -1)
        k = max(3, min(24, nk))
    return best if best else (k, t_max)


def _draw_shape(cv, s, col, oy, width=None):
    b = s.body
    if isinstance(s, pymunk.Segment):
        a, c = b.local_to_world(s.a), b.local_to_world(s.b)
        pygame.draw.line(cv, col, (a.x, a.y + oy), (c.x, c.y + oy), int(width or s.radius * 2))
        for p in (a, c):
            gfx.filled_circle(cv, int(p.x), int(p.y + oy), int(s.radius), col)
    elif isinstance(s, pymunk.Circle):
        c = b.local_to_world(s.offset)
        gfx.filled_circle(cv, int(c.x), int(c.y + oy), int(s.radius), V.darker(col, 0.65))
        gfx.filled_circle(cv, int(c.x), int(c.y + oy), int(s.radius * 0.8), col)
        gfx.aacircle(cv, int(c.x), int(c.y + oy), int(s.radius), col)
    elif isinstance(s, pymunk.Poly):
        pts = [b.local_to_world(v) for v in s.get_vertices()]
        pts = [(p.x, p.y + oy) for p in pts]
        pygame.draw.polygon(cv, col, pts)
        pygame.draw.polygon(cv, V.darker(col, 0.6), pts, 3)


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    rng = random.Random(cfg["seed"])
    level = int(cfg.get("level") or rng.randint(1, 99))
    style = cfg.get("course_style") or "random"
    if style not in STYLES:
        style = rng.choice(list(STYLES))
    k, est = tune(cfg["seed"], n, t_min, t_max, level, style)
    print(f"  level {level}, {style}, {k} zones, ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES[rng.choice(RANDOM_THEMES)] if cfg.get("theme") not in THEMES else THEMES["neon"])
    T = {kk: V.hexc(v) for kk, v in th.items()}
    run = Runner(cfg, out_path, sound, est + 4.5, th)
    run.comm.y = 610
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    S = Sim(looks, cfg["seed"], k, level, style, sound=sound, fx=fx)
    C = S.course
    title_lines = _wrap(cfg.get("title") or f"LEVEL {level}: {STYLES[style][0]}", 22)
    handle = cfg.get("handle", "")
    sound.add(0.0, "go")
    cam = 0.0
    view_h = VIEW_BOT - VIEW_TOP
    win_time = None
    rank_x = {}
    seen_ev = 0
    zone_seen = set()
    banner = None
    while True:
        t = run.t
        if win_time is None or t - win_time < 2.5:
            for i in range(run.sub):
                S.step(run.dt / run.sub, t + i * run.dt / run.sub)
        if S.winner is not None and win_time is None:
            win_time = t
            sound.climax(t)
            sound.add(t, "win")
            fx.confetti(W)
        lead = max((m for m in S.racers if not m.done), key=lambda m: m.y, default=S.winner)
        if win_time is None and lead is not None:
            run.comm.lead(t, lead.look.name)
            z = S.zone_at(lead.y)
            if z and z[0] not in zone_seen:
                zone_seen.add(z[0])
                banner = (t, ZONES[z[1]])
                sound.add(t, "whoosh", gain=0.6)
        while seen_ev < len(S.events):
            kind, m = S.events[seen_ev]
            seen_ev += 1
            if kind == "portal":
                fx.burst(m.x, m.y - cam + VIEW_TOP, (160, 120, 255), n=16, speed=380)
        target = min(C.finish_y + 280 - view_h, max(0, (lead.y if lead else 0) - view_h * 0.58))
        cam += (target - cam) * min(1, run.dt * 4)
        for m in S.racers:
            m.trail.append((m.x, m.y))
            m.trail = m.trail[-8:]
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        oy = VIEW_TOP - cam
        clip = pygame.Rect(L - 22, VIEW_TOP, R - L + 44, view_h)
        pygame.draw.rect(cv, T["panel"], clip, border_radius=18)
        cv.set_clip(clip)
        top, bot = cam - 80, cam + view_h + 80
        # zone bands (subtle tint so each obstacle zone feels like its own area)
        for zi, (y0, y1, z) in enumerate(C.zones):
            if y1 < top or y0 > bot:
                continue
            if zi % 2:
                band = pygame.Surface((R - L, int(y1 - y0)), pygame.SRCALPHA)
                band.fill((*T["accent"], 14))
                cv.blit(band, (L, y0 + oy))
        for (a, b) in [((L, cam - 60), (L, cam + view_h + 60)), ((R, cam - 60), (R, cam + view_h + 60))]:
            pygame.draw.line(cv, T["wall"], (a[0], a[1] + oy), (b[0], b[1] + oy), 14)
        for a, b, el in C.segs:
            if max(a[1], b[1]) < top or min(a[1], b[1]) > bot:
                continue
            pygame.draw.line(cv, T["wall"], (a[0], a[1] + oy), (b[0], b[1] + oy), 14)
            for p in (a, b):
                gfx.filled_circle(cv, int(p[0]), int(p[1] + oy), 7, T["wall"])
        for a, b, v in C.conveyors:
            if max(a[1], b[1]) < top or min(a[1], b[1]) > bot:
                continue
            pygame.draw.line(cv, (40, 40, 48), (a[0], a[1] + oy), (b[0], b[1] + oy), 20)
            dx, dy = b[0] - a[0], b[1] - a[1]
            ln = math.hypot(dx, dy)
            ux, uy = dx / ln, dy / ln
            sgn = 1 if v > 0 else -1
            off = (t * abs(v) * 0.35) % 60
            d = off
            col = T["hot"] if v * (1 if dx > 0 else -1) > 0 else (255, 90, 80)
            while d < ln:
                px, py = a[0] + ux * d, a[1] + uy * d + oy
                tip = (px + ux * 12 * sgn, py + uy * 12 * sgn)
                pygame.draw.line(cv, col, (px - ux * 8 * sgn - uy * 7, py - uy * 8 * sgn + ux * 7), tip, 4)
                pygame.draw.line(cv, col, (px - ux * 8 * sgn + uy * 7, py - uy * 8 * sgn - ux * 7), tip, 4)
                d += 60
        for a, b in C.launch:
            if max(a[1], b[1]) < top or min(a[1], b[1]) > bot:
                continue
            glow = 0.5 + 0.5 * math.sin(t * 8)
            pygame.draw.line(cv, V.mix(T["hot"], (255, 255, 255), glow * 0.5), (a[0], a[1] + oy), (b[0], b[1] + oy), 20)
        for (x, y) in C.pegs:
            if top < y < bot:
                gfx.filled_circle(cv, int(x), int(y + oy), 9, T["peg"])
                gfx.aacircle(cv, int(x), int(y + oy), 9, T["peg"])
        for (x, y, br) in C.bumpers:
            if top - br < y < bot + br:
                pulse = 1 + 0.05 * math.sin(t * 6 + x)
                gfx.filled_circle(cv, int(x), int(y + oy), int(br * pulse), V.darker(T["hot"], 0.55))
                gfx.filled_circle(cv, int(x), int(y + oy), int(br * 0.78 * pulse), T["hot"])
        for pt in C.portals:
            for (px, py), col in ((pt["in"], (150, 110, 255)), (pt["out"], (90, 220, 255))):
                if top - 80 < py < bot + 80:
                    for k2 in range(3):
                        rr = pt["r"] - k2 * 9 + 3 * math.sin(t * 6 + k2)
                        gfx.aacircle(cv, int(px), int(py + oy), int(rr), col)
                        gfx.aacircle(cv, int(px), int(py + oy), int(rr) - 1, col)
        for mv in S.movers:
            y = mv.body.position.y
            if top - 300 < y < bot + 300:
                col = T["accent"] if mv.kind in ("rotor", "swing") else T["hot"] if mv.kind in ("slide", "flip") else (255, 80, 80)
                for s in mv.shapes:
                    _draw_shape(cv, s, col, oy)
                if mv.kind in ("rotor", "swing"):
                    gfx.filled_circle(cv, int(mv.body.position.x), int(y + oy), 10, (255, 255, 255))
        fy = C.finish_y + oy
        for i in range(int((R - L) / 24)):
            for j in range(2):
                col = (20, 20, 24) if (i + j) % 2 else (245, 245, 245)
                pygame.draw.rect(cv, col, pygame.Rect(L + i * 24, fy + j * 24 - 24, 24, 24))
        for m in S.racers:
            pts = [(x, y + oy) for x, y in m.trail]
            for i in range(1, len(pts)):
                kk = i / len(pts)
                pygame.draw.line(cv, V.mix(T["panel"], m.look.color, 0.15 + 0.45 * kk), pts[i - 1], pts[i], max(2, int(m.r * kk)))
        for m in S.racers:
            if -60 < m.y + oy - VIEW_TOP < view_h + 60:
                m.look.draw_body(cv, m.x, m.y + oy, m.body.angle, m.body.velocity.x, m.body.velocity.y, m.r * 2, "ball")
        cv.set_clip(None)
        fx.draw(cv)
        y = _draw_title(cv, title_lines, t)
        # zone banner slides in from the side
        if banner and t - banner[0] < 1.4:
            a = t - banner[0]
            x = W / 2 + (1 - min(1, a / 0.2)) * 700 - max(0, a - 1.15) / 0.25 * 900
            txt = V.text(banner[1], 64, T["hot"], (0, 0, 0), weight="Display")
            box = pygame.Surface((txt.get_width() + 70, txt.get_height() + 24), pygame.SRCALPHA)
            pygame.draw.rect(box, (10, 10, 14, 220), box.get_rect(), border_radius=18)
            pygame.draw.rect(box, (*T["hot"], 255), box.get_rect(), 5, border_radius=18)
            box.blit(txt, (35, 12))
            V.blit_center(cv, box, x, VIEW_TOP + 70)
        # progress bar with everyone + zone ticks
        px0, px1, py = 90, 990, 1700
        pygame.draw.rect(cv, (24, 26, 34), pygame.Rect(px0, py - 6, px1 - px0, 12), border_radius=6)
        for (y0, y1, z) in C.zones:
            xx = px0 + (px1 - px0) * min(1, y0 / C.finish_y)
            pygame.draw.line(cv, (70, 74, 90), (xx, py - 12), (xx, py + 12), 3)
        for m in S.racers:
            f = min(1, max(0, m.y / C.finish_y))
            V.blit_center(cv, m.look.badge(42), px0 + (px1 - px0) * f, py - 32)
        order = S.ranking()
        slot = min(110, 980 // len(order))
        x0 = W / 2 - slot * (len(order) - 1) / 2
        for pos, m in enumerate(order):
            tx = x0 + pos * slot
            cx2 = rank_x.get(m.i, tx)
            cx2 += (tx - cx2) * min(1, run.dt * 8)
            rank_x[m.i] = cx2
            V.blit_center(cv, m.look.badge(int(slot * 0.45)), cx2, 1785)
            V.blit_center(cv, V.text(str(pos + 1), 26, (255, 255, 255), (0, 0, 0)), cx2 + slot * 0.28, 1765)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1865)
        if win_time is not None:
            _draw_winner(cv, S.winner, t - win_time + 0.8, T, line3=f"Beat level {level}")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Race ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": S.winner.look.name, "level": level}
