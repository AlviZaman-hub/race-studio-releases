"""Ball Escape: one ball trapped inside dozens of spinning rings, each with a gap. Every bounce
plays the next note of a melody; every gap it finds breaks that ring. Can it escape them all?"""
import colorsys
import math
import random

import pygame.gfxdraw as gfx

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from engine.melodies import MELODIES
from games.maze import _wrap, _draw_title

THEMES = {
    "night": {"bg1": "#020308", "bg2": "#0e1430", "floor": "#03050c"},
    "mono": {"bg1": "#030303", "bg2": "#151515", "floor": "#000000"},
    "dusk": {"bg1": "#0b0310", "bg2": "#2c0f3a", "floor": "#08030c"},
    "deep": {"bg1": "#010a0c", "bg2": "#06282e", "floor": "#020a0c"},
}
RANDOM_THEMES = list(THEMES)
CX, CY = 540, 1000
R_IN, R_OUT = 75.0, 470.0
BR = 11.0


class Sim:
    def __init__(self, seed, n, gap_deg=45.0, g=1100.0, speed=900.0, open_rate=120.0):
        self.rng = rng = random.Random(seed * 13 + 1)
        self.n = n
        step = (R_OUT - R_IN) / max(1, n - 1)
        self.rings = []
        for k in range(n):
            self.rings.append({"r": R_IN + k * step, "w": (1 if k % 2 else -1) * rng.uniform(0.8, 1.8),
                               "g0": rng.uniform(0, 2 * math.pi), "gap": math.radians(gap_deg), "broken": None})
        self.cur = 0
        self.cur_t = 0.0                       # when the ball reached the current ring
        self.open_rate = math.radians(open_rate)   # a ring slowly opens while the ball is stuck on it
        self.g, self.speed = g, speed
        a = rng.uniform(0, 2 * math.pi)
        self.x, self.y = CX, CY
        self.vx, self.vy = math.cos(a) * speed, math.sin(a) * speed
        self.clock = 0.0
        self.bounces = 0
        self.events = []      # ("bounce"|"break", t, x, y, ring)
        self.escaped = None

    def gap_size(self, k):
        rg = self.rings[k]
        if k != self.cur:
            return rg["gap"]
        return min(math.radians(300), rg["gap"] + self.open_rate * max(0.0, self.clock - self.cur_t - 0.3))

    def gap_center(self, k):
        rg = self.rings[k]
        return rg["g0"] + rg["w"] * self.clock

    def step(self, dt):
        self.clock += dt
        self.vy += self.g * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        if self.cur >= self.n:
            if self.escaped is None and math.hypot(self.x - CX, self.y - CY) > R_OUT + 60:
                self.escaped = self.clock
            return
        rg = self.rings[self.cur]
        dx, dy = self.x - CX, self.y - CY
        d = math.hypot(dx, dy)
        lim = rg["r"] - BR
        if d > lim:
            ang = math.atan2(dy, dx)
            diff = (ang - self.gap_center(self.cur) + math.pi) % (2 * math.pi) - math.pi
            if abs(diff) < self.gap_size(self.cur) / 2:
                rg["broken"] = self.clock
                self.events.append(("break", self.clock, self.x, self.y, self.cur))
                self.cur += 1
                self.cur_t = self.clock
                return
            nx, ny = dx / d, dy / d
            self.x, self.y = CX + nx * lim, CY + ny * lim
            vn = self.vx * nx + self.vy * ny
            if vn > 0:
                self.vx -= 2 * vn * nx
                self.vy -= 2 * vn * ny
                sp = math.hypot(self.vx, self.vy)
                if sp < self.speed:   # keep its energy so it never just rolls at the bottom
                    self.vx, self.vy = self.vx / sp * self.speed, self.vy / sp * self.speed
                self.bounces += 1
                self.events.append(("bounce", self.clock, self.x, self.y, self.cur))


def tune(seed, t_min, t_max):
    target = (t_min + t_max) / 2 - 2.5
    best = None
    for n in (10, 15, 20, 25, 30, 40, 50, 60, 75, 90, 110):
        S = Sim(seed, n)
        while S.escaped is None and S.clock < t_max * 2:
            S.step(1 / 240)
        t = S.escaped or S.clock
        if S.escaped and (best is None or abs(t - target) < abs(best[1] - target)):
            best = (n, t)
        if t > target * 1.3:
            break
    return best or (12, target)


def render(cfg, out_path, sound):
    rng = random.Random(cfg["seed"])
    song = cfg.get("song") if cfg.get("song") in MELODIES else rng.choice(list(MELODIES))
    notes = MELODIES[song][1]
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    n, est = tune(cfg["seed"], t_min, t_max)
    print(f"  {n} rings, {song}, ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["night"])
    T = {k: V.hexc(v) for k, v in th.items()}
    sound.music = False
    run = Runner(cfg, out_path, sound, est + 5, th)
    run.comm.on = False
    fx = V.Particles(random.Random(cfg["seed"]))
    S = Sim(cfg["seed"], n)
    title = _wrap(cfg.get("title") or f"CAN IT ESCAPE {n} RINGS?", 22)
    handle = cfg.get("handle", "")
    hue0 = rng.random()
    cols = [tuple(int(c * 255) for c in colorsys.hsv_to_rgb((hue0 + k / max(1, n) * 0.85) % 1, 0.75, 1)) for k in range(n)]
    seen = 0
    note_i = 0
    end_t = None
    trail = []
    while True:
        t = run.t
        if end_t is None or t - end_t < 1.0:
            for i in range(run.sub):
                S.step(run.dt / run.sub)
        while seen < len(S.events):
            kind, tt, x, y, k = S.events[seen]
            seen += 1
            pan = 0.2 + 0.6 * x / W
            if kind == "bounce":
                sound.add(t, "note", m=notes[note_i % len(notes)], pan=pan)
                note_i += 1
            else:
                sound.add(t, "break", pan=pan, min_gap=0.03)
                rg = S.rings[k]
                for j in range(14):   # the ring bursts into its own colour
                    a = rng.uniform(0, 2 * math.pi)
                    fx.burst(CX + math.cos(a) * rg["r"], CY + math.sin(a) * rg["r"], cols[k], n=2, speed=220, size=(3, 6), life=(0.2, 0.5))
                run.comm.drama += 0.2
        if S.escaped is not None and end_t is None:
            end_t = t
            sound.climax(t)
            sound.add(t, "win")
            fx.confetti(W)
        trail.append((S.x, S.y))
        trail = trail[-14:]
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        gfx.filled_circle(cv, CX, CY, int(R_OUT + 16), T["floor"])
        for k in range(S.cur, n):
            rg = S.rings[k]
            gc = S.gap_center(k)
            half = S.gap_size(k) / 2
            rect = pygame.Rect(CX - rg["r"], CY - rg["r"], rg["r"] * 2, rg["r"] * 2)
            # solid part = everything except the gap; pygame arcs use counter-clockwise angles (y up)
            a0, a1 = -(gc + 2 * math.pi - half), -(gc + half)
            pygame.draw.arc(cv, cols[k], rect, a0, a1, 5 if n <= 40 else 3)
        for i in range(1, len(trail)):
            kk = i / len(trail)
            pygame.draw.line(cv, (255, 255, 255), trail[i - 1], trail[i], max(1, int(BR * kk)))
        gfx.filled_circle(cv, int(S.x), int(S.y), int(BR), (255, 255, 255))
        gfx.aacircle(cv, int(S.x), int(S.y), int(BR), (255, 255, 255))
        fx.draw(cv)
        _draw_title(cv, title, t)
        left = n - S.cur
        V.blit_center(cv, V.text(f"RINGS LEFT: {left}", 84, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, 1600)
        if end_t is not None:
            a = min(1, (t - end_t) / 0.3)
            s2 = V.text("ESCAPED!", 120, (255, 230, 90), (0, 0, 0), weight="Display")
            s2.set_alpha(int(255 * a))
            V.blit_center(cv, s2, W / 2, CY)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1870)
        run.push()
        if end_t is not None and t - end_t >= 3.6:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Simulation ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": f"escaped {n} rings", "level": cfg["seed"]}
