"""Chain Reaction: balls smash a wall of bricks (some need several hits). Combos raise the
pitch of the breaks. Most bricks broken wins; it ends when the wall is gone.
"""
import colorsys
import math
import random

import pymunk

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner

THEMES = {
    "neon": {"bg1": "#03030a", "bg2": "#13103a", "box": "#0b0a1e", "wall": "#4a4f7a", "sat": 0.75},
    "candy": {"bg1": "#12040e", "bg2": "#3d1236", "box": "#1c0818", "wall": "#7a4a70", "sat": 0.5},
    "mono": {"bg1": "#050505", "bg2": "#202024", "box": "#0f0f12", "wall": "#55555e", "sat": 0.0},
    "sunset": {"bg1": "#100503", "bg2": "#3a1508", "box": "#1a0905", "wall": "#80503a", "sat": 0.65},
}
RANDOM_THEMES = list(THEMES)
BX0, BX1, BY0, BY1 = 70, 1010, 380, 1600
G = 1500.0
CT_BALL, CT_BRICK, CT_WALL = 1, 2, 3


class Brick:
    def __init__(self, x, y, w, h, hp, row):
        self.rect = pygame.Rect(x, y, w, h)
        self.hp = self.max = hp
        self.row = row
        self.alive = True
        self.flash = 0.0
        self.shape = None


class Ball:
    def __init__(self, i, look, r):
        self.i, self.look, self.r = i, look, r
        self.body = pymunk.Body(1.0, pymunk.moment_for_circle(1.0, 0, r))
        self.shape = pymunk.Circle(self.body, r)
        self.shape.elasticity, self.shape.friction, self.shape.collision_type = 0.95, 0.3, CT_BALL
        self.shape.ball = self
        self.score = 0
        self.combo = 0
        self.last_break = -9.0
        self.trail = []

    x = property(lambda s: s.body.position.x)
    y = property(lambda s: s.body.position.y)


class Sim:
    def __init__(self, looks, seed, hp_scale=1.0, sound=None, fx=None, size=1.0):
        self.rng = random.Random(seed * 19 + 4)
        self.sound, self.fx = sound, fx
        self.clock = 0.0
        self.now = 0.0
        self.todo = []
        sp = pymunk.Space()
        sp.gravity = (0, G)
        sp.iterations = 20
        self.space = sp
        st = sp.static_body
        for a, b in (((BX0, BY0), (BX1, BY0)), ((BX1, BY0), (BX1, BY1)), ((BX1, BY1), (BX0, BY1)), ((BX0, BY1), (BX0, BY0))):
            s = pymunk.Segment(st, a, b, 6)
            s.elasticity, s.friction, s.collision_type = 1.0, 0.3, CT_WALL
            sp.add(s)
        # brick wall pattern
        cols = self.rng.choice([10, 12, 14])
        rows = max(5, int(self.rng.choice([12, 14, 16]) * size))
        bw = (BX1 - BX0 - 40) / cols
        bh = 30
        top = BY0 + self.rng.choice([150, 200, 250])
        pattern = self.rng.choice(["full", "diamond", "stripes", "pyramid", "checker"])
        self.bricks = []
        for r in range(rows):
            for c in range(cols):
                cx, cy = c - (cols - 1) / 2, r - (rows - 1) / 2
                keep = {"full": True,
                        "diamond": abs(cx) / (cols / 2) + abs(cy) / (rows / 2) <= 1.05,
                        "stripes": r % 3 != 2,
                        "pyramid": abs(cx) <= (r + 1) * cols / (2 * rows) + 0.5,
                        "checker": (r + c) % 2 == 0 or r < 2}[pattern]
                if not keep:
                    continue
                hp = 1 + (1 if self.rng.random() < 0.25 else 0) + (1 if self.rng.random() < 0.08 else 0)
                hp = max(1, int(round(hp * hp_scale)))
                bk = Brick(BX0 + 20 + c * bw + 2, top + r * (bh + 4), bw - 4, bh, hp, r)
                shp = pymunk.Poly(st, [(bk.rect.left, bk.rect.top), (bk.rect.right, bk.rect.top),
                                       (bk.rect.right, bk.rect.bottom), (bk.rect.left, bk.rect.bottom)])
                shp.elasticity, shp.friction, shp.collision_type = 1.0, 0.2, CT_BRICK
                shp.brick = bk
                bk.shape = shp
                sp.add(shp)
                self.bricks.append(bk)
        self.rows = rows
        self.total = len(self.bricks)
        n = len(looks)
        r = 22 if n <= 4 else 18
        per = max(1, math.ceil(6 / n))  # few racers -> each gets several balls
        self.balls = []
        total = n * per
        for j in range(total):
            i = j % n
            b = Ball(i, looks[i], r)
            b.body.position = (BX0 + 80 + (BX1 - BX0 - 160) * (j + 0.5) / total, BY1 - 80)
            b.body.velocity = (self.rng.uniform(-300, 300), -self.rng.uniform(1700, 1900))
            sp.add(b.body, b.shape)
            self.balls.append(b)
        sp.on_collision(CT_BALL, CT_BRICK, post_solve=self._hit)
        sp.on_collision(CT_BALL, CT_WALL, post_solve=self._wall)
        sp.on_collision(CT_BALL, CT_BALL, post_solve=self._bump)
        self.done = False

    def totals(self):
        out = {}
        for b in self.balls:
            out[b.i] = out.get(b.i, 0) + b.score
        return out

    def left(self):
        return sum(1 for b in self.bricks if b.alive)

    def _ev(self, kind, b=None, x=None, **kw):
        if self.sound is not None:
            xx = x if x is not None else (b.x if b else W / 2)
            self.sound.add(self.now, kind, who=b.i if b else None, pan=0.15 + 0.7 * xx / W, **kw)

    def _hit(self, arb, space, data):
        if arb.is_first_contact:
            self.todo.append((arb.shapes[0].ball, arb.shapes[1].brick))

    def _wall(self, arb, space, data):
        if arb.is_first_contact:
            self.todo.append((arb.shapes[0].ball, None))

    def _bump(self, arb, space, data):
        if arb.is_first_contact:
            self._ev("racer", arb.shapes[0].ball, min_gap=0.1)

    def step(self, dt, now):
        self.now = now
        self.clock += dt
        self.space.step(dt)
        todo, self.todo = self.todo, []
        for b, bk in todo:
            if bk is None:
                self._ev("bounce", b, min_gap=0.08, gain=0.6)
                self._keep(b, floor=b.y > BY1 - b.r * 3)
                continue
            if not bk.alive:
                continue
            bk.hp -= 1
            bk.flash = 1.0
            if bk.hp <= 0:
                bk.alive = False
                self.space.remove(bk.shape)
                b.score += 1
                b.combo = b.combo + 1 if self.clock - b.last_break < 0.35 else 1
                b.last_break = self.clock
                # combo = rising notes
                self._ev("escape" if b.combo % 6 == 0 else "bounce", b, x=bk.rect.centerx, min_gap=0.02)
                if self.fx and b.look:
                    self.fx.burst(bk.rect.centerx, bk.rect.centery, self.brick_col(bk), n=8, speed=420, size=(5, 10), life=(0.3, 0.6))
            else:
                self._ev("hit", b, x=bk.rect.centerx, min_gap=0.03)
            self._keep(b)
        for b in self.balls:  # never let a ball sit still anywhere
            if b.body.velocity.length < 120:
                b.stuck = getattr(b, "stuck", 0) + dt
                if b.stuck > 0.4:
                    b.body.velocity = (self.rng.uniform(-400, 400), -900)
                    b.stuck = 0
            else:
                b.stuck = 0
        if self.left() == 0:
            self.done = True

    def _keep(self, b, floor=False):
        v = b.body.velocity
        top_v = math.sqrt(2 * G * (BY1 - BY0 - 60))  # enough to reach the very top of the box
        if floor and v.y > -top_v * 0.8:  # springy floor: always launch back up into the wall
            vx = v.x if abs(v.x) > 150 else self.rng.choice([-1, 1]) * 300
            b.body.velocity = (vx, -top_v * self.rng.uniform(0.85, 1.0))
        sp = b.body.velocity.length
        if sp < top_v * 0.45:  # resting on top of bricks or losing energy: give it a kick
            a = self.rng.uniform(-2.4, -0.7)
            b.body.velocity = (math.cos(a) * top_v * 0.6, math.sin(a) * top_v * 0.6)
        elif sp > top_v * 1.15:
            b.body.velocity = b.body.velocity * (top_v * 1.15 / sp)

    brick_sat = 0.75

    def brick_col(self, bk):
        r, g, bb = colorsys.hsv_to_rgb((bk.row / max(1, self.rows)) * 0.8, self.brick_sat, 1.0)
        return (int(r * 255), int(g * 255), int(bb * 255))


def tune(seed, n, t_min, t_max):
    target = (t_min + t_max) / 2
    scale, size, best = 1.0, 1.0, None
    for _ in range(10):
        S = Sim([None] * n, seed, scale, size=size)
        while not S.done and S.clock < t_max * 2.5:
            S.step(1 / 240, S.clock)
        t = S.clock if S.done else t_max * 2.5
        if best is None or abs(t - target) < abs(best[2] - target):
            best = (scale, size, t)
        if S.done and t_min <= t <= t_max:
            return scale, size, t
        f = max(0.5, min(2.0, target / t))
        if f < 1 and scale <= 1.0:
            size = max(0.4, size * f ** 0.7)  # bricks can't get weaker than 1 hit: shrink the wall instead
        else:
            scale *= f
    return best


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    scale, size, est = tune(cfg["seed"], n, t_min, t_max)
    print(f"  brick HP x{scale:.2f}, wall x{size:.2f}, ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["neon"])
    T = {k: (V.hexc(v) if isinstance(v, str) else v) for k, v in th.items()}
    run = Runner(cfg, out_path, sound, est + 4.5, th)
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    S = Sim(looks, cfg["seed"], scale, sound=sound, fx=fx, size=size)
    S.brick_sat = th["sat"]
    title_lines = _wrap(cfg.get("title") or ("CAN IT BREAK THEM ALL?" if n == 1 else "WHO BREAKS THE MOST BLOCKS?"), 22)
    handle = cfg.get("handle", "")
    sound.add(0.0, "go")
    win_time = None
    winner = None
    while True:
        t = run.t
        if win_time is None:
            for i in range(run.sub):
                S.step(run.dt / run.sub, t + i * run.dt / run.sub)
            if S.done:
                win_time = t
                totals = S.totals()
                wi = max(totals, key=lambda i: (totals[i], -i))
                winner = next(b for b in S.balls if b.i == wi)
                winner.score = totals[wi]
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
        for b in S.balls:
            b.trail.append((b.x, b.y))
            b.trail = b.trail[-8:]
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        pygame.draw.rect(cv, T["box"], pygame.Rect(BX0, BY0, BX1 - BX0, BY1 - BY0), border_radius=12)
        pygame.draw.rect(cv, T["wall"], pygame.Rect(BX0 - 6, BY0 - 6, BX1 - BX0 + 12, BY1 - BY0 + 12), 6, border_radius=14)
        for bk in S.bricks:
            if not bk.alive:
                continue
            col = S.brick_col(bk)
            k = bk.hp / bk.max
            col = V.mix(V.darker(col, 0.55), col, k)
            if bk.flash > 0:
                col = V.mix(col, (255, 255, 255), bk.flash * 0.7)
                bk.flash = max(0, bk.flash - run.dt * 6)
            pygame.draw.rect(cv, col, bk.rect, border_radius=5)
            pygame.draw.line(cv, V.lighter(col, 0.35), (bk.rect.left + 4, bk.rect.top + 3), (bk.rect.right - 4, bk.rect.top + 3), 2)
            if bk.max > 1:
                V.blit_center(cv, V.text(str(bk.hp), 20, (15, 15, 20), None), bk.rect.centerx, bk.rect.centery)
        for b in S.balls:
            for i in range(1, len(b.trail)):
                kk = i / len(b.trail)
                pygame.draw.line(cv, V.mix(T["box"], b.look.color, 0.15 + 0.5 * kk), b.trail[i - 1], b.trail[i], max(2, int(b.r * 1.0 * kk)))
        for b in S.balls:
            b.look.draw_body(cv, b.x, b.y, b.body.angle, b.body.velocity.x, b.body.velocity.y, b.r * 2, "ball")
        fx.draw(cv)
        y = _draw_title(cv, title_lines, t)
        if win_time is None:
            V.blit_center(cv, V.text(f"BLOCKS LEFT: {S.left()}", 44, (255, 210, 120), (0, 0, 0)), W / 2, y + 6)
        _scores(cv, S)
        if handle:
            V.blit_center(cv, V.text(handle, 30, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1860)
        if win_time is not None:
            _draw_winner(cv, winner, t - win_time + 0.8, T, line2="WINS!" if n > 1 else "CLEARED!",
                         line3=f"{winner.score} blocks broken" if n > 1 else f"{S.total} blocks")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Took too long")
    dur = run.finish()
    return {"duration": dur, "winner": winner.look.name, "level": cfg["seed"]}


def _scores(cv, S):
    tot = S.totals()
    first = {}
    for b in S.balls:
        first.setdefault(b.i, b)
    order = sorted(first.values(), key=lambda b: -tot[b.i])
    n = len(order)
    slot = min(130, 980 // max(1, n))
    y = 1700
    x0 = W / 2 - slot * (n - 1) / 2
    for k, b in enumerate(order):
        x = x0 + k * slot
        V.blit_center(cv, b.look.badge(int(slot * 0.5)), x, y)
        V.blit_center(cv, V.text(str(tot[b.i]), 40, (255, 255, 255), (0, 0, 0)), x, y + slot * 0.55)
