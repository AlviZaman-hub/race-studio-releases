"""Snakes & Ladders race: everyone rolls two dice at once each round and hops along a
100-square board. Ladders shoot you up, snakes slide you down. First to 100 wins.
(Original board art.)"""
import math
import random

import pygame.gfxdraw as gfx

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from games.maze import _wrap, _draw_title, _draw_winner

THEMES = {
    "classic": {"bg1": "#0b0a14", "bg2": "#26213f", "a": "#f6e7c8", "b": "#e9d3a6", "ink": "#3a2a14", "snake": "#3fbf5f", "ladder": "#8a5a2b"},
    "neon": {"bg1": "#05030c", "bg2": "#1c0a3a", "a": "#1a1430", "b": "#231a40", "ink": "#c9b8ff", "snake": "#ff4fd8", "ladder": "#3ff2ff"},
    "candy": {"bg1": "#14040e", "bg2": "#3a0c2c", "a": "#ffe3f1", "b": "#ffd0e8", "ink": "#6a1a4a", "snake": "#7a3cff", "ladder": "#ff8a1f"},
    "jungle": {"bg1": "#030a04", "bg2": "#10301a", "a": "#d9efc5", "b": "#c4e2aa", "ink": "#1f3a14", "snake": "#e0452f", "ladder": "#7a4a20"},
}
RANDOM_THEMES = list(THEMES)
BX, BY, CELL = 40, 430, 100
ROUND = 1.75   # seconds per round


def cell_xy(n):
    """Square n (1..100) -> centre in pixels. Row 0 at the bottom, rows snake left/right."""
    n = max(1, min(100, n)) - 1
    row, col = divmod(n, 10)
    if row % 2:
        col = 9 - col
    return BX + col * CELL + CELL / 2, BY + (9 - row) * CELL + CELL / 2


def make_board(rng, n_snakes, n_ladders):
    used = {1, 100}
    jumps = {}
    def pick(lo, hi):
        while True:
            v = rng.randint(lo, hi)
            if v not in used:
                used.add(v)
                return v
    for _ in range(n_ladders):
        a = pick(2, 80)
        b = pick(min(99, a + 11), min(99, a + 45))
        jumps[a] = b
    for _ in range(n_snakes):
        a = pick(20, 99)
        b = pick(max(2, a - 45), max(2, a - 11))
        jumps[a] = b
    return jumps


def play(n, seed, jumps):
    """Plan the whole game. Returns rounds: list of [(racer, roll, path_squares, jump_to or None)]."""
    rng = random.Random(seed * 3 + 7)
    pos = [1] * n
    rounds = []
    winner = None
    while winner is None and len(rounds) < 80:
        moves = []
        for i in range(n):
            roll = rng.randint(1, 6) + rng.randint(1, 6)
            start = pos[i]
            end = min(100, start + roll)
            path = list(range(start + 1, end + 1))
            jump = jumps.get(end)
            pos[i] = jump if jump else end
            moves.append((i, roll, path, jump))
            if pos[i] >= 100 and winner is None:
                winner = i
        rounds.append(moves)
    return rounds, winner


def render(cfg, out_path, sound):
    n = len(cfg["racers"])
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    target = ((t_min + t_max) / 2 - 1.5) / ROUND
    best = None
    for v in range(40):   # try boards until one plays out at the right length
        rng = random.Random(cfg["seed"] * 101 + v)
        jumps = make_board(rng, rng.randint(6, 9), rng.randint(6, 9))
        rounds, winner = play(n, cfg["seed"] * 7 + v, jumps)
        score = abs(len(rounds) - target) + (0 if winner is not None else 99)
        if best is None or score < best[0]:
            best = (score, jumps, rounds, winner)
        if score < 1:
            break
    _, jumps, rounds, winner = best
    print(f"  {len(rounds)} rounds")
    th = THEMES.get(cfg.get("theme"), THEMES["classic"])
    T = {k: V.hexc(v) for k, v in th.items()}
    est = 1.2 + len(rounds) * ROUND
    run = Runner(cfg, out_path, sound, est + 4.5, th)
    run.comm.y = 1560
    fx = V.Particles(random.Random(cfg["seed"]))
    looks = [V.Look(s, 60) for s in cfg["racers"]]
    title = _wrap(cfg.get("title") or "WHO REACHES 100 FIRST?", 22)
    handle = cfg.get("handle", "")
    # static board
    board = pygame.Surface((W, H), pygame.SRCALPHA)
    for k in range(1, 101):
        x, y = cell_xy(k)
        col = T["a"] if (k + ((k - 1) // 10)) % 2 else T["b"]
        pygame.draw.rect(board, col, pygame.Rect(x - CELL / 2, y - CELL / 2, CELL, CELL))
        board.blit(V.text(str(k), 22, T["ink"], None, weight="Medium"), (x - CELL / 2 + 6, y - CELL / 2 + 4))
    pygame.draw.rect(board, T["ink"], pygame.Rect(BX - 6, BY - 6, CELL * 10 + 12, CELL * 10 + 12), 6, border_radius=8)
    for a, b in jumps.items():
        x0, y0 = cell_xy(a)
        x1, y1 = cell_xy(b)
        if b > a:   # ladder: two rails + rungs
            dx, dy = x1 - x0, y1 - y0
            ln = math.hypot(dx, dy)
            nx, ny = -dy / ln * 18, dx / ln * 18
            for s in (-1, 1):
                pygame.draw.line(board, T["ladder"], (x0 + nx * s, y0 + ny * s), (x1 + nx * s, y1 + ny * s), 8)
            steps = int(ln / 34)
            for i in range(1, steps):
                u = i / steps
                cx, cy = x0 + dx * u, y0 + dy * u
                pygame.draw.line(board, T["ladder"], (cx - nx, cy - ny), (cx + nx, cy + ny), 6)
        else:       # snake: wavy body from head (a) to tail (b)
            dx, dy = x1 - x0, y1 - y0
            ln = math.hypot(dx, dy)
            nx, ny = -dy / ln, dx / ln
            pts = []
            for i in range(41):
                u = i / 40
                w = math.sin(u * math.pi * 3) * 26 * (1 - 0.5 * u)
                pts.append((x0 + dx * u + nx * w, y0 + dy * u + ny * w))
            for i in range(1, len(pts)):
                th_ = int(20 * (1 - i / len(pts)) + 6)
                pygame.draw.line(board, V.darker(T["snake"], 0.6), pts[i - 1], pts[i], th_ + 4)
            for i in range(1, len(pts)):
                th_ = int(20 * (1 - i / len(pts)) + 6)
                pygame.draw.line(board, T["snake"], pts[i - 1], pts[i], th_)
            gfx.filled_circle(board, int(x0), int(y0), 20, T["snake"])
            for s in (-1, 1):
                gfx.filled_circle(board, int(x0 + nx * 8 * s), int(y0 + ny * 8 * s), 5, (255, 255, 255))
                gfx.filled_circle(board, int(x0 + nx * 8 * s), int(y0 + ny * 8 * s), 2, (0, 0, 0))
    pos = [1.0] * n
    disp = [list(cell_xy(1)) for _ in range(n)]
    sound.add(0.0, "go")
    win_time = None
    last_round = -1
    seen = set()
    dice = [1, 1]
    while True:
        t = run.t
        rt = t - 1.2
        ri = int(rt // ROUND) if rt >= 0 else -1
        u = (rt - ri * ROUND) if ri >= 0 else 0
        if ri != last_round and 0 <= ri < len(rounds):
            last_round = ri
            sound.add(t, "count")
        if ri >= 0 and ri < len(rounds):
            moves = rounds[ri]
            if u < 0.35:   # dice spin
                dice = [random.Random(int(t * 40)).randint(1, 6), random.Random(int(t * 40) + 9).randint(1, 6)]
            for (i, roll, path, jump) in moves:
                hop_t = 0.4 + 0.07 * len(path)
                key = (ri, i)
                if u >= 0.35:
                    k = min(len(path), int((u - 0.35) / 0.07) + 1) if path else 0
                    if k and key + ("h", k) not in seen:
                        seen.add(key + ("h", k))
                        if i == 0 or k % 2 == 0:
                            x, _ = cell_xy(path[k - 1])
                            sound.add(t, "bounce", who=i, pan=0.15 + 0.7 * x / W, gain=0.5)
                    target = cell_xy(path[k - 1]) if k else cell_xy(int(pos[i]))
                    if jump and u >= hop_t + 0.15:
                        f = min(1.0, (u - hop_t - 0.15) / 0.5)
                        a_ = cell_xy(path[-1])
                        b_ = cell_xy(jump)
                        target = (a_[0] + (b_[0] - a_[0]) * f, a_[1] + (b_[1] - a_[1]) * f)
                        if key + ("j",) not in seen:
                            seen.add(key + ("j",))
                            up = jump > path[-1]
                            sound.add(t, "boost" if up else "die", pan=0.15 + 0.7 * a_[0] / W)
                            run.comm.say(t, "ladder" if up else "snake", weight=1.5, name=looks[i].name)
                            fx.burst(a_[0], a_[1], (120, 255, 140) if up else (255, 90, 90), n=18, speed=360)
                    disp[i][0] += (target[0] - disp[i][0]) * min(1, run.dt * 18)
                    disp[i][1] += (target[1] - disp[i][1]) * min(1, run.dt * 18)
                if u >= ROUND - 0.05 and key + ("done",) not in seen:
                    seen.add(key + ("done",))
                    pos[i] = jump if jump else (path[-1] if path else pos[i])
            if ri == len(rounds) - 1 and u >= ROUND - 0.1 and win_time is None:
                win_time = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
            lead = max(range(n), key=lambda i: pos[i])
            run.comm.lead(t, looks[lead].name, hold=0.6)
        elif ri >= len(rounds) and win_time is None:
            win_time = t
            sound.climax(t)
            sound.add(t, "win")
            fx.confetti(W)
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        cv.blit(board, (0, 0))
        groups = {}
        for i in range(n):
            groups.setdefault((round(disp[i][0] / 30), round(disp[i][1] / 30)), []).append(i)
        for g in groups.values():
            for k2, i in enumerate(g):
                off = (k2 - (len(g) - 1) / 2) * 26
                hop = 0
                if 0 <= ri < len(rounds) and win_time is None and u > 0.35:
                    hop = abs(math.sin((u - 0.35) / 0.07 * math.pi)) * 18
                V.blit_center(cv, looks[i].badge(64), disp[i][0] + off, disp[i][1] - 6 - hop)
                if 0 <= ri < len(rounds) and win_time is None and 0.3 < u < 1.2:
                    roll = rounds[ri][i][1]
                    tag = V.text(f"+{roll}", 34, (255, 230, 90), (0, 0, 0), weight="Display")
                    tag.set_alpha(int(255 * min(1, (1.2 - u) * 4)))
                    V.blit_center(cv, tag, disp[i][0] + off, disp[i][1] - 60 - (u - 0.3) * 30)
        fx.draw(cv)
        _draw_title(cv, title, t)
        # dice
        for k2, d in enumerate(dice):
            x = W / 2 - 70 + k2 * 140
            r = pygame.Rect(x - 52, 1480 - 52, 104, 104)
            pygame.draw.rect(cv, (250, 250, 250), r, border_radius=18)
            pygame.draw.rect(cv, (30, 30, 30), r, 4, border_radius=18)
            pips = {1: [(0, 0)], 2: [(-1, -1), (1, 1)], 3: [(-1, -1), (0, 0), (1, 1)], 4: [(-1, -1), (1, -1), (-1, 1), (1, 1)],
                    5: [(-1, -1), (1, -1), (0, 0), (-1, 1), (1, 1)], 6: [(-1, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (1, 1)]}[d]
            for px, py in pips:
                gfx.filled_circle(cv, int(x + px * 26), int(1480 + py * 26), 10, (20, 20, 20))
        # standings
        order = sorted(range(n), key=lambda i: -pos[i])
        slot = min(130, 1000 // n)
        x0 = W / 2 - slot * (n - 1) / 2
        for p_, i in enumerate(order):
            V.blit_center(cv, looks[i].badge(int(slot * 0.45)), x0 + p_ * slot, 1650)
            V.blit_center(cv, V.text(str(int(min(100, pos[i]))), 28, (255, 255, 255), (0, 0, 0)), x0 + p_ * slot, 1712)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1865)
        if win_time is not None:
            class _W:
                look = looks[winner]
            _draw_winner(cv, _W, t - win_time + 0.8, T, line3=f"Reached 100 in {len(rounds)} rounds")
        run.push()
        if win_time is not None and t - win_time >= 4.2:
            break
        if t > 240:
            raise RuntimeError("Board game ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": looks[winner].name, "level": cfg["seed"]}
