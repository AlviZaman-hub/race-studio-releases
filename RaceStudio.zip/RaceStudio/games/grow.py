"""Grow Every Bounce: one ball bounces inside a circle. Every bounce plays the next note of
a melody and makes the ball bigger (or the circle smaller). Its trail paints the circle.
Ends when the ball fills the circle."""
import colorsys
import math
import random

import pygame.gfxdraw as gfx

from engine import visual as V
from engine.runner import Runner, W, H
from engine.video import pygame
from engine.melodies import MELODIES
from games.maze import _wrap, _draw_title

THEMES = {
    "night": {"bg1": "#020308", "bg2": "#0e1430", "ring": "#e8ecff", "floor": "#04060f"},
    "sunset": {"bg1": "#0e0306", "bg2": "#3a0f1c", "ring": "#ffd2b0", "floor": "#120408"},
    "mono": {"bg1": "#050505", "bg2": "#1a1a1a", "ring": "#ffffff", "floor": "#000000"},
    "ocean": {"bg1": "#020a10", "bg2": "#0a2a40", "ring": "#bff0ff", "floor": "#03101a"},
}
RANDOM_THEMES = list(THEMES)
CX, CY, AR0 = 540, 1010, 460
MODES = {"grow": "EVERY BOUNCE THE BALL GETS BIGGER", "shrink": "EVERY BOUNCE THE CIRCLE GETS SMALLER",
         "both": "BIGGER BALL, SMALLER CIRCLE"}


class Sim:
    def __init__(self, seed, mode, k, g=900.0):
        self.rng = random.Random(seed)
        self.mode, self.k, self.g = mode, k, g
        a = self.rng.uniform(0, 2 * math.pi)
        self.x, self.y = CX + 80 * math.cos(a), CY - 120
        sp = self.rng.uniform(500, 650)
        self.vx, self.vy = math.cos(a) * sp, math.sin(a) * sp * 0.3
        self.r = 24.0
        self.ar = float(AR0)
        self.bounces = 0
        self.clock = 0.0
        self.done = None
        self.events = []

    def step(self, dt):
        self.clock += dt
        self.vy += self.g * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        dx, dy = self.x - CX, self.y - CY
        d = math.hypot(dx, dy)
        lim = self.ar - self.r
        if lim <= 4 and self.done is None:
            self.done = self.clock
            return
        if d > lim:
            nx, ny = dx / d, dy / d
            self.x, self.y = CX + nx * lim, CY + ny * lim
            vn = self.vx * nx + self.vy * ny
            if vn > 0:
                self.vx -= 2 * vn * nx
                self.vy -= 2 * vn * ny
                # keep it lively: never let it settle at the bottom
                sp = math.hypot(self.vx, self.vy)
                want = max(sp, 700 + 6 * self.bounces)
                self.vx, self.vy = self.vx / max(sp, 1e-6) * want, self.vy / max(sp, 1e-6) * want
                self.bounces += 1
                if self.mode in ("grow", "both"):
                    self.r += self.k
                if self.mode in ("shrink", "both"):
                    self.ar -= self.k * (0.8 if self.mode == "shrink" else 0.4)
                self.events.append((self.clock, self.x, self.y))


def tune(seed, mode, t_min, t_max):
    target = (t_min + t_max) / 2 - 2
    lo, hi = 0.5, 40.0
    best = None
    for _ in range(14):
        k = (lo * hi) ** 0.5
        S = Sim(seed, mode, k)
        while S.done is None and S.clock < t_max * 2:
            S.step(1 / 240)
        t = S.done or S.clock
        if best is None or abs(t - target) < abs(best[1] - target):
            best = (k, t)
        if t > target:
            lo = k
        else:
            hi = k
    return best


def render(cfg, out_path, sound):
    rng = random.Random(cfg["seed"])
    mode = cfg.get("grow_mode") or rng.choice(list(MODES))
    song = cfg.get("song") if cfg.get("song") in MELODIES else rng.choice(list(MELODIES))
    notes = MELODIES[song][1]
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    k, est = tune(cfg["seed"], mode, t_min, t_max)
    print(f"  {mode}, +{k:.2f} per bounce, {song}, ~{est:.1f}s")
    th = THEMES.get(cfg.get("theme"), THEMES["night"])
    T = {kk: V.hexc(v) for kk, v in th.items()}
    sound.music = False   # the melody is the music
    run = Runner(cfg, out_path, sound, est + 5, th)
    run.comm.on = False
    fx = V.Particles(random.Random(cfg["seed"]))
    S = Sim(cfg["seed"], mode, k)
    look = V.Look(cfg["racers"][0], 60) if cfg.get("racers") and cfg.get("use_racer") else None
    title = _wrap(cfg.get("title") or MODES[mode], 22)
    handle = cfg.get("handle", "")
    paint = pygame.Surface((W, H), pygame.SRCALPHA)   # the trail stays: it slowly paints the circle
    hue0 = rng.random()
    seen = 0
    end_t = None
    last = (S.x, S.y)
    while True:
        t = run.t
        if end_t is None:
            for i in range(run.sub):
                S.step(run.dt / run.sub)
            while seen < len(S.events):
                tt, x, y = S.events[seen]
                seen += 1
                m = notes[(seen - 1) % len(notes)]
                sound.add(t, "note", m=m, pan=0.2 + 0.6 * x / W)
                col = tuple(int(c * 255) for c in colorsys.hsv_to_rgb((hue0 + seen * 0.03) % 1, 0.7, 1))
                fx.burst(x, y, col, n=8, speed=280, size=(3, 7), life=(0.2, 0.5))
            if S.done is not None:
                end_t = t
                sound.climax(t)
                sound.add(t, "win")
                fx.confetti(W)
        col = tuple(int(c * 255) for c in colorsys.hsv_to_rgb((hue0 + S.bounces * 0.03) % 1, 0.75, 1))
        pygame.draw.line(paint, (*col, 160), last, (S.x, S.y), max(2, int(S.r * 0.5)))
        last = (S.x, S.y)
        fx.update(run.dt)
        run.clear()
        cv = run.canvas
        ar = int(max(S.ar, S.r + 2))
        gfx.filled_circle(cv, CX, CY, ar + 12, V.darker(T["ring"], 0.3))
        gfx.filled_circle(cv, CX, CY, ar, T["floor"])
        sub = pygame.Rect(CX - AR0 - 30, CY - AR0 - 30, 2 * AR0 + 60, 2 * AR0 + 60)
        clipped = paint.subsurface(sub).copy()
        if ar < AR0:   # the circle shrank: erase paint that is now outside it
            m = pygame.Surface(sub.size, pygame.SRCALPHA)
            m.fill((0, 0, 0, 255))
            pygame.draw.circle(m, (0, 0, 0, 0), (sub.w // 2, sub.h // 2), ar)
            clipped.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_SUB)
        cv.blit(clipped, sub.topleft)
        for kk in range(4):
            gfx.aacircle(cv, CX, CY, ar + kk, T["ring"])
        r = int(S.r)
        if look is not None:
            look.draw_body(cv, S.x, S.y, 0, S.vx, S.vy, r * 2, "ball")
        else:
            gfx.filled_circle(cv, int(S.x), int(S.y), r, V.darker(col, 0.7))
            gfx.filled_circle(cv, int(S.x), int(S.y), max(1, r - 4), col)
            gfx.aacircle(cv, int(S.x), int(S.y), r, (255, 255, 255))
        fx.draw(cv)
        _draw_title(cv, title, t)
        V.blit_center(cv, V.text(f"BOUNCES: {S.bounces}", 84, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, 1600)
        fill = min(100, 100 * (S.r / max(S.ar, 1)) ** 2)
        V.blit_center(cv, V.text(f"{fill:.0f}% FULL", 48, col, (0, 0, 0), weight="Bold"), W / 2, 1690)
        if end_t is not None:
            a = min(1, (t - end_t) / 0.3)
            s2 = V.text("IT'S FULL!", 110, (255, 255, 255), (0, 0, 0), weight="Display")
            s2.set_alpha(int(255 * a))
            V.blit_center(cv, s2, W / 2, CY)
        if handle:
            V.blit_center(cv, V.text(handle, 28, (255, 255, 255), (0, 0, 0), weight="Medium"), W / 2, 1870)
        run.push()
        if end_t is not None and t - end_t >= 3.6:
            break
        if t > max(t_max * 3, est * 1.5 + 15):
            raise RuntimeError("Simulation ran too long")
    dur = run.finish()
    return {"duration": dur, "winner": f"{S.bounces} bounces", "level": cfg["seed"]}
