"""Shared frame loop plumbing for games: canvas, video writer, progress, audio mux."""
import os

from .video import pygame, VideoWriter
from . import visual as V
from . import backgrounds

W, H = 1080, 1920


class Runner:
    def __init__(self, cfg, out_path, sound, est_seconds, theme=None):
        V.STYLE["mode"] = cfg.get("style", "sleek")
        pygame.display.init()
        pygame.font.init()
        pygame.display.set_mode((1, 1))
        self.cfg = cfg
        self.out_path = out_path
        self.sound = sound
        self.fps = cfg.get("fps", 60)
        self.dt = 1 / self.fps
        self.sub = max(1, round(240 / self.fps))
        self.canvas = pygame.Surface((W, H))
        self.frame = 0
        self.est = est_seconds
        self.writer = VideoWriter(out_path, W, H, self.fps, cfg.get("quality", "good"))
        self.bg = None
        if theme is not None:
            self.bg, _ = backgrounds.make(W, H, V.hexc(theme["bg1"]), V.hexc(theme["bg2"]),
                                          cfg.get("background"), cfg["seed"])

    @property
    def t(self):
        return self.frame * self.dt

    def clear(self):
        if self.bg is not None:
            self.canvas.blit(self.bg, (0, 0))
        else:
            self.canvas.fill((8, 9, 14))

    def push(self):
        self.writer.write(self.canvas)
        self.frame += 1
        if self.frame % 30 == 0:
            print(f"PROGRESS {self.frame} {int(max(self.est, self.t + 1) * self.fps)}", flush=True)

    def finish(self):
        duration = self.frame * self.dt
        wav = self.out_path + ".wav"
        self.sound.render(duration, wav)
        self.writer.close(wav)
        os.remove(wav)
        pygame.quit()
        return duration
