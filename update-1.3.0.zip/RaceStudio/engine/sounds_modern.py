"""Modern sound pack: crisp clicks, deep thuds, sub impacts, dark beats.

Used by default. Every voice is synthesized (no samples, no copyright).
"""
import numpy as np

SR = 48000


def _t(d):
    return np.arange(int(d * SR)) / SR


def midi(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def _e(t, tau):
    return np.exp(-t / tau)


def _fade(x, out_ms=10):
    n = max(1, int(SR * out_ms / 1000))
    x = x.copy()
    x[-n:] *= np.linspace(1, 0, n)
    return x


def band(n, rng, lo, hi):
    spec = np.fft.rfft(rng.standard_normal(n))
    f = np.fft.rfftfreq(n, 1 / SR)
    spec[(f < lo) | (f > hi)] = 0
    y = np.fft.irfft(spec, n)
    return y / (np.max(np.abs(y)) + 1e-9)


def sweep(f0, f1, d, curve=4.0):
    t = _t(d)
    k = 1 - (1 - t / d) ** curve if f1 < f0 else (t / d) ** curve
    f = f0 + (f1 - f0) * k
    return np.sin(2 * np.pi * np.cumsum(f) / SR)


def sat(x, drive=2.0):
    return np.tanh(x * drive) / np.tanh(drive)


def pad_to(a, n):
    return np.pad(a, (0, max(0, n - len(a))))[:n]


# ------------------------------------------------------------------ voices

def tick(freq, seed=0, body=1.0):
    """The core bounce: tight click + short tuned 'tok'. Satisfying, not cute."""
    rng = np.random.default_rng(seed)
    d = 0.16
    t = _t(d)
    click = band(len(t), rng, 3000, 12000) * _e(t, 0.0012)
    f = freq * (1 + 0.18 * _e(t, 0.004))
    ph = 2 * np.pi * np.cumsum(f) / SR
    tok = (np.sin(ph) + 0.25 * np.sin(2 * ph)) * _e(t, 0.03) * body
    return _fade(sat(0.55 * click + 0.8 * tok, 1.4))


def thud(freq=80, seed=0):
    """Block hit: weighty low thump with a crunchy edge."""
    rng = np.random.default_rng(10 + seed)
    d = 0.3
    t = _t(d)
    f = freq * (1 + 1.2 * _e(t, 0.01))
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * _e(t, 0.07)
    crunch = band(len(t), rng, 1500, 7000) * _e(t, 0.006)
    return _fade(sat(body + 0.45 * crunch, 2.2))


def impact(seed=0, size=1.0):
    """Big hit (block shatter / ring break): sub drop + noise + air."""
    rng = np.random.default_rng(20 + seed)
    d = 1.4
    t = _t(d)
    sub = pad_to(sweep(150, 36, 0.7) * _e(_t(0.7), 0.28), len(t))
    noise = band(len(t), rng, 80, 2500) * _e(t, 0.07)
    air = band(len(t), rng, 5000, 14000) * _e(t, 0.35) * 0.18
    crack = band(len(t), rng, 2000, 9000) * _e(t, 0.004)
    x = sat(sub * 1.1 + noise * 0.5 * size + crack * 0.4, 2.5) + air
    return _fade(x, 80)


def zap_down(seed=0):
    rng = np.random.default_rng(30 + seed)
    d = 0.4
    t = _t(d)
    z = pad_to(sweep(1100, 70, 0.32), len(t)) * _e(t, 0.12)
    return _fade(sat(z + 0.3 * band(len(t), rng, 200, 4000) * _e(t, 0.03), 3))


def swish(d=0.35, up=True, seed=0):
    rng = np.random.default_rng(40 + seed)
    t = _t(d)
    n = band(len(t), rng, 600 if up else 300, 9000)
    env = (t / d) ** 2.2 if up else (1 - t / d) ** 2.2
    return _fade(n * env * 0.7, 15)


def clock_tick(high=True, seed=0):
    rng = np.random.default_rng(50 + seed)
    t = _t(0.06)
    f = 2400 if high else 1800
    return _fade(band(len(t), rng, 1500, 8000) * _e(t, 0.004) * 0.6 + np.sin(2 * np.pi * f * t) * _e(t, 0.01) * 0.4)


def riser(d=2.0, seed=0):
    """Tension build: rising filtered noise + rising tone."""
    rng = np.random.default_rng(60 + seed)
    t = _t(d)
    n = band(len(t), rng, 800, 12000) * (t / d) ** 2.5
    tone = sweep(110, 880, d, 2.0) * (t / d) ** 2 * 0.25
    return n * 0.45 + tone


def chord_swell(notes, d=2.4):
    """Dark, wide pad chord for the winner moment."""
    t = _t(d)
    x = np.zeros_like(t)
    for m in notes:
        f = midi(m)
        for det in (-0.07, 0.07):
            for h in range(1, 7):
                x += np.sin(2 * np.pi * f * 2 ** (det / 12) * h * t) / (h ** 1.6)
    env = np.minimum(1, t / 0.08) * _e(t, 0.9)
    return x / len(notes) * env * 0.5


def win_hit(key):
    out = impact(7, 1.4) * 1.2
    sw = chord_swell([key - 12, key - 5, key, key + 3, key + 10, key + 14])
    n = max(len(out), len(sw))
    return pad_to(out, n) + pad_to(sw, n)


# ------------------------------------------------------------------ drums

def kick808(dur=0.6, f0=48, punch=1.0):
    t = _t(dur)
    f = f0 * (1 + 2.6 * punch * _e(t, 0.025))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * _e(t, dur * 0.45)
    return _fade(sat(x, 1.8), 30)


def clap(seed=0):
    rng = np.random.default_rng(70 + seed)
    t = _t(0.3)
    env = np.zeros_like(t)
    for k, o in enumerate((0, 0.009, 0.018)):
        tt = np.clip(t - o, 0, None)
        env += (t >= o) * _e(tt, 0.006 if k < 2 else 0.07)
    return _fade(band(len(t), rng, 900, 6500) * env * 0.7 + np.sin(2 * np.pi * 190 * t) * _e(t, 0.03) * 0.3)


def hat(open_=False, seed=0):
    rng = np.random.default_rng(80 + seed)
    d = 0.25 if open_ else 0.05
    t = _t(d)
    return _fade(band(len(t), rng, 7000, 16000) * _e(t, 0.06 if open_ else 0.011))


def cowbell(freq):
    t = _t(0.35)
    x = np.zeros_like(t)
    for f in (freq, freq * 1.48):
        x += np.sign(np.sin(2 * np.pi * f * t)) * 0.5 + np.sin(2 * np.pi * f * t) * 0.5
    x = band_like(x, 400, 4500)
    return _fade(x * _e(t, 0.09) * 0.5)


def band_like(x, lo, hi):
    n = len(x)
    spec = np.fft.rfft(x)
    f = np.fft.rfftfreq(n, 1 / SR)
    spec[(f < lo) | (f > hi)] = 0
    y = np.fft.irfft(spec, n)
    return y / (np.max(np.abs(y)) + 1e-9)


def epiano(freq, d=1.2):
    t = _t(d)
    x = np.sin(2 * np.pi * freq * t) + 0.3 * np.sin(2 * np.pi * freq * 2 * t) * _e(t, 0.3)
    trem = 1 + 0.15 * np.sin(2 * np.pi * 4.5 * t)
    return _fade(x * _e(t, 0.6) * trem * np.minimum(1, t / 0.005), 40)


def dark_pad(freqs, d):
    t = _t(d)
    x = np.zeros_like(t)
    rng = np.random.default_rng(int(freqs[0]))
    for f in freqs:
        for det in (-0.1, 0.1):
            for h in range(1, 5):
                x += np.sin(2 * np.pi * f * 2 ** (det / 12) * h * t + rng.uniform(0, 6)) / (h ** 1.8)
    env = np.minimum(1, t / 0.4) * np.minimum(1, (d - t) / 0.4)
    return x / len(freqs) * env


# ------------------------------------------------------------------ beds

VIBES = {
    # bpm, progression (root offset, minor?), pattern
    "dark": {"bpm": 140, "prog": [(0, "m"), (8, "M"), (3, "M"), (10, "M")]},
    "phonk": {"bpm": 128, "prog": [(0, "m"), (0, "m"), (8, "M"), (10, "M")]},
    "lofi": {"bpm": 84, "prog": [(0, "m7"), (5, "m7"), (8, "M7"), (7, "m7")]},
    "hype": {"bpm": 150, "prog": [(0, "m"), (8, "M"), (5, "m"), (7, "M")]},
}
QUAL = {"m": [0, 3, 7], "M": [0, 4, 7], "m7": [0, 3, 7, 10], "M7": [0, 4, 7, 11]}


class ModernHarmony:
    def __init__(self, key, vibe):
        self.vibe = vibe if vibe in VIBES else "dark"
        v = VIBES[self.vibe]
        self.key = key
        self.bpm = v["bpm"]
        self.prog = v["prog"]
        self.bar = 4 * 60 / self.bpm

    def chord_at(self, t):
        root, q = self.prog[int(t / self.bar) % len(self.prog)]
        return root, QUAL[q]

    def note_at(self, t, idx, octave=0):
        root, tones = self.chord_at(t)
        pool = [self.key + 12 * octave + root + x for x in tones] + [self.key + 12 * (octave + 1) + root]
        seq = [0, 2, 1, 3, 2, 0, 1, 2]
        return pool[seq[idx % len(seq)] % len(pool)]


def bed(duration, H, climax=None, seed=0):
    """Beat from frame 0, builds near the climax, drops at the climax."""
    n = int(duration * SR) + SR
    out = np.zeros((n, 2))
    rng = np.random.default_rng(seed)
    step = 60 / H.bpm / 4  # 16th note
    vibe = H.vibe

    def put(sig, t0, gain=1.0, pan=0.5):
        o = int(t0 * SR)
        if o >= n:
            return
        seg = sig[: n - o]
        out[o:o + len(seg), 0] += seg * gain * np.cos(pan * np.pi / 2) * 1.41
        out[o:o + len(seg), 1] += seg * gain * np.sin(pan * np.pi / 2) * 1.41

    k808 = kick808(0.7 if vibe in ("dark", "phonk") else 0.4, 46 if vibe != "lofi" else 55)
    clp = clap(seed)
    hh = hat(False, seed)
    oh = hat(True, seed)
    if vibe == "phonk":
        kick_steps, clap_steps = {0, 6, 10}, {4, 12}
    elif vibe == "lofi":
        kick_steps, clap_steps = {0, 7, 10}, {4, 12}
    elif vibe == "hype":
        kick_steps, clap_steps = {0, 3, 10}, {8}
    else:
        kick_steps, clap_steps = {0, 10}, {8}
    drop_start = (climax - 0.6) if climax else None
    total_steps = int(duration / step) + 1
    for s in range(total_steps):
        t = s * step
        if vibe == "lofi" and s % 2 == 1:
            t += step * 0.18  # swing
        if drop_start and drop_start <= t < climax:
            continue  # silence right before the finish: makes the hit land
        build = climax is not None and climax - 4.0 <= t < drop_start
        after = climax is not None and t >= climax
        pos = s % 16
        bar_i = s // 16
        if pos in kick_steps or (build and pos in (0, 4, 8, 12)):
            put(k808, t, 0.42 if not after else 0.25)
        if pos in clap_steps and not after:
            put(clp, t, 0.32)
        hat_every = 1 if (vibe == "hype" or build) else 2
        if s % hat_every == 0:
            put(hh, t, 0.1 + (0.05 if pos % 4 == 2 else 0), 0.62)
        if vibe in ("dark", "hype") and pos == 14 and bar_i % 2 == 1 and not after:
            for r in range(3):  # trap hat roll
                put(hh, t + r * step / 3, 0.08, 0.4)
        if vibe == "lofi" and pos == 14:
            put(oh, t, 0.06, 0.4)
        if vibe == "phonk" and not after:
            root, tones = H.chord_at(t)
            patt = [0, None, 0, 7, None, 0, 10, None, 0, None, 3, 0, None, 7, 5, None]
            if patt[pos] is not None:
                put(cowbell(midi(H.key + 12 + root + patt[pos])), t, 0.12, 0.55)
    # harmony layer per bar
    b = 0
    while b * H.bar < duration:
        t0 = b * H.bar
        root, tones = H.chord_at(t0 + 0.01)
        if vibe == "lofi":
            for k, x in enumerate(tones):
                put(epiano(midi(H.key + root + x), H.bar * 0.95), t0 + k * 0.012, 0.09, 0.3 + 0.12 * k)
        else:
            pad = dark_pad([midi(H.key - 12 + root + x) for x in tones], H.bar + 0.3)
            put(pad, t0, 0.07 if vibe != "hype" else 0.05, 0.5)
        # 808 / sub bass on the root
        bass = kick808(H.bar * 0.9, midi(H.key - 24 + root) if vibe != "lofi" else midi(H.key - 12 + root), 0.3)
        put(bass, t0, 0.16 if vibe != "lofi" else 0.1)
        b += 1
    if vibe == "lofi":  # vinyl crackle
        crack = np.zeros(n)
        idx = rng.integers(0, n, int(duration * 18))
        crack[idx] = rng.uniform(-0.6, 0.6, len(idx))
        out += np.stack([crack, np.roll(crack, 37)], 1) * 0.12
    if climax is not None:
        r = riser(3.4, seed)
        put(r, max(0, climax - 3.4), 0.22)
    return out[: int(duration * SR)]
