"""Game 1: Square Maze Race.

Racers bounce at constant speed through a zig-zag maze. Numbered blocks
seal some of the passages and lose 1 point per hit; spikes send a racer
back to the start of its lane; the first racer to touch the checkered
flag wins.

Every race is generated from a seed and auto-tuned so the race lasts
inside the target time window.
"""
import math
import random
from collections import deque

from engine.video import pygame
from engine import visual as V

EMPTY, WALL, SPIKE, FINISH = 0, 1, 2, 3

THEMES = {
    "ocean": {"bg1": "#0b1a3a", "bg2": "#1b4a8a", "paper": "#eef6ff", "grid": "#d7e6f7",
              "wall": "#2456c8", "wall_hi": "#5d8cf0", "block": "#ffb020", "block_txt": "#3a2200"},
    "jungle": {"bg1": "#0b2a17", "bg2": "#1f6a3a", "paper": "#effbe9", "grid": "#d6efcb",
               "wall": "#1f8a3c", "wall_hi": "#57c46f", "block": "#ff6b5b", "block_txt": "#3a0c06"},
    "candy": {"bg1": "#3a0b33", "bg2": "#8a2b72", "paper": "#fff2fa", "grid": "#f6d7ea",
              "wall": "#d9368b", "wall_hi": "#ff7cbc", "block": "#45c7ff", "block_txt": "#062a3a"},
    "night": {"bg1": "#07070f", "bg2": "#1d1b3a", "paper": "#1c1f33", "grid": "#262a44",
              "wall": "#7b5cff", "wall_hi": "#b29dff", "block": "#22e3a1", "block_txt": "#05301f"},
    "lava": {"bg1": "#1a0500", "bg2": "#5a1a05", "paper": "#fff4ea", "grid": "#f6dcc6",
             "wall": "#e2461b", "wall_hi": "#ff8a4c", "block": "#ffd400", "block_txt": "#3a2a00"},
    "ice": {"bg1": "#06202e", "bg2": "#1a6a8a", "paper": "#f2fbff", "grid": "#d4eef8",
            "wall": "#2aa8d8", "wall_hi": "#8fe0ff", "block": "#ff5c8a", "block_txt": "#3a0614"},
    "retro": {"bg1": "#1b1a2e", "bg2": "#3a2f5b", "paper": "#fdf6e3", "grid": "#efe3c4",
              "wall": "#2b2b2b", "wall_hi": "#5a5a5a", "block": "#ff6f3c", "block_txt": "#2b0d00"},
    "mint": {"bg1": "#062a24", "bg2": "#0f6b5c", "paper": "#f0fffa", "grid": "#cdf2e6",
             "wall": "#13a383", "wall_hi": "#5be0bf", "block": "#7a5cff", "block_txt": "#ffffff"},
}

THEMES.update({
    "midnight": {"bg1": "#04060c", "bg2": "#111a30", "paper": "#0c1120", "grid": "#141b2e",
                 "wall": "#3d7bff", "wall_hi": "#86abff", "block": "#eef2ff", "block_txt": "#0c1120"},
    "carbon": {"bg1": "#050505", "bg2": "#1c1c1f", "paper": "#111113", "grid": "#19191c",
               "wall": "#e9e9ec", "wall_hi": "#ffffff", "block": "#ff3b4e", "block_txt": "#ffffff"},
    "aurora": {"bg1": "#020d10", "bg2": "#0b2c31", "paper": "#06171b", "grid": "#0b2429",
               "wall": "#17cfa0", "wall_hi": "#7af2cf", "block": "#c08cff", "block_txt": "#12051f"},
    "ember": {"bg1": "#0b0402", "bg2": "#2a0e05", "paper": "#130806", "grid": "#1f0f0a",
              "wall": "#ff6a2a", "wall_hi": "#ffa36f", "block": "#ffd166", "block_txt": "#271300"},
    "minimal": {"bg1": "#1a1c22", "bg2": "#3a3e48", "paper": "#f7f8fa", "grid": "#eceef2",
                "wall": "#15171c", "wall_hi": "#2c2f37", "block": "#15171c", "block_txt": "#ffffff"},
})
RANDOM_THEMES = ["midnight", "carbon", "aurora", "ember", "minimal"]

W, H = 1080, 1920
TILE = 40
COLS, ROWS = 25, 31
BX, BY = 40, 360  # board top-left on screen


# ====================================================================== level

class Level:
    def __init__(self, seed, n_gates=None, lanes=None):
        rng = random.Random(seed)
        self.rng = rng
        g = [[EMPTY] * COLS for _ in range(ROWS)]
        for r in range(ROWS):
            g[r][0] = g[r][COLS - 1] = WALL
        for c in range(COLS):
            g[0][c] = g[ROWS - 1][c] = WALL
        # --- lanes separated by wall rows, openings zig-zag left/right
        k = rng.choice(lanes or [4, 5, 5])
        inner = ROWS - 2 - (k - 1)
        heights = [inner // k] * k
        for i in range(inner - sum(heights)):
            heights[i % k] += 1
        for _ in range(3):  # vary lane heights a little
            a, b = rng.sample(range(k), 2)
            if heights[a] > 4:
                heights[a] -= 1
                heights[b] += 1
        # first lane is short so the first obstacle comes fast
        if heights[0] > 3:
            extra = heights[0] - 3
            heights[0] = 3
            for i in range(extra):
                heights[1 + i % (k - 1)] += 1
        self.lanes = []  # (top_row, bottom_row)
        r = 1
        seps = []
        for i, h in enumerate(heights):
            self.lanes.append((r, r + h - 1))
            r += h
            if i < k - 1:
                seps.append(r)
                for c in range(COLS):
                    g[r][c] = WALL
                r += 1
        self.gaps = []  # (sep_row, c0, c1, side)
        side = "R"
        for sr in seps:
            gw = rng.choice([3, 3, 4])
            c0, c1 = (COLS - 1 - gw, COLS - 2) if side == "R" else (1, gw)
            for c in range(c0, c1 + 1):
                g[sr][c] = EMPTY
            self.gaps.append((sr, c0, c1, side))
            side = "L" if side == "R" else "R"
        self.start_side = "L"
        self.finish_side = side  # far end of last lane
        # --- finish 2x2 at far end of the last lane (vertically centred)
        lt, lb = self.lanes[-1]
        fr = (lt + lb) // 2
        fc = COLS - 3 if self.finish_side == "R" else 1
        self.finish = [(fc, fr), (fc + 1, fr), (fc, fr + 1), (fc + 1, fr + 1)]
        for c, rr in self.finish:
            g[rr][c] = FINISH

        def near_gap(c, lane_i):
            for sr, c0, c1, s in self.gaps:
                if abs(sr - self.lanes[lane_i][0]) <= 1 or abs(sr - self.lanes[lane_i][1]) <= 1:
                    if c0 - 4 <= c <= c1 + 4:
                        return True
            return False

        # --- wall stubs inside lanes for bouncier paths
        for li, (t, b) in enumerate(self.lanes):
            if li == 0:
                continue
            h = b - t + 1
            for _ in range(rng.choice([1, 2, 2, 3])):
                c = rng.randint(5, COLS - 6)
                if near_gap(c, li) or (li == len(self.lanes) - 1 and abs(c - fc) < 5):
                    continue
                ln = rng.randint(1, max(1, h - 3))
                if rng.random() < 0.5:
                    for rr in range(t, t + ln):
                        g[rr][c] = WALL
                else:
                    for rr in range(b - ln + 1, b + 1):
                        g[rr][c] = WALL
        # --- spikes on lane floors / ceilings
        for li, (t, b) in enumerate(self.lanes):
            if li == 0:
                continue
            for _ in range(rng.choice([0, 1, 1, 2])):
                ln = rng.randint(2, 3)
                c = rng.randint(4, COLS - 5 - ln)
                if any(near_gap(cc, li) for cc in range(c, c + ln)):
                    continue
                if li == len(self.lanes) - 1 and abs(c - fc) < 6:
                    continue
                rr = b if rng.random() < 0.6 else t
                if all(g[rr][cc] == EMPTY for cc in range(c, c + ln)):
                    for cc in range(c, c + ln):
                        g[rr][cc] = SPIKE
        self.grid = g
        # --- numbered gate blocks in some openings (gap row + row above)
        n_gates = n_gates if n_gates is not None else rng.choice([2, 2, 3])
        n_gates = min(n_gates, len(self.gaps))
        rest = list(range(1, len(self.gaps)))
        gated = sorted([0] + rng.sample(rest, max(0, min(len(rest), n_gates - 1)))) if n_gates else []
        self.blocks = []
        for gi in gated:
            sr, c0, c1, s = self.gaps[gi]
            tiles = [(c, rr) for c in range(c0, c1 + 1) for rr in (sr - 1, sr)]
            self.blocks.append({"tiles": tiles, "hp": rng.randint(20, 45), "max": 0,
                                "alive": True, "flash": 0.0, "pulse": 0.0,
                                "rect": pygame.Rect(BX + c0 * TILE, BY + (sr - 1) * TILE,
                                                    (c1 - c0 + 1) * TILE, 2 * TILE)})
        # numbers ramp up: first block breaks quickly, later ones take longer
        g = len(self.blocks)
        for i, b in enumerate(self.blocks):
            if i == 0:
                b["hp"] = rng.randint(6, 12)  # first obstacle: quick win in the first seconds
            else:
                b["hp"] = max(8, int(b["hp"] * (0.6 + 0.4 * (i / (g - 1) if g > 1 else 1))))
            b["max"] = b["hp"]
        self._rebuild_blockmap()
        self.dist = self._distance_field()

    def _rebuild_blockmap(self):
        self.blockmap = {}
        for i, b in enumerate(self.blocks):
            if b["alive"]:
                for t in b["tiles"]:
                    self.blockmap[t] = i

    def set_hp(self, values):
        for b, v in zip(self.blocks, values):
            b["hp"] = b["max"] = max(1, int(v))

    def _distance_field(self):
        d = [[10 ** 6] * COLS for _ in range(ROWS)]
        q = deque()
        for c, r in self.finish:
            d[r][c] = 0
            q.append((c, r))
        while q:
            c, r = q.popleft()
            for dc, dr in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nc, nr = c + dc, r + dr
                if 0 <= nc < COLS and 0 <= nr < ROWS and self.grid[nr][nc] != WALL and d[nr][nc] > d[r][c] + 1:
                    d[nr][nc] = d[r][c] + 1
                    q.append((nc, nr))
        return d

    def lane_of(self, row):
        for i, (t, b) in enumerate(self.lanes):
            if t - 1 <= row <= b:
                return i
        return len(self.lanes) - 1

    def checkpoint(self, lane_i):
        """Where a racer respawns: entrance of its lane (screen coords)."""
        t, b = self.lanes[lane_i]
        if lane_i == 0:
            return BX + 3 * TILE, BY + (t + 1.5) * TILE
        sr, c0, c1, s = self.gaps[lane_i - 1]
        return BX + ((c0 + c1 + 1) / 2) * TILE, BY + (t + 1.4) * TILE


# ====================================================================== sim (real physics)

import pymunk  # noqa: E402

CT_RACER, CT_WALL, CT_BLOCK, CT_SPIKE, CT_FINISH = 1, 2, 3, 4, 5
GRAVITY = 1900.0


class Racer:
    def __init__(self, idx, look, body, shape):
        self.i = idx
        self.look = look
        self.body = body
        self.shape = shape
        self.dead = 0.0
        self.squash = 0.0
        self.trail = deque(maxlen=12)
        self.finished = False
        self.slow = 0.0
        self.last_hit = -9.0

    @property
    def x(self):
        return self.body.position.x

    @property
    def y(self):
        return self.body.position.y

    @property
    def vx(self):
        return self.body.velocity.x

    @property
    def vy(self):
        return self.body.velocity.y


class Sim:
    """Rigid-body sim (pymunk): gravity, real collisions, spin, friction.
    Racers hop along each lane, drop through the gaps, and smash numbered blocks."""

    def __init__(self, level, looks, seed, speed=640, size=56, sound=None, fx=None):
        self.L = level
        self.rng = random.Random(seed * 7919 + 13)
        self.speed = speed
        self.size = size
        self.half = size / 2
        self.sound = sound
        self.fx = fx
        self.shake = 0.0
        self.winner = None
        self.now = 0.0
        self.clock = 0.0  # internal clock for game logic (keeps tuned and rendered races identical)
        self._todo = []
        sp = pymunk.Space()
        sp.gravity = (0, GRAVITY)
        sp.iterations = 25
        self.space = sp
        self._build_static()
        self.racers = []
        t, b = level.lanes[0]
        y = BY + (t + (b - t + 1) / 2) * TILE
        for i, lk in enumerate(looks):
            x = BX + TILE * 1.3 + self.half + i * (size + 10)
            body = pymunk.Body(1.0, pymunk.moment_for_box(1.0, (size, size)))
            body.position = (x, y)
            body.velocity = (self.rng.uniform(0.6, 1.0) * speed * 0.55, -self.rng.uniform(150, 350))
            body.angular_velocity = self.rng.uniform(-3, 3)
            shape = pymunk.Poly.create_box(body, (size - 8, size - 8), radius=4)
            shape.elasticity = 0.9
            shape.friction = 0.55
            shape.collision_type = CT_RACER
            sp.add(body, shape)
            R = Racer(i, lk, body, shape)
            shape.racer = R
            self.racers.append(R)
        sp.on_collision(CT_RACER, CT_WALL, post_solve=self._on_wall)
        sp.on_collision(CT_RACER, CT_BLOCK, post_solve=self._on_block)
        sp.on_collision(CT_RACER, CT_SPIKE, begin=self._on_spike)
        sp.on_collision(CT_RACER, CT_FINISH, begin=self._on_finish)
        sp.on_collision(CT_RACER, CT_RACER, post_solve=self._on_racer)

    # --------------------------------------------------- world
    def _box(self, x0, y0, x1, y1, ct, sensor=False, elastic=0.92):
        sh = pymunk.Poly(self.space.static_body, [(x0, y0), (x1, y0), (x1, y1), (x0, y1)])
        sh.elasticity = elastic
        sh.friction = 0.6
        sh.collision_type = ct
        sh.sensor = sensor
        self.space.add(sh)
        return sh

    def _build_static(self):
        g = self.L.grid
        for r in range(ROWS):
            c = 0
            while c < COLS:
                if g[r][c] == WALL:
                    c0 = c
                    while c < COLS and g[r][c] == WALL:
                        c += 1
                    self._box(BX + c0 * TILE, BY + r * TILE, BX + c * TILE, BY + (r + 1) * TILE, CT_WALL)
                else:
                    c += 1
        for r in range(ROWS):
            for c in range(COLS):
                x0, y0 = BX + c * TILE, BY + r * TILE
                if g[r][c] == SPIKE:
                    up = r + 1 < ROWS and g[r + 1][c] == WALL
                    yy0, yy1 = (y0 + TILE * 0.35, y0 + TILE) if up else (y0, y0 + TILE * 0.65)
                    self._box(x0 + 3, yy0, x0 + TILE - 3, yy1, CT_SPIKE, sensor=True)
                elif g[r][c] == FINISH:
                    self._box(x0, y0, x0 + TILE, y0 + TILE, CT_FINISH, sensor=True)
        for i, b in enumerate(self.L.blocks):
            rc = b["rect"]
            sh = self._box(rc.left, rc.top, rc.right, rc.bottom, CT_BLOCK, elastic=0.95)
            sh.block_index = i
            b["shape"] = sh

    # --------------------------------------------------- events
    def _ev(self, kind, R=None, x=None, **kw):
        if self.sound is not None:
            px = (x if x is not None else (R.x if R else W / 2)) / W
            self.sound.add(self.now, kind, who=R.i if R else None, pan=0.15 + 0.7 * px, **kw)

    def _impulse(self, arb):
        j = arb.total_impulse
        return math.hypot(j.x, j.y)

    def _on_wall(self, arb, space, data):
        if not arb.is_first_contact:
            return
        R = arb.shapes[0].racer
        imp = self._impulse(arb)
        if imp > 140:
            R.squash = min(1.0, imp / 900)
            self._ev("bounce", R, min_gap=0.06, gain=min(1.0, 0.35 + imp / 1400))
        self._todo.append(("keep", R, arb.normal.y))

    def _on_block(self, arb, space, data):
        if not arb.is_first_contact:
            return
        R = arb.shapes[0].racer
        bi = arb.shapes[1].block_index
        if self._impulse(arb) > 120 and self.clock - R.last_hit > 0.05:
            R.last_hit = self.clock
            self._todo.append(("hit", bi, R))
        self._todo.append(("keep", R, arb.normal.y))

    def _on_spike(self, arb, space, data):
        R = arb.shapes[0].racer
        if R.dead <= 0:
            self._todo.append(("die", R))
        arb.process_collision = False

    def _on_finish(self, arb, space, data):
        R = arb.shapes[0].racer
        if self.winner is None and R.dead <= 0:
            self.winner = R
            R.finished = True
            self._ev("win", R)
        arb.process_collision = False

    def _on_racer(self, arb, space, data):
        if arb.is_first_contact and self._impulse(arb) > 120:
            a = arb.shapes[0].racer
            self._ev("racer", a, x=(a.x + arb.shapes[1].racer.x) / 2, min_gap=0.12)

    # --------------------------------------------------- energy (keeps them lively, applied smoothly at contacts)
    def _keep(self, R, ny):
        b = R.body
        vx, vy = b.velocity
        lane = self.L.lanes[self.L.lane_of(int((R.y - BY) // TILE))]
        lane_h = (lane[1] - lane[0] + 1) * TILE
        hop = max(70.0, min(220.0, lane_h - self.size - 14))
        v_hop = math.sqrt(2 * GRAVITY * hop)
        if ny > 0.6 and vy > -v_hop * 0.9:  # landed on a floor: springy hop
            vy = -v_hop * self.rng.uniform(0.92, 1.05)
        vx_min, vx_max = self.speed * 0.38, self.speed * 0.85
        if abs(vx) < vx_min:
            vx = math.copysign(vx_min, vx if abs(vx) > 5 else self.rng.choice([-1, 1]))
        elif abs(vx) > vx_max:
            vx = math.copysign(vx_max, vx)
        b.velocity = (vx, vy)
        b.angular_velocity = max(-14, min(14, b.angular_velocity))

    def _hit_block(self, bi, R):
        b = self.L.blocks[bi]
        if not b["alive"]:
            return
        b["hp"] -= 1
        b["flash"] = 1.0
        b["pulse"] = 1.0
        if b["hp"] <= 0:
            b["alive"] = False
            self.space.remove(b["shape"])
            self.L._rebuild_blockmap()
            self.shake = 1.0
            self._ev("break", R, x=b["rect"].centerx)
            if self.fx:
                rc = b["rect"]
                for k in range(6):
                    self.fx.burst(rc.x + rc.w * (k + 0.5) / 6, rc.centery, self.block_color, n=10, speed=650, size=(10, 22))
        else:
            self._ev("hit", R, x=b["rect"].centerx, min_gap=0.035)

    def _die(self, R):
        R.dead = 0.8
        self._ev("die", R)
        if self.fx:
            self.fx.burst(R.x, R.y, R.look.color, n=26, speed=600)
        self.space.remove(R.body, R.shape)
        R.trail.clear()

    def _respawn(self, R):
        lane = self.L.lane_of(int((R.y - BY) // TILE))
        x, y = self.L.checkpoint(lane)
        R.body.position = (x, y)
        R.body.velocity = (self.rng.choice([-1, 1]) * self.speed * 0.5, -200)
        R.body.angle = 0
        R.body.angular_velocity = 0
        self.space.add(R.body, R.shape)
        self._ev("spawn", R)

    # --------------------------------------------------- step
    def step(self, dt, now):
        self.now = now
        self.clock += dt
        for R in self.racers:
            R.squash *= math.exp(-dt / 0.07)
            if R.dead > 0:
                R.dead -= dt
                if R.dead <= 0:
                    self._respawn(R)
        self.space.step(dt)
        todo, self._todo = self._todo, []
        for item in todo:
            if item[0] == "keep" and item[1].dead <= 0:
                self._keep(item[1], item[2])
            elif item[0] == "hit":
                self._hit_block(item[1], item[2])
            elif item[0] == "die" and item[1].dead <= 0:
                self._die(item[1])
        for R in self.racers:
            if R.dead > 0:
                continue
            sp = R.body.velocity.length
            R.slow = R.slow + dt if sp < 60 else 0.0
            if R.slow > 1.0:  # never let anyone get stuck
                R.body.velocity = (self.rng.choice([-1, 1]) * self.speed * 0.5, -600)
                R.slow = 0.0
        self.shake *= math.exp(-dt / 0.15)

    def ranking(self):
        def key(R):
            if R.finished:
                return -1
            c, r = int((R.x - BX) // TILE), int((R.y - BY) // TILE)
            c, r = min(max(c, 0), COLS - 1), min(max(r, 0), ROWS - 1)
            return self.L.dist[r][c] + (1000 if R.dead > 0 else 0)
        prev = getattr(self, "_prev_rank", {})
        order = sorted(self.racers, key=lambda R: (key(R) // 5, prev.get(R.i, 0)))
        self._prev_rank = {R.i: p for p, R in enumerate(order)}
        return order

    block_color = (255, 176, 32)


# ====================================================================== tuning

def tune(seed, n_racers, t_min, t_max, speed, size, n_gates=None, tries=80):
    """Find a level + block numbers whose race length lands in [t_min, t_max].
    Returns (level_seed, block_hp, race_seconds, lanes)."""
    lanes = [3, 3, 4] if t_max <= 30 else [3, 4] if t_max <= 40 else [4, 5, 5] if t_max <= 75 else [5, 6]
    dummy_looks = [None] * n_racers
    best = None
    for attempt in range(tries):
        lseed = seed * 1000 + attempt
        L = Level(lseed, n_gates, lanes)
        hp = [b["hp"] for b in L.blocks]
        for _ in range(8):
            L = Level(lseed, n_gates, lanes)
            L.set_hp(hp)
            S = Sim(L, dummy_looks, lseed, speed, size)
            t, dt = 0.0, 1 / 240
            while S.winner is None and t < t_max * 1.6:
                S.step(dt, t)
                t += dt
            if S.winner is not None:
                miss = max(0, t_min - t, t - t_max)
                if best is None or miss < best[0]:
                    best = (miss, lseed, list(hp), t)
            if S.winner is None or t > t_max:
                if len(hp) < 2 or max(hp[1:]) * 0.7 < 15:
                    break  # numbers would get too small -> try a new layout
                hp = hp[:1] + [max(8, int(h * 0.7)) for h in hp[1:]]
                continue
            if t < t_min:
                if len(hp) < 2:
                    break
                hp = hp[:1] + [min(400, int(h * (t_min / t) * 1.25) + 2) for h in hp[1:]]
                continue
            return lseed, hp, t, lanes
    if best:
        return best[1], best[2], best[3], lanes
    raise RuntimeError("Could not make a level for that race length, try a longer range")


# ====================================================================== render

def render(cfg, out_path, sound):
    from engine.video import VideoWriter
    theme = THEMES.get(cfg.get("theme", "ocean"), THEMES["ocean"])
    T = {k: V.hexc(v) for k, v in theme.items()}
    fps = cfg.get("fps", 60)
    seed = cfg["seed"]
    racers_spec = cfg["racers"]
    n = len(racers_spec)
    size = cfg.get("racer_size", 60 if n <= 6 else 50)
    V.STYLE["mode"] = cfg.get("style", "sleek")
    t_min, t_max = cfg.get("race_seconds", [20, 35])
    speed = cfg.get("speed", 820 if t_max > 40 else 960)

    lseed, hp, est, lanes = tune(seed, n, t_min, t_max, speed, size, cfg.get("gates"))
    print(f"  level {lseed}: blocks {hp}, race ~{est:.1f}s")

    pygame.display.init()
    pygame.font.init()
    pygame.display.set_mode((1, 1))
    canvas = pygame.Surface((W, H))
    looks = [V.Look(s, size) for s in racers_spec]
    L = Level(lseed, cfg.get("gates"), lanes)
    L.set_hp(hp)
    fx = V.Particles(random.Random(seed))
    S = Sim(L, looks, lseed, speed, size, sound=sound, fx=fx)
    S.block_color = T["block"]

    from engine import backgrounds
    bg, _ = backgrounds.make(W, H, T["bg1"], T["bg2"], cfg.get("background"), seed)
    board = _board_layer(L, T)
    title = cfg.get("title") or "WHO REACHES THE FLAG FIRST?"
    title_lines = _wrap(title, 22)
    handle = cfg.get("handle", "")

    writer = VideoWriter(out_path, W, H, fps, cfg.get("quality", "good"))
    dt = 1 / fps
    sub = max(1, round(240 / fps))
    count_in = 0.0 if V.sleek() else 1.5  # sleek: action from the very first frame
    frame = 0
    t = 0.0
    phase = "count"
    win_time = None
    rank_x = {R.i: 0.0 for R in S.racers}
    if count_in > 0:
        for m in (0.0, 0.5, 1.0):
            sound.add(m, "count")
    sound.add(count_in, "go")

    end_len = 4.0
    while True:
        t = frame * dt
        # ------------------------------------------------ simulate
        if phase == "count" and t >= count_in:
            phase = "race"
        if phase == "race":
            for i in range(sub):
                S.step(dt / sub, t + i * dt / sub)
                if S.winner:
                    phase = "slowmo"
                    win_time = t
                    sound.climax(t)
                    fx.confetti(W)
                    break
        elif phase == "slowmo":
            if t - win_time < 0.8:
                for i in range(sub):
                    S.step(dt / sub * 0.25, t + i * dt / sub)
        fx.update(dt)
        for b in L.blocks:
            b["flash"] = max(0, b["flash"] - dt * 6)
            b["pulse"] = max(0, b["pulse"] - dt * 8)
        for R in S.racers:
            if R.dead <= 0 and phase in ("race", "slowmo"):
                R.trail.append((R.x, R.y))
        # ------------------------------------------------ draw
        canvas.blit(bg, (0, 0))
        sx = sy = 0
        if S.shake > 0.02:  # smooth decaying wobble, not random jitter
            sx = math.sin(t * 52) * 12 * S.shake
            sy = math.cos(t * 41) * 9 * S.shake
        canvas.blit(board, (BX - 20 + sx, BY - 20 + sy))
        _draw_blocks(canvas, L, T, sx, sy)
        for R in S.racers:
            _draw_trail(canvas, R, T, sx, sy)
        for R in sorted(S.racers, key=lambda r: r is S.winner):
            if R.dead > 0:
                continue
            bob = math.sin(t * 6 + R.i) * 4 if phase == "count" else 0
            R.look.draw_body(canvas, R.x + sx, R.y + sy + bob, R.body.angle, R.vx, R.vy, size)
        fx.draw(canvas)
        # title
        _draw_title(canvas, title_lines, t)
        # leaderboard
        order = S.ranking()
        _draw_leader(canvas, order, rank_x, dt)
        if handle:
            V.blit_center(canvas, V.text(handle, 30, (255, 255, 255), (0, 0, 0), 3, "Medium"), W / 2, BY + ROWS * TILE + 150)
        # countdown
        if phase == "count":
            k = min(2, int(t / 0.5))
            local = (t % 0.5) / 0.5
            sc = 1.6 - 0.6 * min(1, local * 3)
            surf = V.text(str(3 - k), int(260 * sc), (255, 255, 255), (15, 15, 25), 14)
            V.blit_center(canvas, surf, W / 2, BY + ROWS * TILE / 2)
        elif phase == "race" and count_in > 0 and t - count_in < 0.45:
            a = (t - count_in) / 0.45
            surf = V.text("GO!", int(240 * (1 + a * 0.3)), (255, 230, 60), (15, 15, 25), 14)
            V.blit_center(canvas, surf, W / 2, BY + ROWS * TILE / 2)
        if win_time is not None:
            _draw_winner(canvas, S.winner, t - win_time, T)
        writer.write(canvas)
        frame += 1
        if frame % 30 == 0:
            print(f"PROGRESS {frame} {int((est + count_in + end_len) * fps)}", flush=True)
        if win_time is not None and t - win_time >= end_len:
            break
        if t > max(t_max * 2.5, est * 1.5 + 15):
            raise RuntimeError("Race ran too long")
    duration = frame * dt
    wav = out_path + ".wav"
    sound.render(duration, wav)
    writer.close(wav)
    import os
    os.remove(wav)
    pygame.quit()
    return {"duration": duration, "winner": S.winner.look.name, "level": lseed}


# ---------------------------------------------------------------- drawing

def _draw_title(canvas, lines, t, y0=120):
    """Big headline. Sleek: condensed display font with a quick punch-in at the start."""
    y = y0
    for line in lines:
        if V.sleek():
            surf = V.text(line, 92, (255, 255, 255), (0, 0, 0), weight="Display")
            if t < 0.3:
                k = 1 + 0.18 * (1 - t / 0.3) ** 2
                surf = pygame.transform.smoothscale(surf, (int(surf.get_width() * k), int(surf.get_height() * k)))
            V.blit_center(canvas, surf, W / 2, y)
            y += 104
        else:
            V.blit_center(canvas, V.text(line, 66, (255, 255, 255), (15, 15, 25), 7), W / 2, y)
            y += 84
    return y


def _wrap(s, width):
    words, lines, cur = s.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width and cur:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return lines[:3]


def _background(T):
    s = pygame.Surface((W, H))
    for y in range(H):
        pygame.draw.line(s, V.mix(T["bg1"], T["bg2"], y / H), (0, y), (W, y))
    # soft diagonal stripes
    over = pygame.Surface((W, H), pygame.SRCALPHA)
    for k in range(-H, W + H, 120):
        pygame.draw.polygon(over, (255, 255, 255, 10), [(k, 0), (k + 60, 0), (k + 60 - H, H), (k - H, H)])
    s.blit(over, (0, 0))
    return s


def _board_layer(L, T):
    pad = 20
    s = pygame.Surface((COLS * TILE + pad * 2, ROWS * TILE + pad * 2), pygame.SRCALPHA)
    # shadow + frame
    pygame.draw.rect(s, (0, 0, 0, 90), pygame.Rect(pad + 6, pad + 12, COLS * TILE, ROWS * TILE), border_radius=18)
    paper = pygame.Rect(pad, pad, COLS * TILE, ROWS * TILE)
    pygame.draw.rect(s, T["paper"], paper, border_radius=14)
    gw = 1 if V.sleek() else 2
    for c in range(COLS + 1):
        pygame.draw.line(s, T["grid"], (pad + c * TILE, pad), (pad + c * TILE, pad + ROWS * TILE), gw)
    for r in range(ROWS + 1):
        pygame.draw.line(s, T["grid"], (pad, pad + r * TILE), (pad + COLS * TILE, pad + r * TILE), gw)
    g = L.grid
    for r in range(ROWS):
        for c in range(COLS):
            x, y = pad + c * TILE, pad + r * TILE
            v = g[r][c]
            if v == WALL:
                rc = pygame.Rect(x, y, TILE, TILE)
                pygame.draw.rect(s, T["wall"], rc)
                if r == 0 or g[r - 1][c] != WALL:
                    pygame.draw.rect(s, T["wall_hi"], pygame.Rect(x, y, TILE, 3 if V.sleek() else 8))
            elif v == SPIKE:
                up = r + 1 < ROWS and g[r + 1][c] == WALL
                base_y, tip_y = (y + TILE, y + 6) if up else (y, y + TILE - 6)
                if V.sleek():
                    for k in range(3):
                        x0 = x + k * TILE / 3
                        pts = [(x0 + 1, base_y), (x0 + TILE / 3 - 1, base_y), (x0 + TILE / 6, tip_y)]
                        pygame.draw.polygon(s, (255, 70, 85), pts)
                    continue
                for k in range(2):
                    x0 = x + k * TILE / 2
                    pts = [(x0 + 1, base_y), (x0 + TILE / 2 - 1, base_y), (x0 + TILE / 4, tip_y)]
                    pygame.draw.polygon(s, (60, 64, 80) if sum(T["paper"]) > 380 else (190, 196, 215), pts)
                    tip = [(x0 + TILE / 4 - 5, tip_y + (10 if up else -10)), (x0 + TILE / 4 + 5, tip_y + (10 if up else -10)), (x0 + TILE / 4, tip_y)]
                    pygame.draw.polygon(s, (235, 60, 70), tip)
            elif v == FINISH:
                fc, fr = L.finish[0]
                cell = TILE // 2
                for i in range(2):
                    for j in range(2):
                        col = (25, 25, 30) if (c * 2 + i + r * 2 + j) % 2 else (250, 250, 250)
                        pygame.draw.rect(s, col, pygame.Rect(x + i * cell, y + j * cell, cell, cell))
    # wall outlines for a crisp cartoon look
    edge = V.darker(T["wall"], 0.45)
    for r in range(ROWS):
        for c in range(COLS):
            if g[r][c] != WALL:
                continue
            x, y = pad + c * TILE, pad + r * TILE
            for dc, dr, a, b in ((0, -1, (x, y), (x + TILE, y)), (0, 1, (x, y + TILE), (x + TILE, y + TILE)),
                                 (-1, 0, (x, y), (x, y + TILE)), (1, 0, (x + TILE, y), (x + TILE, y + TILE))):
                nc, nr = c + dc, r + dr
                if 0 <= nc < COLS and 0 <= nr < ROWS and g[nr][nc] != WALL:
                    pygame.draw.line(s, edge, a, b, 2 if V.sleek() else 4)
    # finish outline
    fx0, fy0 = L.finish[0]
    pygame.draw.rect(s, (20, 20, 25), pygame.Rect(pad + fx0 * TILE, pad + fy0 * TILE, TILE * 2, TILE * 2), 4)
    pygame.draw.rect(s, V.mix(T["paper"], T["wall"], 0.35) if V.sleek() else (40, 44, 60), paper, 3 if V.sleek() else 6, border_radius=14)
    return s


def _draw_blocks(dst, L, T, sx, sy):
    for b in L.blocks:
        if not b["alive"]:
            continue
        rc = b["rect"].move(sx, sy)
        k = 1 + 0.06 * b["pulse"]
        rc = rc.inflate(rc.w * (k - 1), rc.h * (k - 1))
        col = V.mix(T["block"], (255, 255, 255), b["flash"] * 0.7)
        if V.sleek():
            pygame.draw.rect(dst, (0, 0, 0), rc.move(0, 4), border_radius=10)
            pygame.draw.rect(dst, col, rc, border_radius=10)
            pygame.draw.rect(dst, V.darker(col, 0.8), pygame.Rect(rc.x, rc.centery, rc.w, rc.h // 2), border_bottom_left_radius=10, border_bottom_right_radius=10)
            dmg = 1 - b["hp"] / b["max"]
            rr = random.Random(id(b) % 997)
            for i in range(int(dmg * 5)):
                x0 = rc.x + rr.uniform(0.1, 0.9) * rc.w
                y0 = rc.y + rr.uniform(0.1, 0.9) * rc.h
                pygame.draw.line(dst, V.darker(col, 0.55), (x0, y0), (x0 + rr.uniform(-22, 22), y0 + rr.uniform(-16, 16)), 2)
            surf = V.text(str(b["hp"]), int(min(rc.h * 0.8, 70)), T["block_txt"], None)
            V.blit_center(dst, surf, rc.centerx, rc.centery)
            continue
        pygame.draw.rect(dst, V.darker(T["block"], 0.5), rc.move(0, 6), border_radius=12)
        pygame.draw.rect(dst, col, rc, border_radius=12)
        pygame.draw.rect(dst, V.lighter(col, 0.35), pygame.Rect(rc.x + 8, rc.y + 6, rc.w - 16, 10), border_radius=5)
        # crack lines as HP drops
        dmg = 1 - b["hp"] / b["max"]
        rr = random.Random(id(b) % 997)
        for i in range(int(dmg * 6)):
            x0 = rc.x + rr.uniform(0.1, 0.9) * rc.w
            y0 = rc.y + rr.uniform(0.1, 0.9) * rc.h
            pygame.draw.line(dst, V.darker(col, 0.6), (x0, y0), (x0 + rr.uniform(-25, 25), y0 + rr.uniform(-18, 18)), 3)
        pygame.draw.rect(dst, V.darker(T["block"], 0.4), rc, 4, border_radius=12)
        surf = V.text(str(b["hp"]), int(min(rc.h * 0.75, 64)), T["block_txt"], None)
        V.blit_center(dst, surf, rc.centerx, rc.centery + 2)


def _draw_trail(dst, R, T, sx, sy):
    pts = list(R.trail)
    n = len(pts)
    if n < 2:
        return
    base = T["paper"]
    for i in range(1, n):
        k = i / n
        col = V.mix(base, R.look.color, (0.12 + 0.5 * k) if V.sleek() else (0.25 + 0.55 * k))
        w = max(2, int(R.look.size * (0.42 if V.sleek() else 0.55) * k))
        (x0, y0), (x1, y1) = pts[i - 1], pts[i]
        pygame.draw.line(dst, col, (x0 + sx, y0 + sy), (x1 + sx, y1 + sy), w)


def _draw_leader(dst, order, rank_x, dt):
    n = len(order)
    slot = min(120, 900 // n)
    y = BY + ROWS * TILE + 70
    x0 = W / 2 - slot * (n - 1) / 2
    for pos, R in enumerate(order):
        target = x0 + pos * slot
        cur = rank_x.get(R.i) or target
        cur += (target - cur) * min(1, dt * 10)
        rank_x[R.i] = cur
        badge = R.look.badge(int(slot * 0.62))
        V.blit_center(dst, badge, cur, y)
        V.blit_center(dst, V.text(str(pos + 1), 30, (255, 255, 255), (0, 0, 0), 3), cur + slot * 0.32, y - slot * 0.3)


_glow_cache = {}


def _glow(color, r):
    key = (color, r)
    if key not in _glow_cache:
        g = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        for i in range(24):
            f = i / 24
            pygame.draw.circle(g, (*color, int(10 + 40 * f)), (r, r), int(r * (1 - f * 0.85)))
        _glow_cache[key] = g
    return _glow_cache[key]


def _spaced(s):
    return " ".join(s)


def _draw_winner_sleek(dst, R, t, line1, line2, line3):
    a = min(1, (t - 0.8) / 0.35)
    dim = pygame.Surface((W, H), pygame.SRCALPHA)
    dim.fill((4, 5, 9, int(205 * a)))
    dst.blit(dim, (0, 0))
    u = min(1, (t - 0.8) / 0.5)
    ease = 1 - (1 - u) ** 3
    cx, cy = W / 2, H * 0.42
    g = _glow(tuple(R.look.color), 300)
    g2 = g.copy()
    g2.set_alpha(int(255 * a))
    V.blit_center(dst, g2, cx, cy)
    V.blit_center(dst, R.look.hero((0.75 + 0.55 * ease)), cx, cy + (1 - ease) * 60)
    label = {"WINS!": "WINNER", "CHAMPION!": "CHAMPION", "ESCAPED!": "ESCAPED"}.get(line2, line2.strip("!"))
    lab = V.text(_spaced(label), 40, (200, 205, 220), None, weight="ExtraBold")
    lab.set_alpha(int(255 * a))
    V.blit_center(dst, lab, W / 2, H * 0.61)
    name = (line1 if line1 is not None else R.look.name).upper()
    if name:
        V.blit_center(dst, V.text(name, 170 if len(name) < 9 else 120, (255, 255, 255), (0, 0, 0), weight="Display"), W / 2, H * 0.68)
    if t > 1.9 and line3:
        b = min(1, (t - 1.9) / 0.35)
        s3 = V.text(line3, 46, (255, 210, 120), None, weight="Medium")
        s3.set_alpha(int(255 * b))
        V.blit_center(dst, s3, W / 2, H * 0.77)


def _draw_winner(dst, R, t, T, line1=None, line2="WINS!", line3="Did you guess right?"):
    if t < 0.8:
        return
    if V.sleek():
        return _draw_winner_sleek(dst, R, t, line1, line2, line3)
    a = min(1, (t - 0.8) / 0.3)
    dim = pygame.Surface((W, H), pygame.SRCALPHA)
    dim.fill((0, 0, 0, int(170 * a)))
    dst.blit(dim, (0, 0))
    # pop-in with overshoot
    u = min(1, (t - 0.8) / 0.45)
    sc = 1 + 0.25 * math.sin(u * math.pi) if u < 1 else 1 + 0.03 * math.sin((t - 1.25) * 5)
    hero = R.look.hero(sc * 1.4)
    # rays
    rays = pygame.Surface((W, H), pygame.SRCALPHA)
    cx, cy = W / 2, H * 0.43
    for k in range(12):
        ang = t * 0.6 + k * math.pi / 6
        p = [(cx, cy), (cx + math.cos(ang - 0.12) * 1400, cy + math.sin(ang - 0.12) * 1400),
             (cx + math.cos(ang + 0.12) * 1400, cy + math.sin(ang + 0.12) * 1400)]
        pygame.draw.polygon(rays, (*R.look.color, int(45 * a)), p)
    dst.blit(rays, (0, 0))
    V.blit_center(dst, hero, cx, cy)
    name = (line1 if line1 is not None else R.look.name).upper()
    if name:
        V.blit_center(dst, V.text(name, 120 if len(name) < 9 else 90, R.look.color, (255, 255, 255), 10), W / 2, H * 0.62)
    V.blit_center(dst, V.text(line2, 150 if len(line2) < 8 else 110, (255, 255, 255), (15, 15, 25), 12), W / 2, H * 0.71)
    if t > 2.4 and line3:
        b = min(1, (t - 2.4) / 0.3)
        V.blit_center(dst, V.text(line3, int(64 * b) or 1, (255, 230, 60), (15, 15, 25), 6), W / 2, H * 0.8)
